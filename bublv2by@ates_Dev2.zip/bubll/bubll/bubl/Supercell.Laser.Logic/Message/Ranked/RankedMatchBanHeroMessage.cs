using System.IO;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using Supercell.Laser.Logic.Avatar.Structures;
using Supercell.Laser.Logic.Helper;
using Supercell.Laser.Logic.Message.Club;

namespace Supercell.Laser.Logic.Message.Ranked
{
    public class RankedMatchBanHeroMessage : GameMessage
    {
        public int BrawlerId;
        public int PickType;
        public override void Decode()
        {
            Stream.ReadVInt();
            BrawlerId = Stream.ReadVInt();
            PickType = Stream.ReadVInt();
        }

        public override int GetMessageType()
        {
            return 12152;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
