using System.IO;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using Supercell.Laser.Logic.Avatar.Structures;
using Supercell.Laser.Logic.Helper;
using Supercell.Laser.Logic.Ranked;

namespace Supercell.Laser.Logic.Message.Ranked
{
    public class RankedMatchHeroPickedMessage : GameMessage
    {
        public AtesDev2RankedMatchPlayer Player;
        public override void Encode()
        {
            Stream.WriteBoolean(true);
            Player.Encode(Stream);
        }

        public override int GetMessageType()
        {
            return 22156;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
