﻿namespace Supercell.Laser.Logic.Message.Friends
{
    using System.Linq;
    using Supercell.Laser.Logic.Club;
    using Newtonsoft.Json;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Logic.Message.Club;
    using Supercell.Laser.Logic.Stream;
    using Supercell.Laser.Logic.Stream.Entry;
    using Supercell.Laser.Titan.DataStream;

    public class AllianceOnlineStatusUpdatedMessage : GameMessage
    {
        public long AvatarId { get; set; }
        public int PlayerStatus { get; set; }
        public int Members;

        public override void Encode()
        {
            Stream.WriteVInt(Members); // Общее количество игроков в клане
            Stream.WriteVInt(1);
            Stream.WriteLong(AvatarId);
            Stream.WriteVInt(PlayerStatus);
        }

        public override int GetMessageType()
        {
            return 20207;
        }

        public override int GetServiceNodeType()
        {
            return 3;
        }
    }
}