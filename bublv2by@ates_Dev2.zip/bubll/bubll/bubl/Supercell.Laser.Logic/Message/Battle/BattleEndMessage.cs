﻿// Supercell.Laser.Logic.Message.Battle.BattleEndMessage.cs
namespace Supercell.Laser.Logic.Message.Battle
{
    using System;
    using System.Collections.Generic;
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home.Quest;
    using Supercell.Laser.Logic.Home.Structures;

    public class BattleEndMessage : GameMessage
    {
        public BattleEndMessage() : base()
        {
            ProgressiveQuests = new List<Quest>();
            // Инициализируем Players по умолчанию, чтобы избежать NullReferenceException
            Players = new List<BattlePlayer>();
        }

        public int Result;
        public int TokensReward;
        public int TokensDoublersReward;
        public int TokensRemainingReward;
        public int TrophiesReward;
        // Убедимся, что поле инициализировано
        public List<BattlePlayer> Players { get; set; }
        public long StarPlayerAccountId { get; set; }
public int CoinsGained { get; set; }
        public List<Quest> ProgressiveQuests;
        public BattlePlayer OwnPlayer;
        public bool StarToken;

        public int GameMode;

        public bool BattleWithoutTrophies;
        public bool IsPvP;

        public int Winstreak;
        public int WinstreakTrophies;
        public int MasteryGained;
        public int MasteryPoints;
                public bool RankedMatch;
        public int MatchType;
        public int Rank;
        public int UpRank;
        public int ELO;
        public int TrueBlueTeamWins;
        public int TrueRedTeamWins;
        public int Round;
        public bool Solo;
        public int Add;

        public override void Encode()
        {
            // --- КРИТИЧЕСКИ ВАЖНО: Создаем копию списка Players для безопасного перебора ---
            // Это предотвращает ошибку "Collection was modified; enumeration operation may not execute."
            // если оригинальный список Players (который может быть m_players из BattleMode)
            // изменяется во время кодирования, например, в другом потоке или при вызове методов внутри Encode.
            List<BattlePlayer> playersSnapshot;
            if (this.Players != null)
            {
                playersSnapshot = new List<BattlePlayer>(this.Players);
            }
            else
            {
                playersSnapshot = new List<BattlePlayer>();
            }
            // --- Конец создания копии ---

            Stream.WriteLong(OwnPlayer?.AccountId ?? 0);
            Stream.WriteLong(OwnPlayer?.AccountId ?? 0);

            Stream.WriteVInt(GameMode); // game mode
            Stream.WriteVInt(Result);
            Stream.WriteVInt(TokensReward); // tokens reward
            Stream.WriteVInt(TrophiesReward); // trophies reward
            Stream.WriteVInt(0);//Power Play Points Gained (Pro League Points)
            Stream.WriteVInt(TokensDoublersReward);//Doubled Tokens (Double Keys)
            Stream.WriteVInt(0);//Double Token Event (Double Event Keys)
            Stream.WriteVInt(TokensRemainingReward);//Token Doubler Remaining (Double Keys Remaining)
            Stream.WriteVInt(0);//game Lenght In Seconds
            Stream.WriteVInt(0);//Epic Win Power Play Points Gained (op Win Points)
            Stream.WriteVInt(0);//Championship Level Reached (CC Wins)

            Stream.WriteBoolean(false);//gen offer

            Stream.WriteVInt(0);
            Stream.WriteVInt(0);

            Stream.WriteBoolean(false);//164
            Stream.WriteBoolean(false);//165

            Stream.WriteVInt(0); // lavina manetok
            Stream.WriteVInt(0); // chromalavina
            Stream.WriteVInt(0); // underdog
            Stream.WriteVInt(WinstreakTrophies); // WINSTREAK ++ (ФЕЙК)
            Stream.WriteVInt(Winstreak); // WINSTREAK (ФЕЙК)
            Stream.WriteVInt(0);// trophies + (КРАШ)
            Stream.WriteVInt(0);// trophies +
            Stream.WriteVInt(0);//v53

            Stream.WriteBoolean(false);
            Stream.WriteBoolean(false); // no experience
            Stream.WriteBoolean(false); // no tokens left
            Stream.WriteBoolean(BattleWithoutTrophies); // Result type
            Stream.WriteBoolean(IsPvP); // isPvp
            Stream.WriteBoolean(false);
            Stream.WriteBoolean(false); // powerplay
            Stream.WriteBoolean(false);

            Stream.WriteVInt(-1);//ChallengeType, 0 - champochimp, -1 - normal
            Stream.WriteBoolean(false);

            // --- Используем копию списка для записи количества и перебора ---
            Stream.WriteVInt(playersSnapshot.Count);
            foreach (BattlePlayer player in playersSnapshot)
            {
                // --- Проверки на null для безопасности ---
                if (player == null) continue;

                bool isOwnPlayer = (OwnPlayer != null) && (player.AccountId == OwnPlayer.AccountId);
                bool isEnemy = (OwnPlayer != null) && (player.TeamIndex != OwnPlayer.TeamIndex);

                Stream.WriteBoolean(isOwnPlayer); // is own player
                Stream.WriteBoolean(isEnemy); // is enemy
                Stream.WriteBoolean(false); // Star player
                Stream.WriteVInt(1);
                {
                    ByteStreamHelper.WriteDataReference(Stream, player.CharacterId);
                }
                Stream.WriteVInt(1);
                {
                    ByteStreamHelper.WriteDataReference(Stream, player.SkinId);//skin
                }
                Stream.WriteVInt(1);
                {
                    Stream.WriteVInt(player.Trophies);
                }
                Stream.WriteVInt(1);
                {
                    Stream.WriteVInt(player.HeroPowerLevel);
                }
                Stream.WriteVInt(1);
                {
                    Stream.WriteVInt(0);
                }

                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                if (Stream.WriteBoolean(player.IsBot() == 0))
                {
                    Stream.WriteLong(player.AccountId);
                }

                // --- Безопасная обработка DisplayData ---
                // Мы используем try-catch для максимальной устойчивости.
                try
                {
                    if (player.DisplayData != null)
                    {
                        player.DisplayData.Encode(Stream);
                    }
                    else
                    {
                        // Если DisplayData null, записываем минимальную структуру.
                        // Часто это длина данных = 0.
                        Stream.WriteVInt(0);
                    }
                }
                catch (Exception ex)
                {
                    // Логируем предупреждение и записываем заглушку, чтобы не сломать весь Encode.
                    Console.WriteLine($"Warning: Exception in player.DisplayData.Encode for player {player.AccountId}: {ex.Message}");
                    Stream.WriteVInt(0); // Заглушка
                }
                Stream.WriteBoolean(false);

                Hero hero = null;
                if (player != null && player.IsBot() < 1 && player.Avatar != null)
                {
                    hero = player.Avatar.GetHero(player.CharacterId);
                }

                if (hero != null)
                {
                    Stream.WriteVInt(1);
                    Stream.WriteVInt(MasteryPoints); // mastery points
                    Stream.WriteVInt(1);
                    Stream.WriteVInt(MasteryGained); // mastery points gained
                }
                else
                {
                    Stream.WriteVInt(0);
                    Stream.WriteVInt(0);
                }

                Stream.WriteInt16((short)(player.Kills)); // kills
                Stream.WriteInt16((short)(player.Deaths)); // deaths
                Stream.WriteInt(player.Damage); // uron
                Stream.WriteInt(player.Heals); // heal
                // Console.WriteLine(player.Heals); // Убрано для безопасности
                
                // --- Получаем ID титула из DefaultBattleCard игрока (из Home) ---
                int titleId = 0;

                // Проверяем, что это наш игрок (OwnPlayer), так как титул берется из его профиля.
                if (player == OwnPlayer && player.Home != null)
                {
                    // Используем DefaultBattleCard из ClientHome
                    var defaultBattleCard = player.Home.DefaultBattleCard;
                    if (defaultBattleCard != null)
                    {
                        titleId = defaultBattleCard.Title;
                    }
                }
                // Для других игроков (не OwnPlayer) можно оставить 0 или попробовать использовать другой источник,
                // если он доступен. В данном случае, по логике игры, титул показывается только для владельца аккаунта.
                ByteStreamHelper.WriteDataReference(Stream, titleId);
            }

            Stream.WriteVInt(0);//xp
            Stream.WriteVInt(0);//dataref

            Stream.WriteVInt(2);
            {
                Stream.WriteVInt(1);
                Stream.WriteVInt(OwnPlayer?.Trophies ?? 0); // Trophies
                Stream.WriteVInt(OwnPlayer?.HighestTrophies ?? 0); // Highest Trophies

                Stream.WriteVInt(5);
                Stream.WriteVInt(100);
                Stream.WriteVInt(100);
            }

            // --- Исправленная обработка Thumbnail ---
            // Используем явную проверку и GetGlobalId(), как в найденном файле ClientHome.cs.
            int thumbnailId = 0;
            var thumbnail = OwnPlayer?.Home?.Thumbnail;
            if (thumbnail != null)
            {
                // PlayerThumbnailData наследуется от Data и имеет метод GetGlobalId()
                thumbnailId = thumbnail.GetGlobalId();
            }
            ByteStreamHelper.WriteDataReference(Stream, thumbnailId);
            // --- Конец исправленной обработки Thumbnail ---

            if (Stream.WriteBoolean(false)) // play again
            {
                Stream.WriteInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteInt(0);
                Stream.WriteInt(0);
            }

            if (Stream.WriteBoolean(false)) // quests
            {
                Stream.WriteVInt(-1);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
            }

            Stream.WriteBoolean(false);
            Stream.WriteBoolean(false);//v53
            Stream.WriteVInt(0);
            Stream.WriteVInt(0);
            Stream.WriteVInt(0);//v53
if (Stream.WriteBoolean(RankedMatch))
            {
                Stream.WriteVInt(6);
                Stream.WriteVInt(Solo ? 0 : 1); 
                Stream.WriteVInt(ELO);
                Stream.WriteVInt(Rank); 
                Stream.WriteVInt(ELO);
                Stream.WriteVInt(UpRank);
                Stream.WriteVInt(ELO); 
                Stream.WriteVInt(TrueBlueTeamWins); 
                Stream.WriteVInt(TrueRedTeamWins); 
                Stream.WriteVInt(Round); 
                Stream.WriteVInt(10); 
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(4);
                Stream.WriteVInt(0);

            }
            Stream.WriteVInt(-1);
            Stream.WriteBoolean(false);//chronosTextEntry
            Stream.WriteVInt(0);

            Stream.WriteBoolean(false);
            Stream.WriteBoolean(false);
            Stream.WriteVInt(0);
            Stream.WriteVInt(0);//v53
            Stream.WriteBoolean(false);
            Stream.WriteBoolean(false);//v53
            Stream.WriteBoolean(false);//v53
        }

        public override int GetMessageType()
        {
            return 23456;
        }

        public override int GetServiceNodeType()
        {
            return 27;
        }
    }
}