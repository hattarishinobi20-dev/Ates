﻿using Supercell.Laser.Logic.Home.Items;
using Supercell.Laser.Logic.Ranked;

namespace Supercell.Laser.Logic.Listener
{
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Home;

    public interface LogicServerListener
    {
        public static LogicServerListener Instance;

        ClientAvatar GetAvatar(long id);
        LogicGameListener GetGameListener(long id);
        HomeMode GetHomeMode(long id);
        bool IsPlayerOnline(long id);
        void StartMatchBattle(List<AtesDev2RankedMatchPlayer> entries, EventData edata, int Location = -1, int id = 0, int round = 0);
        AtesDev2RankedMatch GetRankedMatch(long id);
    }
}
