using System.Threading.Tasks;
using Supercell.Laser.Logic.Ranked;
namespace Supercell.Laser.Logic.Battle
{
    using BattleLogEntry;
    using Masuda.Net.HelpMessage;
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Battle.Component;
    using Supercell.Laser.Logic.Battle.Input;
    using Supercell.Laser.Logic.Battle.Level;
    using Supercell.Laser.Logic.Battle.Level.Factory;
    using Supercell.Laser.Logic.Battle.Objects;
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Command.Home;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Math;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Logic.Message.Account;
    using Supercell.Laser.Logic.Message.Battle;
    using Supercell.Laser.Logic.Message.Club;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Logic.Notification;
    using Supercell.Laser.Logic.Time;
    using Supercell.Laser.Logic.Util;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Debug;
    using Supercell.Laser.Titan.Json;
    using Supercell.Laser.Titan.Math;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Numerics;
    using System.Security.Cryptography;
    using System.Security.Cryptography.X509Certificates;
    using System.Security.Principal;
    using System.Threading;

    public struct DiedEntry
    {
        public int DeathTick;
        public BattlePlayer Player;
    }

    public enum MarkerState
    {
        Neutral = 0,
        Team0 = 1,
        Team1 = 2,
        Crossed = 3
    }

    public class KnockoutMarker
    {
        public int X { get; set; }
        public int Y { get; set; }
        public MarkerState State { get; set; }
        public Character VisualObject { get; set; }

        public KnockoutMarker(int x, int y)
        {
            X = x;
            Y = y;
            State = MarkerState.Neutral;
        }
    }
    
    public class KingOfHillState
    {
        public int ZoneIndex;
        public int ZonePercentage; 
        public int ZonePercentageTeam0 { get; set; } = 0;
        public int ZonePercentageTeam1 { get; set; } = 0;
        public bool CaptureEffectActiveTeam0 { get; set; }
        public bool CaptureEffectActiveTeam1 { get; set; }
        public AreaEffect CurrentCaptureEffectTeam0 { get; set; }
        public AreaEffect CurrentCaptureEffectTeam1 { get; set; }

        public bool GaugeTeam0 { get; set; }
        public bool GaugeTeam1 { get; set; }
        public AreaEffect GaugeTeam0Effect { get; set; }
        public AreaEffect GaugeTeam1Effect { get; set; }

        public int LastUpTickTeam0 { get; set; }
        public int LastUpTickTeam1 { get; set; }
        public bool HillCompleteEffectSpawnedTeam0 { get; set; }
        public bool CanContinueUpTeam0 = true;

        public bool HillCompleteEffectSpawnedTeam1 { get; set; }
        public bool CanContinueUpTeam1 = true;

        public KingOfHillState(int zoneIndex)
        {
            this.ZoneIndex = zoneIndex;
        }
    }
    
    public class BattleMode
    {
        public const int ORBS_TO_COLLECT_NORMAL = 0xA;
        public const int INTRO_TICKS = 180;
        public const int NO_TIME_TICKS = 16000;
        public const int NORMAL_TICKS = 3180;
        
        // Константы для режимов
        public const int GAME_MODE_VARIATION_KNOCKOUT = 20; // ID 20 - чистый нокаут (БЕЗ МЯЧА!)
        public const int GAME_MODE_VARIATION_BRAWL_BALL = 5; // ID 5 - Brawl Ball
        public const int GAME_MODE_VARIATION_HOT_ZONE = 17; // ID 17 - Горячая зона
        public const int GAME_MODE_VARIATION_BOUNTY = 3; // ID 3 - Охота
        public const int GAME_MODE_VARIATION_GEM_GRAB = 0; // ID 0 - Столкновение
        public const int GAME_MODE_VARIATION_SHOWDOWN = 6; // ID 6 - Одиночное столкновение
        public const int GAME_MODE_VARIATION_DUO_SHOWDOWN = 7; // ID 7 - Парное столкновение
        public const int GAME_MODE_VARIATION_HEIST = 2; // ID 2 - Ограбление
        public const int GAME_MODE_VARIATION_SIEGE = 27; // ID 27 - Осада
        public const int GAME_MODE_VARIATION_PAYLOAD = 33; // ID 33 - Доставка
        public const int GAME_MODE_VARIATION_BOSS_FIGHT = 8; // ID 8 - Битва с боссом
        public const int GAME_MODE_VARIATION_TRAINING = 13; // ID 13 - Тренировка
        public const int GAME_MODE_VARIATION_STORY = 30; // ID 30 - Сюжетный режим
        public const int GAME_MODE_VARIATION_VOLLEYBRAWL = 25; // ID 25 - Волейбол
        public const int GAME_MODE_VARIATION_LAST_STAND = 19; // ID 19 - Последний рубеж
        
        public StartLoadingMessage Dummy;
        private bool m_hasSentEndMessages = false;

        public Timer m_updateTimer;

        public int m_locationId;
        public int m_gameModeVariation;
        private int m_playersCountWithGameModeVariation;

        public bool BattleWithTrophies;

        private Queue<ClientInput> m_inputQueue;

        List<GameObject> printobjects = new List<GameObject>();

        public List<BattlePlayer> m_players;
        private Dictionary<long, BattlePlayer> m_playersBySessionId;
        private Dictionary<long, LogicGameListener> m_spectators;
        private GameObjectManager m_gameObjectManager;
        private Dictionary<long, BattlePlayer> m_playersByAccountId;

        private Rect m_playArea;
        private TileMap m_tileMap;
        public GameTime m_time;
        private LogicRandom m_random;
        private int m_randomSeed;
        public List<GameObject> StoryModeStuffs;
        public int m_winnerTeam;
        private List<KingOfHillState> _koHStates = new List<KingOfHillState>();
        public BattlePlayerMap BattlePlayerMap;
        private int m_playersAlive;

        private int m_gemGrabCountdown;
        public bool IsStoryMode;
        public bool IsGameOver { get; set; }

        public List<int> EventModifiers;

        // Knockout mode variables
        public List<KnockoutMarker> m_knockoutMarkers;
        private int m_team0AliveCount;
        private int m_team1AliveCount;
        
        // Переменные для нокаута (раунды)
        public int m_knockoutRound = 1;
        public int[] m_knockoutRoundWins = new int[2] { 0, 0 };
        public int RoundTicks;
        public int RoundResetTicks;
        public List<int> TScore = new List<int> { 0, 0 };
        public int RoundCount;
        public int[] RoundWins = { 0, 0, 0 };
        public bool nokbool;
        public int KnockoutTicks;

        public StoryMode StoryMode;
        private int Team1King;
        private int Team2King;
        List<int> PlayerIndexesForTeam1 = new List<int> { 0, 1, 2 };
        List<int> PlayerIndexesForTeam2 = new List<int> { 3, 4, 5 };
        
        // Для Brawl Ball
        public Character Carryable;
        public int ToGoalTeam = -1;
        public int GoalTicks;
        public bool CanReset = true;
        
        private int _reconnectTimeoutTicks = 600;
        private Dictionary<long, int> _disconnectedTicks = new Dictionary<long, int>();
        
        private int _lastSpectatorUpdateTick = 0;
        private const int SPECTATOR_UPDATE_INTERVAL_TICKS = 4;
        
        private int Zone1Score;
        private int Zone2Score;
                public bool IsRanked;
        public int RankedId;
        public int Round;

        public BattleMode(int locationId)
        {
            m_winnerTeam = -1;
            m_locationId = locationId;
            m_gameModeVariation = GameModeUtil.GetGameModeVariation(Location.GameModeVariation);
            m_playersCountWithGameModeVariation = GamePlayUtil.GetPlayerCountWithGameModeVariation(m_gameModeVariation);

            m_inputQueue = new Queue<ClientInput>();

            m_randomSeed = 0;
            m_random = new LogicRandom(m_randomSeed);

            m_players = new List<BattlePlayer>();
            m_playersBySessionId = new Dictionary<long, BattlePlayer>();
            m_playersByAccountId = new Dictionary<long, BattlePlayer>();

            m_time = new GameTime();
            m_tileMap = TileMapFactory.CreateTileMap(Location.Map);
            m_playArea = new Rect(0, 0, m_tileMap.LogicWidth, m_tileMap.LogicHeight);
            m_gameObjectManager = new GameObjectManager(this);

            m_spectators = new Dictionary<long, LogicGameListener>();

            // Инициализируем нокаут переменные
            if (m_gameModeVariation == GAME_MODE_VARIATION_KNOCKOUT)
            {
                m_knockoutMarkers = new List<KnockoutMarker>();
                m_team0AliveCount = 0;
                m_team1AliveCount = 0;
                m_knockoutRound = 1;
                m_knockoutRoundWins = new int[2] { 0, 0 };
                
                // НОКАУТ: НИКАКОГО МЯЧА!
                Carryable = null;
                
                // Сбрасываем счет раундов
                TScore = new List<int> { 0, 0 };
                RoundCount = 0;
                RoundWins = new int[] { 0, 0, 0 };
                nokbool = false;
                KnockoutTicks = 0;
                
                Console.WriteLine("[Knockout] Чистый нокаут режим инициализирован (ID 20)!");
            }

            // Инициализируем Dummy для наблюдателей
            Dummy = new StartLoadingMessage();
            Dummy.LocationId = m_locationId;
            Dummy.GameMode = m_gameModeVariation;
            Dummy.GameType = 0;
            
            Dummy.map = BattlePlayerMap;
            Dummy.MapMode = 1;
            Dummy.Modifiers = EventModifiers ?? new List<int>();
            Dummy.LeaveButton = true;

            Console.WriteLine($"[BattleMode] Dummy инициализирован для наблюдения: LocationId={m_locationId}, GameMode={m_gameModeVariation}");

            EventModifiers = new List<int>();
            PlayerIndexesForTeam1.Clear();
            PlayerIndexesForTeam2.Clear();
            if (m_gameModeVariation == 30) StoryMode = new(this);
        }
        
        public int GetKOHZoneCount() => _koHStates.Count;
        public KingOfHillState GetZoneByUID(int a1) => _koHStates[a1] != null ? _koHStates[a1] : null;
        public int GetTeam1King() => Team1King;
        public int GetTeam2King() => Team2King;
        
        public List<BattlePlayer> GetPlayersByTeam(int team)
        {
            List<BattlePlayer> teamCharacters = new List<BattlePlayer>();

            foreach (BattlePlayer bplr in m_players)
            {
                if (bplr.TeamIndex == team)
                {
                    teamCharacters.Add(bplr);
                }
            }
            return teamCharacters;
        }
        
        public void SetPlayerMap(BattlePlayerMap map)
        {
            BattlePlayerMap = map;
            m_tileMap = TileMapFactory.CreatePlayerMap(map.MapData);
            m_gameModeVariation = map.GMV;
            m_playersCountWithGameModeVariation = GamePlayUtil.GetPlayerCountWithGameModeVariation(map.GMV);

            if (Dummy != null)
            {
                Dummy.map = map;
                Dummy.GameMode = map.GMV;
                Dummy.LocationId = 0;
                Console.WriteLine($"[BattleMode] Dummy обновлен для пользовательской карты: GameMode={map.GMV}");
            }
        }
        
        public int GetGoalTeam() => ToGoalTeam;
        
        private BattlePlayerMap CreateSimpleMap()
        {
            Console.WriteLine($"[BattleMode] Создание простого PlayerMap...");
            
            try
            {
                PlayerMap playerMap = new PlayerMap();
                BattlePlayerMap battleMap = new BattlePlayerMap(playerMap);
                Console.WriteLine($"[BattleMode] Простой map создан");
                return battleMap;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[BattleMode ERROR] CreateSimpleMap failed: {ex.Message}");
                return new BattlePlayerMap(null);
            }
        }

        public void AddWinInLaserBall(int teamIndex)
        {
            BattlePlayer plr = m_players.Find(p => p.PlayerIndex == teamIndex);
            if (plr != null)
            {
                plr.AddScore(1);
            }
        }
        
        public void SetGoalLaserBall(int team)
        {
            ToGoalTeam = team;
            GoalTicks = 3 * 20;
        }
        
        public int GetZone2Score() => Zone2Score;
        public int GetZone1Score() => Zone1Score;
        public void AddScoreTo1Zone() { Zone1Score++; }
        public void AddScoreTo2Zone() { Zone2Score++; }
        
        public void ResetRoundLaserBall(bool ballr)
        {
            if (!CanReset && ballr) return;
            
            foreach (Character character in m_gameObjectManager.GetCharacters())
            {
                if (character.GetPlayer() != null && character.CharacterData.IsHero())
                {
                    m_gameObjectManager.RemoveGameObject(character);
                }
                else character.CauseDamage(null, 99999, 99999, false, null, false);
            }
            
            foreach (BattlePlayer playerrrr in m_players)
            {
                InstantRespawn(playerrrr);
            }
            
            foreach (Item item in m_gameObjectManager.GetItems())
            {
                m_gameObjectManager.RemoveGameObject(item);
            }
            
            foreach (AreaEffect area in m_gameObjectManager.GetAreaEffects())
            {
                m_gameObjectManager.RemoveGameObject(area);
            }
            
            foreach (Projectile proj in m_gameObjectManager.GetProjectiles())
            {
                m_gameObjectManager.RemoveGameObject(proj);
            }
            
            m_gameObjectManager.Petrols.Clear();
            
            if (!ballr)
            {
                nokbool = !nokbool;
                RoundTicks = 0;
                return;
            }
            
            Character ball = new(DataTables.Get(16).GetData<CharacterData>("LaserBall"));
            ball.SetPosition(3150, 4950, 0);
            ball.SetIndex(0);
            m_gameObjectManager.AddGameObject(ball);
            Carryable = ball;
        }
        
        public void InstantRespawn(BattlePlayer player)
        {
            foreach (Character TG_THESTEALDEV in m_gameObjectManager.GetCharacters())
            {
                if (TG_THESTEALDEV.GetPlayer() != null && TG_THESTEALDEV.GetPlayer().PlayerIndex == player.PlayerIndex) 
                    m_gameObjectManager.RemoveGameObject(TG_THESTEALDEV);
            }
            
            Character character = SpawnHero(player.CharacterData, player.HeroPowerLevel, player.TeamIndex * 16 + player.PlayerIndex, 0, false);
            LogicVector2 spawnPoint = player.GetSpawnPoint();
            character.TriggerBlink(spawnPoint.X, spawnPoint.Y, null, null, 0, 0);
            character.SetBot(player.IsBot());
            character.SpawnTick = GetTicksGone();
            
            player.OwnObjectId = character.GetGlobalID();
            player.IsAlive = true;
        }
        
        public bool ResetCarryableState;
        
        public void ResetCarryable()
        {
            if (Carryable == null) return;
            
            Carryable.CARRi_CODEBYSTEAL_atesDev2 = null;
            Carryable.CARRYABLETICK_CODEBYSTEAL_atesDev2 = 0;
            Carryable.StopKicking();
            Carryable.CauseDamage(null, 99999, 99999, false, null, false, false, -1, -1, false, true);
            Carryable = null;
            
            foreach (Character cha in m_gameObjectManager.GetCharacters())
            {
                cha.CarryablePersonImunTicks = 0;
            }
        }
        
        public bool HasEventModifier(int m) => EventModifiers.Contains(m);
        
        public void SetEventModifiers(List<int> ms)
        {
            EventModifiers = ms.ToList();
        }
        
        public int GetGemGrabCountdown()
        {
            return m_gemGrabCountdown;
        }
        
        public LogicRandom GetLogicRandom()
        {
            return m_random;
        }
        
        public GameObjectManager GetGameObjectManager()
        {
            return m_gameObjectManager;
        }
        
        public int GetPlayersAliveCountForBattleRoyale()
        {
            return m_playersAlive;
        }
        
        public Petrol AddPetrol(int a2, int a3, int a4, int a5, int a6, int a7)
        {
            Petrol v32 = new Petrol(a2, a3, a4, a5, a6, a7);
            m_gameObjectManager.Petrols.Add(v32);
            return v32;
        }
        
         private void TickSpawnHeroes()
        {
            foreach (BattlePlayer player in m_players)
            {
                if (player.IsAlive) continue;
                if (m_gameModeVariation is 6 or 20) return;
                
                LogicVector2 spawnPoint = player.GetSpawnPoint();
                Random random = new Random();
                int randomindex = random.Next(0, 3);
                
                if (GetTicksGone() == player.DeathTick + 20 * GameModeUtil.GetRespawnSeconds(m_gameModeVariation))
                {
                    if (player.DeathTick != 1)
                    {
                        AreaEffect v90 = GameObjectFactory.CreateGameObjectByData(DataTables.GetAreaEffectByName("HeroSpawn"));
                        v90.SetPosition(spawnPoint.X, spawnPoint.Y, 0);
                        
                        if (m_gameModeVariation == 5)
                        {
                            if (player.TeamIndex == 0)
                            {
                                var respawnTiles = GetTileMap().LaserBallInstantRespawnTileTeam1;
                                if (respawnTiles != null && respawnTiles.Count > 0)
                                {
                                    randomindex = randomindex % respawnTiles.Count;
                                    v90.SetPosition(
                                        respawnTiles[randomindex].X + 150,
                                        respawnTiles[randomindex].Y + 150,
                                        0);
                                }
                            }
                            else if (player.TeamIndex == 1)
                            {
                                var respawnTiles = GetTileMap().LaserBallInstantRespawnTileTeam2;
                                if (respawnTiles != null && respawnTiles.Count > 0)
                                {
                                    randomindex = randomindex % respawnTiles.Count;
                                    v90.SetPosition(
                                        respawnTiles[randomindex].X + 150,
                                        respawnTiles[randomindex].Y + 150,
                                        0);
                                }
                            }
                        }
///// до сюда
                        

                        v90.SetIndex(player.TeamIndex * 16 + player.PlayerIndex);
                        m_gameObjectManager.AddGameObject(v90);
                        v90.Trigger();
                    }
                }
                
                if (GetTicksGone() == player.DeathTick + 20 * GameModeUtil.GetRespawnSeconds(m_gameModeVariation) + 40)
                {
                    Character character = SpawnHero(player.CharacterData, player.HeroPowerLevel, player.TeamIndex * 16 + player.PlayerIndex, 0, false);
                    character.SetPosition(spawnPoint.X, spawnPoint.Y, 0);
                    
                    if (m_gameModeVariation == 5)
                    {
                        if (player.TeamIndex == 0)
                        {
                            var respawnTiles = GetTileMap().LaserBallInstantRespawnTileTeam1;
                            if (respawnTiles != null && respawnTiles.Count > 0)
                            {
                                randomindex = randomindex % respawnTiles.Count;
                                character.SetPosition(
                                    respawnTiles[randomindex].X + 150,
                                    respawnTiles[randomindex].Y + 150,
                                    0);
                            }
                        }
                        else if (player.TeamIndex == 1)
                        {
                            var respawnTiles = GetTileMap().LaserBallInstantRespawnTileTeam2;
                            if (respawnTiles != null && respawnTiles.Count > 0)
                            {
                                randomindex = randomindex % respawnTiles.Count;
                                character.SetPosition(
                                    respawnTiles[randomindex].X + 150,
                                    respawnTiles[randomindex].Y + 150,
                                    0);
                            }
                        }
                    }
                    
                    character.SetBot(player.IsBot());
                    
                    if (player.Gear1 != null) character.Gear1 = new Gear("ConsumableShield");
                    if (player.Gear2 != null) character.Gear2 = null;
                    character.SpawnTick = GetTicksGone();
                    character.IsInvincible = true;
                    player.OwnObjectId = character.GetGlobalID();
                    player.IsAlive = true;
                }
            }
        }
        
        public Character SpawnHero(CharacterData a2, int a3, int a4, int a5, bool a6)
        {
            if (a2 == null)
            {
                Console.WriteLine("[BattleMode] SpawnHero: CharacterData is null");
                return null;
            }

            if (m_gameObjectManager == null)
            {
                Console.WriteLine("[BattleMode] SpawnHero: m_gameObjectManager is null");
                return null;
            }

            try
            {
                Character v9 = new Character(a2);
                m_gameObjectManager.AddGameObject(v9);
                if (a2.AreaEffect != null)
                {
                    v9.AddAreaEffect(0, 0, null, 1, false);
                }
                v9.SetIndex(a4);
                v9.SetUpgrades(a3);
                return v9;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[BattleMode] SpawnHero: Exception - {ex.Message}\n{ex.StackTrace}");
                return null;
            }
        }
        
        public void PlayerDied(BattlePlayer player)
        {
            if (player == null) return;

            player.Deaths += 1;
            Console.WriteLine($"Player died: {player.PlayerIndex}, Deaths: {player.Deaths}");

            // Нокаут логика (ID 20)
            if (m_gameModeVariation == GAME_MODE_VARIATION_KNOCKOUT)
            {
                if (player.TeamIndex == 0)
                {
                    m_team0AliveCount--;
                    if (m_team0AliveCount < 0) m_team0AliveCount = 0;
                }
                else if (player.TeamIndex == 1)
                {
                    m_team1AliveCount--;
                    if (m_team1AliveCount < 0) m_team1AliveCount = 0;
                }
                
                Console.WriteLine($"[Knockout] Игрок {player.PlayerIndex} умер. Живых: Team0={m_team0AliveCount}, Team1={m_team1AliveCount}");
                
                // Проверяем, закончился ли раунд
                if (m_team0AliveCount <= 0 || m_team1AliveCount <= 0)
                {
                    Console.WriteLine($"[Knockout] Раунд закончился! Team0={m_team0AliveCount}, Team1={m_team1AliveCount}");
                }
            }

            if (m_gameModeVariation == 6)
            {
                int rank = m_playersAlive;
                m_playersAlive--;
                player.BattleRoyaleRank = rank;

                BattleEndMessage message = new BattleEndMessage();
                message.GameMode = 2;
                message.IsPvP = BattleWithTrophies;
                message.Players = new List<BattlePlayer>();
                message.Players.Add(player);
                message.OwnPlayer = player;

                if (player.IsBot() == 0)
                {
                    HomeMode homeMode = LogicServerListener.Instance.GetHomeMode(player.AccountId);
                    if (homeMode != null)
                    {
                        if (homeMode.Home.Quests != null)
                        {
                            if (m_gameModeVariation != 13 && BattleWithTrophies)
                            {
                                message.ProgressiveQuests = homeMode.Home.Quests.UpdateQuestsProgress(m_gameModeVariation, player.CharacterId, player.Kills, player.Damage, player.Heals, homeMode.Home);
                            }
                        }
                    }
                }

                if (player.Avatar == null) return;
                player.Avatar.BattleId = -1;

                if (player.GameListener == null) return;
                Console.WriteLine("отправил");
                player.Home.BattleLogs.Add(new BattleLogStructure(), 1, 0, 0, BattleWithTrophies, m_locationId, rank);
                Hero hero = player.Avatar.GetHero(player.CharacterId);
                if (hero.Trophies > hero.HighestTrophies)
                {
                    hero.HighestTrophies = hero.Trophies;
                }
                if (player.Avatar.Trophies > player.Avatar.HighestTrophies)
                {
                    player.Avatar.HighestTrophies = player.Avatar.Trophies;
                }
                message.Result = rank;
                int tokensReward = 40 / rank;
                message.TokensReward = tokensReward;
                if (rank > 5)
                {
                    if (BattleWithTrophies)
                    {
                        player.Avatar.WinStreak += 1;
                        message.MasteryGained = 50;
                        player.Avatar.GetHero(player.CharacterId).MasteryPoints += 50;
                        int trophiesReward = -(rank - 5);
                        if (hero.Trophies < -trophiesReward) trophiesReward = -hero.Trophies;
                        message.TrophiesReward = trophiesReward;

                        player.Avatar.AddTokens(tokensReward);
                        player.Home.TokenReward += tokensReward;
                        hero.AddTrophies(message.TrophiesReward);
                    }
                }
                else
                {
                    if (BattleWithTrophies)
                    {
                        player.Avatar.WinStreak = 0;
                        int trophiesReward = (5 - rank) * 2;
                        message.TrophiesReward = trophiesReward;

                        player.Avatar.AddTokens(tokensReward);
                        player.Home.TokenReward += tokensReward;
                        player.Home.TrophiesReward += trophiesReward;

                        if (rank <= 4)
                        {
                            player.Avatar.AddStarTokens(1);
                            message.StarToken = true;
                            player.Home.StarTokenReward += 1;
                        }
                        hero.AddTrophies(message.TrophiesReward);
                    }
                }

                message.Winstreak = player.Avatar.WinStreak;
                player.GameListener.SendTCPMessage(message);
            }
            
            if (m_gameModeVariation == 25)
            {
                int killedTeam = player.TeamIndex;
                int enemyTeam = killedTeam == 0 ? 1 : 0;

                bool scoreAdded = false;
                foreach (BattlePlayer enemyPlayer in m_players)
                {
                    if (enemyTeam == enemyPlayer.TeamIndex && !scoreAdded)
                    {
                        enemyPlayer.AddScore(1);
                        scoreAdded = true;
                    }
                }
            }
            
            if (m_gameModeVariation == 0)
            {
                player.ResetScore();
            }
        }
        
        public BattlePlayer GetPlayerWithObject(int globalId)
        {
            GameObject gameObject = m_gameObjectManager.GetGameObjectByID(globalId);
            if (gameObject == null) return null;
            return gameObject.GetPlayer();
        }

        public TileMap GetTileMap()
        {
            return m_tileMap;
        }

        public void Start()
        {
            m_updateTimer = new Timer(new TimerCallback(Update), null, 0, 1000 / 20);
        }

        public void Update(object stateInfo)
        {
            this.ExecuteOneTick();
        }

        public BattlePlayer GetPlayer(int globalId)
        {
            return m_gameObjectManager.GetGameObjectByID(globalId).GetPlayer();
        }

public void ChangePlayerSessionId(long old, long newId)
        {
            if (m_playersBySessionId.ContainsKey(old))
            {
                BattlePlayer player = m_playersBySessionId[old];
                player.LastHandledInput = 0;
                m_playersBySessionId.Remove(old);
                m_playersBySessionId.Add(newId, player);
            }
        }

        public void AddSpectator(long sessionId, LogicGameListener gameListener)
        {
            m_spectators.Add(sessionId, gameListener);
        }
        
        public BattlePlayer GetPlayerBySessionId(long sessionId)
        {
            if (m_playersBySessionId.ContainsKey(sessionId))
            {
                return m_playersBySessionId[sessionId];
            }
            return null;
        }

        private BattlePlayer FindDisconnectedPlayerBySession(long sessionId)
        {
            return null;
        }
        
        private BattlePlayer FindDisconnectedPlayerByAccountId(long accountId)
        {
            foreach (var player in m_players)
            {
                if (player.AccountId == accountId && !player.IsConnected)
                {
                    return player;
                }
            }
            return null;
        }

        public void AddPlayer(BattlePlayer player, long sessionId)
        {
            if (player == null)
            {
                Console.WriteLine("LogicBattle::AddPlayer - player is NULL!");
                return;
            }

            if (m_players == null)
            {
                Console.WriteLine("LogicBattle::AddPlayer - m_players is NULL!");
                return;
            }

            if (m_playersBySessionId == null)
            {
                Console.WriteLine("LogicBattle::AddPlayer - m_playersBySessionId is NULL!");
                return;
            }

            if (m_playersByAccountId == null)
            {
                Console.WriteLine("LogicBattle::AddPlayer - m_playersByAccountId is NULL!");
                return;
            }

            try
            {
                player.SessionId = sessionId;
                player.IsConnected = true;
                m_players.Add(player);

                if (m_players.Count == 1 && m_gameModeVariation == 30 && StoryMode != null)
                {
                    StoryMode.Player = player;
                }

                if (sessionId > 0)
                {
                    if (!m_playersBySessionId.ContainsKey(sessionId))
                    {
                        m_playersBySessionId.Add(sessionId, player);
                    }
                    else
                    {
                        Console.WriteLine($"LogicBattle::AddPlayer - sessionId {sessionId} already exists in m_playersBySessionId!");
                        m_playersBySessionId[sessionId] = player;
                    }
                }

                if (player.AccountId > 0)
                {
                    m_playersByAccountId[player.AccountId] = player;
                }

                if (player.Avatar != null)
                {
                    player.Avatar.BattleId = Id;
                    player.Avatar.TeamIndex = player.TeamIndex;
                    player.Avatar.OwnIndex = player.PlayerIndex;
                }
                
                Console.WriteLine($"[BattleMode] Added player {player.PlayerIndex} (AccountId={player.AccountId}, SessionId={sessionId})");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"LogicBattle::AddPlayer - Exception: {ex.Message}\n{ex.StackTrace}");
            }
        }

        public void DisconnectPlayer(BattlePlayer player)
        {
            if (player != null)
            {
                Console.WriteLine($"[BattleMode] DisconnectPlayer: Player {player.PlayerIndex} (AccountId={player.AccountId}) marked as disconnected (NOT REMOVED)");
                
                player.GameListener = null;
                player.IsConnected = false;
                
                long oldSessionId = player.SessionId;
                player.SessionId = 0;
                
                if (oldSessionId != 0 && m_playersBySessionId.ContainsKey(oldSessionId))
                {
                    m_playersBySessionId.Remove(oldSessionId);
                    Console.WriteLine($"[BattleMode] Removed session {oldSessionId} from m_playersBySessionId");
                }
                
                if (player.AccountId > 0)
                {
                    _disconnectedTicks[player.AccountId] = GetTicksGone();
                    Console.WriteLine($"[BattleMode] Player marked as disconnected at tick {GetTicksGone()}, can reconnect within {_reconnectTimeoutTicks/20} seconds");
                    
                    if (!m_playersByAccountId.ContainsKey(player.AccountId))
                    {
                        m_playersByAccountId[player.AccountId] = player;
                        Console.WriteLine($"[BattleMode] Added player back to m_playersByAccountId");
                    }
                }
                
                Console.WriteLine($"[BattleMode] Player {player.PlayerIndex} remains in battle (m_players count: {m_players.Count})");
            }
            else
            {
                Console.WriteLine("[BattleMode] DisconnectPlayer: player is NULL!");
            }
        }

        public void RemovePlayer(BattlePlayer player)
        {
            if (player != null)
            {
                Console.WriteLine($"[BattleMode] RemovePlayer: Player {player.PlayerIndex} (AccountId={player.AccountId}) completely removed from battle");
                
                player.GameListener = null;
                player.IsConnected = false;
                m_playersBySessionId.Remove(player.SessionId);
                if (player.AccountId > 0) 
                {
                    m_playersByAccountId.Remove(player.AccountId);
                    _disconnectedTicks.Remove(player.AccountId);
                }
                m_players.Remove(player);
            }
            else
            {
                Console.WriteLine("[BattleMode] RemovePlayer: player is NULL!");
            }
        }
        
        public List<int> GetPlayerIndexesByTeam(int teamIndex)
        {
            List<int> teamCharacters = new List<int>();

            foreach (BattlePlayer player in m_players)
            {
                if (player != null && player.TeamIndex == teamIndex)
                {
                    teamCharacters.Add(player.PlayerIndex);
                }
            }

            return teamCharacters;
        }
        
        public void AddGameObjects()
        {
            m_playersAlive = m_players.Count;
            PlayerIndexesForTeam1 = GetPlayerIndexesByTeam(0);
            PlayerIndexesForTeam2 = GetPlayerIndexesByTeam(1);
            
            if (m_gameModeVariation == 19)
            {
                Team1King = PlayerIndexesForTeam1[new Random().Next(PlayerIndexesForTeam1.Count)];
                Team2King = PlayerIndexesForTeam2[new Random().Next(PlayerIndexesForTeam2.Count)];
            }
            
            int team1Indexer = 0;
            int team2Indexer = 0;
            
            if (IsStoryMode)
            {
                StoryModeStuffs = new List<GameObject>();
                foreach (BattlePlayer player in m_players)
                {
                    Character character = new Character(player.CharacterData);
                    character.SetIndex(player.PlayerIndex + (16 * player.TeamIndex));
                    character.SetHeroLevel(0);
                    character.Gear1 = new Gear(player.Gear1);
                    character.Gear2 = null;
                    character.SetPosition(3150, 4950, 0);

                    m_gameObjectManager.AddGameObject(character);
                    player.OwnObjectId = character.GetGlobalID();
                    StoryModeStuffs.Add(character);
                }
                return;
            }
            
            // ========== НОКАУТ (ID 20) - ЧИСТЫЙ НОКАУТ БЕЗ МЯЧА ==========
            if (m_gameModeVariation == GAME_MODE_VARIATION_KNOCKOUT)
            {
                Console.WriteLine("[Knockout] Запуск ЧИСТОГО нокаут режима - БЕЗ МЯЧА! Только бой до последнего!");
                
                // НОКАУТ: НИКАКОГО МЯЧА!
                Carryable = null;
                
                // Инициализируем счетчики живых игроков
                m_team0AliveCount = 0;
                m_team1AliveCount = 0;
                
                // Создаем персонажей для всех игроков
                foreach (BattlePlayer player in m_players)
                {
                    Character character = SpawnHero(player.CharacterData, player.HeroPowerLevel, player.TeamIndex * 16 + player.PlayerIndex, 0, false);
                    player.IsAlive = true;
                    character.SetBot(player.IsBot());
                    
                    if (player.Gear1 != null) character.Gear1 = new Gear("ConsumableShield");
                    if (player.Gear2 != null) character.Gear2 = null;

                    // Спавн на точках респавна
                    if (player.TeamIndex == 0)
                    {
                        if (m_tileMap.SpawnPointsTeam1 != null && m_tileMap.SpawnPointsTeam1.Count > 0)
                        {
                            Tile tile = m_tileMap.SpawnPointsTeam1[team1Indexer % m_tileMap.SpawnPointsTeam1.Count];
                            team1Indexer++;
                            character.SetPosition(tile.X + 150, tile.Y + 150, 0);
                            player.SetSpawnPoint(tile.X + 150, tile.Y + 150);
                            m_team0AliveCount++;
                        }
                        else
                        {
                            int fallbackX = 1500;
                            int fallbackY = 1500;
                            character.SetPosition(fallbackX, fallbackY, 0);
                            player.SetSpawnPoint(fallbackX, fallbackY);
                            m_team0AliveCount++;
                            Console.WriteLine($"[WARNING] No spawn points for Team1! Using fallback position: ({fallbackX}, {fallbackY})");
                        }
                    }
                    else
                    {
                        if (m_tileMap.SpawnPointsTeam2 != null && m_tileMap.SpawnPointsTeam2.Count > 0)
                        {
                            Tile tile = m_tileMap.SpawnPointsTeam2[team2Indexer % m_tileMap.SpawnPointsTeam2.Count];
                            team2Indexer++;
                            character.SetPosition(tile.X + 150, tile.Y + 150, 0);
                            player.SetSpawnPoint(tile.X + 150, tile.Y + 150);
                            m_team1AliveCount++;
                        }
                        else
                        {
                            int fallbackX = m_tileMap.LogicWidth - 1500;
                            int fallbackY = m_tileMap.LogicHeight - 1500;
                            character.SetPosition(fallbackX, fallbackY, 0);
                            player.SetSpawnPoint(fallbackX, fallbackY);
                            m_team1AliveCount++;
                            Console.WriteLine($"[WARNING] No spawn points for Team2! Using fallback position: ({fallbackX}, {fallbackY})");
                        }
                    }

                    player.OwnObjectId = character.GetGlobalID();
                    character.SetHeroLevel(player.HeroPowerLevel + 10);
                }
                
                Console.WriteLine($"[Knockout] Инициализация завершена. Живых: Team0={m_team0AliveCount}, Team1={m_team1AliveCount}");
                
                // Сбрасываем счет раундов
                TScore = new List<int> { 0, 0 };
                RoundCount = 0;
                RoundWins = new int[] { 0, 0, 0 };
                nokbool = false;
                KnockoutTicks = 0;
                m_knockoutRound = 1;
                m_knockoutRoundWins = new int[2] { 0, 0 };
                
                return; // ВАЖНО: выходим, чтобы не создавать другие объекты
            }
            
            // ========== ДРУГИЕ РЕЖИМЫ ==========
            
            // Обычный код для других режимов (создание персонажей)
            foreach (BattlePlayer player in m_players)
            {
                Character character = SpawnHero(player.CharacterData, player.HeroPowerLevel, player.TeamIndex * 16 + player.PlayerIndex, 0, false);
                player.IsAlive = true;
                character.SetBot(player.IsBot());
                
                if (player.Gear1 != null) character.Gear1 = new Gear("ConsumableShield");
                if (player.Gear2 != null) character.Gear2 = null;

                if (GameModeUtil.HasTwoTeams(m_gameModeVariation) || m_gameModeVariation == GAME_MODE_VARIATION_KNOCKOUT)
                {
                    if (player.TeamIndex == 0)
                    {
                        if (m_tileMap.SpawnPointsTeam1 != null && m_tileMap.SpawnPointsTeam1.Count > 0)
                        {
                            Tile tile = m_tileMap.SpawnPointsTeam1[team1Indexer % m_tileMap.SpawnPointsTeam1.Count];
                            team1Indexer++;
                            character.SetPosition(tile.X + 150, tile.Y + 150, 0);
                            player.SetSpawnPoint(tile.X + 150, tile.Y + 150);
                        }
                        else
                        {
                            int fallbackX = 1500;
                            int fallbackY = 1500;
                            character.SetPosition(fallbackX, fallbackY, 0);
                            player.SetSpawnPoint(fallbackX, fallbackY);
                            Console.WriteLine($"[WARNING] No spawn points for Team1! Using fallback position: ({fallbackX}, {fallbackY})");
                        }
                    }
                    else
                    {
                        if (m_tileMap.SpawnPointsTeam2 != null && m_tileMap.SpawnPointsTeam2.Count > 0)
                        {
                            Tile tile = m_tileMap.SpawnPointsTeam2[team2Indexer % m_tileMap.SpawnPointsTeam2.Count];
                            team2Indexer++;
                            character.SetPosition(tile.X + 150, tile.Y + 150, 0);
                            player.SetSpawnPoint(tile.X + 150, tile.Y + 150);
                        }
                        else
                        {
                            int fallbackX = m_tileMap.LogicWidth - 1500;
                            int fallbackY = m_tileMap.LogicHeight - 1500;
                            character.SetPosition(fallbackX, fallbackY, 0);
                            player.SetSpawnPoint(fallbackX, fallbackY);
                            Console.WriteLine($"[WARNING] No spawn points for Team2! Using fallback position: ({fallbackX}, {fallbackY})");
                        }
                    }
                }
                else
                {
                    if (m_tileMap.SpawnPointsTeam1 != null && m_tileMap.SpawnPointsTeam1.Count > 0)
                    {
                        Tile tile = m_tileMap.SpawnPointsTeam1[team1Indexer % m_tileMap.SpawnPointsTeam1.Count];
                        team1Indexer++;
                        character.SetPosition(tile.X + 150, tile.Y + 150, 0);
                        player.SetSpawnPoint(tile.X + 150, tile.Y + 150);
                    }
                    else
                    {
                        int fallbackX = m_tileMap.LogicWidth / 2;
                        int fallbackY = m_tileMap.LogicHeight / 2;
                        character.SetPosition(fallbackX, fallbackY, 0);
                        player.SetSpawnPoint(fallbackX, fallbackY);
                        Console.WriteLine($"[WARNING] No spawn points available! Using center position: ({fallbackX}, {fallbackY})");
                    }
                }

                player.OwnObjectId = character.GetGlobalID();
                character.SetHeroLevel(player.HeroPowerLevel + 10);

                if (m_gameModeVariation == 19)
                {
                    if (player.PlayerIndex == Team2King) character.SetKing();
                    if (player.PlayerIndex == Team1King) character.SetKing();
                }
            }

            // Спавн объектов для разных режимов
            if (m_gameModeVariation == 0)
            {
                Item item = new Item(DataTables.GetItemByName("OrbSpawner"));
                item.SetPosition(3150, 4950, 0);
                item.DisableAppearAnimation();
                m_gameObjectManager.AddGameObject(item);
            }

            if (m_gameModeVariation == 3)
            {
                ItemData data = DataTables.Get(18).GetData<ItemData>("Money");
                Item item = new Item(data);
                item.SetPosition(3150, 4950, 0);
                item.DisableAppearAnimation();
                m_gameObjectManager.AddGameObject(item);
            }
            
            // ========== ГОРЯЧАЯ ЗОНА (ID 17) - ИЗ ПЕРВОГО ФАЙЛА ==========
            if (m_gameModeVariation == GAME_MODE_VARIATION_HOT_ZONE)
            {
                Console.WriteLine("[HotZone] Инициализация горячей зоны!");
                
                // ОЧИЩАЕМ ВСЁ!
                _koHStates.Clear();
                Zone1Score = 0;
                Zone2Score = 0;
                
                // ТОЛЬКО ЗОНЫ, БЕЗ МАРКЕРОВ!
                int[][] zonePositions = new int[][]
                {
                    new int[] { 3150, 4950 }, // Центр
                    new int[] { 1150, 2950 }, // Лево-верх
                    new int[] { 5150, 6950 }, // Право-низ
                };
                
                for (int i = 0; i < zonePositions.Length; i++)
                {
                    int posX = zonePositions[i][0];
                    int posY = zonePositions[i][1];
                    
                    // СОЗДАЕМ ТОЛЬКО ЗОНУ, БЕЗ МАРКЕРА
                    AreaEffect zoneArea = GameObjectFactory.CreateGameObjectByData(DataTables.GetAreaEffectByName("KingOfHillArea"));
                    if (zoneArea != null)
                    {
                        zoneArea.SetPosition(posX, posY, 0);
                        zoneArea.SetIndex(16);
                        zoneArea.KOHUID = i;
                        
                        _koHStates.Add(new KingOfHillState(i));
                        m_gameObjectManager.AddGameObject(zoneArea);
                        zoneArea.Trigger();
                        
                        Console.WriteLine($"[HotZone] Зона {i} создана на ({posX}, {posY})");
                    }
                    else
                    {
                        Console.WriteLine($"[HotZone] ОШИБКА: Эффект KingOfHillArea не найден!");
                        
                        // Если нет эффекта - просто добавляем состояние зоны
                        _koHStates.Add(new KingOfHillState(i));
                    }
                }
                
                Console.WriteLine($"[HotZone] Готово! Создано зон: {_koHStates.Count}");
            }

            if (m_gameModeVariation == GAME_MODE_VARIATION_BRAWL_BALL)
            {
                Character ball = new Character(DataTables.Get(16).GetData<CharacterData>("LaserBall"));
                ball.SetPosition(3150, 4950, 0);
                ball.SetIndex(100);
                ball.TeamIndex = -1;
                
                m_gameObjectManager.AddGameObject(ball);
                Carryable = ball;
                
                Console.WriteLine($"[BrawlBall] Brawl Ball mode initialized!");
            }

            if (m_gameModeVariation == 6)
            {
                CharacterData data = DataTables.Get(16).GetData<CharacterData>("LootBox");
                for (int i = 0; i < m_tileMap.Height; i++)
                {
                    for (int j = 0; j < m_tileMap.Width; j++)
                    {
                        Tile tile = m_tileMap.GetTile(i, j, true);
                        if (tile.Code == '4')
                        {
                            bool shouldSpawnBox = GetRandomInt(0, 120) < 60;

                            if (shouldSpawnBox)
                            {
                                Character box = new Character(data);
                                box.SetPosition(tile.X + 150, tile.Y + 150, 0);
                                box.SetIndex(165);
                                m_gameObjectManager.AddGameObject(box);
                            }
                        }
                    }
                }
            }
            
            if (m_gameModeVariation == 7) { }
            
            if (m_gameModeVariation == 8)
            {
                CharacterData characterData = DataTables.Get(16).GetData<CharacterData>("FleaPet");
                Character boss = new Character(characterData);
                boss.SetPosition(10000, 10000, 0);
                boss.SetIndex(32);
                m_gameObjectManager.AddGameObject(boss);
            }
            
            if (m_gameModeVariation == 2)
            {
                CharacterData b = DataTables.GetCharacterByName("Safe");
                Character base1 = new Character(b);
                base1.SetPosition(m_tileMap.SpawnPointsBases[0].X + 150, m_tileMap.SpawnPointsBases[0].Y + 150, 0);
                base1.SetIndex(22);
                base1.TeamIndex = 1;
                m_gameObjectManager.AddGameObject(base1);
                Character base2 = new Character(b);
                base2.SetPosition(m_tileMap.SpawnPointsBases[1].X + 150, m_tileMap.SpawnPointsBases[1].Y + 150, 0);
                base2.SetIndex(6);
                base2.TeamIndex = 0;
                m_gameObjectManager.AddGameObject(base2);
            }
            
            if (m_gameModeVariation == 33)
            {
                Item item = new Item(DataTables.GetItemByName("OrbSpawner"));
                item.SetPosition(3150, 4950, 0);
                item.DisableAppearAnimation();
                m_gameObjectManager.AddGameObject(item);
            }
            
     // ========== ТРЕНИРОВКА (ID 13) ==========
// ========== ТРЕНИРОВКА (ID 13) ==========
// ========== ТРЕНИРОВКА (ID 13) ==========
if (m_gameModeVariation == 13)
{
    Console.WriteLine("[Training] Инициализация тренировочной пещеры");
    
    // ЛОГ: Кто зашел и на каком бойце
    foreach (BattlePlayer player in m_players)
    {
        string brawlerName = player.CharacterData?.Name ?? "Unknown";
        int brawlerID = player.CharacterId; // АЙДИ БОЙЦА
        int powerLevel = player.HeroPowerLevel;
        string playerName = player.Avatar?.Name ?? $"Player {player.PlayerIndex}";
        
        Console.WriteLine($"[TRAINING] ИГРОК: {playerName} | БОЕЦ: {brawlerName} | ID БОЙЦА: {brawlerID} | УРОВЕНЬ: {powerLevel}");
    }
    
   
    Console.WriteLine("[Training] Инициализация тренировочной пещеры");
    
    // СОЗДАЕМ ТОЛЬКО МАНЕКЕНЫ, НЕ СОЗДАЕМ ПЕРСОНАЖА!
    
    // Большой манекен
    Character TrainingDummyBig = new Character(DataTables.Get(16).GetData<CharacterData>("TrainingDummyBig"));
    TrainingDummyBig.SetPosition(m_tileMap.TrainingDummyBigSpawners[0].X + 150, m_tileMap.TrainingDummyBigSpawners[0].Y + 150, 0);
    TrainingDummyBig.SetIndex(-16);
    m_gameObjectManager.AddGameObject(TrainingDummyBig);
    
    // Маленькие манекены
    for (int i = 0; i < m_tileMap.TrainingDummySmallSpawners.Count; i++)
    {
        Character TrainingDummySmall = new Character(DataTables.Get(16).GetData<CharacterData>("TrainingDummySmall"));
        Tile tile = m_tileMap.TrainingDummySmallSpawners[i];
        TrainingDummySmall.SetPosition(tile.X + 150, tile.Y + 150, 0);
        TrainingDummySmall.SetIndex(-16);
        m_gameObjectManager.AddGameObject(TrainingDummySmall);
    }
    
    // Стреляющие манекены
    for (int i = 0; i < m_tileMap.TrainingDummyShooting.Count; i++)
    {
        Character TrainingDummyShooting = new Character(DataTables.Get(16).GetData<CharacterData>("TrainingDummyShooting"));
        Tile spawner = m_tileMap.TrainingDummyShooting[i];
        TrainingDummyShooting.SetPosition(spawner.X + 150, spawner.Y + 150, 0);
        TrainingDummyShooting.SetIndex(-16);
        m_gameObjectManager.AddGameObject(TrainingDummyShooting);
    }
    
    // Средние манекены
    if (m_tileMap.TrainingDummyMediumSpawners.Count >= 4)
    {
        Character TrainingDummyMedium = new Character(DataTables.Get(16).GetData<CharacterData>("TrainingDummyMedium"));
        TrainingDummyMedium.SetPosition(m_tileMap.TrainingDummyMediumSpawners[0].X + 150, m_tileMap.TrainingDummyMediumSpawners[0].Y + 150, 0);
        TrainingDummyMedium.SetIndex(-16);
        m_gameObjectManager.AddGameObject(TrainingDummyMedium);
        
        Character TrainingDummyMedium1 = new Character(DataTables.Get(16).GetData<CharacterData>("TrainingDummyMedium"));
        TrainingDummyMedium1.SetPosition(m_tileMap.TrainingDummyMediumSpawners[1].X + 150, m_tileMap.TrainingDummyMediumSpawners[1].Y + 150, 0);
        TrainingDummyMedium1.SetIndex(-16);
        m_gameObjectManager.AddGameObject(TrainingDummyMedium1);
        
        Character TrainingDummyMedium2 = new Character(DataTables.Get(16).GetData<CharacterData>("TrainingDummyMedium"));
        TrainingDummyMedium2.SetPosition(m_tileMap.TrainingDummyMediumSpawners[2].X + 150, m_tileMap.TrainingDummyMediumSpawners[2].Y + 150, 0);
        TrainingDummyMedium2.SetIndex(-16);
        m_gameObjectManager.AddGameObject(TrainingDummyMedium2);
        
        Character TrainingDummyMedium3 = new Character(DataTables.Get(16).GetData<CharacterData>("TrainingDummyMedium"));
        TrainingDummyMedium3.SetPosition(m_tileMap.TrainingDummyMediumSpawners[3].X + 150, m_tileMap.TrainingDummyMediumSpawners[3].Y + 150, 0);
        TrainingDummyMedium3.SetIndex(-16);
        m_gameObjectManager.AddGameObject(TrainingDummyMedium3);
    }
    
    Console.WriteLine("[Training] Манекены созданы, персонаж будет создан в общем коде");
    // НЕТ RETURN! ПРОДОЛЖАЕМ ДАЛЬШЕ!
}
            if (m_gameModeVariation == 30)
            {
                StoryMode.AddGameObjects();
            }
        }
        
        
        // ========== МЕТОД ДЛЯ ГОРЯЧЕЙ ЗОНЫ - ИЗ ПЕРВОГО ФАЙЛА ==========
        private void TickKingOfHill()
        {
            if (m_gameModeVariation != GAME_MODE_VARIATION_HOT_ZONE) return;
            if (_koHStates == null || _koHStates.Count == 0) return;
            
            int currentTick = GetTicksGone();
            
            for (int i = 0; i < _koHStates.Count; i++)
            {
                KingOfHillState zone = _koHStates[i];
                if (zone == null) continue;
                
                AreaEffect zoneArea = null;
                
                // Находим объект зоны
                foreach (AreaEffect area in m_gameObjectManager.GetAreaEffects())
                {
                    if (area.KOHUID == i)
                    {
                        zoneArea = area;
                        break;
                    }
                }
                
                if (zoneArea == null) continue;
                
                // Считаем игроков в зоне
                int playersInZoneTeam0 = 0;
                int playersInZoneTeam1 = 0;
                
                foreach (Character character in m_gameObjectManager.GetCharacters())
                {
                    if (!character.IsAlive() || character.GetPlayer() == null) continue;
                    
                    // ПРОСТАЯ МАТЕМАТИКА - 100% РАБОТАЕТ
                    int deltaX = character.GetX() - zoneArea.GetX();
                    int deltaY = character.GetY() - zoneArea.GetY();
                    int distanceSquared = deltaX * deltaX + deltaY * deltaY;
                        
                    if (distanceSquared < 250000) // 500^2 = 250000
                    {
                        if (character.GetPlayer().TeamIndex == 0)
                            playersInZoneTeam0++;
                        else
                            playersInZoneTeam1++;
                    }
                }
                
                // Логика захвата
                if (playersInZoneTeam0 > 0 && playersInZoneTeam1 == 0)
                {
                    // Только команда 0
                    zone.ZonePercentageTeam0 += 1;
                    
                    if (zone.ZonePercentageTeam0 >= 100)
                    {
                        Zone1Score += 1;
                        zone.ZonePercentageTeam0 = 0;
                        Console.WriteLine($"[HotZone] Team 0 захватила зону {i}! Счет: {Zone1Score}");
                        
                        // Эффект захвата
                        AreaEffect captureEffect = new AreaEffect(DataTables.GetAreaEffectByName("KingOfHillAreaCapture"));
                        captureEffect.SetPosition(zoneArea.GetX(), zoneArea.GetY(), 0);
                        m_gameObjectManager.AddGameObject(captureEffect);
                        captureEffect.Trigger();
                    }
                }
                else if (playersInZoneTeam1 > 0 && playersInZoneTeam0 == 0)
                {
                    // Только команда 1
                    zone.ZonePercentageTeam1 += 1;
                    
                    if (zone.ZonePercentageTeam1 >= 100)
                    {
                        Zone2Score += 1;
                        zone.ZonePercentageTeam1 = 0;
                        Console.WriteLine($"[HotZone] Team 1 захватила зону {i}! Счет: {Zone2Score}");
                        
                        AreaEffect captureEffect = new AreaEffect(DataTables.GetAreaEffectByName("KingOfHillAreaCapture"));
                        captureEffect.SetPosition(zoneArea.GetX(), zoneArea.GetY(), 0);
                        m_gameObjectManager.AddGameObject(captureEffect);
                        captureEffect.Trigger();
                    }
                }
            }
        }

        public void RemoveSpectator(long id)
        {
            if (m_spectators.ContainsKey(id))
            {
                m_spectators.Remove(id);
            }
        }

        public bool IsInPlayArea(int x, int y)
        {
            return m_playArea.IsInside(x + 150, y + 150);
        }

        public int GetTeamPlayersCount(int teamIndex)
        {
            int result = 0;
            foreach (BattlePlayer player in GetPlayers())
            {
                if (player.TeamIndex == teamIndex) result++;
            }
            return result;
        }

        public void AddClientInput(ClientInput input, long sessionId)
{
    if (input == null)
    {
        Console.WriteLine($"[BattleMode] AddClientInput: input is null for session {sessionId}");
        return;
    }

    // ===== Ищем игрока =====
    BattlePlayer player = GetPlayerBySessionId(sessionId);
    
    // ===== Если не нашли и есть игроки - берем первого =====
    if (player == null && m_players.Count > 0)
    {
        player = m_players[0];
        player.SessionId = sessionId;
        player.IsConnected = true;
        player.NeedsFullState = true;
        m_playersBySessionId[sessionId] = player;
        Console.WriteLine($"[BattleMode] Assigned session {sessionId} to player {player.PlayerIndex}");
    }

    if (player == null)
    {
        Console.WriteLine($"[BattleMode] AddClientInput: NO PLAYER FOUND for session {sessionId}");
        return;
    }

    if (!player.IsConnected)
    {
        Console.WriteLine($"[BattleMode] Player {player.PlayerIndex} is not marked as connected, marking as connected");
        player.IsConnected = true;
        player.NeedsFullState = true;
    }

    input.OwnerSessionId = sessionId;
    m_inputQueue.Enqueue(input);
}

        public void HandleSpectatorInput(ClientInput input, long sessionId)
        {
            if (input == null)
            {
                Console.WriteLine($"[BattleMode] HandleSpectatorInput: input is null for session {sessionId}");
                return;
            }

            if (m_spectators == null)
            {
                Console.WriteLine($"[BattleMode] HandleSpectatorInput: m_spectators is null");
                return;
            }

            if (!m_spectators.ContainsKey(sessionId))
            {
                Console.WriteLine($"[BattleMode] HandleSpectatorInput: session {sessionId} not found in spectators");
                return;
            }

            var spectator = m_spectators[sessionId];
            if (spectator == null)
            {
                Console.WriteLine($"[BattleMode] HandleSpectatorInput: spectator is null for session {sessionId}");
                return;
            }

            spectator.HandledInputs = input.Index;
        }

        private void HandleClientInput(ClientInput input)
        {
            if (input == null)
            {
                Console.WriteLine("[BattleMode] HandleClientInput: input is null");
                return;
            }

            BattlePlayer player = GetPlayerBySessionId(input.OwnerSessionId);

            if (player == null)
            {
                Console.WriteLine($"[BattleMode] HandleClientInput: player is null for session {input.OwnerSessionId}");
                return;
            }
            if (player.LastHandledInput >= input.Index) return;

            player.LastHandledInput = input.Index;

            if (m_gameObjectManager == null)
            {
                Console.WriteLine("[BattleMode] HandleClientInput: m_gameObjectManager is null");
                return;
            }

            Character character1 = (Character)m_gameObjectManager.GetGameObjectByID(player.OwnObjectId);
            if ((character1 == null || !character1.IsAlive()) && input.Type != 4 && input.Type != 9) return;
            if (character1 != null && character1.ViusalChargeType > 0 && input.Type >= 2 && input.Type <= 8) return;
            if (input.Type < 8 && input.Type != 4 && StoryMode != null && StoryMode.Intangible) return;
            if (input.Type != 0 && StoryMode != null && StoryMode.Choosing) return;
            
            switch (input.Type)
            {
                case 0:
                    {
                        if (StoryMode != null && StoryMode.Choosing)
                        {
                            StoryMode.ChoiceChosen(input.X, input.Y);
                            return;
                        }

                        Character character = (Character)m_gameObjectManager.GetGameObjectByID(player.OwnObjectId);
                        if (character == null) return;
                        
                        Skill skill = character.GetWeaponSkill();
                        if (skill == null) return;

                        character.UltiDisabled();
                        if (input.AutoAttack)
                        {
                            Character target = (Character)m_gameObjectManager.GetGameObjectByID(input.AutoAttackTarget);
                            if (target != null)
                            {
                                input.X = target.GetX();
                                input.Y = target.GetY();
                            }
                            else
                            {
                                target = character.GetClosestVisibleEnemy();
                                if (target != null)
                                {
                                    input.X = target.GetX();
                                    input.Y = target.GetY();
                                }
                            }
                            character.ActivateSkill(0, input.X, input.Y);
                            break;
                        }
                        if (!skill.SkillData.IsPositionalTargeted())
                        {
                            character.ActivateSkill(0, input.X + character.GetX(), input.Y + character.GetY());
                        }
                        else character.ActivateSkill(0, input.X, input.Y);

                        var counter = character1.GetFadeCounter();
                        character1.IncrementFadeCounter();
                        character.SetFadeCounter(counter);

                        character1.ResetAFKTicks();
                        break;
                    }
                case 1:
                    {
                        if (character1.IsControlled) return;
                        
                        Character character = (Character)m_gameObjectManager.GetGameObjectByID(player.OwnObjectId);

                        if (character == null) return;
                        character.m_skills[1].SeemToBeActive = false;

                        if (character.DisplayUltiTmp) return;
                        Skill skill = character.GetUltimateSkill();
                        if (skill == null) return;
                        character?.UltiDisabled();
                        if (!player.HasUlti()) return;
                        
                        if (character.CharacterData != null && character.CharacterData.Name.Contains("Dynamike"))
                        {
                            if (Carryable != null)
                            {
                                ResetCarryable();
                            }
                        }
                        
                        character.UltiEnabled();
                        skill.IsFromAutoAttack = input.AutoAttack;
                        if (input.AutoAttack && !skill.SkillData.MovementBasedAutoshoot)
                        {
                            Character target = (Character)m_gameObjectManager.GetGameObjectByID(input.AutoAttackTarget);
                            if (target != null)
                            {
                                input.X = target.GetX();
                                input.Y = target.GetY();
                            }
                            else
                            {
                                target = character.GetClosestVisibleEnemy();
                                if (target != null)
                                {
                                    input.X = target.GetX();
                                    input.Y = target.GetY();
                                }
                            }
                            character.ActivateSkill(1, input.X, input.Y);
                            break;
                        }
                        if (input.AutoAttack && skill.SkillData.MovementBasedAutoshoot)
                        {
                            character.ActivateSkill(1, input.X, input.Y);
                            break;
                        }
                        if (!skill.SkillData.IsPositionalTargeted())
                        {
                            character.ActivateSkill(1, input.X + character.GetX(), input.Y + character.GetY());
                        }
                        else character.ActivateSkill(1, input.X, input.Y);
                        var counter = character1.GetFadeCounter();
                        character1.IncrementFadeCounter();
                        character.SetFadeCounter(counter);

                        character1.ResetAFKTicks();
                        break;
                    }
                case 2:
                    {
                        Character character = (Character)m_gameObjectManager.GetGameObjectByID(player.OwnObjectId);

                        if (character == null) return;

                        LogicVector2 old = new LogicVector2(character.GetX(), character.GetY());
                        LogicVector2 destin = new LogicVector2(input.X, input.Y);
                        int v15 = old.GetDistanceSquaredTo(input.X, input.Y);
                        
                        character.MoveTo(0, input.X, input.Y, 0, 0, 0, 0);

                        character1.ResetAFKTicks();
                        break;
                    }
                case 4:
                        SendBattleEndToPlayers();
                        RemovePlayer(player);
                        if (m_gameModeVariation == 13)
                        {
                            this.IsGameOver = true;
     //                       EndTicks++;
                            this.m_updateTimer.Dispose();
                        }
                break;
                case 5:
                    {
                        if (character1.IsControlled) return;
                        Character character = (Character)m_gameObjectManager.GetGameObjectByID(player.OwnObjectId);
                        character?.UltiEnabled();
                        character1.ResetAFKTicks();
                        break;
                    }
                case 6:
                    {
                        if (character1.IsControlled) return;
                        Character character = (Character)m_gameObjectManager.GetGameObjectByID(player.OwnObjectId);
                        character?.UltiDisabled();
                        character1.ResetAFKTicks();
                        break;
                    }
                case 7:
                    {
                        break;
                    }
                case 8:
                    {
                        if (StoryMode != null && StoryMode.StartWaitingTick > GetTicksGone())
                        {
                            StoryMode.DoorTest ^= true;
                            StoryMode.WaitSkipped = true;
                            return;
                        }
                        if (character1.IsControlled) return;
                        Accessory accessory = player.Accessory;
                        Character character = (Character)m_gameObjectManager.GetGameObjectByID(player.OwnObjectId);
                        if (accessory != null) accessory.TriggerAccessory(character, input.X, input.Y);
                        character1.ResetAFKTicks();
                        break;
                    }
                case 9:
                    {
                        if (character1.IsControlled) return;
                        player.UsePin(input.EmoteIndex, GetTicksGone());
                        if (player.LastPinUseTicks + 200 < GetTicksGone()) player.UsePin(input.EmoteIndex, GetTicksGone());
                        character1.ResetAFKTicks();
                        break;
                    }
                case 10:
                    {
                        if (character1.IsSteerMovementActive())
                        {
                            if ((input.X | input.Y) < 0) character1.SteerAngle = -1;
                            else
                                character1.SteerAngle = LogicMath.GetAngle(-input.X + character1.GetX(), -input.Y + character1.GetY());
                            return;
                        }
                        Projectile projectile = character1.GetControlledProjectile();
                        if (projectile == null) return;
                        int v26;
                        if ((input.X | input.Y) < 0) v26 = -1;
                        else
                        {
                            v26 = LogicMath.GetAngle(input.X - projectile.GetX(), input.Y - projectile.GetY());
                        }
                        projectile.SteerAngle = v26;
                        character1.ResetAFKTicks();
                        break;
                    }
                case 13:
                    input.X = input.X * 150 / 100;
                    if (character1.GetSkillHoldedTicks() <= 0)
                    {
                        character1.HoldSkillStarted();
                        if (character1.m_skills[0].SkillData.AttackPattern == 13) break;
                        AreaEffect areaEffect = GameObjectFactory.CreateGameObjectByData(DataTables.GetAreaEffectByName("Tara005UltiSuck"));
                        areaEffect.SetIndex(character1.GetIndex());
                        areaEffect.SetPosition(character1.GetX(), character1.GetY(), 0);
                        m_gameObjectManager.AddGameObject(areaEffect);
                    }
                    if (character1.m_skills[0].SkillData.AttackPattern == 13) break;
                    character1.SetForcedAngle(LogicMath.NormalizeAngle360(LogicMath.GetAngle(input.X, input.Y) - character1.GetIndex() / 16 * 180));
                    character1.SetVisionOverride(input.X + character1.GetX(), input.Y + character1.GetY(), 2);
                    character1.StopMovement();
                    character1.SetForcedVisible();
                    character1.BlockHealthRegen();
                    character1.m_skills[1].SeemToBeActive = true;
                    character1.ResetAFKTicks();
                    break;
                case 14:
                    character1.SkillHoldTicks = -1;
                    character1.m_skills[1].SeemToBeActive = false;
                    character1.ResetAFKTicks();
                    break;
                case 15:
                    Item Spray = new Item(DataTables.GetItemByName("Spray"));
                    if (input.SprayIndex < 0) { Console.WriteLine("input index dissmatch"); return;}
                    player.SprayIndex = input.SprayIndex;
     ///////               добавь после этого
Console.WriteLine($"index: {input.SprayIndex}");
                    Spray.SprayData = DataTables.Get(DataType.Spray).GetDataWithId<SprayData>(player.GetSprayIDBySprayIndex(input.SprayIndex));
                    Spray.Owner = character1;
                    if (player.CharacterSpray != null) m_gameObjectManager.RemoveGameObject(player.CharacterSpray);
                    player.CharacterSpray = Spray;

                    Spray.SetPosition(
                        character1.GetX() + LogicMath.GetRotatedX(500, 0, input.SprayAngle),
                        character1.GetY() + LogicMath.GetRotatedY(500, 0, input.SprayAngle),
                        0
                    );
                   Console.WriteLine("Success !");
Spray.SetIndex(character1.GetIndex());
                    m_gameObjectManager.AddGameObject(Spray);
                    break;
                case 16:
                    break;
                case 17:
                    if (!player.HasOverCharge()) return;
                    player.OverCharging = true;
                    character1.ResetAFKTicks();
                    break;
                default:
                    Debugger.Warning("Input is unhandled: " + input.Type); 
                    break;
            }
        }

        public bool IsTileOnPoisonArea(int xTile, int yTile)
        {
            if (m_gameModeVariation != 6) return false;

            int tick = GetTicksGone();

            if (tick > 500)
            {
                int poisons = 0;
                poisons += (tick - 500) / 100;

                if (xTile <= poisons || xTile >= 59 - poisons || yTile <= poisons || yTile >= 59 - poisons)
                {
                    return true;
                }
            }
            return false;
        }

        private void HandleIncomingInputMessages()
        {
            ClientInput input;
            while (m_inputQueue.TryDequeue(out input))
            {
                if (input != null)
                {
                    try
                    {
                        this.HandleClientInput(input);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine($"Error processing input in HandleClientInput: {e.Message}. Input Type: {input.Type}, OwnerSessionId: {input.OwnerSessionId}, Tick: {GetTicksGone()}, Trace: {e.StackTrace}");
                    }
                }
                else
                {
                    Console.WriteLine("HandleIncomingInputMessages: Dequeued a null input!");
                }
            }
        }

        private void CheckAndRecoverDisconnectedPlayers()
        {
            int currentTick = GetTicksGone();
            List<long> toRemove = new List<long>();
            
            foreach (var kvp in _disconnectedTicks)
            {
                long accountId = kvp.Key;
                int disconnectTick = kvp.Value;
                
                if (currentTick - disconnectTick > _reconnectTimeoutTicks)
                {
                    Console.WriteLine($"[BattleMode] Player {accountId} exceeded reconnect timeout ({_reconnectTimeoutTicks/20} seconds), removing from battle");
                    BattlePlayer player = GetPlayerByAccountId(accountId);
                    if (player != null)
                    {
                        if (!player.IsConnected)
                        {
                            Console.WriteLine($"[BattleMode] Removing player {player.PlayerIndex} due to timeout");
                            RemovePlayer(player);
                        }
                        else
                        {
                            Console.WriteLine($"[BattleMode] Player {player.PlayerIndex} reconnected, keeping in battle");
                            _disconnectedTicks.Remove(accountId);
                        }
                    }
                    toRemove.Add(accountId);
                }
            }
            
            foreach (var accountId in toRemove)
            {
                _disconnectedTicks.Remove(accountId);
            }
        }
        private bool _tmpb;
        private int _tmpi;
        public void ExecuteOneTick()
        {
            try
            {
                this.HandleIncomingInputMessages();

if (CalculateIsGameOver())
            {
                if (IsRanked)
                {
                    if (!_tmpb)
                    {
                        AtesDev2RankedMatch r = LogicServerListener.Instance.GetRankedMatch(RankedId);
                        if (m_winnerTeam == 0) r.AtesDev2TrueTeamWins++;
                        if (m_winnerTeam == 1) r.AtesDev2TrueRedWins++;
                        r.AtesDev2GameRounds++;
                        _tmpi = GetTicksGone();
                        _tmpb = true;
                        GameOver();

                    }
                    if (_tmpi + (10 * 20) == GetTicksGone())
                    {
                        if (LogicServerListener.Instance.GetRankedMatch(RankedId).RestartRound() == -1)
                        {
                            this.IsGameOver = true;
                            this.m_updateTimer.Dispose();
                            return;
                        }
                    }
                    if (_tmpi + (11 * 20) == GetTicksGone())
                    {
                        this.IsGameOver = true;
                        this.m_updateTimer.Dispose();
                    }
                    m_time.IncreaseTick();
                    return;
                }
                GameOver();
                this.IsGameOver = true;
                this.m_updateTimer.Dispose();
                return;
            }
                
                this.SendVisionUpdateToPlayers();
                
                foreach (BattlePlayer player in GetPlayers())
                {
                    player.KillList.Clear();
                }
                
                if (StoryMode != null) StoryMode.Tick();
                
                this.m_gameObjectManager.PreTick();
                this.Tick();
                this.m_time.IncreaseTick();
            }
            catch (Exception e)
            {
                Parallel.ForEach(m_players, player =>
                {
                    if (player.GameListener != null)
                    {
                        try { } catch (Exception)
                        {
                            Console.WriteLine("Battle stopped with exception! Message: " + e.Message + " Trace: " + e.StackTrace);
                        }
                    }
                });

                m_updateTimer.Dispose();
                IsGameOver = true;
            }
        }
        
        private void TickSpawnEventStuffDelayed() { }

        public void GameOver()
        {
            if (IsGameOver) return;
            IsGameOver = true;
            Console.WriteLine("game over");
            m_updateTimer.Dispose();
            SendBattleEndToPlayers();
        }

        public void SendBattleEndToPlayers()
        {
            if (m_hasSentEndMessages) return;
            m_hasSentEndMessages = true;

            foreach (BattlePlayer player in m_players)
            {
                if (player.SessionId < 0) continue;

                if (m_gameModeVariation == 6 && player.BattleRoyaleRank == -1)
                {
                    if (player.IsAlive)
                    {
                        player.BattleRoyaleRank = m_playersAlive;
                    }
                    else
                    {
                        player.BattleRoyaleRank = 1;
                    }
                }
                if (player.BattleRoyaleRank == -1)
                {
                    player.BattleRoyaleRank = m_players.Count;
                }

                if (player.Avatar == null) continue;

                int rank = player.BattleRoyaleRank;
                player.Avatar.BattleId = -1;
                bool isVictory = m_winnerTeam == player.TeamIndex;

                BattleEndMessage message = new BattleEndMessage();
                Hero hero = player.Avatar.GetHero(player.CharacterId);
                
                int oldMasteryPoints = hero?.MasteryPoints ?? 0;
                message.MasteryPoints = oldMasteryPoints;
                message.MasteryGained = 0;

                // Прогресс квестов
                if (player.IsBot() == 0)
                {
                    HomeMode homeMode = LogicServerListener.Instance.GetHomeMode(player.AccountId);
                    if (homeMode != null && homeMode.Home.Quests != null)
                    {
                        if (m_gameModeVariation != 13 && BattleWithTrophies)
                        {
                            message.ProgressiveQuests = homeMode.Home.Quests.UpdateQuestsProgress(
                                m_gameModeVariation, 
                                player.CharacterId, 
                                player.Kills, 
                                player.Damage, 
                                player.Heals, 
                                homeMode.Home);
                        }
                    }
                }

                // Определяем звездного игрока
                try
                {
                    BattlePlayer best = null;
                    int bestScore = int.MinValue;
                    foreach (var p in m_players)
                    {
                        if (p == null) continue;
                        int score = p.Kills * 300 + p.Damage / 100 + p.Heals / 100;
                        if (score > bestScore)
                        {
                            bestScore = score;
                            best = p;
                        }
                    }
                    if (best != null)
                    {
                        message.StarPlayerAccountId = best.AccountId;
                    }
                }
                catch { }

                if (m_gameModeVariation != 6) // Не Showdown
                {
                    message.GameMode = 1;
                    message.IsPvP = BattleWithTrophies;
                    message.Players = m_players;
                    message.OwnPlayer = player;

                    message.Result = 2;
                    message.TokensReward = 0;
                    message.TrophiesReward = 0;
                    message.WinstreakTrophies = 0;
                    message.TokensDoublersReward = 0;
                    message.TokensRemainingReward = player.Home?.TokenDoublers ?? 0;
                    message.StarToken = false;
                    message.MasteryPoints = oldMasteryPoints;
                    message.MasteryGained = 0;

                    try
                    {
                        if (m_winnerTeam == -1) // НИЧЬЯ
                        {
                            message.Result = 2;
                            Random random = new Random();
                            int baseTokens = random.Next(20, 151);
                            message.TokensReward = baseTokens;
                            
                            if (BattleWithTrophies)
                            {
                                // МАСТЕРСТВО
                                int masteryGain = random.Next(50, 201);
                                if (hero != null)
                                {
                                    hero.MasteryPoints += masteryGain;
                                    message.MasteryGained = masteryGain;
                                }
                                
                                // ТОКЕН ДАБЛЕРЫ
                                int doublersAvailable = player.Home?.TokenDoublers ?? 0;
                                int doublersUsed = Math.Min(doublersAvailable, baseTokens);
                                int finalTokens = baseTokens + doublersUsed;
                                message.TokensDoublersReward = doublersUsed;
                                message.TokensRemainingReward = doublersAvailable - doublersUsed;
                                if (player.Home != null) player.Home.TokenDoublers -= doublersUsed;

                                // VIP БОНУС
                                int vipBonus = 0;
                                if (player.Avatar.IsVIP && player.Avatar.VIPExpire > DateTime.UtcNow)
                                {
                                    vipBonus = random.Next(5, 9);
                                }
                                
                                // VIP x2 кубки - дополнительные 3 кубка за ничью
                                bool hasDoubleTrophyVIP = player.Avatar.HasDoubleTrophyVIP && 
                                                         player.Avatar.DoubleTrophyVIPEndTime > DateTime.UtcNow;
                                if (hasDoubleTrophyVIP)
                                {
                                    vipBonus += 3;
                                    Console.WriteLine($"[VIP x2] {player.Avatar.Name}: Ничья! +3 дополнительных кубка! Итого: {vipBonus} кубков");
                                }
                                
                                message.TrophiesReward = vipBonus;
                                if (vipBonus > 0 && hero != null)
                                {
                                    hero.AddTrophies(vipBonus);
                                    if (player.Home != null) 
                                        player.Home.TrophiesReward = LogicMath.Max(player.Home.TrophiesReward + vipBonus, 0);
                                }
                                
                                player.Avatar.AddTokens(finalTokens);
                                if (player.Home != null) 
                                {
                                    player.Home.TokenReward += finalTokens;
                                    player.Home.BattleLogs.Add(new BattleLogStructure(), 1, vipBonus, 0, BattleWithTrophies, m_locationId, 2);
                                }
                            }
                        }
                        else // ПОБЕДА ИЛИ ПОРАЖЕНИЕ
                        {
                            int brawlerTrophies = hero?.Trophies ?? 0;
                            int winTrophies = 0;
                            int loseTrophies = 0;
                            
                            // Таблица кубков
                            if (0 <= brawlerTrophies && brawlerTrophies <= 49) { winTrophies = 8; loseTrophies = 0; }
                            else if (50 <= brawlerTrophies && brawlerTrophies <= 99) { winTrophies = 8; loseTrophies = -1; }
                            else if (100 <= brawlerTrophies && brawlerTrophies <= 199) { winTrophies = 8; loseTrophies = -2; }
                            else if (200 <= brawlerTrophies && brawlerTrophies <= 299) { winTrophies = 8; loseTrophies = -3; }
                            else if (300 <= brawlerTrophies && brawlerTrophies <= 399) { winTrophies = 8; loseTrophies = -3; }
                            else if (400 <= brawlerTrophies && brawlerTrophies <= 499) { winTrophies = 8; loseTrophies = -5; }
                            else if (500 <= brawlerTrophies && brawlerTrophies <= 599) { winTrophies = 8; loseTrophies = -6; }
                            else if (600 <= brawlerTrophies && brawlerTrophies <= 699) { winTrophies = 8; loseTrophies = -7; }
                            else if (700 <= brawlerTrophies && brawlerTrophies <= 799) { winTrophies = 8; loseTrophies = -8; }
                            else if (800 <= brawlerTrophies && brawlerTrophies <= 899) { winTrophies = 7; loseTrophies = -9; }
                            else if (900 <= brawlerTrophies && brawlerTrophies <= 999) { winTrophies = 6; loseTrophies = -10; }
                            else if (1000 <= brawlerTrophies && brawlerTrophies <= 1099) { winTrophies = 5; loseTrophies = -11; }
                            else if (1100 <= brawlerTrophies && brawlerTrophies <= 1199) { winTrophies = 4; loseTrophies = -12; }
                            else if (brawlerTrophies >= 1200) { winTrophies = 3; loseTrophies = -12; }

                            if (isVictory) // ПОБЕДА
                            {
                                message.Result = 0;
                                Random random = new Random();
                                int baseTokens = random.Next(20, 151);
                                message.TokensReward = baseTokens;
                                
                                if (BattleWithTrophies)
                                {
                                    // МАСТЕРСТВО
                                    int masteryGain = random.Next(50, 201);
                                    if (hero != null)
                                    {
                                        hero.MasteryPoints += masteryGain;
                                        message.MasteryGained = masteryGain;
                                    }
                                    
                                    // ТОКЕН ДАБЛЕРЫ
                                    int doublersAvailable = player.Home?.TokenDoublers ?? 0;
                                    int doublersUsed = Math.Min(doublersAvailable, baseTokens);
                                    int finalTokens = baseTokens + doublersUsed;
                                    message.TokensDoublersReward = doublersUsed;
                                    message.TokensRemainingReward = doublersAvailable - doublersUsed;
                                    if (player.Home != null) player.Home.TokenDoublers -= doublersUsed;

                                    // ВИНСТРИК
                                    if (!IsRanked )player.Avatar.WinStreak += 1;
                                    if (!IsRanked )player.Avatar.MaxWinstreak = LogicMath.Max(player.Avatar.MaxWinstreak, player.Avatar.WinStreak);
                                    
                                    int trophiesReward = winTrophies;
                                    message.WinstreakTrophies = 0;
                                    
                                    // БОНУС ЗА ВИНСТРИК
                                    if (player.Avatar.WinStreak >= 2)
                                    {
                                        int bonusTrophies = Math.Min(player.Avatar.WinStreak, 5);
                                        trophiesReward += bonusTrophies;
                                        if (!IsRanked )message.WinstreakTrophies = bonusTrophies;
                                    }
                                    
                                    // VIP БОНУС
                                    int vipBonus = 0;
                                    if (player.Avatar.IsVIP && player.Avatar.VIPExpire > DateTime.UtcNow)
                                    {
                                        vipBonus = random.Next(5, 9);
                                        trophiesReward += vipBonus;
                                    }
                                    
                                    // VIP x2 кубки - дополнительные 3 кубка за победу
                                    bool hasDoubleTrophyVIP = player.Avatar.HasDoubleTrophyVIP && 
                                                             player.Avatar.DoubleTrophyVIPEndTime > DateTime.UtcNow;
                                    if (hasDoubleTrophyVIP)
                                    {
                                        trophiesReward += 3;
                                        Console.WriteLine($"[VIP x2] {player.Avatar.Name}: Победа! +3 дополнительных кубка! Итого: {trophiesReward} кубков");
                                    }

                                    message.TrophiesReward = trophiesReward;
                                    if (hero != null) if (!IsRanked )hero.AddTrophies(trophiesReward);
                                    if (!IsRanked )player.Avatar.AddTokens(finalTokens);
                                    player.Avatar.TrioWins++;
                                    if (player.Home != null)
                                    {
                                        if (!IsRanked )player.Home.TokenReward += finalTokens;
                                        if (!IsRanked )player.Home.TrophiesReward = LogicMath.Max(player.Home.TrophiesReward + trophiesReward, 0);
                                        player.Home.BattleLogs.Add(new BattleLogStructure(), 1, trophiesReward, 0, BattleWithTrophies, m_locationId, 0);
                                    }
                                     if (IsRanked)
                                {
                                    message.RankedMatch = true;
                                    AtesDev2RankedMatch r = LogicServerListener.Instance.GetRankedMatch(RankedId);
                                    if (r == null) return;
                                    switch (r.AtesDev2Solo)
                                    {
                                        case true:
                                            int v1s = player.Home.RankedSoloMaxRank;
                                            int tempRewards = new Random().Next(40, 150);
                                            //if(player.)
                                            int a1s = player.Home.RankedSoloMaxProgress;
                                            player.Home.RankedSoloProgress += tempRewards;
                                            if (player.Home.RankedSoloProgress > player.Home.RankedSoloMaxProgress)
                                                player.Home.RankedSoloMaxProgress = player.Home.RankedSoloProgress;
                                            int a2s = player.Home.RankedSoloMaxProgress;
                                            int ps = player.Home.RankedSoloRank * 1000;
                                            if (a1s < ps && a2s >= ps)
                                                player.Home.RankedSoloRank += 1;
                                            if (player.Home.RankedSoloRank > player.Home.RankedSoloMaxRank)
                                                player.Home.RankedSoloMaxRank = player.Home.RankedSoloRank;
                                            if (v1s != player.Home.RankedSoloMaxRank) message.UpRank = player.Home.RankedSoloMaxRank;
                                            message.Add = tempRewards;
                                            message.ELO = player.Home.RankedSoloProgress;
                                            message.Rank = player.Home.RankedSoloRank + 1;
                                            break;
                                        case false:
                                            int v1t = player.Home.RankedTrioMaxRank;
                                            int tempReward = 100;// new Random().Next(40, 150);
                                                                 //if(player.)
                                            int a1t = player.Home.RankedTrioMaxProgress;
                                            player.Home.RankedTrioProgress += tempReward;
                                            if (player.Home.RankedTrioProgress > player.Home.RankedTrioMaxProgress)
                                                player.Home.RankedTrioMaxProgress = player.Home.RankedTrioProgress;
                                            int a2t = player.Home.RankedTrioMaxProgress;
                                            int pt = player.Home.RankedTrioRank * 1000;
                                            if (a1t < pt && a2t >= pt)
                                                player.Home.RankedTrioRank += 1;
                                            if (player.Home.RankedTrioRank > player.Home.RankedTrioMaxRank)
                                                player.Home.RankedTrioMaxRank = player.Home.RankedTrioRank;
                                            if (v1t != player.Home.RankedTrioMaxRank) message.UpRank = player.Home.RankedTrioMaxRank;
                                            message.ELO = player.Home.RankedTrioProgress;
                                            message.Rank = player.Home.RankedTrioRank + 1;
                                            break;
                                    }
                                    message.TrueBlueTeamWins = r.AtesDev2TrueTeamWins;
                                    message.TrueRedTeamWins = r.AtesDev2TrueRedWins;
                                    message.Round = !r.AtesDev2MatchOver ? r.AtesDev2Round : 0;
                                    message.Solo = r.AtesDev2Solo;
                                }
                                }
                            }
                            else // ПОРАЖЕНИЕ
                            {
                                message.Result = 1;
                                Random random = new Random();
                                int baseTokens = random.Next(20, 151);
                                message.TokensReward = baseTokens;
                                
                                if (BattleWithTrophies)
                                {
                                    // МАСТЕРСТВО
                                    int masteryGain = random.Next(50, 201);
                                    if (hero != null)
                                    {
                                        hero.MasteryPoints += masteryGain;
                                        message.MasteryGained = masteryGain;
                                    }
                                    
                                    // ТОКЕН ДАБЛЕРЫ
                                    int doublersAvailable = player.Home?.TokenDoublers ?? 0;
                                    int doublersUsed = Math.Min(doublersAvailable, baseTokens);
                                    int finalTokens = baseTokens + doublersUsed;
                                    message.TokensDoublersReward = doublersUsed;
                                    message.TokensRemainingReward = doublersAvailable - doublersUsed;
                                    if (player.Home != null) player.Home.TokenDoublers -= doublersUsed;

                                    // СБРОС ВИНСТРИКА
                                    if (!IsRanked )player.Avatar.WinStreak = 0;
                                    
                                    int trophiesReward = loseTrophies;

                                    // VIP БОНУС
                                    int vipBonus = 0;
                                    if (player.Avatar.IsVIP && player.Avatar.VIPExpire > DateTime.UtcNow)
                                    {
                                        vipBonus = random.Next(5, 9);
                                        trophiesReward += vipBonus;
                                    }
                                    
                                    // VIP x2 кубки - уменьшение потери
                                    bool hasDoubleTrophyVIP = player.Avatar.HasDoubleTrophyVIP && 
                                                             player.Avatar.DoubleTrophyVIPEndTime > DateTime.UtcNow;
                                    if (hasDoubleTrophyVIP && trophiesReward < 0)
                                    {
                                        trophiesReward = trophiesReward / 2;
                                        Console.WriteLine($"[VIP x2] {player.Avatar.Name}: Поражение! Потеря кубков уменьшена в 2 раза: {loseTrophies + vipBonus} -> {trophiesReward}");
                                    }

                                    if (hero != null && hero.Trophies < -trophiesReward)
                                    {
                                        trophiesReward = -hero.Trophies;
                                    }
                                    if (!IsRanked )message.TrophiesReward = trophiesReward;
                                    if (hero != null) if (!IsRanked )hero.AddTrophies(trophiesReward);
                                    player.Avatar.AddTokens(finalTokens);
                                    if (player.Home != null)
                                    {
                                        player.Home.TokenReward += finalTokens;
                                        if (!IsRanked )player.Home.TrophiesReward = LogicMath.Max(player.Home.TrophiesReward + trophiesReward, 0);
                                        player.Home.BattleLogs.Add(new BattleLogStructure(), 1, trophiesReward, 0, BattleWithTrophies, m_locationId, 1);
                                    }
                                    if (IsRanked)
                                {
                                    message.RankedMatch = true;
                                    AtesDev2RankedMatch r = LogicServerListener.Instance.GetRankedMatch(RankedId);
                                    if (r == null) return;
                                    switch (r.AtesDev2Solo)
                                    {
                                        case true:
                                            int tempRewards = new Random().Next(40, 69);
                                            //if(player.)
                                            player.Home.RankedSoloProgress -= tempRewards;
                                            if (player.Home.RankedSoloProgress < 0) player.Home.RankedSoloProgress = 0;
                                            message.ELO = player.Home.RankedSoloProgress;
                                            message.Rank = player.Home.RankedSoloRank + 1;
                                            break;
                                        case false:
                                            int tempReward = 65;// new Random().Next(40, 150);
                                            player.Home.RankedTrioProgress -= tempReward;
                                            if (player.Home.RankedTrioProgress < 0) player.Home.RankedTrioProgress = 0;
                                            message.ELO = player.Home.RankedTrioProgress;
                                            message.Rank = player.Home.RankedTrioRank + 1;
                                            break;
                                    }
                                    message.TrueBlueTeamWins = r.AtesDev2TrueTeamWins;
                                    message.TrueRedTeamWins = r.AtesDev2TrueRedWins;
                                    message.Round = !r.AtesDev2MatchOver ? r.AtesDev2Round : 0;
                                    message.Solo = r.AtesDev2Solo;
                                }
                                }
                            }
                        }
                    }
                    finally
                    {
                        // ЗВЕЗДНЫЕ ТОКЕНЫ ЗА BOUNTY
                        if (m_gameModeVariation == 3 && player.KillList.Count > 0)
                        {
                            player.Avatar.AddStarTokens(player.KillList.Count);
                            if (player.Home != null) player.Home.StarTokenReward += player.KillList.Count;
                            Console.WriteLine($"[Bounty] Awarded {player.KillList.Count} star tokens for {player.KillList.Count} kills");
                        }

                        // РЕКОРДЫ
                        if (hero != null && hero.Trophies > hero.HighestTrophies)
                        {
                            hero.HighestTrophies = hero.Trophies;
                        }
                        if (player.Avatar != null && player.Avatar.Trophies > player.Avatar.HighestTrophies)
                        {
                            player.Avatar.HighestTrophies = player.Avatar.Trophies;
                        }
                    }
                }
                else // SHOWDOWN
                {
                    message.GameMode = 2;
                    message.IsPvP = BattleWithTrophies;
                    message.Result = player.BattleRoyaleRank;
                    message.Players = new List<BattlePlayer> { player };
                    message.OwnPlayer = player;

                    message.TokensReward = 0;
                    message.TrophiesReward = 0;
                    message.WinstreakTrophies = 0;
                    message.TokensDoublersReward = 0;
                    message.TokensRemainingReward = player.Home?.TokenDoublers ?? 0;
                    message.StarToken = false;
                    message.MasteryPoints = oldMasteryPoints;
                    message.MasteryGained = 0;

                    if (BattleWithTrophies)
                    {
                        int oldWinStreak = player.Avatar.WinStreak;

                        // ВИНСТРИК SHOWDOWN
                        if (rank <= 4)
                        {
                            player.Avatar.WinStreak += 1;
                            player.Avatar.MaxWinstreak = LogicMath.Max(player.Avatar.MaxWinstreak, player.Avatar.WinStreak);
                        }
                        else
                        {
                            player.Avatar.WinStreak = 0;
                        }

                        // МАСТЕРСТВО SHOWDOWN
                        Random random = new Random();
                        int masteryGain = random.Next(50, 201);
                        if (hero != null)
                        {
                            hero.MasteryPoints += masteryGain;
                            message.MasteryGained = masteryGain;
                        }
                        
                        // ТОКЕНЫ SHOWDOWN
                        int baseTokens = random.Next(20, 151);
                        int doublersAvailable = player.Home?.TokenDoublers ?? 0;
                        int doublersUsed = Math.Min(doublersAvailable, baseTokens);
                        int finalTokens = baseTokens + doublersUsed;
                        message.TokensReward = baseTokens;
                        message.TokensDoublersReward = doublersUsed;
                        message.TokensRemainingReward = doublersAvailable - doublersUsed;
                        if (player.Home != null) player.Home.TokenDoublers -= doublersUsed;

                        // БОНУС ЗА ВИНСТРИК SHOWDOWN
                        int winstreakBonusTrophies = 0;
                        if (rank <= 4 && player.Avatar.WinStreak > oldWinStreak)
                        {
                            winstreakBonusTrophies = Math.Min(player.Avatar.WinStreak, 5);
                            message.WinstreakTrophies = winstreakBonusTrophies;
                        }

                        if (rank > 5) // ПОРАЖЕНИЕ В SHOWDOWN
                        {
                            int trophiesReward = -(rank - 5);

                            // VIP БОНУС
                            int vipBonus = 0;
                            if (player.Avatar.IsVIP && player.Avatar.VIPExpire > DateTime.UtcNow)
                            {
                                vipBonus = random.Next(5, 9);
                                trophiesReward += vipBonus;
                            }
                            
                            // VIP x2 кубки для SHOWDOWN поражения
                            bool hasDoubleTrophyVIP = player.Avatar.HasDoubleTrophyVIP && 
                                                     player.Avatar.DoubleTrophyVIPEndTime > DateTime.UtcNow;
                            if (hasDoubleTrophyVIP && trophiesReward < 0)
                            {
                                trophiesReward = trophiesReward / 2;
                                Console.WriteLine($"[VIP x2] {player.Avatar.Name}: BR ранк {rank}! Потеря кубков уменьшена в 2 раза: {-(rank - 5) + vipBonus} -> {trophiesReward}");
                            }

                            if (hero != null && hero.Trophies < -trophiesReward)
                            {
                                trophiesReward = -hero.Trophies;
                            }
                            message.TrophiesReward = trophiesReward;
                            player.Avatar.AddTokens(finalTokens);
                            if (player.Home != null) 
                            {
                                player.Home.TokenReward += finalTokens;
                                player.Home.BattleLogs.Add(new BattleLogStructure(), 1, trophiesReward, 0, BattleWithTrophies, m_locationId, rank);
                            }
                            if (hero != null) hero.AddTrophies(message.TrophiesReward);
                        }
                        else // ПОБЕДА В SHOWDOWN (ранк 1-4)
                        {
                            int trophiesReward = (5 - rank) * 2;
                            trophiesReward += winstreakBonusTrophies;

                            // VIP БОНУС
                            int vipBonus = 0;
                            if (player.Avatar.IsVIP && player.Avatar.VIPExpire > DateTime.UtcNow)
                            {
                                vipBonus = random.Next(5, 9);
                                trophiesReward += vipBonus;
                            }
                            
                            // VIP x2 кубки - дополнительные 3 кубка за победу в SHOWDOWN
                            bool hasDoubleTrophyVIP = player.Avatar.HasDoubleTrophyVIP && 
                                                     player.Avatar.DoubleTrophyVIPEndTime > DateTime.UtcNow;
                            if (hasDoubleTrophyVIP && rank <= 4)
                            {
                                trophiesReward += 3;
                                Console.WriteLine($"[VIP x2] {player.Avatar.Name}: BR победа (ранк {rank})! +3 дополнительных кубка! Итого: {trophiesReward} кубков");
                            }

                            message.TrophiesReward = trophiesReward;
                            player.Avatar.AddTokens(finalTokens);
                            if (player.Home != null)
                            {
                                player.Home.TokenReward += finalTokens;
                                player.Home.TrophiesReward += trophiesReward;
                                player.Home.BattleLogs.Add(new BattleLogStructure(), 1, trophiesReward, 0, BattleWithTrophies, m_locationId, rank);
                            }
                            
                            if (rank <= 4)
                            {
                                player.Avatar.AddStarTokens(1);
                                message.StarToken = true;
                                if (player.Home != null) player.Home.StarTokenReward += 1;
                            }
                            if (hero != null) hero.AddTrophies(message.TrophiesReward);
                        }
                        player.Avatar.SoloWins++;
                    }
                    else
                    {
                        int baseTokens = 40 / rank;
                        message.TokensReward = baseTokens;
                    }

                    try
                    {
                        // РЕКОРДЫ SHOWDOWN
                        if (hero != null && hero.Trophies > hero.HighestTrophies)
                        {
                            hero.HighestTrophies = hero.Trophies;
                        }
                        if (player.Avatar != null && player.Avatar.Trophies > player.Avatar.HighestTrophies)
                        {
                            player.Avatar.HighestTrophies = player.Avatar.Trophies;
                        }
                    }
                    catch { }
                }

                message.Winstreak = player.Avatar.WinStreak;
                if (!BattleWithTrophies)
                {
                    message.BattleWithoutTrophies = true;
                }

                player.Avatar.MaxWinstreak = LogicMath.Max(player.Avatar.MaxWinstreak, player.Avatar.WinStreak);

                // МОНЕТНЫЙ ИВЕНТ
                try
                {
                    if (player?.Home != null && player.Home.CoinsEventEnabled)
                    {
                        int coins = GetRandomInt(20, 81);
                        if (coins > 0 && player.Avatar != null)
                        {
                            player.Avatar.AddGold(coins);
                            player.Home.CoinsReward += coins;
                            message.CoinsGained = coins;
                        }
                    }
                }
                catch { }

                if (player.Avatar != null && player.GameListener != null)
                {
                    player.GameListener.SendTCPMessage(message);
                    Console.WriteLine($"[BattleEnd] Отправлено игроку {player.PlayerIndex}: Результат={message.Result}, Кубки={message.TrophiesReward}, Мастерство={message.MasteryGained}, Винстрик={player.Avatar.WinStreak}");
                }
            }
        }

        public void FixStuckBall() { }
        public void RecreateBall() { }
        public void ForceBallReset() { }
        public void SyncBallState() { }
        public void SetBallOwner(Character newOwner) { }

        public void SendBattleEndToPlayer(BattlePlayer player)
        {
            Console.WriteLine($"[BattleMode] WARNING: BattleEnd for individual player called! Player: {player?.PlayerIndex}");
            return;
        }

        public int GetTeamScore(int team)
        {
            int score = 0;
            foreach (BattlePlayer player in m_players)
            {
                if (player.TeamIndex == team) score += player.GetScore();
            }
            return score;
        }

        private int CalculateIsRoundOver()
        {
            if (GetAliveCharactersByTeam(0).Count <= 0 && GetAliveCharactersByTeam(1).Count > 0) return 1;
            if (GetAliveCharactersByTeam(1).Count <= 0 && GetAliveCharactersByTeam(0).Count > 0) return 0;
            if (RoundTicks > 4095) return 2;
            return -1;
        }

        private bool CalculateIsGameOver()
        {
            // ========== НОКАУТ (ID 20) ==========
            if (m_gameModeVariation == GAME_MODE_VARIATION_KNOCKOUT)
            {
                m_team0AliveCount = 0;
                m_team1AliveCount = 0;
                
                foreach (Character character in m_gameObjectManager.GetCharacters())
                {
                    if (character.GetPlayer() != null && character.IsAlive())
                    {
                        if (character.GetPlayer().TeamIndex == 0)
                            m_team0AliveCount++;
                        else if (character.GetPlayer().TeamIndex == 1)
                            m_team1AliveCount++;
                    }
                }
                
                int roundResult = CalculateIsRoundOver();
                if (roundResult != -1 && !nokbool)
                {
                    nokbool = true;
                    KnockoutTicks = 3 * 20;
                    RoundWins[RoundCount] = roundResult;
                    RoundCount++;
                    if (roundResult == 0 || roundResult == 1) TScore[roundResult]++;
                    
                    Console.WriteLine($"[Knockout] Раунд {RoundCount}: Team {roundResult} победила! Счет: {TScore[0]}-{TScore[1]}");
                }
                
                if (TScore[0] >= 2)
                {
                    m_winnerTeam = 0;
                    Console.WriteLine($"[Knockout] Team 0 победила в матче! Счет: {TScore[0]}-{TScore[1]}");
                    return true;
                }
                else if (TScore[1] >= 2)
                {
                    m_winnerTeam = 1;
                    Console.WriteLine($"[Knockout] Team 1 победила в матче! Счет: {TScore[0]}-{TScore[1]}");
                    return true;
                }
                
                if (GetTicksGone() >= 2400)
                {
                    if (GetTeamScore(0) > GetTeamScore(1))
                        m_winnerTeam = 0;
                    else if (GetTeamScore(1) > GetTeamScore(0))
                        m_winnerTeam = 1;
                    else
                        m_winnerTeam = -1;
                    
                    Console.WriteLine($"[Knockout] Time's up! Winner: {(m_winnerTeam == -1 ? "Draw" : $"Team {m_winnerTeam}")}");
                    return true;
                }
                
                return false;
            }

            // ========== ГОРЯЧАЯ ЗОНА (ID 17) ==========
            if (m_gameModeVariation == GAME_MODE_VARIATION_HOT_ZONE)
            {
                if (Zone1Score >= 100)
                {
                    m_winnerTeam = 0;
                    Console.WriteLine($"[HotZone] Team 0 победила! Счет: {Zone1Score}-{Zone2Score}");
                    return true;
                }
                else if (Zone2Score >= 100)
                {
                    m_winnerTeam = 1;
                    Console.WriteLine($"[HotZone] Team 1 победила! Счет: {Zone1Score}-{Zone2Score}");
                    return true;
                }
            }

            // ========== BRAWL BALL (ID 5) ==========
            if (m_gameModeVariation == GAME_MODE_VARIATION_BRAWL_BALL)
            {
                if (GetTeamScore(0) >= 2)
                {
                    m_winnerTeam = 0;
                    Console.WriteLine($"[BrawlBall] Team 0 wins the match with {GetTeamScore(0)} goals!");
                    return true;
                }
                else if (GetTeamScore(1) >= 2)
                {
                    m_winnerTeam = 1;
                    Console.WriteLine($"[BrawlBall] Team 1 wins the match with {GetTeamScore(1)} goals!");
                    return true;
                }
                
                if (GetTicksGone() >= 3200 - 1)
                {
                    if (GetTeamScore(0) == GetTeamScore(1))
                    {
                        m_winnerTeam = -1;
                        Console.WriteLine($"[BrawlBall] Draw at the end of regular time!");
                        return true;
                    }
                    else
                    {
                        m_winnerTeam = GetTeamScore(0) > GetTeamScore(1) ? 0 : 1;
                        Console.WriteLine($"[BrawlBall] Team {m_winnerTeam} wins on time! Score: {GetTeamScore(0)}-{GetTeamScore(1)}");
                        return true;
                    }
                }
                
                return false;
            }

            // ========== СТОЛКНОВЕНИЕ (ID 0) ==========
            if (m_gameModeVariation == GAME_MODE_VARIATION_GEM_GRAB)
            {
                if (GetTeamScore(0) > GetTeamScore(1) && GetTeamScore(0) >= 10)
                {
                    if (m_gemGrabCountdown == 0)
                    {
                        m_gemGrabCountdown = GetTicksGone() + 20 * 17;
                    }
                    else if (GetTicksGone() > m_gemGrabCountdown)
                    {
                        m_winnerTeam = 0;
                        return true;
                    }
                }
                else if (GetTeamScore(0) < GetTeamScore(1) && GetTeamScore(1) >= 10)
                {
                    if (m_gemGrabCountdown == 0)
                    {
                        m_gemGrabCountdown = GetTicksGone() + 20 * 17;
                    }
                    else if (GetTicksGone() > m_gemGrabCountdown)
                    {
                        m_winnerTeam = 1;
                        return true;
                    }
                }
                else
                {
                    m_gemGrabCountdown = 0;
                }
            }

            // ========== ВОЛЕЙБОЛ (ID 25) ==========
            else if (m_gameModeVariation == GAME_MODE_VARIATION_VOLLEYBRAWL)
            {
                if (GetTeamScore(0) >= 10)
                {
                    m_winnerTeam = 0;
                    return true;
                }
                if (GetTeamScore(1) >= 10)
                {
                    m_winnerTeam = 1;
                    return true;
                }
            }

            // ========== SHOWDOWN (ID 6) ==========
            else if (m_gameModeVariation == GAME_MODE_VARIATION_SHOWDOWN)
            {
                if (m_playersAlive <= 1)
                {
                    return true;
                }
            }

            // ========== РЕЖИМЫ С БАЗАМИ (ОГРАБЛЕНИЕ, ОСАДА) ==========
            else if (GameModeUtil.HasTwoBases(m_gameModeVariation))
            {
                bool Base1Alive = false;
                bool Base2Alive = false;
                foreach (Character character in m_gameObjectManager.GetCharacters())
                {
                    if (character.CharacterData.IsBase())
                    {
                        if (character.GetIndex() / 16 == 0) Base1Alive = true;
                        else Base2Alive = true;
                    }
                }
                if (!Base1Alive || !Base2Alive)
                {
                    m_winnerTeam = Base1Alive ? 0 : 1;
                    if (!Base1Alive && !Base2Alive) m_winnerTeam = -1;
                    return true;
                }
            }

            // ========== ПОСЛЕДНИЙ РУБЕЖ (ID 19) ==========
            else if (m_gameModeVariation == GAME_MODE_VARIATION_LAST_STAND)
            {
                int Base1Alive = 0;
                int Base2Alive = 0;
                foreach (Character character in m_gameObjectManager.GetCharacters())
                {
                    if (!character.CharacterData.IsHero()) continue;
                    if (!character.IsAlive()) continue;
                    if (character.GetPlayer() != null && character.GetPlayer().PlayerIndex == GetTeam1King()) Base1Alive = character.GetHitpointPercentage();
                    if (character.GetPlayer() != null && character.GetPlayer().PlayerIndex == GetTeam2King()) Base2Alive = character.GetHitpointPercentage();
                }
                if (Base1Alive <= 0 || Base2Alive <= 0)
                {
                    if (Base1Alive <= 0)
                    {
                        m_winnerTeam = 1;
                    }
                    else if (Base2Alive <= 0)
                    {
                        m_winnerTeam = 0;
                    }
                    return true;
                }
            }

            // ========== ОСАДА (ID 27) ==========
            else if (m_gameModeVariation == GAME_MODE_VARIATION_SIEGE)
            {
                if (GetTeamScore(0) >= 8)
                {
                    m_winnerTeam = 0;
                    return true;
                }
                else if (GetTeamScore(1) >= 8)
                {
                    m_winnerTeam = 1;
                    return true;
                }
            }

            // ========== ДОСТАВКА (ID 33) ==========
            else if (m_gameModeVariation == GAME_MODE_VARIATION_PAYLOAD)
            {
                if (GetTeamScore(0) > GetTeamScore(1) && GetTeamScore(0) >= 20)
                {
                    if (m_gemGrabCountdown == 0)
                    {
                        m_gemGrabCountdown = GetTicksGone() + 20 * 17;
                    }
                    else if (GetTicksGone() > m_gemGrabCountdown)
                    {
                        m_winnerTeam = 0;
                        return true;
                    }
                }
                else if (GetTeamScore(0) < GetTeamScore(1) && GetTeamScore(1) >= 20)
                {
                    if (m_gemGrabCountdown == 0)
                    {
                        m_gemGrabCountdown = GetTicksGone() + 20 * 17;
                    }
                    else if (GetTicksGone() > m_gemGrabCountdown)
                    {
                        m_winnerTeam = 1;
                        return true;
                    }
                }
                else
                {
                    m_gemGrabCountdown = 0;
                }
            }

            // ========== ОХОТА (ID 3) ==========
            else if (m_gameModeVariation == GAME_MODE_VARIATION_BOUNTY)
            {
                int team0Score = GetTeamScore(0);
                int team1Score = GetTeamScore(1);

                if (team0Score >= 20)
                {
                    m_winnerTeam = 0;
                    return true;
                }
                if (team1Score >= 20)
                {
                    m_winnerTeam = 1;
                    return true;
                }
            }

            // ========== ПРОВЕРКА ПО ВРЕМЕНИ ==========
            if (GetTicksGone() >= GameModeUtil.GetBattleTicks(m_gameModeVariation) - 1)
            {
                if (GameModeUtil.HasTwoBases(m_gameModeVariation))
                {
                    int Base1Alive = 0;
                    int Base2Alive = 0;
                    foreach (Character character in m_gameObjectManager.GetCharacters())
                    {
                        if (character.CharacterData.IsBase())
                        {
                            if (character.GetIndex() / 16 == 0) Base1Alive = character.GetHitpointPercentage();
                            else Base2Alive = character.GetHitpointPercentage();
                        }
                    }
                    if (Base1Alive > Base2Alive) m_winnerTeam = 0;
                    else if (Base1Alive < Base2Alive) m_winnerTeam = 1;
                    else m_winnerTeam = -1;
                }
                else if (m_gameModeVariation == GAME_MODE_VARIATION_VOLLEYBRAWL)
                {
                    int team0Score = GetTeamScore(0);
                    int team1Score = GetTeamScore(1);
                    if (team0Score > team1Score)
                        m_winnerTeam = 0;
                    else if (team1Score > team0Score)
                        m_winnerTeam = 1;
                    else
                        m_winnerTeam = -1;
                }
                else if (m_gameModeVariation == GAME_MODE_VARIATION_LAST_STAND)
                {
                    int Base1Alive = 0;
                    int Base2Alive = 0;
                    foreach (Character character in m_gameObjectManager.GetCharacters())
                    {
                        if (!character.CharacterData.IsHero()) continue;
                        if (!character.IsAlive()) continue;
                        if (character.GetPlayer() != null && character.GetPlayer().PlayerIndex == GetTeam1King()) Base1Alive = character.GetHitpointPercentage();
                        if (character.GetPlayer() != null && character.GetPlayer().PlayerIndex == GetTeam2King()) Base2Alive = character.GetHitpointPercentage();
                    }
                    if (Base1Alive > Base2Alive) m_winnerTeam = 0;
                    else if (Base1Alive < Base2Alive) m_winnerTeam = 1;
                    else m_winnerTeam = -1;
                }
                else if (m_gameModeVariation == GAME_MODE_VARIATION_SIEGE)
                {
                    if (GetTeamScore(0) > GetTeamScore(1)) m_winnerTeam = 0;
                    else if (GetTeamScore(0) < GetTeamScore(1)) m_winnerTeam = 1;
                    else m_winnerTeam = -1;
                }
                else if (m_gameModeVariation == GAME_MODE_VARIATION_BOUNTY)
                {
                    int team0Score = GetTeamScore(0);
                    int team1Score = GetTeamScore(1);

                    if (team0Score > team1Score)
                        m_winnerTeam = 0;
                    else if (team1Score > team0Score)
                        m_winnerTeam = 1;
                    else
                        m_winnerTeam = -1;
                }
                
                if (m_gameModeVariation != GAME_MODE_VARIATION_KNOCKOUT && 
                    m_gameModeVariation != GAME_MODE_VARIATION_BRAWL_BALL)
                    return true;
            }
            
            return false;
        }
        
        public int TmpBrawlballTick;
        
        public List<Character> GetAliveCharactersByTeam(int teamIndex)
        {
            if (m_gameObjectManager == null) return null;
            List<Character> teamCharacters = new List<Character>();

            foreach (Character character in m_gameObjectManager.GetCharacters())
            {
                BattlePlayer player = character.GetPlayer();
                if (player != null && player.TeamIndex == teamIndex)
                {
                    if (player.IsAlive) teamCharacters.Add(character);
                }
            }

            return teamCharacters;
        }
        
                private void Tick()
        {
            m_gameObjectManager.Tick();
            m_tileMap.Tick(m_gameObjectManager);
            TickSpawnEventStuffDelayed();
            TickSpawnHeroes();
            TickPetrols();
            
            if (m_gameModeVariation == 27) TickInvasion();
            if (m_gameModeVariation == GAME_MODE_VARIATION_HOT_ZONE) TickKingOfHill();
            
            UpdatePlayerStatus();
            
            if (TmpBrawlballTick > 1) TmpBrawlballTick--;
            if (TmpBrawlballTick == 1) ResetCarryable();
            if(KnockoutTicks > 0) KnockoutTicks--;
            if (KnockoutTicks == 1) ResetRoundLaserBall(false);
            RoundTicks++;
            
            if (m_gameModeVariation == GAME_MODE_VARIATION_BRAWL_BALL && GoalTicks > 0) GoalTicks--;
            if (GoalTicks <= 1 && ToGoalTeam != -1) ResetRoundLaserBall(true);
            if (GoalTicks <= 1 && ToGoalTeam != -1) ToGoalTeam = -1;
        }

        private void TickPetrols()
        {
            List<Petrol> ToRemove = new List<Petrol>();
            foreach (Petrol v5 in m_gameObjectManager.Petrols)
            {
                if (v5.Tick(m_gameObjectManager))
                {
                    ToRemove.Add(v5);
                    foreach (Petrol v9 in m_gameObjectManager.Petrols)
                    {
                        if (v9.TeamIndex == v5.TeamIndex && LogicMath.Abs(v9.X - v5.X) <= 1 && LogicMath.Abs(v9.Y - v5.Y) <= 1) 
                            v9.Ignite(m_gameObjectManager, v5.Damage);
                    }
                }
            }
            foreach (Petrol v1 in ToRemove)
            {
                m_gameObjectManager.Petrols.Remove(v1);
            }
        }
        
        private int lastSpawnTick = -1;
        
        private void TickInvasion()
        {
            int _firstSpawnTick = 150;
            int _otherSpawnTick = 235;

            int ticksGone = GetTicksGone();

            if (ticksGone == _firstSpawnTick ||
               (ticksGone > _firstSpawnTick && (ticksGone - lastSpawnTick) >= _otherSpawnTick))
            {
                AreaEffect area = new AreaEffect(DataTables.Get(DataType.AreaEffect).GetData<AreaEffectData>("InvasionSpawnIncoming"));
                area.SetPosition(m_tileMap.InvasionBotSpawn[new Random().Next(m_tileMap.InvasionBotSpawn.Count)].X + 150, m_tileMap.InvasionBotSpawn[new Random().Next(m_tileMap.InvasionBotSpawn.Count)].Y + 150, 0);
                area.SetIndex(-16);
                area.m_ticksElapsed = GetTicksGone();
                m_gameObjectManager.AddGameObject(area);
                area.Trigger();
                lastSpawnTick = ticksGone;
            }

            if (ticksGone == 1500)
            {
                AreaEffect area = new AreaEffect(DataTables.Get(DataType.AreaEffect).GetData<AreaEffectData>("InvasionSpawnIncoming"));
                area.SetPosition(m_tileMap.InvasionBotSpawn[new Random().Next(m_tileMap.InvasionBotSpawn.Count)].X + 150, m_tileMap.InvasionBotSpawn[new Random().Next(m_tileMap.InvasionBotSpawn.Count)].Y + 150, 0);
                area.SetIndex(-16);
                area.m_ticksElapsed = GetTicksGone();
                m_gameObjectManager.AddGameObject(area);
                area.Trigger();
                lastSpawnTick = ticksGone;
            }
        }
        
        public void UpdatePlayerStatus()
        {
            foreach (BattlePlayer player in m_players)
            {
                if (m_gameObjectManager.GetGameObjectByID(player.OwnObjectId) == null && player.IsAlive && 
                    m_gameObjectManager.AddObjects.ToList().Find(obj => obj.GetGlobalID() == player.OwnObjectId) == null)
                {
                    player.IsAlive = false;
                    player.DeathTick = GetTicksGone();
                }

                Character character = (Character)m_gameObjectManager.GetGameObjectByID(player.OwnObjectId);
                player.UpdateOverCharge();
                
                if (character != null)
                {
                    Accessory v9 = player.Accessory;
                    if (v9 != null) v9.UpdateAccessory(character);
                }
            }
        }
        
        private void SendVisionUpdateToPlayers()
        {
            Parallel.ForEach(m_players, player =>
            {
                if (player.GameListener != null)
                {
                    BitStream visionBitStream = new BitStream(64);
                    m_gameObjectManager.Encode(visionBitStream, m_tileMap, player.OwnObjectId, player.PlayerIndex, player.TeamIndex);

                    VisionUpdateMessage visionUpdate = new VisionUpdateMessage();
                    visionUpdate.Tick = GetTicksGone();
                    visionUpdate.HandledInputs = player.LastHandledInput;
                    visionUpdate.Viewers = m_spectators.Count;
                    visionUpdate.VisionBitStream = visionBitStream;

                    try
                    {
                        player.GameListener.SendMessage(visionUpdate);
                    }
                    catch (Exception)
                    {
                        RemovePlayer(player);
                    }
                }
            });

            BitStream spectateStream = new BitStream(64);
            m_gameObjectManager.Encode(spectateStream, m_tileMap, 0, -1, -1);

            Task.Run(() =>
            {
                foreach (LogicGameListener gameListener in m_spectators.Values.ToArray())
                {
                    VisionUpdateMessage visionUpdate = new VisionUpdateMessage();
                    visionUpdate.Tick = GetTicksGone();
                    visionUpdate.HandledInputs = gameListener.HandledInputs;
                    visionUpdate.Viewers = m_spectators.Count;
                    visionUpdate.VisionBitStream = spectateStream;

                    gameListener.SendMessage(visionUpdate);
                }
            });
        }
        
        public int GetKnockoutRound() => m_knockoutRound;

        public int GetKnockoutRoundWins(int teamIndex)
        {
            if (teamIndex >= 0 && teamIndex < 2 && m_knockoutRoundWins != null)
                return m_knockoutRoundWins[teamIndex];
            return 0;
        }
        
        public int GetTeam0AliveCount() => m_team0AliveCount;
        public int GetTeam1AliveCount() => m_team1AliveCount;

        public BattlePlayer[] GetPlayers() => m_players.ToArray();

        public int GetRandomInt(int min, int max) => m_random.Rand(max - min) + min;
        public int GetRandomInt(int max) => m_random.Rand(max);
        public int GetTicksGone() => m_time.GetTick();
        public int GetGameModeVariation() => m_gameModeVariation;
        public int GetPlayersCountWithGameModeVariation() => m_playersCountWithGameModeVariation;
        public int GetRandomSeed() => m_randomSeed;

        public LocationData Location
        {
            get
            {
                return DataTables.Get(DataType.Location).GetDataByGlobalId<LocationData>(m_locationId);
            }
        }

        public long Id { get; set; }

        public BattlePlayer GetPlayerByAccountId(long accountId)
        {
            if (m_playersByAccountId != null && m_playersByAccountId.TryGetValue(accountId, out var player))
                return player;
            
            player = m_players?.FirstOrDefault(x => x != null && x.AccountId == accountId);
            
            if (player != null && m_playersByAccountId != null)
            {
                m_playersByAccountId[accountId] = player;
            }
            
            return player;
        }
    }
}