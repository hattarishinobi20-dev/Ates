using Newtonsoft.Json;
using Supercell.Laser.Logic.Avatar;
using Supercell.Laser.Logic.Avatar.Structures;
using Supercell.Laser.Logic.Battle;
using Supercell.Laser.Logic.Data;
using Supercell.Laser.Logic.Data.Helper;
using Supercell.Laser.Logic.Helper;
using Supercell.Laser.Logic.Home;
using Supercell.Laser.Logic.Home.Items;
using Supercell.Laser.Logic.Home.Structures;
using Supercell.Laser.Logic.Listener;
using Supercell.Laser.Logic.Message;
using Supercell.Laser.Logic.Message.Home;
using Supercell.Laser.Logic.Message.Ranked;
using Supercell.Laser.Logic.Time;
using Supercell.Laser.Titan.DataStream;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Supercell.Laser.Logic.Ranked
{
    public struct TickAction
    {
        public bool ActionWill;
        public int AtWhenTick;
    }
    public class AtesDev2RankedMatch // ranked by @ates_Dev2
    {
        public long AtesDev2MatchId;
        public List<AtesDev2RankedMatchPlayer> AtesDev2;
        public Timer AtesDev2TempTimer;
        public bool AtesDev2Done;
        public bool AtesDev2Over;
        public GameTime AtesDev2Ticks;
        public bool AtesDev2MatchWithBans = true;
        private bool AtesDev2AllPickedUp;
        private int AtesDev2AllPickedUpLastTick;
        private bool AtesDev2AllBan;
        private int AtesDev2AllBanLastTick;
        private int AtesDev2PostAllPickupTick;
        
        public TickAction AtesDev2AllPlayersBannedAction;
        public TickAction AtesDev2PickupAction;
        public bool AtesDev2PickUpStarted;
        public int AtesDev2PickUpLastTick;
        public List<int> AtesDev2QueueModel;
        public int AtesDev2Round;
        public AtesDev2RankedMatchPlayer AtesDev2Turn;
        private int AtesDev2PrefferedLocation;
        private int AtesDev2PrefferedTeam;
        public int AtesDev2GameRounds;
        public int AtesDev2TrueTeamWins;
        public int AtesDev2TrueRedWins;
        public bool AtesDev2Solo;
        public bool AtesDev2BanDone;
        public bool AtesDev2MatchOver => AtesDev2TrueRedWins >= 2 || AtesDev2TrueTeamWins >= 2;
        
        private static readonly Random _random = new Random();

        public AtesDev2RankedMatch()
        {
            AtesDev2Round = 0;
            AtesDev2QueueModel = new();
            AtesDev2PrefferedTeam = _random.Next(2);
            AtesDev2MatchId = 0;
            AtesDev2Ticks = new();
            AtesDev2 = new();
        }

        public void Start() => AtesDev2TempTimer = new Timer(new TimerCallback(Update), null, 0, 1000 / 20);
        public void Stop()
        {
            AtesDev2TempTimer?.Dispose();
            AtesDev2TempTimer = null;
        }

        public void AddMatchPlayer(AtesDev2RankedMatchPlayer plr)=>AtesDev2.Add(plr);
        public static int CalculatePlayerIndex(int playerPosition, int teamIndex)
        {
            if (playerPosition == 0 && teamIndex == 1)
            {
                return 3;
            }

            if (teamIndex == 0)
            {
                return playerPosition % 3;
            }
            else if (teamIndex == 1)
            {
                return (playerPosition % 3) + 3;
            }
            return -1;
        }
        public void Update(object stateInfo) => Tick();

        public void Tick()
        {
            AtesDev2Ticks.IncreaseTick();
            if (AtesDev2Done) return;
            HandleTerminate();
            if (GetTicks() == 10)
            {
                AtesDev2PrefferedLocation = CalculateRandomMap();
                AtesDev2QueueModel = new List<int> { 0, 1, 2, 3, 4, 5 };

                Send(new RankedMatchStartedMessage
                {
                    Players = AtesDev2,
                    SelectedMap = GlobalId.GetInstanceId(AtesDev2PrefferedLocation),
                    Team = AtesDev2PrefferedTeam,
                    MatchId = AtesDev2MatchId
                });
            }
            if (GetTicks() == 20 * 9)
            {
                if (AtesDev2MatchWithBans)
                {
                    foreach (AtesDev2RankedMatchPlayer p in AtesDev2)
                        p.AtesDev2BanState = 1;
                    Send(new RankedMatchBanStartedMessage());

                    AtesDev2AllBan = false;
                    AtesDev2AllBanLastTick = GetTicks();
                }
                else
                {
                    if (AtesDev2QueueModel.Count > 0 && AtesDev2Round < AtesDev2QueueModel.Count)
                    {
                        AtesDev2Turn = AtesDev2.Find(p => p.AtesDev2PlayerInternalIndex == AtesDev2QueueModel[AtesDev2Round]);
                    }
                    
                    if (AtesDev2Turn != null)
                    {
                        int nextIndex = (AtesDev2Round + 1 < AtesDev2QueueModel.Count) ? AtesDev2QueueModel[AtesDev2Round + 1] : -1;
                        Send(new RankedMatchPickStartedMessage { Player = AtesDev2Turn, Next = nextIndex });
                        AtesDev2Turn.AtesDev2PickState = 0;
                        AtesDev2PickUpStarted = true;
                        AtesDev2PickUpLastTick = GetTicks();
                    }
                }
            }

            if (AtesDev2.All(p => p.AtesDev2Picked) && !AtesDev2AllPickedUp)
            {
                Send(new RankedMatchFinalPreparationStartedMessage());
                AtesDev2AllPickedUp = true;
                AtesDev2AllPickedUpLastTick = GetTicks();
            }

            if (AtesDev2.All(p => p.AtesDev2Banned) && !AtesDev2AllBan)
            {
                Dictionary<long, int> bannedPersons = new();
                foreach (AtesDev2RankedMatchPlayer p in AtesDev2)
                {
                    bannedPersons.Add(p.AtesDev2AccountId, p.AtesDev2BannedCharacter);
                }
                Send(new RankedMatchBanEndedMessage { BannedBrawlers = bannedPersons });
                
                foreach (AtesDev2RankedMatchPlayer p in AtesDev2)
                {
                    p.AtesDev2Character = 0;
                    p.AtesDev2BanState = 0;
                }
                
                if (AtesDev2QueueModel.Count > 0 && AtesDev2Round < AtesDev2QueueModel.Count)
                {
                    AtesDev2Turn = AtesDev2.Find(p => p.AtesDev2PlayerInternalIndex == AtesDev2QueueModel[AtesDev2Round]);
                }
                
                if (AtesDev2Turn != null)
                {
                    int nextIndex = (AtesDev2Round + 1 < AtesDev2QueueModel.Count) ? AtesDev2QueueModel[AtesDev2Round + 1] : -1;
                    Send(new RankedMatchPickStartedMessage { Player = AtesDev2Turn, Next = nextIndex });
                    AtesDev2Turn.AtesDev2PickState = 0;
                    AtesDev2PickUpStarted = true;
                    AtesDev2PickUpLastTick = GetTicks();
                }
                
                AtesDev2AllBan = true;
                AtesDev2BanDone = true;
            }

            if (AtesDev2PickUpStarted && AtesDev2PickUpLastTick + (20 * 16) < GetTicks() && AtesDev2Turn != null)
            {
                Send(new RankedMatchTerminatedMessage { Name = AtesDev2Turn.AtesDev2DisplayData.Name, Reason = 2 });
                AtesDev2Done = true;
            }

            if (AtesDev2AllPickedUp && AtesDev2AllPickedUpLastTick + (20 * 10) < GetTicks())
            {
                LogicServerListener.Instance.StartMatchBattle(AtesDev2, null, AtesDev2PrefferedLocation, (int)AtesDev2MatchId);
                AtesDev2Done = true;
            }

            if (!AtesDev2BanDone && AtesDev2AllBan && AtesDev2AllBanLastTick + (20 * 15) <= GetTicks())
            {
                Dictionary<long, int> bannedPersons = new();
                foreach (AtesDev2RankedMatchPlayer p in AtesDev2)
                {
                    bannedPersons.Add(p.AtesDev2AccountId, p.AtesDev2BannedCharacter);
                }
                Send(new RankedMatchBanEndedMessage { BannedBrawlers = bannedPersons });
                
                foreach (AtesDev2RankedMatchPlayer p in AtesDev2)
                {
                    p.AtesDev2Character = 0;
                    p.AtesDev2BanState = 0;
                }
                
                if (AtesDev2QueueModel.Count > 0 && AtesDev2Round < AtesDev2QueueModel.Count)
                {
                    AtesDev2Turn = AtesDev2.Find(p => p.AtesDev2PlayerInternalIndex == AtesDev2QueueModel[AtesDev2Round]);
                }
                
                if (AtesDev2Turn != null)
                {
                    int nextIndex = (AtesDev2Round + 1 < AtesDev2QueueModel.Count) ? AtesDev2QueueModel[AtesDev2Round + 1] : -1;
                    Send(new RankedMatchPickStartedMessage { Player = AtesDev2Turn, Next = nextIndex });
                    AtesDev2Turn.AtesDev2PickState = 0;
                    AtesDev2PickUpStarted = true;
                    AtesDev2PickUpLastTick = GetTicks();
                }
            }

            TickTimers();
        }

        public void NextTurn()
        {
            AtesDev2Round++;

            if (AtesDev2Round >= AtesDev2QueueModel.Count)
                return;

            AtesDev2Turn = AtesDev2.Find(p => p.AtesDev2PlayerInternalIndex == AtesDev2QueueModel[AtesDev2Round]);
            if (AtesDev2Turn != null)
            {
                AtesDev2PickUpStarted = true;
                AtesDev2Turn.AtesDev2PickState = 0;
                int nextIndex = (AtesDev2Round + 1 < AtesDev2QueueModel.Count) ? AtesDev2QueueModel[AtesDev2Round + 1] : -1;
                Send(new RankedMatchPickStartedMessage { Player = AtesDev2Turn, Next = nextIndex });
                AtesDev2PickUpLastTick = GetTicks();
            }
        }

        public void TickTimers()
        {
            if (AtesDev2PostAllPickupTick > 0) AtesDev2PostAllPickupTick--;
        }

        public void TerminateError(string name)
        {
            Send(new RankedMatchTerminatedMessage { Name = name });
            AtesDev2Done = true;
        }
        public int RestartRound()
        {
            if (AtesDev2TrueRedWins >= 2 || AtesDev2TrueTeamWins >= 2) return -1;
            LogicServerListener.Instance.StartMatchBattle(AtesDev2, null, AtesDev2PrefferedLocation, (int)AtesDev2MatchId, AtesDev2GameRounds);
            return 0;
        }
        
        public void StopMatch()
        {
            AtesDev2Over = true;
            Stop();
        }

        public void HandleTerminate()
        {
            foreach (AtesDev2RankedMatchPlayer p in AtesDev2)
                if (!LogicServerListener.Instance.IsPlayerOnline(p.AtesDev2AccountId))
                {
                    Send(new RankedMatchTerminatedMessage { Name = p.AtesDev2DisplayData.Name , Reason = 2});
                    AtesDev2Done = true;
                }
        }

        public void Send(GameMessage message)
        {
            foreach (AtesDev2RankedMatchPlayer conn in AtesDev2)
                conn.Home.HomeMode.GameListener.SendMessage(message);
        }

        public int CalculateRandomMap()
        {
            List<string> Names = new();
            foreach (RankedLocationsData data in DataTables.Get(DataType.RankedE).GetDatas())
            {
                var locationData = DataTables.Get(DataType.Location).GetData<LocationData>(data.Name);
                if (locationData != null && !GeneralStaticLogic.BlockedEventsForRanked.Contains(locationData.GameModeVariation))
                {
                    Names.Add(data.Name);
                }
            }
            
            if (Names.Count == 0)
            {
                throw new InvalidOperationException("No available ranked maps found");
            }
            
            string random = Names[_random.Next(Names.Count)];
            var selectedLocation = DataTables.Get(DataType.Location).GetData<LocationData>(random);
            if (selectedLocation == null)
            {
                throw new InvalidOperationException($"Location data not found: {random}");
            }
            
            return selectedLocation.GetGlobalId();
        }

        public AtesDev2RankedMatchPlayer GetPlayer(long id) => AtesDev2.Find(p => p.AtesDev2AccountId == id);
        public int GetTicks() => AtesDev2Ticks.GetTick();
    }
    public class AtesDev2RankedMatchPlayer
    {
        public long AtesDev2AccountId;
        public PlayerDisplayData AtesDev2DisplayData;
        public int AtesDev2Character;
        public int AtesDev2BanState;
        public int AtesDev2PickState;
        public bool AtesDev2Picked;
        public bool AtesDev2Banned;
        public Hero AtesDev2HeroData;
        public int AtesDev2PlayerIndex;
        public int AtesDev2PlayerInternalIndex;
        public int AtesDev2TeamIndex;
        public int AtesDev2BannedCharacter;
        [JsonIgnore] public readonly ClientHome Home;
        [JsonIgnore] public readonly ClientAvatar Avatar;
        public AtesDev2RankedMatchPlayer()
        {
            AtesDev2DisplayData = new PlayerDisplayData();
            AtesDev2AccountId = -1;
        }
        public AtesDev2RankedMatchPlayer(ClientAvatar a, ClientHome h) : this()
        {
            Home = h;
            Avatar = a;
        }
        public static AtesDev2RankedMatchPlayer CreateRankedPlayer(ClientAvatar avatar, ClientHome home, int teamIndex, int playerIndex)
        {
            AtesDev2RankedMatchPlayer player = new(avatar, home);
            player.AtesDev2TeamIndex = teamIndex;
            player.AtesDev2PlayerInternalIndex = playerIndex;
            player.AtesDev2PlayerIndex = playerIndex >= 3 ? AtesDev2RankedMatch.CalculatePlayerIndex(playerIndex, teamIndex) : playerIndex;
            player.AtesDev2DisplayData = new(home.ThumbnailId, home.NameColorId, avatar.Name);
            player.AtesDev2AccountId = avatar.AccountId;
            return player;
        }
        public void ChangeHeroData(int character, int state)
        {
            // 0 - cannot ban
            // 1 - can ban
            // 2 - cannot pickup
            // 3 - can pickup
            if (state >= 0 && state <= 1) AtesDev2BanState = state;
            if (state >= 2 && state <= 3)
                switch (state)
                {
                    case 2:
                        AtesDev2PickState = 0;
                        break;
                    case 3:
                        AtesDev2PickState = 1;
                        break;
                }


        }
        public void SetBanQueue(int i) => AtesDev2BanState = i;
        public void SetPickUpQueue(int q) => AtesDev2PickState = q;
        public void Encode(ByteStream Stream)
        {
            ByteStreamHelper.EncodeLogicLong(Stream, AtesDev2AccountId);
            Stream.WriteBoolean(true);
            AtesDev2DisplayData.Encode(Stream);

            Stream.WriteVInt(AtesDev2BanState); // state?
            Stream.WriteVInt(AtesDev2PickState); // PickUp
            Stream.WriteVInt(AtesDev2PlayerIndex); // index 0-2
            ByteStreamHelper.WriteDataReference(Stream, AtesDev2Character); // picked up brawler
            if (AtesDev2Character == 0)
            {
                Stream.WriteVInt(11); // PlayerLVL
                ByteStreamHelper.WriteDataReference(Stream, 0);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                Stream.WriteBoolean(false); // picked up
                Stream.WriteVInt(1); // gear lvl (not used);
                ByteStreamHelper.WriteDataReference(Stream, 0); // gear
                Stream.WriteVInt(1); // gear lvl (not used);
                ByteStreamHelper.WriteDataReference(Stream, 0); // gear
                Stream.WriteVInt(0);
            }
            else
            {
                Hero hero = Avatar.GetHero(AtesDev2Character);
                int _heroLVL = 1;
                int _starpowerId = 0;
                int _gadgetId = 0;
                int _hyperCharge = 0;
                int _gear1GlobalId = 0;
                int _gear2GlobalId = 0;
                if (hero != null)
                {
                    _heroLVL = hero.PowerLevel;
                    _starpowerId =  GlobalId.CreateGlobalId(23, hero.SelectedStarPowerId);
                    _gadgetId = GlobalId.CreateGlobalId(23, hero.SelectedGadgetId);
                    _hyperCharge = GlobalId.CreateGlobalId(23, hero.SelectedOverChargeId);
                    _gear1GlobalId = GlobalId.CreateGlobalId(62, hero.SelectedGearId1);
                    _gear2GlobalId = GlobalId.CreateGlobalId(62, hero.SelectedGearId2);
                }
                Stream.WriteVInt(_heroLVL); // PlayerLVL
                ByteStreamHelper.WriteDataReference(Stream, 0); // Unknown
                ByteStreamHelper.WriteDataReference(Stream, _starpowerId); // brawler starpower
                ByteStreamHelper.WriteDataReference(Stream, _gadgetId); // brawler gadget
                ByteStreamHelper.WriteDataReference(Stream, _hyperCharge); // hypercharge
                Stream.WriteBoolean(AtesDev2Picked); // picked up
                Stream.WriteVInt(1); // gear lvl (not used);
                ByteStreamHelper.WriteDataReference(Stream, _gear1GlobalId); // gear
                Stream.WriteVInt(1); // gear lvl (not used);
                ByteStreamHelper.WriteDataReference(Stream, _gear2GlobalId); // gear
                Stream.WriteVInt(0); // Hero count (not used)
            }
        }
    }
}

// by @ates_dev2\\
