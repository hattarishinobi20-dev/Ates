﻿namespace Supercell.Laser.Server.Database
{
    using MySql.Data.MySqlClient;
    using Newtonsoft.Json;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Server.Database.Cache;
    using Supercell.Laser.Server.Database.Models;
    using Supercell.Laser.Server.Settings;
    using Supercell.Laser.Server.Utils;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class Accounts
    {
        private static long AvatarIdCounter;
        private static string ConnectionString;

        private static List<Account> CachedGlobalRanking = new List<Account>();
        private static Dictionary<int, List<Account>> CachedBrawlerRankings = new Dictionary<int, List<Account>>();
        private static DateTime LastGlobalUpdate = DateTime.MinValue;
        private static DateTime LastBrawlerUpdate = DateTime.MinValue;
        private const int CacheTimeoutSeconds = 15; // Обновление раз в секунду
        private const int RANKING_LIMIT = 200; // Максимум 200 игроков в топе

        public static void Init(string user, string password)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "127.0.0.1";
            builder.UserID = user;
            builder.Password = password;
            builder.SslMode = MySqlSslMode.Disabled;
            builder.Database = Configuration.Instance.DatabaseName;
            builder.CharacterSet = "utf8mb4";
            builder.AllowPublicKeyRetrieval = true;

            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
            {
                DefaultValueHandling = DefaultValueHandling.Include,
                NullValueHandling = NullValueHandling.Ignore
            };

            ConnectionString = builder.ToString();

            AccountCache.Init();

            try
            {
                AvatarIdCounter = GetMaxAvatarId();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[CRITICAL] Ошибка инициализации AvatarIdCounter: {ex.Message}");
            }
        }

        public static long GetMaxAvatarId()
        {
            try
            {
                using var connection = new MySqlConnection(ConnectionString);
                connection.Open();
                using var cmd = new MySqlCommand("SELECT COALESCE(MAX(Id), 0) FROM accounts", connection);
                var result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt64(result) : 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] Ошибка получения максимального ID: {ex.Message}");
                return 0;
            }
        }

        public static Account Create()
        {
            try
            {
                Account account = new Account();
                account.AccountId = ++AvatarIdCounter;
                account.PassToken = Helpers.RandomString(40);

                account.Avatar.AccountId = account.AccountId;
                account.Avatar.PassToken = account.PassToken;

                account.Home.HomeId = account.AccountId;

                Hero hero = new Hero(16000000);
                account.Avatar.Heroes.Add(hero);

                account.Avatar.Gold = 100;

                // Инициализация списков
                foreach (var h in account.Avatar.Heroes)
                {
                    if (h.UnlockedGearInstanceIds == null)
                        h.UnlockedGearInstanceIds = new List<int>();
                }

                if (account.Home.UnlockedSkins == null)
                    account.Home.UnlockedSkins = new List<int>();
                if (account.Home.UnlockedEmotes == null)
                    account.Home.UnlockedEmotes = new List<int>();
                if (account.Home.UnlockedThumbnails == null)
                    account.Home.UnlockedThumbnails = new List<int>();
                if (account.Home.UnlockedTituls == null)
                    account.Home.UnlockedTituls = new List<int>();
                if (account.Avatar.SPGS == null)
                    account.Avatar.SPGS = new List<int>();
                if (account.Avatar.SelectedSPGS == null)
                    account.Avatar.SelectedSPGS = new List<int>();

                string json = JsonConvert.SerializeObject(account);

                using var connection = new MySqlConnection(ConnectionString);
                connection.Open();
                using var cmd = new MySqlCommand("INSERT INTO accounts (`Id`, `Trophies`, `Data`) VALUES (@id, @trophies, @data)", connection);
                cmd.Parameters.AddWithValue("@id", account.AccountId);
                cmd.Parameters.AddWithValue("@trophies", account.Avatar.Trophies);
                cmd.Parameters.AddWithValue("@data", json);
                cmd.ExecuteNonQuery();

                AccountCache.Cache(account);

                return account;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] Ошибка создания аккаунта: {ex.Message}");
                return null;
            }
        }

        public static void Save(Account account)
        {
            if (account == null) return;

            try
            {
                // Инициализация списков
                InitializeAllLists(account);

                string json = JsonConvert.SerializeObject(account);

                using var connection = new MySqlConnection(ConnectionString);
                connection.Open();
                using var cmd = new MySqlCommand("UPDATE accounts SET `Trophies`=@trophies, `Data`=@data WHERE Id = @id", connection);
                cmd.Parameters.AddWithValue("@id", account.AccountId);
                cmd.Parameters.AddWithValue("@trophies", account.Avatar.Trophies);
                cmd.Parameters.AddWithValue("@data", json);
                cmd.ExecuteNonQuery();

                AccountCache.Cache(account);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] Ошибка сохранения аккаунта: {ex.Message}");
            }
        }

        public static Account Load(long id)
        {
            if (AccountCache.IsAccountCached(id))
            {
                var cachedAccount = AccountCache.GetAccount(id);
                if (cachedAccount != null)
                {
                    InitializeAllLists(cachedAccount);
                    return cachedAccount;
                }
            }

            try
            {
                using var connection = new MySqlConnection(ConnectionString);
                connection.Open();
                using var cmd = new MySqlCommand("SELECT `Data` FROM accounts WHERE Id = @id", connection);
                cmd.Parameters.AddWithValue("@id", id);
                using var reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    string jsonData = reader["Data"].ToString();
                    Account account = JsonConvert.DeserializeObject<Account>(jsonData);

                    if (account == null) return null;

                    InitializeAllLists(account);

                    AccountCache.Cache(account);
                    return account;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[CRITICAL] Ошибка загрузки аккаунта {id}: {ex.Message}");
            }

            // Если не удалось загрузить — создаём новый
            return Create();
        }

        private static void InitializeAllLists(Account account)
        {
            if (account == null) return;

            // Только инициализация списков, без создания Avatar и Home
            // так как они уже должны существовать в Account

            if (account.Avatar != null)
            {
                if (account.Avatar.Heroes == null)
                    account.Avatar.Heroes = new List<Hero>();
                
                if (account.Avatar.SPGS == null)
                    account.Avatar.SPGS = new List<int>();
                
                if (account.Avatar.SelectedSPGS == null)
                    account.Avatar.SelectedSPGS = new List<int>();

                // Инициализация героев
                foreach (var hero in account.Avatar.Heroes)
                {
                    if (hero == null) continue;
                    
                    if (hero.UnlockedGearInstanceIds == null)
                        hero.UnlockedGearInstanceIds = new List<int>();

                    if (hero.SelectedGearId1 == 0 && (hero.UnlockedGearInstanceIds == null || !hero.UnlockedGearInstanceIds.Contains(0)))
                        hero.SelectedGearId1 = -1;

                    if (hero.SelectedGearId2 == 0 && (hero.UnlockedGearInstanceIds == null || !hero.UnlockedGearInstanceIds.Contains(0)))
                        hero.SelectedGearId2 = -1;
                }
            }

            if (account.Home != null)
            {
                if (account.Home.UnlockedSkins == null)
                    account.Home.UnlockedSkins = new List<int>();
                
                if (account.Home.UnlockedEmotes == null)
                    account.Home.UnlockedEmotes = new List<int>();
                
                if (account.Home.UnlockedThumbnails == null)
                    account.Home.UnlockedThumbnails = new List<int>();
                
                if (account.Home.UnlockedTituls == null)
                    account.Home.UnlockedTituls = new List<int>();
            }
        }

        // 🔧 Оптимизированный метод получения глобального рейтинга
        public static List<Account> GetRankingList()
        {
            var now = DateTime.UtcNow;
            if ((now - LastGlobalUpdate).TotalSeconds > CacheTimeoutSeconds)
            {
                RefreshGlobalRankingCache();
                LastGlobalUpdate = now;
            }
            return CachedGlobalRanking ?? new List<Account>();
        }

        // 🔧 Оптимизированный метод получения рейтинга по бравлеру
        public static List<Account> GetBrawlerRankingList(int heroDataId)
        {
            var now = DateTime.UtcNow;
            if (!CachedBrawlerRankings.ContainsKey(heroDataId) || (now - LastBrawlerUpdate).TotalSeconds > CacheTimeoutSeconds)
            {
                RefreshBrawlerRankingCache(heroDataId);
                LastBrawlerUpdate = now;
            }
            
            if (CachedBrawlerRankings.TryGetValue(heroDataId, out var ranking))
                return ranking ?? new List<Account>();
            
            return new List<Account>();
        }

        // 🔧 Обновление глобального рейтинга
        private static void RefreshGlobalRankingCache()
        {
            var list = new List<Account>();
            try
            {
                using var connection = new MySqlConnection(ConnectionString);
                connection.Open();
                using var cmd = new MySqlCommand(
                    "SELECT `Data` FROM accounts WHERE `Trophies` > 0 ORDER BY `Trophies` DESC LIMIT @limit",
                    connection);
                cmd.Parameters.AddWithValue("@limit", RANKING_LIMIT);
                using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    try
                    {
                        string jsonData = reader["Data"].ToString();
                        var account = JsonConvert.DeserializeObject<Account>(jsonData);
                        
                        if (account != null)
                        {
                            InitializeAllLists(account);
                            list.Add(account);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[RANKING] Ошибка десериализации аккаунта: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[RANKING] Ошибка получения глобального списка: {ex.Message}");
            }
            
            CachedGlobalRanking = list;
        }

        // 🔧 Обновление бравлер-специфичного рейтинга
        private static void RefreshBrawlerRankingCache(int heroDataId)
        {
            var list = new List<Account>();
            try
            {
                using var connection = new MySqlConnection(ConnectionString);
                connection.Open();

                using var cmd = new MySqlCommand(
                    "SELECT `Data` FROM accounts WHERE `Trophies` > 0 ORDER BY `Trophies` DESC",
                    connection);
                using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    try
                    {
                        string jsonData = reader["Data"].ToString();
                        var account = JsonConvert.DeserializeObject<Account>(jsonData);

                        if (account != null)
                        {
                            InitializeAllLists(account);
                            
                            var hero = account.Avatar?.GetHero(heroDataId);
                            if (hero != null && hero.Trophies > 0)
                            {
                                list.Add(account);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[RANKING] Ошибка десериализации аккаунта в бравлер-рейтинге: {ex.Message}");
                    }
                }

                list.Sort((a, b) =>
                {
                    var aHero = a?.Avatar?.GetHero(heroDataId);
                    var bHero = b?.Avatar?.GetHero(heroDataId);
                    
                    int aTrophies = aHero?.Trophies ?? 0;
                    int bTrophies = bHero?.Trophies ?? 0;
                    
                    return bTrophies.CompareTo(aTrophies);
                });

                // Ограничиваем список до RANKING_LIMIT элементов
                if (list.Count > RANKING_LIMIT)
                {
                    list = list.Take(RANKING_LIMIT).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[RANKING] Ошибка получения бравлер-рейтинга: {ex.Message}");
            }

            CachedBrawlerRankings[heroDataId] = list;
        }

        public static List<long> GetAllAccountIdsFromDatabase()
        {
            var accountIds = new List<long>();
            try
            {
                using var connection = new MySqlConnection(ConnectionString);
                connection.Open();
                using var cmd = new MySqlCommand("SELECT Id FROM accounts", connection);
                using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    long accountId = reader.GetInt64("Id");
                    accountIds.Add(accountId);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Accounts] Ошибка при получении всех AccountId: {ex.Message}");
            }
            return accountIds;
        }
    }
}