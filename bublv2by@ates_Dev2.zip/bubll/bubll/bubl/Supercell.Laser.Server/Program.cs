﻿/*
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║                        BUBLL                              ║
║                  BY TG@ATES_dEV2                          ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
*/

namespace Supercell.Laser.Server
{
    using Masuda.Net;
    using Masuda.Net.HelpMessage;
    using Masuda.Net.Models;
    using Supercell.Laser.Server.Database.Models;
    using Supercell.Laser.Server.Database;
    using Supercell.Laser.Server.Handler;
    using Supercell.Laser.Server.Settings;
    using Supercell.Laser.Titan.Debug;
    using System.Drawing;
    using Supercell.Laser.Server.Networking.Session;
    using Supercell.Laser.Server.Fingerprint;
    using System.Threading.Tasks;
    using Supercell.Laser.Server.Bot;

    static class Program
    {
        public const string SERVER_VERSION = "1.7";
        public const string BUILD_TYPE = "Beta";

        private static async Task Main(string[] args)
        {
       
            Console.WriteLine(@"
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║                        BUBLL                              ║
║                  BY TG@ATES_dEV2                          ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
");

            Console.Title = "Supercell.Laser";
            Directory.SetCurrentDirectory(AppContext.BaseDirectory);
            RefreshFingerprint.Main();

            Colorful.Console.WriteWithGradient(
                @"    


                            START

                           " + "\n\n\n", Color.DarkRed, Color.Red, 12);

            Logger.Print("72%");

            // 1. Инициализация логгера
            Logger.Init();

            // 2. Загрузка конфигурации
            Configuration.Instance = Configuration.LoadFromFile("config.json");

            // 3. Инициализация ресурсов
            Resources.InitDatabase();
            Resources.InitLogic();
            Resources.InitNetwork();

            // 4. Вывод сообщения о запуске
            
            Logger.Print("sex Development");
          
            // 5. Инициализация ExitHandler
            ExitHandler.Init();

            // 6. ЗАПУСК CmdHandler В ОТДЕЛЬНОМ ПОТОКЕ
            // Это ключевое изменение
            _ = Task.Run(() => CmdHandler.Start());

            // 7. Запуск Telegram-бота
            // В Program.cs после всех инициализаций:

// Бот 1: Redirect (старый токен) - в фоне
_ = Task.Run(async () =>
{
    Console.WriteLine("RedirectBot запущен");
    await Supercell.Laser.Server.Bot.TelegramBot.StartRedirectBot();
});

// Бот 2: Основной (новый токен) - основной поток
var telegramBot = new Supercell.Laser.Server.Bot.TelegramBot();
await telegramBot.StartAsync();

            // 8. Бесконечная задержка (должна быть ПОСЛЕ всех инициализаций)
            await Task.Delay(-1);
        }
    }
}