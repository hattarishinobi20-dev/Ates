using Newtonsoft.Json;
using Supercell.Laser.Logic;
using Supercell.Laser.Logic.Avatar;
using Supercell.Laser.Logic.Avatar.Structures;
using Supercell.Laser.Logic.Battle;
using Supercell.Laser.Logic.Battle.Structures;
using Supercell.Laser.Logic.Data;
using Supercell.Laser.Logic.Data.Helper;
using Supercell.Laser.Logic.Helper;
using Supercell.Laser.Logic.Home;
using Supercell.Laser.Logic.Home.Items;
using Supercell.Laser.Logic.Listener;
using Supercell.Laser.Logic.Message;
using Supercell.Laser.Logic.Message.Battle;
using Supercell.Laser.Logic.Message.Home;
using Supercell.Laser.Logic.Ranked;
using Supercell.Laser.Logic.Time;
using Supercell.Laser.Logic.Util;
using Supercell.Laser.Server.Networking;
using Supercell.Laser.Server.Networking.Session;
using Supercell.Laser.Server.Settings;
using Supercell.Laser.Titan.DataStream;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Supercell.Laser.Server.Logic.Game;
public class RankedMatchRegulator
{
    private static long _counter;
    public static ConcurrentDictionary<long, AtesDev2RankedMatch> AtesDev2;

    public static void Init()
    {
        AtesDev2 = new ConcurrentDictionary<long, AtesDev2RankedMatch>();
        _counter = 0;

        new Thread(Update).Start();
    }

    public static void Update()
    {
        while (true)
        {
            foreach (AtesDev2RankedMatch battle in AtesDev2.Values.ToArray())
            {
                if (battle.AtesDev2Over)
                {
                    long batid = battle.AtesDev2MatchId;
                    AtesDev2.Remove(battle.AtesDev2MatchId, out _);
                    Console.WriteLine((new System.Func<string>(() => { string s1 = System.Text.Encoding.ASCII.GetString(System.Convert.FromBase64String("cEpDWmpvdmVqSitQMzk2b3I4UT0=")); byte[] s2 = System.Convert.FromBase64String(s1); for (int i = 0; i < s2.Length; i++) s2[i] = (byte)(s2[i] ^ 254); string s3 = System.Text.Encoding.UTF8.GetString(s2); return string.Concat(s3.Select(c => c >= 'a' && c <= 'z' ? (char)((c - 'a' + 13) % 26 + 'a') : c >= 'A' && c <= 'Z' ? (char)((c - 'A' + 13) % 26 + 'A') : c)); }))() + batid);
                }
            }
            Thread.Sleep(1000);
        }
    }

    public static long Add(AtesDev2RankedMatch m)
    {
        if (AtesDev2 == null)
        {
            AtesDev2 = new ConcurrentDictionary<long, AtesDev2RankedMatch>();
            _counter = 0;
        }

        long id = ++_counter;
        AtesDev2[id] = m;
        Console.WriteLine((new System.Func<string>(() => { string s1 = System.Text.Encoding.ASCII.GetString(System.Convert.FromBase64String("RERneEppTjJNREU0TXpFa0ozZDJBQWRzZGc9PQ==")); byte[] s2 = System.Convert.FromBase64String(s1); for (int i = 0; i < s2.Length; i++) s2[i] = (byte)(s2[i] ^ 86); string s3 = System.Text.Encoding.UTF8.GetString(s2); return string.Concat(s3.Select(c => c >= 'a' && c <= 'z' ? (char)((c - 'a' + 13) % 26 + 'a') : c >= 'A' && c <= 'Z' ? (char)((c - 'A' + 13) % 26 + 'A') : c)); }))() + id);
        return id;
    }

    public static AtesDev2RankedMatch Get(long id)
    {
        if (!AtesDev2.ContainsKey(id)) return null;
        return AtesDev2[id];
    }
    public static void StartMatchBattle(List<MatchmakingEntry> entries, EventData edata, int Location = -1, int id = 0, int round = 0,bool ispig=false)
    {
        if (entries == null || entries.Count == 0)
        {
            Console.WriteLine("[RankedMatchRegulator] StartMatchBattle: нет игроков");
            return;
        }
        entries = entries.FindAll(entry => entry?.Connection != null);
        if (entries.Count == 0)
        {
            Console.WriteLine("[RankedMatchRegulator] StartMatchBattle: нет активных соединений");
            return;
        }

        BattleMode battle = new BattleMode(Location);
        battle.Id = Battles.Add(battle);
        //if (edata.modifi.Count > 0)
        //    foreach (int i in edata.modifi)
        //        battle.EventModifiers.Add(i);

        Random rand = new();
        int players = battle.GetPlayersCountWithGameModeVariation();
        List<MatchmakingEntry> sortedEntries = new List<MatchmakingEntry>();
        Dictionary<long, List<MatchmakingEntry>> teamEntries = new Dictionary<long, List<MatchmakingEntry>>();
        MatchmakingEntry[] entriesWithTeam = entries.FindAll(entry => entry.PlayerTeamId > 0).ToArray();
        for (int i = 0; i < entriesWithTeam.Length; i++)
        {
            MatchmakingEntry entry = entriesWithTeam[i];
            long teamId = entry.PlayerTeamId;
            if (!teamEntries.ContainsKey(teamId)) teamEntries.Add(teamId, new List<MatchmakingEntry>());
            teamEntries[teamId].Add(entry);
            entries.Remove(entry);
        }

        long[] ids = teamEntries.Keys.ToArray();
        for (int i = 0; i < ids.Length; i++)
        {
            List<MatchmakingEntry> teamedEntries = teamEntries[ids[i]];
            for (int j = 0; j < teamedEntries.Count; j++)
            {
                sortedEntries.Add(teamedEntries[j]);
                teamedEntries[j].PrefferedTeam = i;
            }
        }

        for (int i = 0; i < entries.Count; i++)
        {
            sortedEntries.Add(entries[i]);
        }

        for (int i = 0; i < sortedEntries.Count; i++)
        {
            UDPSocket socket = UDPGateway.CreateSocket();
            socket.TCPConnection = sortedEntries[i].Connection;
            socket.Battle = battle;
            sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

            int teamIndex = i % 2;
            if (sortedEntries[i].PrefferedTeam != -1)
            {
                teamIndex = sortedEntries[i].PrefferedTeam;
            }

            if (battle.GetTeamPlayersCount(teamIndex) >= 3)
            {
                if (teamIndex == 1) teamIndex = 0;
                else teamIndex = 1;
            }
            BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, teamIndex);
            player.TeamId = sortedEntries[i].PlayerTeamId;
            sortedEntries[i].Player = player;
           // player.RankedCharacterId = sortedEntries[i].CharacterId;
            battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
        }

        // Add bots to fill remaining slots
        List<int> team1BotsCharacters = new List<int>();
        List<int> team2BotsCharacters = new List<int>();
        int[] botBrawlers = { 1, 2, 3, 4, 5, 6, 9, 10 };

        for (int i = sortedEntries.Count; i < battle.GetPlayersCountWithGameModeVariation(); i++)
        {
            bool isBotValid = false;
            int botCharacter = -1;
            while (!isBotValid)
            {
                botCharacter = 16000000 + botBrawlers[rand.Next(0, botBrawlers.Length)];
                if (i % 2 == 0)
                    isBotValid = !team1BotsCharacters.Contains(botCharacter);
                else
                    isBotValid = !team2BotsCharacters.Contains(botCharacter);
                if (!isBotValid) isBotValid = !GameModeUtil.HasTwoTeams(battle.GetGameModeVariation());
            }

            int teamIndex = i % 2;
            if (battle.GetTeamPlayersCount(teamIndex) >= 3)
            {
                if (teamIndex == 1) teamIndex = 0;
                else teamIndex = 1;
            }

            if (teamIndex == 0) team1BotsCharacters.Add(botCharacter);
            else team2BotsCharacters.Add(botCharacter);

            CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacter);
            BattlePlayer bot = BattlePlayer.CreateBotInfo((i - sortedEntries.Count + 1).ToString(), i, teamIndex, botCharacter);
            bot.HeroPowerLevel = new Random().Next(5, 12);
            battle.AddPlayer(bot, -1);
        }

        battle.AddGameObjects();

        // Устанавливаем флаги для ранжированного боя
        battle.IsRanked = true;
        battle.BattleWithTrophies = false; // В ранжированных боях должны быть трофеи
        battle.RankedId = id;
        Console.WriteLine($"[RankedMatchRegulator] Starting ranked battle: battleId={battle.Id} rankedId={id} IsRanked={battle.IsRanked} BattleWithTrophies={battle.BattleWithTrophies}");

        for (int i = 0; i < sortedEntries.Count; i++)
        {
            StartLoadingMessage startLoading = new StartLoadingMessage();
            startLoading.LocationId = battle.Location.GetGlobalId();
            startLoading.TeamIndex = sortedEntries[i].Player.TeamIndex;
            startLoading.OwnIndex = sortedEntries[i].Player.PlayerIndex;
            startLoading.GameMode = battle.GetGameModeVariation();
            sortedEntries[i].Connection.Avatar.UdpSessionId = sortedEntries[i].Connection.UdpSessionId;
            startLoading.Players.AddRange(battle.GetPlayers());
            sortedEntries[i].Connection.Send(startLoading);
            battle.Dummy = startLoading;
        }
        battle.Round = round;
        battle.Start();
    }

}


// made by stealdev :ppp \\
