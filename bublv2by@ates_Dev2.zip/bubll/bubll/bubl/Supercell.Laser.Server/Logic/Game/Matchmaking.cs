namespace Supercell.Laser.Server.Logic.Game
{
    using Masuda.Net;
    using Supercell.Laser.Logic.Battle;
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Command.Home;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Logic.Message.Battle;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Logic.Notification;
    using Supercell.Laser.Logic.Ranked;
    using Supercell.Laser.Logic.Team;
    using Supercell.Laser.Logic.Util;
    using Supercell.Laser.Server.Networking;
    using Supercell.Laser.Server.Networking.Session;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using System.Threading;

    public static class Matchmaking
    {
        private static Dictionary<int, MatchmakingSlot> Slots;
        private static Thread UpdateThread;

        public static void Init()
        {
            Slots = new Dictionary<int, MatchmakingSlot>();

            foreach (EventData e in Events.GetEvents())
            {
                if (e == null || e.Location == null) continue;
                
                int mode = GameModeUtil.GetGameModeVariation(e.Location.GameModeVariation);
                
                // ????????? ????????????? ?????? ??? ??????? ???? (????? 14 ? 15)
                if ((e.Slot == 14 || e.Slot == 15) && IsBannedRankedMode(mode))
                {
                    Console.WriteLine($"[Matchmaking] Skipping banned ranked mode {mode} for slot {e.Slot}");
                    continue;
                }
                
                MatchmakingSlot slot = new(e, GamePlayUtil.GetPlayerCountWithGameModeVariation(mode));
                slot.Slot = e.Slot;
                Slots.Add(e.Slot, slot);
            }

            Console.WriteLine($"[Matchmaking] Init: slots=[{string.Join(",", Slots.Keys.OrderBy(x => x))}]");
            Console.WriteLine($"[Matchmaking] Init: hasRanked14={Slots.ContainsKey(14)} hasRanked15={Slots.ContainsKey(15)}");

            UpdateThread = new Thread(Update);
            UpdateThread.Start();
        }

        // ???????? ?? ??????????? ?????? ??? ??????? ????
        public static bool IsBannedRankedMode(int gameModeVariation)
        {
            // ?????????: HotZone (3), BrawlBall (5), Knockout (20)
            return gameModeVariation == 3 || gameModeVariation == 5 || gameModeVariation == 20;
        }

        private static void Update()
        {
            while (true)
            {
                foreach (MatchmakingSlot slot in Slots.Values)
                {
                    slot.Update();
                }
                Thread.Sleep(250);
            }
        }

        public static void RequestMatchmake(Connection connection, int slot, long team = -1)
        {
            Console.WriteLine($"[Matchmaking.RequestMatchmake] slot={slot}, team={team}, accountId={connection?.Avatar?.AccountId ?? 0}");

            if (!Slots.ContainsKey(slot))
            {
                Console.WriteLine($"[Matchmaking.RequestMatchmake] Slot {slot} not found! Available slots: [{string.Join(",", Slots.Keys.OrderBy(x => x))}]");
                return;
            }

            var eventData = Events.GetEvent(slot);
            int gameModeVariation = 0;
            if (eventData != null && eventData.Location != null)
                gameModeVariation = GameModeUtil.GetGameModeVariation(eventData.Location.GameModeVariation);

            Console.WriteLine($"[Matchmaking.RequestMatchmake] EventData found: slot={slot}, gameMode={eventData?.Location?.GameModeVariation}, variation={gameModeVariation}, isRanked={Slots[slot].IsRanked}");

            if (gameModeVariation == 6 && team > 0)
            {
                TeamEntry teamEntry = Teams.Get(team);
                if (teamEntry != null)
                {
                    long groupId = DateTime.UtcNow.Ticks + teamEntry.Id;
                    foreach (var member in teamEntry.Members)
                    {
                        Session session = Sessions.GetSession(member.AccountId);
                        if (session != null && session.Connection != null)
                        {
                            session.Connection.MatchmakeSlot = slot;
                            MatchmakingEntry soloEntry = new MatchmakingEntry(session.Connection);
                            soloEntry.PlayerTeamId = 0;
                            soloEntry.GroupId = groupId;
                            session.Connection.MatchmakingEntry = soloEntry;
                            Slots[slot].Add(soloEntry);
                        }
                    }
                }
                return;
            }

            connection.MatchmakeSlot = slot;
            MatchmakingEntry entry = new MatchmakingEntry(connection);
            entry.PlayerTeamId = team;
            connection.MatchmakingEntry = entry;
            Slots[slot].Add(entry);
        }

        public static void RequestRankedMatchmake(Connection connection, bool solo, int prefferedTeam = -1)
        {
            connection.MatchmakeSlot = solo ? 14 : 15;
            MatchmakingEntry entry = new MatchmakingEntry(connection);
            if (prefferedTeam != -1) entry.PrefferedTeam = prefferedTeam;
            connection.MatchmakingEntry = entry;
            int slot = solo ? 14 : 15;
            Console.WriteLine($"[Matchmaking] RequestRankedMatchmake: acc={connection?.Avatar?.AccountId ?? 0} solo={solo} slot={slot} hasSlot={Slots.ContainsKey(slot)}");
            if (!Slots.ContainsKey(slot))
            {
                Console.WriteLine($"[Matchmaking] RequestRankedMatchmake: ERROR slot {slot} missing.");
                return;
            }
            Slots[slot].Add(entry);
        }

        public static void CancelMatchmake(Connection connection)
        {
            if (connection == null)
                return;

            int slot = connection.MatchmakeSlot;
            if (Slots != null && Slots.ContainsKey(slot))
            {
                connection.MatchmakeSlot = -1;
                if (connection.MatchmakingEntry != null)
                    Slots[slot].Remove(connection.MatchmakingEntry);

                if (connection.MatchmakingEntry != null && connection.MatchmakingEntry.PlayerTeamId > 0)
                {
                    TeamEntry team = Teams.Get(connection.MatchmakingEntry.PlayerTeamId);
                    if (team != null)
                    {
                        foreach (TeamMember member in team.Members)
                        {
                            try
                            {
                                member.IsReady = false;
                                Session session = Sessions.GetSession(member.AccountId);
                                if (session != null && session.Connection != null && session.Connection.MatchmakingEntry != null)
                                {
                                    session.Connection.MatchmakingEntry.PlayerTeamId = -1;
                                    CancelMatchmake(session.Connection);
                                    MatchMakingCancelledMessage cancelled = new MatchMakingCancelledMessage();
                                    if (session.Connection.IsOpen)
                                    {
                                        session.Connection.Send(cancelled);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"[Matchmaking] Error cancelling team member: {ex.Message}");
                            }
                        }
                        team.TeamUpdated();
                    }
                }
            }
        }
    }

    public class MatchmakingSlot
    {
        private Queue<MatchmakingEntry> RequestQueue;
        private Queue<MatchmakingEntry> RemoveQueue;

        private List<MatchmakingEntry> Queue;

        private int PlayersRequired;
        private EventData EventData;

        public int SecondsLeft;
        private int Turns;

        public const int SEARCH_TIMEOUT = 10;
        public const int RANKED_SEARCH_TIMEOUT = 3;
        public int Slot { get; set; }
        public bool IsRanked => Slot == 14 || Slot == 15;

        public MatchmakingSlot(EventData eventData, int playersRequired)
        {
            PlayersRequired = playersRequired;
            if (GameModeUtil.GetGameModeVariation(eventData.Location.GameModeVariation) == 6)
            {
                PlayersRequired = 10;
            }
            EventData = eventData;
            Queue = new List<MatchmakingEntry>();

            RequestQueue = new Queue<MatchmakingEntry>();
            RemoveQueue = new Queue<MatchmakingEntry>();

            SecondsLeft = IsRanked ? RANKED_SEARCH_TIMEOUT : SEARCH_TIMEOUT;
        }

        public void Update()
        {
            if (IsRanked)
            {
                int gameModeVariation = GameModeUtil.GetGameModeVariation(EventData.Location.GameModeVariation);
                
                // ?????????? ??????????? ?????? ? ??????? ????
                if (Matchmaking.IsBannedRankedMode(gameModeVariation))
                {
                    Console.WriteLine($"[Matchmaking] Skipping banned ranked mode {gameModeVariation} in update");
                    return;
                }
                
                PlayersRequired = GamePlayUtil.GetPlayerCountWithGameModeVariation(gameModeVariation);
            }
            else
            {
                int gameModeVariation = GameModeUtil.GetGameModeVariation(EventData.Location.GameModeVariation);
                PlayersRequired = gameModeVariation == 6 ? 10 : 6;
            }

            if (Sessions.Maintenance) return;

            // ??????? ??????????? ???????
            foreach (MatchmakingEntry entry in Queue)
            {
                try
                {
                    if (entry?.Connection?.IsOpen != true)
                    {
                        Console.WriteLine($"[Matchmaking] Removing disconnected entry: accountId={entry?.Connection?.Avatar?.AccountId ?? 0}");
                        Remove(entry);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Matchmaking] Error checking entry connection: {ex.Message}");
                    if (entry != null) Remove(entry);
                }
            }

            if (EventData.Slot == 5)
            {
                LogicAddNotificationCommand logicAddNotificationCommand = new LogicAddNotificationCommand();
                logicAddNotificationCommand.Notification = new FloaterTextNotification("Sorry, this gamemode unavailable\nTry another gamemode");
                AvailableServerCommandMessage availableServerCommandMessage = new AvailableServerCommandMessage();
                availableServerCommandMessage.Command = logicAddNotificationCommand;
                foreach (MatchmakingEntry member in Queue)
                {
                    try
                    {
                        if (member?.Connection?.Home?.HomeMode?.GameListener != null)
                        {
                            member.Connection.Home.HomeMode.GameListener.SendMessage(availableServerCommandMessage);
                            member.Connection.Home.HomeMode.GameListener.SendMessage(new MatchMakingCancelledMessage());
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[Matchmaking] Error sending cancelled message: {ex.Message}");
                    }
                    finally
                    {
                        if (member != null) Remove(member);
                    }
                }
            }

            while (RemoveQueue.Count > 0)
            {
                Queue.Remove(RemoveQueue.Dequeue());
            }

            while (RequestQueue.Count > 0)
            {
                MatchmakingEntry entry = RequestQueue.Dequeue();
                MatchmakingEntry check = Queue.Find(x => x.Connection == entry.Connection);
                if (check != null) continue;
                Queue.Add(entry);
            }

            // ?????????? ??????? ??? ??????
            if (Queue.Count >= PlayersRequired)
            {
                Console.WriteLine($"[Matchmaking] Queue has {Queue.Count} players, required {PlayersRequired} for slot {EventData.Slot} (IsRanked={IsRanked})");
                List<MatchmakingEntry> playersToStart = new List<MatchmakingEntry>();

                if (GameModeUtil.HasTwoTeams(GameModeUtil.GetGameModeVariation(EventData.Location.GameModeVariation)))
                {
                    Dictionary<long, List<MatchmakingEntry>> teamGroups = new Dictionary<long, List<MatchmakingEntry>>();
                    List<MatchmakingEntry> soloPlayers = new List<MatchmakingEntry>();

                    foreach (MatchmakingEntry entry in Queue)
                    {
                        if (entry.PlayerTeamId > 0)
                        {
                            if (!teamGroups.ContainsKey(entry.PlayerTeamId))
                                teamGroups[entry.PlayerTeamId] = new List<MatchmakingEntry>();
                            teamGroups[entry.PlayerTeamId].Add(entry);
                        }
                        else
                        {
                            soloPlayers.Add(entry);
                        }
                    }

                    int totalTeamPlayers = teamGroups.Values.Sum(team => team.Count);
                    int totalPlayers = totalTeamPlayers + soloPlayers.Count;

                    if (totalPlayers >= 1)
                    {
                        List<MatchmakingEntry> team1 = new List<MatchmakingEntry>();
                        List<MatchmakingEntry> team2 = new List<MatchmakingEntry>();

                        // ???????????? ??????
                        foreach (var teamGroup in teamGroups.Values)
                        {
                            if (team1.Count + teamGroup.Count <= 3)
                            {
                                foreach (var p in teamGroup) p.PrefferedTeam = 0;
                                team1.AddRange(teamGroup);
                            }
                            else if (team2.Count + teamGroup.Count <= 3)
                            {
                                foreach (var p in teamGroup) p.PrefferedTeam = 1;
                                team2.AddRange(teamGroup);
                            }
                        }

                        // ???????????? ???? ???????
                        foreach (var soloPlayer in soloPlayers)
                        {
                            if (team1.Count == 0 && team2.Count == 0)
                            {
                                // ?????? ???? ????? ???? ? ??????? 1
                                soloPlayer.PrefferedTeam = 0;
                                team1.Add(soloPlayer);
                            }
                            else if (team1.Count == 1 && team2.Count == 0 && soloPlayers.Count == 2)
                            {
                                // ?????? ???? ????? (????? ????? 2 ??????) ???? ? ??????? 2
                                soloPlayer.PrefferedTeam = 1;
                                team2.Add(soloPlayer);
                            }
                            else if (team1.Count < team2.Count)
                            {
                                soloPlayer.PrefferedTeam = 0;
                                team1.Add(soloPlayer);
                            }
                            else if (team2.Count < team1.Count)
                            {
                                soloPlayer.PrefferedTeam = 1;
                                team2.Add(soloPlayer);
                            }
                            else
                            {
                                // ??????? ?????, ???????????? ??????????
                                if (team1.Count < 3)
                                {
                                    soloPlayer.PrefferedTeam = 0;
                                    team1.Add(soloPlayer);
                                }
                                else if (team2.Count < 3)
                                {
                                    soloPlayer.PrefferedTeam = 1;
                                    team2.Add(soloPlayer);
                                }
                            }
                        }

                        if (team1.Count > 0 && team2.Count > 0)
                        {
                            Console.WriteLine($"[Matchmaking] Teams: Team1={team1.Count}, Team2={team2.Count}");
                            Console.WriteLine($"[Matchmaking] Team1: {string.Join(", ", team1.Select(p => p.Connection?.Avatar?.AccountId ?? 0))}");
                            Console.WriteLine($"[Matchmaking] Team2: {string.Join(", ", team2.Select(p => p.Connection?.Avatar?.AccountId ?? 0))}");

                            playersToStart.AddRange(team1);
                            playersToStart.AddRange(team2);

                            foreach (var player in playersToStart)
                                Queue.Remove(player);

                            if (IsRanked) StartRankedMatch(playersToStart);
                            else StartGame(playersToStart);
                        }
                        else
                        {
                            Console.WriteLine($"[Matchmaking] Failed teams: T1={team1.Count}, T2={team2.Count}");
                        }
                    }
                }
                else
                {
                    if (Queue.Count >= 1)
                    {
                        playersToStart = Queue.Take(Math.Min(PlayersRequired, Queue.Count)).ToList();
                        Queue.RemoveRange(0, playersToStart.Count);

                        if (IsRanked) StartRankedMatch(playersToStart);
                        else StartGame(playersToStart);
                    }
                }
            }

            // ???????
            if (Queue.Count > 0 && Queue.Count < PlayersRequired && SecondsLeft <= 0)
            {
                SecondsLeft = IsRanked ? RANKED_SEARCH_TIMEOUT : SEARCH_TIMEOUT;
                Console.WriteLine($"[Matchmaking] Timeout: {Queue.Count} players for slot {EventData.Slot}");

                if (Queue.Count >= 1)
                {
                    var toStart = Queue.Take(Queue.Count).ToList();
                    if (IsRanked) StartRankedMatch(toStart);
                    else StartGame(toStart);
                    Queue.RemoveRange(0, toStart.Count);
                }
            }

            // ??????
            if (Queue.Count > 0)
            {
                Turns++;
                if (Turns >= 4)
                {
                    Turns = 0;
                    SecondsLeft--;
                    if (IsRanked && Queue.Count > 0 && Queue.Count < PlayersRequired)
                    {
                        Console.WriteLine($"[Matchmaking] Ranked: {Queue.Count}/{PlayersRequired}, {SecondsLeft}s left");
                    }
                }
            }
            else
            {
                Turns = 0;
                SecondsLeft = IsRanked ? RANKED_SEARCH_TIMEOUT : SEARCH_TIMEOUT;
            }

            // ?????? ??????
            if (Queue.Count > 0)
            {
                MatchMakingStatusMessage message = new MatchMakingStatusMessage();
                message.Seconds = SecondsLeft;
                message.Found = Queue.Count;
                message.Max = PlayersRequired;
                message.ShowTips = true;

                foreach (MatchmakingEntry entry in Queue)
                {
                    try
                    {
                        entry.Connection.Messaging.Send(message);
                    }
                    catch { }
                }
            }
        }

        public void Remove(MatchmakingEntry entry)
        {
            RemoveQueue.Enqueue(entry);
        }

        public void Add(MatchmakingEntry entry)
        {
            RequestQueue.Enqueue(entry);
        }

        public static readonly int[] botBrawlers = { 1, 2, 3, 4, 5, 6, 9, 10 };

        public void StartRankedMatch(List<MatchmakingEntry> entries)
        {
            Console.WriteLine($"[Matchmaking] StartRankedMatch: slot={Slot} entries={entries?.Count ?? 0}");

            if (entries == null || entries.Count < 1)
            {
                Console.WriteLine($"[Matchmaking] Not enough players for ranked: {entries?.Count ?? 0}");
                return;
            }

            // ????????? ?????????? ????
            List<MatchmakingEntry> validEntries = new List<MatchmakingEntry>();
            foreach (var entry in entries)
            {
                try
                {
                    if (entry?.Connection?.IsOpen == true && entry.Connection.Avatar != null)
                    {
                        validEntries.Add(entry);
                    }
                    else
                    {
                        Console.WriteLine($"[Matchmaking] Removing invalid entry: {entry?.Connection?.Avatar?.AccountId ?? 0}");
                        if (entry != null) Remove(entry);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Matchmaking] Error checking entry: {ex.Message}");
                    if (entry != null) Remove(entry);
                }
            }

            if (validEntries.Count < 1)
            {
                Console.WriteLine($"[Matchmaking] No valid players for ranked");
                return;
            }

            entries = validEntries;

            AtesDev2RankedMatch ranked = new();
            ranked.AtesDev2MatchId = RankedMatchRegulator.Add(ranked);

            // ?????????: ??????? ?????????, ????? ????
            List<MatchmakingEntry> sortedEntries = new List<MatchmakingEntry>();
            Dictionary<long, List<MatchmakingEntry>> teamEntries = new Dictionary<long, List<MatchmakingEntry>>();

            MatchmakingEntry[] entriesWithTeam = entries.FindAll(entry => entry.PlayerTeamId > 0).ToArray();
            for (int i = 0; i < entriesWithTeam.Length; i++)
            {
                MatchmakingEntry entry = entriesWithTeam[i];
                long teamId = entry.PlayerTeamId;
                if (!teamEntries.ContainsKey(teamId)) teamEntries.Add(teamId, new List<MatchmakingEntry>());
                teamEntries[teamId].Add(entry);
                entries.Remove(entry);
            }

            long[] ids = teamEntries.Keys.ToArray();
            for (int i = 0; i < ids.Length; i++)
            {
                List<MatchmakingEntry> teamedEntries = teamEntries[ids[i]];
                for (int j = 0; j < teamedEntries.Count; j++)
                {
                    sortedEntries.Add(teamedEntries[j]);
                    // PrefferedTeam ??? ?????????? ? Update()
                }
            }

            for (int i = 0; i < entries.Count; i++)
            {
                sortedEntries.Add(entries[i]);
            }

            // ??. ????: ?????????? ?????????? ?????? ? ????????
            int team0Count = 0, team1Count = 0;
            List<MatchmakingEntry> team0 = new List<MatchmakingEntry>();
            List<MatchmakingEntry> team1 = new List<MatchmakingEntry>();
            
            // ????????? ??????? ?? ????????
            for (int i = 0; i < sortedEntries.Count; i++)
            {
                try
                {
                    if (sortedEntries[i] == null)
                    {
                        Console.WriteLine($"[Matchmaking] Skipping null entry at index {i}");
                        continue;
                    }

                    if (sortedEntries[i].Connection == null)
                    {
                        Console.WriteLine($"[Matchmaking] Skipping player with no connection");
                        continue;
                    }

                    if (sortedEntries[i].Connection.IsOpen != true)
                    {
                        Console.WriteLine($"[Matchmaking] Skipping player with closed connection: {sortedEntries[i].Connection?.Avatar?.AccountId ?? 0}");
                        continue;
                    }

                    if (sortedEntries[i].Connection.Avatar == null)
                    {
                        Console.WriteLine($"[Matchmaking] Skipping player with no avatar");
                        continue;
                    }

                    int teamIndex;
                    if (sortedEntries[i].PrefferedTeam != -1)
                    {
                        teamIndex = sortedEntries[i].PrefferedTeam;
                    }
                    else
                    {
                        // ???????????: ??? ?????? � ????
                        teamIndex = team0Count <= team1Count ? 0 : 1;
                    }

                    if (teamIndex == 0)
                    {
                        team0.Add(sortedEntries[i]);
                        team0Count++;
                    }
                    else
                    {
                        team1.Add(sortedEntries[i]);
                        team1Count++;
                    }

                    Console.WriteLine($"[Matchmaking] Added player to team {teamIndex}: {sortedEntries[i].Connection.Avatar.AccountId}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Matchmaking] Error sorting player: {ex.Message} | StackTrace: {ex.StackTrace}");
                }
            }

            // ??????? ??????? ? ?????????? globalIndex
            int globalIndex = 0;

            // ????? ???????
            for (int i = 0; i < team0.Count; i++)
            {
                try
                {
                    if (team0[i].Connection?.Avatar == null)
                    {
                        Console.WriteLine($"[Matchmaking] Skipping team0 player with null avatar");
                        continue;
                    }

                    team0[i].Connection.Avatar.RanledId = ranked.AtesDev2MatchId;
                    var player = AtesDev2RankedMatchPlayer.CreateRankedPlayer(
                        team0[i].Connection.Avatar, 
                        team0[i].Connection.Home, 
                        0, 
                        globalIndex);
                    ranked.AddMatchPlayer(player);
                    Console.WriteLine($"[Matchmaking] Added team0 player: {team0[i].Connection.Avatar.AccountId} at globalIndex {globalIndex}");
                    globalIndex++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Matchmaking] Error adding team0 player: {ex.Message} | {ex.StackTrace}");
                }
            }

            // ??????? ???????
            for (int i = 0; i < team1.Count; i++)
            {
                try
                {
                    if (team1[i].Connection?.Avatar == null)
                    {
                        Console.WriteLine($"[Matchmaking] Skipping team1 player with null avatar");
                        continue;
                    }

                    team1[i].Connection.Avatar.RanledId = ranked.AtesDev2MatchId;
                    var player = AtesDev2RankedMatchPlayer.CreateRankedPlayer(
                        team1[i].Connection.Avatar, 
                        team1[i].Connection.Home, 
                        1, 
                        globalIndex);
                    ranked.AddMatchPlayer(player);
                    Console.WriteLine($"[Matchmaking] Added team1 player: {team1[i].Connection.Avatar.AccountId} at globalIndex {globalIndex}");
                    globalIndex++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Matchmaking] Error adding team1 player: {ex.Message} | {ex.StackTrace}");
                }
            }

            // ?? Debug output
            foreach (var p in ranked.AtesDev2)
            {
                Console.WriteLine($"team={p.AtesDev2TeamIndex} global={p.AtesDev2PlayerInternalIndex}");
            }

            ranked.AtesDev2Solo = Slot == 14;
            int minPlayersRequired = ranked.AtesDev2Solo ? 1 : 2; // Solo 1v1'e ihtiya� duyar, Team en az 1v1
            
            Console.WriteLine($"[Matchmaking] RankedMatch: id={ranked.AtesDev2MatchId} solo={ranked.AtesDev2Solo} team0={team0Count} team1={team1Count} totalPlayers={globalIndex} minRequired={minPlayersRequired}");

            // E�er minimum oyuncu say�s� sa�lanmam��sa oyun ba�lamaz
            if (globalIndex < minPlayersRequired)
            {
                Console.WriteLine($"[Matchmaking] Ranked match NOT started: not enough players ({globalIndex}/{minPlayersRequired})");
                foreach (var entry in sortedEntries)
                {
                    if (entry != null) Remove(entry);
                }
                return;
            }

            try
            {
                ranked.Start();
                Console.WriteLine($"[Matchmaking] Ranked match STARTED: {globalIndex} players, solo={ranked.AtesDev2Solo}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Matchmaking] Error starting ranked: {ex.Message} | StackTrace: {ex.StackTrace}");
                foreach (var entry in sortedEntries)
                {
                    if (entry != null) Remove(entry);
                }
            }
        }

        public void StartGame(List<MatchmakingEntry> entries)
        {
            BattleMode battle = new BattleMode(EventData.LocationId);
            battle.Id = Battles.Add(battle);

            Random rand = new Random();

            List<MatchmakingEntry> sortedEntries = new List<MatchmakingEntry>();

            if (battle.GetGameModeVariation() == 7)
            {
                sortedEntries = entries;
                for (int i = 0; i < entries.Count; i++)
                {
                    UDPSocket socket = UDPGateway.CreateSocket();
                    socket.TCPConnection = sortedEntries[i].Connection;
                    socket.Battle = battle;
                    sortedEntries[i].Connection.UdpSessionId = socket.SessionId;
                    BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, 0);
                    player.TeamId = sortedEntries[i].PlayerTeamId;
                    sortedEntries[i].Player = player;
                    var hero = player.Avatar?.GetHero(player.CharacterId);
                    if (hero != null)
                        player.HeroPowerLevel = hero.PowerLevel;
                    else
                        player.HeroPowerLevel = 1;
                    battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
                }
                BattlePlayer bot1 = BattlePlayer.CreateStoryModeDummy("??", battle.GetPlayersCountWithGameModeVariation(), 1, 32, 310, 254);
                battle.AddPlayer(bot1, -1);
                bot1.Bot = 2;
            }
            else if (GameModeUtil.HasTwoTeams(battle.GetGameModeVariation()))
            {
                Dictionary<long, List<MatchmakingEntry>> teamEntries = new Dictionary<long, List<MatchmakingEntry>>();
                List<MatchmakingEntry> soloPlayers = new List<MatchmakingEntry>();

                foreach (MatchmakingEntry entry in entries)
                {
                    if (entry.PlayerTeamId > 0)
                    {
                        if (!teamEntries.ContainsKey(entry.PlayerTeamId))
                            teamEntries[entry.PlayerTeamId] = new List<MatchmakingEntry>();
                        teamEntries[entry.PlayerTeamId].Add(entry);
                    }
                    else
                    {
                        soloPlayers.Add(entry);
                    }
                }

                List<MatchmakingEntry> team1 = new List<MatchmakingEntry>();
                List<MatchmakingEntry> team2 = new List<MatchmakingEntry>();

                foreach (var teamGroup in teamEntries.Values)
                {
                    if (team1.Count + teamGroup.Count <= 3)
                    {
                        foreach (var player in teamGroup)
                        {
                            player.PrefferedTeam = 0;
                            team1.Add(player);
                        }
                    }
                    else if (team2.Count + teamGroup.Count <= 3)
                    {
                        foreach (var player in teamGroup)
                        {
                            player.PrefferedTeam = 1;
                            team2.Add(player);
                        }
                    }
                }

                foreach (var soloPlayer in soloPlayers)
                {
                    if (team1.Count < 3)
                    {
                        soloPlayer.PrefferedTeam = 0;
                        team1.Add(soloPlayer);
                    }
                    else if (team2.Count < 3)
                    {
                        soloPlayer.PrefferedTeam = 1;
                        team2.Add(soloPlayer);
                    }
                }

                sortedEntries.AddRange(team1);
                sortedEntries.AddRange(team2);

                for (int i = 0; i < sortedEntries.Count; i++)
                {
                    UDPSocket socket = UDPGateway.CreateSocket();
                    socket.TCPConnection = sortedEntries[i].Connection;
                    socket.Battle = battle;
                    sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

                    int teamIndex = sortedEntries[i].PrefferedTeam;

                    if (sortedEntries[i].Connection?.MessageManager?.HomeMode == null ||
                        sortedEntries[i].Connection?.Avatar == null)
                    {
                        var accountId = sortedEntries[i].Connection?.MessageManager?.HomeMode?.Avatar?.AccountId ?? 0;
                        Console.WriteLine($"[Matchmaking] Invalid account data for connection {accountId}");
                        continue;
                    }

                    BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, teamIndex);
                    player.TeamId = sortedEntries[i].PlayerTeamId;
                    sortedEntries[i].Player = player;
                    var hero = player.Avatar?.GetHero(player.CharacterId);
                    if (hero != null)
                        player.HeroPowerLevel = hero.PowerLevel;
                    else
                        player.HeroPowerLevel = 1;
                    battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
                }

                List<int> team1BotsCharacters = new List<int>();
                List<int> team2BotsCharacters = new List<int>();

                for (int i = sortedEntries.Count; i < battle.GetPlayersCountWithGameModeVariation(); i++)
                {
                    bool isBotValid = false;
                    int botCharacter = -1;
                    while (!isBotValid)
                    {
                        botCharacter = 16000000 + botBrawlers[rand.Next(0, botBrawlers.Length)];
                        if (i % 2 == 0)
                            isBotValid = !team1BotsCharacters.Contains(botCharacter);
                        else
                            isBotValid = !team2BotsCharacters.Contains(botCharacter);
                        if (!isBotValid) isBotValid = !GameModeUtil.HasTwoTeams(battle.GetGameModeVariation());
                    }

                    int teamIndex = i % 2;
                    if (battle.GetTeamPlayersCount(teamIndex) >= 3)
                    {
                        if (teamIndex == 1) teamIndex = 0;
                        else teamIndex = 1;
                    }

                    if (teamIndex == 0) team1BotsCharacters.Add(botCharacter);
                    else team2BotsCharacters.Add(botCharacter);

                    CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacter);
                    BattlePlayer bot = BattlePlayer.CreateBotInfo((i - sortedEntries.Count + 1).ToString(), i, teamIndex, botCharacter);
                    bot.HeroPowerLevel = new Random().Next(5, 12);
                    battle.AddPlayer(bot, -1);
                }
            }
            else
            {
                sortedEntries = entries;
                for (int i = 0; i < entries.Count; i++)
                {
                    UDPSocket socket = UDPGateway.CreateSocket();
                    socket.TCPConnection = sortedEntries[i].Connection;
                    socket.Battle = battle;
                    sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

                    int teamIndex = i;

                    if (sortedEntries[i].Connection?.MessageManager?.HomeMode == null ||
                        sortedEntries[i].Connection?.Avatar == null)
                    {
                        var accountId = sortedEntries[i].Connection?.MessageManager?.HomeMode?.Avatar?.AccountId ?? 0;
                        Console.WriteLine($"[Matchmaking] Invalid account data for connection {accountId}");
                        continue;
                    }

                    BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, teamIndex);
                    player.TeamId = sortedEntries[i].PlayerTeamId;
                    sortedEntries[i].Player = player;
                    var hero = player.Avatar?.GetHero(player.CharacterId);
                    if (hero != null)
                        player.HeroPowerLevel = hero.PowerLevel;
                    else
                        player.HeroPowerLevel = 1;
                    battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
                }

                for (int i = entries.Count; i < battle.GetPlayersCountWithGameModeVariation(); i++)
                {
                    int botCharacter = 16000000 + botBrawlers[rand.Next(0, botBrawlers.Length)];
                    int teamIndex = i;
                    CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacter);
                    BattlePlayer bot = BattlePlayer.CreateBotInfo(data.ItemName.ToUpper(), i, teamIndex, botCharacter);
                    bot.HeroPowerLevel = new Random().Next(5, 12);
                    battle.AddPlayer(bot, -1);
                }
            }

            if (battle.m_players[0].IsAdmin) for (int i = 0; i < 120; i++) battle.m_time.IncreaseTick();
            if (battle.StoryMode != null) battle.StoryMode.Init();
            battle.AddGameObjects();

            for (int i = 0; i < sortedEntries.Count; i++)
            {
                StartLoadingMessage startLoading = new StartLoadingMessage();
                startLoading.LocationId = battle.Location.GetGlobalId();
                startLoading.TeamIndex = sortedEntries[i].Player.TeamIndex;
                startLoading.OwnIndex = sortedEntries[i].Player.PlayerIndex;
                startLoading.GameMode = battle.GetGameModeVariation();
                sortedEntries[i].Connection.Avatar.UdpSessionId = sortedEntries[i].Connection.UdpSessionId;
                startLoading.Players.AddRange(battle.GetPlayers());
                sortedEntries[i].Connection.Send(startLoading);
                battle.Dummy = startLoading;
                battle.BattleWithTrophies = true;
            }
            battle.Start();
        }
    }

    public class MatchmakingEntry
    {
        public readonly Connection Connection;
        public BattlePlayer Player;
        public long PlayerTeamId;
        public int PrefferedTeam;
        public long GroupId;
        public int CharacterId;

        public MatchmakingEntry(Connection connection)
        {
            PrefferedTeam = -1;
            this.Connection = connection;
            GroupId = 0;
        }
    }
}
