﻿using Supercell.Laser.Logic.Home.Items;
using Supercell.Laser.Logic.Ranked;
using Supercell.Laser.Server.Logic.Game;
using Supercell.Laser.Server.Networking;

namespace Supercell.Laser.Server.Logic
{
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Server.Database;
    using Supercell.Laser.Server.Networking.Session;

    public class ServerListener : LogicServerListener
    {
        public ClientAvatar GetAvatar(long id)
        {
            return Accounts.Load(id).Avatar;
        }

        public LogicGameListener GetGameListener(long id)
        {
            if (Sessions.IsSessionActive(id))
            {
                return Sessions.GetSession(id).GameListener;
            }
            return null;
        }

        public HomeMode GetHomeMode(long id)
        {
            if (Sessions.IsSessionActive(id))
            {
                return Sessions.GetSession(id).Home;
            }
            return null;
        }

        public bool IsPlayerOnline(long id)
        {
            return Sessions.IsSessionActive(id);
        }
        public void StartMatchBattle(List<AtesDev2RankedMatchPlayer> entries, EventData edata, int Location = -1, int id = 0, int round = 0)
        {
            List<MatchmakingEntry> list = new();

            foreach(AtesDev2RankedMatchPlayer ranked in entries)
            {
                Connection conn = null;
                if (Sessions.IsSessionActive(ranked.AtesDev2AccountId))
                    conn = Sessions.GetSession(ranked.AtesDev2AccountId).Connection;
                MatchmakingEntry e = new(conn);
                e.PrefferedTeam = ranked.AtesDev2TeamIndex;
                e.CharacterId = ranked.AtesDev2Character;
                list.Add(e);
            }
            RankedMatchRegulator.StartMatchBattle(list, edata, Location, id, round);
        }
        public AtesDev2RankedMatch GetRankedMatch(long id) => RankedMatchRegulator.Get(id);
    }
}
