using System;
using System.Collections.Concurrent;
using System.IO;
using System.Threading.Tasks;
using Supercell.Laser.Server.Telegram;
using Supercell.Laser.Server.Database.Models;
using Supercell.Laser.Server.Database;
using Supercell.Laser.Logic.Message.Account;
using Supercell.Laser.Server.Networking.Session;
using Supercell.Laser.Server.Networking;
using Supercell.Laser.Logic.Home.Items;
using Supercell.Laser.Logic.Message.Account.Auth;
using Supercell.Laser.Logic.Util;
using Supercell.Laser.Server.Utils;
using System.Linq;
using System.Collections.Generic;
using System.Text.Json;
using Supercell.Laser.Logic.Data;
using Supercell.Laser.Logic.Avatar;
using Newtonsoft.Json;
using System.Text;

namespace Supercell.Laser.Server.Bot
{
    public class TelegramBot
    {
        private TelegramClient _client;
        private string _botToken = "8546970928:AAHOtpjyOVpcVC08hiKmY0I8Ua6Mms95FEs";

        private TelegramLinkManager _linkManager;

        private static readonly ConcurrentDictionary<long, LinkState> _linkStates = new ConcurrentDictionary<long, LinkState>();
        private static readonly ConcurrentDictionary<long, bool> _notificationSettings = new ConcurrentDictionary<long, bool>();
        private static readonly ConcurrentDictionary<long, DateTime> _lastSpinTimes = new ConcurrentDictionary<long, DateTime>();
        private static readonly ConcurrentDictionary<long, int> _dailyStreaks = new ConcurrentDictionary<long, int>();
        private static readonly ConcurrentDictionary<long, bool> _activeSpinRequests = new ConcurrentDictionary<long, bool>();

        // Классы для Тайного Санты
        public class SantaParticipant
        {
            public long TelegramUserId { get; set; }
            public string AccountTag { get; set; }
            public long AccountId { get; set; }
            public DateTime JoinedAt { get; set; }
            public bool IsActive { get; set; }
            public int TotalGiftsSent { get; set; }
            public int TotalGiftsReceived { get; set; }
            public int TotalAmountSent { get; set; }
            public DateTime LastGiftSent { get; set; }
            public string Wish { get; set; }
        }

        public class SantaGift
        {
            public string Id { get; set; }
            public long FromUserId { get; set; }
            public long ToUserId { get; set; }
            public string FromTag { get; set; }
            public string ToTag { get; set; }
            public int Amount { get; set; }
            public string GiftType { get; set; }
            public DateTime SentAt { get; set; }
            public bool IsDelivered { get; set; }
            public string Message { get; set; }
        }

        public class SantaData
        {
            public Dictionary<long, SantaParticipant> Participants { get; set; } = new();
            public List<SantaGift> Gifts { get; set; } = new();
            public DateTime EventStart { get; set; }
            public DateTime EventEnd { get; set; }
        }

        private static readonly ConcurrentDictionary<long, SantaParticipant> _santaParticipants = new();
        private static readonly ConcurrentDictionary<string, SantaGift> _santaGifts = new();
        private static readonly ConcurrentDictionary<long, List<DateTime>> _dailyGiftLog = new();
        private static SantaData _santaData = new();
        private static readonly string SANTA_DATA_PATH = "./SantaData.json";
        
        private static readonly ConcurrentDictionary<long, int> _dailyGemsTransferred = new();
private static readonly ConcurrentDictionary<long, DateTime> _lastTransferDate = new();
private static readonly ConcurrentDictionary<long, DailyLimitsRecord> _dailyLimits = new();
private const int DAILY_GEMS_LIMIT = 4000;

public class DailyLimitsRecord
{
    public long TelegramUserId { get; set; }
    public int GemsTransferred { get; set; }
    public DateTime LastTransferDate { get; set; }
}

        private readonly HashSet<long> _adminIds = new()
        {
            8215034562
        };

        private const int MAX_GIFTS_PER_DAY = 10;
        private const int MAX_GEMS_PER_GIFT = 1000;
        private const int MAX_COINS_PER_GIFT = 1000000;
        private const int MAX_POWERPOINTS_PER_GIFT = 5000;

        public class LinkState
        {
            public string TargetAccountId { get; set; }
            public string ConfirmationCode { get; set; }
            public DateTime Expiry { get; set; }
            public long TelegramUserId { get; set; }
            public int AttemptsCount { get; set; }
        }

        public class DailyReward
        {
            public int Gems { get; set; }
            public int Coins { get; set; }
            public int PowerPoints { get; set; }
            public int BrawlerId { get; set; }
            public bool HasBrawlerChance { get; set; }
            public int StreakBonus { get; set; }
            public int BrawlerPowerPoints { get; set; }
        }

        // Класс для хранения забранных предложений
        public class ClaimedOfferRecord
        {
            public long TelegramUserId { get; set; }
            public string AccountTag { get; set; }
            public string OfferTitle { get; set; }
            public int OfferCost { get; set; }
            public int ItemCount { get; set; }
            public ShopItem ItemType { get; set; }
            public DateTime ClaimedAt { get; set; }
            public string OfferHash { get; set; }
        }
        
        
        public class GemTransferRecord
{
    public string Id { get; set; }
    public long TelegramUserId { get; set; }
    public string SenderTag { get; set; }
    public string ReceiverTag { get; set; }
    public int Amount { get; set; }
    public int Commission { get; set; }
    public int TotalDeducted { get; set; }
    public int DailyUsedBefore { get; set; } // Сколько использовано до этого перевода
    public int DailyRemainingBefore { get; set; } // Сколько оставалось до этого перевода
    public DateTime TransferTime { get; set; }
}

// Метод загрузки забранных предложений
private List<ClaimedOfferRecord> LoadClaimedOffers()
{
    try
    {
        string filePath = "./claimed_offers.json";
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            return Newtonsoft.Json.JsonConvert.DeserializeObject<List<ClaimedOfferRecord>>(json) ?? new List<ClaimedOfferRecord>();
        }
        return new List<ClaimedOfferRecord>();
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[ClaimedOffers] Ошибка загрузки: {ex.Message}");
        return new List<ClaimedOfferRecord>();
    }
}

// Метод сохранения забранных предложений
private void SaveClaimedOffers(List<ClaimedOfferRecord> claimedOffers)
{
    try
    {
        string filePath = "./claimed_offers.json";
        string json = Newtonsoft.Json.JsonConvert.SerializeObject(claimedOffers, Newtonsoft.Json.Formatting.Indented);
        File.WriteAllText(filePath, json);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[ClaimedOffers] Ошибка сохранения: {ex.Message}");
    }
}


// Добавьте эти методы в класс TelegramBot (например, после метода GetShopItemIcon):

private string GetShopItemName(ShopItem itemType, int skinDataId, int itemDataId)
{
    switch (itemType)
    {
        case ShopItem.Gems:
            return "Гемы";
        case ShopItem.Coin:
            return "Монеты";
        case ShopItem.Skin:
            return skinDataId > 0 ? GetSkinNameById(skinDataId) : "Скин";
        case ShopItem.PowerPoint:
            return "Очки силы";
        case ShopItem.GuaranteedHero:
            return itemDataId > 0 ? GetBrawlerNameById(itemDataId) : "Бравлер";
        case ShopItem.Titul:
            return "Титул";
        case ShopItem.RarityStarrDrop:
            return "Звёздная капля";
        case ShopItem.Bling:
            return "Блинг";
        default:
            return "Предложение";
    }
}

private string GetBrawlerNameById(int brawlerId)
{
    try
    {
        // Adjust brawler ID if needed
        int adjustedId = brawlerId;
        if (adjustedId < 16000000 && adjustedId > 0)
        {
            adjustedId += 16000000;
        }
        
        // Try to get from game data
        var characterData = DataTables.Get(16)?.GetDataWithId<CharacterData>(adjustedId);
        if (characterData != null)
        {
            var type = characterData.GetType();
            
            // Try different property/method names
            var nameProp = type.GetProperty("Name");
            if (nameProp != null)
            {
                string name = (string)nameProp.GetValue(characterData);
                if (!string.IsNullOrEmpty(name))
                    return name;
            }
            
            var tidNameProp = type.GetProperty("TID_Name");
            if (tidNameProp != null)
            {
                string tidName = (string)tidNameProp.GetValue(characterData);
                if (!string.IsNullOrEmpty(tidName))
                    return tidName;
            }
            
            var getNameMethod = type.GetMethod("GetName");
            if (getNameMethod != null)
            {
                string name = (string)getNameMethod.Invoke(characterData, null);
                if (!string.IsNullOrEmpty(name))
                    return name;
            }
        }
        
        // Fallback to common brawler names
        return adjustedId switch
        {
            16000000 => "Шелли",
            16000001 => "Нита",
            16000002 => "Кольт",
            16000003 => "Булл",
            16000004 => "Джесси",
            16000005 => "Брок",
            16000006 => "Динамик",
            16000007 => "Бо",
            16000008 => "Тик",
            16000009 => "Эль Примо",
            16000010 => "Барли",
            16000011 => "Поко",
            16000012 => "Мортис",
            16000013 => "Тара",
            16000014 => "Джин",
            16000015 => "Кроу",
            16000016 => "Леон",
            16000017 => "Сэнди",
            16000018 => "Спайк",
            16000019 => "Биби",
            _ => $"Бравлер #{adjustedId}"
        };
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TelegramBot] Ошибка получения имени бравлера {brawlerId}: {ex.Message}");
        return $"Бравлер #{brawlerId}";
    }
}


// Генерация хэша для предложения
private string GenerateOfferHash(string accountTag, string offerTitle, int offerCost, int itemCount)
{
    string hashString = $"{accountTag}|{offerTitle}|{offerCost}|{itemCount}";
    return Math.Abs(hashString.GetHashCode()).ToString();
}

// Проверка, было ли предложение уже забрано
private bool IsOfferAlreadyClaimed(long userId, string accountTag, string offerTitle, int offerCost, int itemCount)
{
    var claimedOffers = LoadClaimedOffers();
    string offerHash = GenerateOfferHash(accountTag, offerTitle, offerCost, itemCount);
    
    return claimedOffers.Any(o => 
        o.TelegramUserId == userId && 
        o.AccountTag == accountTag && 
        o.OfferHash == offerHash);
}

// Отметить предложение как забранное
private void MarkOfferAsClaimed(long userId, string accountTag, OfferBundle offer)
{
    var claimedOffers = LoadClaimedOffers();
    
    var mainItem = offer.Items?.FirstOrDefault();
    if (mainItem == null) return;
    
    string offerHash = GenerateOfferHash(accountTag, offer.Title, offer.Cost, mainItem.Count);
    
    claimedOffers.Add(new ClaimedOfferRecord
    {
        TelegramUserId = userId,
        AccountTag = accountTag,
        OfferTitle = offer.Title,
        OfferCost = offer.Cost,
        ItemCount = mainItem.Count,
        ItemType = mainItem.Type,
        ClaimedAt = DateTime.UtcNow,
        OfferHash = offerHash
    });
    
    SaveClaimedOffers(claimedOffers);
    Console.WriteLine($"[ClaimedOffers] Предложение '{offer.Title}' помечено как забранное для {accountTag}");
}

// Метод для просмотра забранных предложений
private async Task HandleClaimedOffersCommand(long chatId, long userId)
{
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, "❌ Аккаунт не привязан!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    var claimedOffers = LoadClaimedOffers()
        .Where(c => c.TelegramUserId == userId && c.AccountTag == accountTag)
        .OrderByDescending(c => c.ClaimedAt)
        .Take(15)
        .ToList();
    
    var message = new StringBuilder();
    message.AppendLine("📋 *МОИ ЗАБРАННЫЕ ПРЕДЛОЖЕНИЯ*");
    message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    message.AppendLine("");
    
    if (claimedOffers.Any())
    {
        message.AppendLine($"🎮 *Аккаунт:* `{accountTag}`");
        message.AppendLine($"");
        
        // Группируем по типам
        var gems = claimedOffers.Where(c => c.ItemType == ShopItem.Gems).Sum(c => c.ItemCount);
        var coins = claimedOffers.Where(c => c.ItemType == ShopItem.Coin).Sum(c => c.ItemCount);
        var powerPoints = claimedOffers.Where(c => c.ItemType == ShopItem.PowerPoint).Sum(c => c.ItemCount);
        var skins = claimedOffers.Count(c => c.ItemType == ShopItem.Skin);
        
        message.AppendLine("💰 *Общая статистика:*");
        if (gems > 0) message.AppendLine($"💎 Гемы: {gems}");
        if (coins > 0) message.AppendLine($"🪙 Монеты: {coins}");
        if (powerPoints > 0) message.AppendLine($"⚡ Очки силы: {powerPoints}");
        if (skins > 0) message.AppendLine($"🎨 Скины: {skins}");
        message.AppendLine($"");
        
        message.AppendLine("*Последние забранные:*");
        foreach (var claim in claimedOffers.Take(5))
        {
            string itemIcon = GetShopItemIcon(claim.ItemType);
            message.AppendLine($"• {itemIcon} **{claim.OfferTitle}**");
            message.AppendLine($"  🎁 {claim.ItemCount} | ⏰ {claim.ClaimedAt:dd.MM HH:mm}");
            message.AppendLine("");
        }
        
        message.AppendLine($"📊 *Всего забрано:* {claimedOffers.Count} предложений");
        message.AppendLine("");
        message.AppendLine("🔄 *Команды:*");
        message.AppendLine("/shop - вернуться в магазин");
    }
    else
    {
        message.AppendLine("📭 *Вы ещё не забирали предложения!*");
        message.AppendLine("");
        message.AppendLine("🎁 *Начните здесь:*");
        message.AppendLine("/shop - перейти в магазин");
    }
    
    // Кнопка возврата
    var keyboard = new
    {
        inline_keyboard = new[]
        {
            new[]
            {
                new { text = "← Назад в магазин", callback_data = "shop_back_to_list" }
            }
        }
    };
    
    string keyboardJson = System.Text.Json.JsonSerializer.Serialize(keyboard);
    
    await _client.SendMessageWithKeyboardAsync(chatId, 
        message.ToString(), 
        keyboardJson,
        TelegramClient.ParseMode.MarkdownV2);
}

        public async Task StartAsync()
        {
            _linkManager = new TelegramLinkManager();
            _client = new TelegramClient(_botToken);
            InitializeSantaEvent();
            // Запускаем задачу сброса лимитов
            LoadDailyLimits();
    _ = Task.Run(() => StartDailyLimitResetTask());
    
        _ = Task.Run(() => StartDailyLimitsAutoSave());
    
            await StartPolling();
        }

        private void InitializeSantaEvent()
        {
            _santaData.EventStart = new DateTime(DateTime.UtcNow.Year, 12, 1);
            _santaData.EventEnd = new DateTime(DateTime.UtcNow.Year, 12, 31, 23, 59, 59);
            
            LoadSantaData();
            
            Task.Run(async () =>
            {
                while (true)
                {
                    await Task.Delay(300000);
                    SaveSantaData();
                }
            });
        }

        private void LoadSantaData()
        {
            try
            {
                if (File.Exists(SANTA_DATA_PATH))
                {
                    var json = File.ReadAllText(SANTA_DATA_PATH);
                    _santaData = Newtonsoft.Json.JsonConvert.DeserializeObject<SantaData>(json) ?? new SantaData();
                    
                    foreach (var participant in _santaData.Participants)
                    {
                        _santaParticipants[participant.Key] = participant.Value;
                    }
                    
                    foreach (var gift in _santaData.Gifts)
                    {
                        _santaGifts[gift.Id] = gift;
                    }
                    
                    Console.WriteLine($"[Santa] Загружено {_santaParticipants.Count} участников и {_santaGifts.Count} подарков");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Santa] Ошибка загрузки данных: {ex.Message}");
                _santaData = new SantaData();
            }
        }

        private void SaveSantaData()
        {
            try
            {
                _santaData.Participants = _santaParticipants.ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                _santaData.Gifts = _santaGifts.Values.ToList();
                
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(_santaData, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(SANTA_DATA_PATH, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Santa] Ошибка сохранения данных: {ex.Message}");
            }
        }

        private bool IsAdmin(long userId) => _adminIds.Contains(userId);

        private bool IsSantaEventActive()
        {
            var now = DateTime.UtcNow;
            return now >= _santaData.EventStart && now <= _santaData.EventEnd;
        }

        private string GetTimeRemaining()
        {
            if (!IsSantaEventActive())
            {
                if (DateTime.UtcNow > _santaData.EventEnd)
                    return "🎅 *Тайный Санта завершился!*";
                else
                    return $"🎅 *Тайный Санта начнётся {_santaData.EventStart:dd.MM.yyyy}*";
            }
            
            var timeLeft = _santaData.EventEnd - DateTime.UtcNow;
            return $"⏰ *До конца:* {timeLeft.Days}д {timeLeft.Hours}ч {timeLeft.Minutes}м";
        }


private void SaveDailyLimitsSimple()
{
    try
    {
        string filePath = "./daily_limits_simple.txt";
        var lines = new List<string>();
        
        foreach (var kvp in _dailyLimits)
        {
            lines.Add($"{kvp.Key}|{kvp.Value.GemsTransferred}|{kvp.Value.LastTransferDate:yyyy-MM-dd}");
        }
        
        File.WriteAllLines(filePath, lines);
        Console.WriteLine($"[TransferGems] Лимиты сохранены в простой файл: {lines.Count} записей");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TransferGems] Ошибка простого сохранения: {ex.Message}");
    }
}

private void LoadDailyLimitsSimple()
{
    try
    {
        string filePath = "./daily_limits_simple.txt";
        if (File.Exists(filePath))
        {
            var lines = File.ReadAllLines(filePath);
            Console.WriteLine($"[TransferGems] Загружено {lines.Length} строк из простого файла");
            
            foreach (var line in lines)
            {
                var parts = line.Split('|');
                if (parts.Length == 3 && long.TryParse(parts[0], out long userId) && 
                    int.TryParse(parts[1], out int gems) && 
                    DateTime.TryParse(parts[2], out DateTime date))
                {
                    _dailyLimits[userId] = new DailyLimitsRecord
                    {
                        TelegramUserId = userId,
                        GemsTransferred = gems,
                        LastTransferDate = date
                    };
                }
            }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TransferGems] Ошибка простой загрузки: {ex.Message}");
    }
}


        private async Task StartPolling()
{
    int offset = 0;

    while (true)
    {
        try
        {
            var updates = await _client.GetUpdatesAsync(
                offset: offset,
                limit: 10,
                timeout: 30
            );

            foreach (var update in updates)
            {
                offset = update.update_id + 1;

                _ = Task.Run(() => HandleUpdateAsync(update));
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TelegramBot] Ошибка опроса: {ex.Message}");
            await Task.Delay(5000);
        }

        await Task.Delay(1000);
    }
}

        private async Task HandleUpdateAsync(Update update)
        {
            try
            {
                if (update.callback_query != null)
                {
                    await HandleCallbackQueryAsync(update.callback_query);
                    return;
                }

                if (update.message == null) return;
                if (string.IsNullOrEmpty(update.message.text)) return;

                var message = update.message;
                var chatId = message.chat.id;
                var userId = message.from.id;
                var text = message.text.Trim();

                if (message.chat.type != "private") return;

                if (_linkStates.TryGetValue(userId, out var state))
                {
                    if (DateTime.UtcNow > state.Expiry)
                    {
                        _linkStates.TryRemove(userId, out _);
                        await _client.SendMessageAsync(chatId, "ℹ️ Время на ввод кода истекло. Начните заново.", TelegramClient.ParseMode.MarkdownV2);
                        return;
                    }

                    if (state.AttemptsCount >= 3)
                    {
                        _linkStates.TryRemove(userId, out _);
                        await _client.SendMessageAsync(chatId, "❌ Слишком много неверных попыток. Начните заново.", TelegramClient.ParseMode.MarkdownV2);
                        return;
                    }

                    if (text == state.ConfirmationCode)
                    {
                        await HandleConfirmationCode(chatId, state.TargetAccountId, userId);
                        _linkStates.TryRemove(userId, out _);
                        return;
                    }
                    else
                    {
                        state.AttemptsCount++;
                        await _client.SendMessageAsync(chatId, $"❌ Неверный код. Попыток осталось: {3 - state.AttemptsCount}", TelegramClient.ParseMode.MarkdownV2);
                        return;
                    }
                }

                if (text.StartsWith("/"))
                {
                    await HandleCommandAsync(chatId, text, userId);
                }
                else if (IsAccountId(text))
                {
                    await HandleAccountId(chatId, userId, text);
                }
                else
                {
                    await _client.SendMessageAsync(chatId, "❌ Неизвестная команда. Используйте /start для помощи.", TelegramClient.ParseMode.MarkdownV2);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TelegramBot] Ошибка в HandleUpdateAsync: {ex.Message}");
                try
                {
                    await _client.SendMessageAsync(update.message?.chat.id ?? 0, "Произошла ошибка. Попробуйте позже.");
                }
                catch { }
            }
        }

        private async Task HandleCallbackQueryAsync(CallbackQuery callbackQuery)
{
    var userId = callbackQuery.from.id;
    var chatId = callbackQuery.message.chat.id;
    var messageId = callbackQuery.message.message_id;
    var callbackData = callbackQuery.data;

    try
    {
        await _client.AnswerCallbackQueryAsync(callbackQuery.id);

        Console.WriteLine($"[TelegramBot] Callback: {callbackData} от {userId} в {DateTime.UtcNow:HH:mm:ss}");

        if (callbackData.StartsWith("spin_wheel_"))
        {
            // Проверяем блокировку
            if (_activeSpinRequests.TryGetValue(userId, out bool isProcessing) && isProcessing)
            {
                await _client.SendMessageAsync(chatId, 
                    "⏳ Ваш запрос уже обрабатывается! Пожалуйста, подождите...",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            // Проверяем привязку аккаунта
            if (!_linkManager.TryGetAccountId(userId, out string accountTag))
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ Сначала привяжите аккаунт, чтобы использовать колесо фортуны!",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            // Проверяем, крутили ли уже сегодня
            if (_lastSpinTimes.TryGetValue(userId, out DateTime lastSpin))
            {
                if (lastSpin.Date == DateTime.UtcNow.Date)
                {
                    var nextSpinTime = lastSpin.AddDays(1).Date;
                    var timeUntilNextSpin = nextSpinTime - DateTime.UtcNow;
                    
                    // Дополнительная защита от быстрых нажатий
                    if ((DateTime.UtcNow - lastSpin).TotalSeconds < 10)
                    {
                        await _client.SendMessageAsync(chatId,
                            "⏳ Вы уже крутили колесо! Пожалуйста, подождите немного...",
                            TelegramClient.ParseMode.MarkdownV2);
                        return;
                    }
                    
                    await _client.SendMessageAsync(chatId,
                        "⏳ Вы уже крутили колесо сегодня!\n\n" +
                        $"🔥 Ваша серия: {_dailyStreaks.GetValueOrDefault(userId, 0)} дней\n" +
                        $"⏰ Следующий спин будет доступен завтра в 00:00 UTC",
                        TelegramClient.ParseMode.MarkdownV2);
                    return;
                }
            }

            try
            {
                // Устанавливаем блокировку
                _activeSpinRequests[userId] = true;
                
                await ProcessWheelSpin(chatId, messageId, userId);
            }
            finally
            {
                // Всегда снимаем блокировку
                _activeSpinRequests.TryRemove(userId, out _);
            }
        }
        else if (callbackData.StartsWith("shop_view_"))
        {
            await HandleShopViewCallback(chatId, messageId, userId, callbackData);
        }
        else if (callbackData == "shop_refresh_list")
        {
            await HandleShopCommand(chatId, userId);
        }
        else if (callbackData == "shop_debug")
        {
            await HandleShopDebugCommand(chatId, userId);
        }
        else if (callbackData == "shop_refresh_single")
        {
            await _client.SendMessageAsync(chatId,
                "🔄 *Информация обновлена!*",
                TelegramClient.ParseMode.MarkdownV2);
        }
        else if (callbackData == "shop_balance_warning")
        {
            await _client.SendMessageAsync(chatId,
                "⚠️ *Недостаточно средств!*\n\n" +
                "Пополните баланс в игре и попробуйте снова.",
                TelegramClient.ParseMode.MarkdownV2);
        }
        else if (callbackData == "shop_back_to_list")
        {
            await HandleShopCommand(chatId, userId);
        }
        else if (callbackData.StartsWith("shop_claim_"))
        {
            string indexStr = callbackData.Replace("shop_claim_", "");
            if (!int.TryParse(indexStr, out int offerIndex))
            {
                await _client.SendMessageAsync(chatId, "❌ Ошибка индекса", TelegramClient.ParseMode.MarkdownV2);
                return;
            }
            
            await ProcessFreeOfferClaim(chatId, userId, offerIndex);
        }
        else if (callbackData.StartsWith("shop_buy_"))
        {
            await HandleShopBuyCommand(chatId, userId, callbackData);
        }
        else if (callbackData == "shop_fix999_callback")
        {
            await HandleQuickShopFixCommand(chatId, userId);
        }
        else if (callbackData == "check_balance")
{
    await HandleAccountInfoCommand(chatId, userId, null);
}
else if (callbackData == "my_accounts_list")
{
    await HandleMyAccountsCommand(chatId, userId);
}
else if (callbackData == "transfer_again")
{
    await HandleTransferGemsCommand(chatId, userId, "");
}
else if (callbackData == "show_limits")
{
    await ShowTransferLimits(chatId, userId);
}
else if (callbackData == "transfer_history_callback")
{
    await HandleTransferHistoryCommand(chatId, userId);
}
        else if (callbackData == "my_claims_callback")
        {
            await HandleClaimedOffersCommand(chatId, userId);
        }
        else
        {
            Console.WriteLine($"[TelegramBot] Неизвестный callback: {callbackData}");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TelegramBot] Ошибка в HandleCallbackQueryAsync: {ex.Message}");
        Console.WriteLine($"[TelegramBot] StackTrace: {ex.StackTrace}");
        
        // Всегда снимаем блокировку при ошибке
        _activeSpinRequests.TryRemove(userId, out _);
        
        try
        {
            await _client.SendMessageAsync(chatId,
                "❌ Произошла ошибка при обработке запроса. Попробуйте позже.",
                TelegramClient.ParseMode.MarkdownV2);
        }
        catch { }
    }
}



private int GetGemsTransferredToday(long userId)
{
    // Используем _dailyLimits вместо _dailyGemsTransferred
    if (_dailyLimits.TryGetValue(userId, out var record))
    {
        // Проверяем, если дата не сегодня, сбрасываем
        if (record.LastTransferDate.Date != DateTime.UtcNow.Date)
        {
            record.GemsTransferred = 0;
            record.LastTransferDate = DateTime.UtcNow;
            SaveDailyLimits(); // Сохраняем изменения
            return 0;
        }
        
        return record.GemsTransferred;
    }
    
    // Если записи нет, создаем новую
    _dailyLimits[userId] = new DailyLimitsRecord
    {
        TelegramUserId = userId,
        GemsTransferred = 0,
        LastTransferDate = DateTime.UtcNow
    };
    SaveDailyLimits();
    
    return 0;
}

private void UpdateDailyGemsLimit(long userId, int amount)
{
    if (!_dailyLimits.TryGetValue(userId, out var record))
    {
        record = new DailyLimitsRecord
        {
            TelegramUserId = userId,
            GemsTransferred = 0,
            LastTransferDate = DateTime.UtcNow
        };
    }
    
    // Проверяем дату
    if (record.LastTransferDate.Date != DateTime.UtcNow.Date)
    {
        record.GemsTransferred = 0;
        record.LastTransferDate = DateTime.UtcNow;
    }
    
    // Обновляем сумму
    record.GemsTransferred += amount;
    record.LastTransferDate = DateTime.UtcNow;
    
    _dailyLimits[userId] = record;
    SaveDailyLimits();
    
    Console.WriteLine($"[TransferGems] Пользователь {userId} использовал {record.GemsTransferred}/{DAILY_GEMS_LIMIT} гемов сегодня");
}

private void ResetDailyLimits()
{
    try
    {
        var today = DateTime.UtcNow.Date;
        var usersToReset = _dailyLimits
            .Where(kvp => kvp.Value.LastTransferDate.Date < today)
            .Select(kvp => kvp.Key)
            .ToList();
        
        foreach (var userId in usersToReset)
        {
            if (_dailyLimits.TryGetValue(userId, out var record))
            {
                record.GemsTransferred = 0;
                record.LastTransferDate = today;
                Console.WriteLine($"[TransferGems] Сброшен лимит для {userId}");
            }
        }
        
        if (usersToReset.Count > 0)
        {
            SaveDailyLimits();
            Console.WriteLine($"[TransferGems] Сброшены лимиты для {usersToReset.Count} пользователей");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TransferGems] Ошибка сброса лимитов: {ex.Message}");
    }
}

private async Task LogTransferToFile(long userId, string senderTag, string receiverTag, int amount, int commission)
{
    try
    {
        string filePath = "./gems_transfers.json";
        List<GemTransferRecord> transfers = new List<GemTransferRecord>();
        
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            transfers = Newtonsoft.Json.JsonConvert.DeserializeObject<List<GemTransferRecord>>(json) 
                ?? new List<GemTransferRecord>();
        }
        
        // Получаем текущие лимиты из _dailyLimits
        int gemsUsedBeforeTransfer = 0;
        if (_dailyLimits.TryGetValue(userId, out var record))
        {
            gemsUsedBeforeTransfer = record.GemsTransferred;
        }
        
        // ВЫЧИТАЕМ текущий перевод, чтобы получить значение "до перевода"
        int gemsUsedBefore = Math.Max(0, gemsUsedBeforeTransfer - amount);
        
        transfers.Add(new GemTransferRecord
        {
            Id = Guid.NewGuid().ToString(),
            TelegramUserId = userId,
            SenderTag = senderTag,
            ReceiverTag = receiverTag,
            Amount = amount,
            Commission = commission,
            TotalDeducted = amount + commission,
            DailyUsedBefore = gemsUsedBefore,
            DailyRemainingBefore = DAILY_GEMS_LIMIT - gemsUsedBefore,
            TransferTime = DateTime.UtcNow
        });
        
        // Оставляем только последние 1000 записей
        if (transfers.Count > 1000)
        {
            transfers = transfers.Skip(transfers.Count - 1000).ToList();
        }
        
        string newJson = Newtonsoft.Json.JsonConvert.SerializeObject(transfers, Newtonsoft.Json.Formatting.Indented);
        File.WriteAllText(filePath, newJson);
        
        Console.WriteLine($"[TransferGems] Запись сохранена: {senderTag} → {receiverTag} ({amount} гемов), " +
                         $"использовано до перевода: {gemsUsedBefore}/{DAILY_GEMS_LIMIT}");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TransferGems] Ошибка логирования: {ex.Message}");
    }
}

private async Task HandleTransferGemsCommand(long chatId, long userId, string args)
{
    try
    {
        // Проверяем, есть ли привязанные аккаунты
        if (!_linkManager.TryGetAccountId(userId, out string senderTag))
        {
            await _client.SendMessageAsync(chatId,
                "❌ *У вас нет привязанного аккаунта!*\n\n" +
                "Сначала привяжите аккаунт, отправив свой ТЭГ (например: `#2PP`)",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        if (string.IsNullOrEmpty(args))
        {
            // Показываем инструкцию с информацией о лимитах
            int gemsUsedTodayInitial = GetGemsTransferredToday(userId);
            int gemsRemainingInitial = DAILY_GEMS_LIMIT - gemsUsedTodayInitial;
            
            await _client.SendMessageAsync(chatId,
                "💰 *ПЕРЕДАЧА ГЕМОВ ЛЮБОМУ ИГРОКУ*\n" +
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n" +
                $"📊 *Сегодня использовано:* {gemsUsedTodayInitial}/{DAILY_GEMS_LIMIT} гемов\n" +
                $"🎯 *Осталось до лимита:* {gemsRemainingInitial} гемов\n" +
                $"🕐 *Лимит сбросится:* в 00:00 UTC\n\n" +
                "📋 *Формат команды:*\n" +
                "`/transfer_gems #ТЭГ_ПОЛУЧАТЕЛЯ КОЛИЧЕСТВО`\n\n" +
                "📌 *Примеры:*\n" +
                "`/transfer_gems #89LJP 50` - передать 50 гемов\n" +
                "`/transfer_gems #89LJP 1000` - передать 1000 гемов\n\n" +
                "⚙️ *Ограничения:*\n" +
                $"• Максимум в день: {DAILY_GEMS_LIMIT} гемов\n" +
                "• Минимум за раз: 10 гемов\n" +
                "• Максимум за раз: 1000 гемов\n" +
                "• Комиссия: 5% (мин. 1 гем)\n" +
                "• Можно передавать ЛЮБОМУ игроку\n\n" +
                "📊 *Для просмотра своих аккаунтов:*\n" +
                "/myaccounts",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Парсим аргументы
        var parts = args.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length < 2)
        {
            await _client.SendMessageAsync(chatId,
                "❌ *Неверный формат!*\n\n" +
                "Используйте: `/transfer_gems #ТЭГ КОЛИЧЕСТВО`\n" +
                "Пример: `/transfer_gems #89LJP 50`",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        string receiverTag = parts[0].ToUpper();
        if (!receiverTag.StartsWith("#"))
        {
            receiverTag = "#" + receiverTag;
        }

        if (!int.TryParse(parts[1], out int amount) || amount <= 0)
        {
            await _client.SendMessageAsync(chatId,
                "❌ *Неверное количество гемов!*\n" +
                "Укажите число от 10 до 1000",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Проверяем ограничения
        if (amount < 10)
        {
            await _client.SendMessageAsync(chatId,
                "❌ *Минимальная сумма для передачи - 10 гемов!*",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        if (amount > 1000)
        {
            await _client.SendMessageAsync(chatId,
                "❌ *Максимальная сумма за раз - 1000 гемов!*",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Проверяем дневной лимит
        int gemsUsedToday = GetGemsTransferredToday(userId);
        int gemsRemaining = DAILY_GEMS_LIMIT - gemsUsedToday;
        
        if (amount > gemsRemaining)
        {
            await _client.SendMessageAsync(chatId,
                $"❌ *Превышен дневной лимит!*\n\n" +
                $"💰 *Сегодня уже отправлено:* {gemsUsedToday}/{DAILY_GEMS_LIMIT} гемов\n" +
                $"🎯 *Осталось до лимита:* {gemsRemaining} гемов\n" +
                $"📤 *Вы хотите отправить:* {amount} гемов\n\n" +
                $"ℹ️ Уменьшите сумму или дождитесь сброса лимита в 00:00 UTC",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Проверяем, что аккаунт получателя существует
        long receiverAccountId = TagToId(receiverTag);
        var receiverAccount = Accounts.Load(receiverAccountId);

        if (receiverAccount?.Avatar == null)
        {
            await _client.SendMessageAsync(chatId,
                $"❌ *Аккаунт `{receiverTag}` не существует!*\n\n" +
                "Проверьте правильность ТЭГа получателя.",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Проверяем, что получатель не является отправителем
        if (senderTag == receiverTag)
        {
            await _client.SendMessageAsync(chatId,
                "❌ *Нельзя передавать гемы самому себе!*\n" +
                "Укажите другого игрока.",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Рассчитываем комиссию (5%, минимум 1 гем)
        int commission = Math.Max(1, (int)Math.Ceiling(amount * 0.05));
        int totalToDeduct = amount + commission;

        // Загружаем аккаунт отправителя
        long senderAccountId = TagToId(senderTag);
        var senderAccount = Accounts.Load(senderAccountId);
        
        if (senderAccount?.Avatar == null)
        {
            await _client.SendMessageAsync(chatId,
                "❌ *Ошибка загрузки вашего аккаунта!*",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Проверяем баланс
        if (senderAccount.Avatar.Diamonds < totalToDeduct)
        {
            await _client.SendMessageAsync(chatId,
                $"❌ *Недостаточно гемов!*\n\n" +
                $"💰 *Ваш баланс:* {senderAccount.Avatar.Diamonds} гемов\n" +
                $"📤 *Требуется:* {totalToDeduct} гемов ({amount} + {commission} комиссия)\n" +
                $"📊 *Не хватает:* {totalToDeduct - senderAccount.Avatar.Diamonds} гемов",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Выполняем перевод
        senderAccount.Avatar.Diamonds -= totalToDeduct;
        receiverAccount.Avatar.Diamonds += amount;

        // Сохраняем изменения
        Accounts.Save(senderAccount);
        Accounts.Save(receiverAccount);

        // Обновляем дневной лимит
        UpdateDailyGemsLimit(userId, amount);

        // Записываем в историю переводов
        await LogTransferToFile(userId, senderTag, receiverTag, amount, commission);

        // Формируем сообщение об успехе
        var message = new StringBuilder();
        message.AppendLine("✅ *ПЕРЕВОД ВЫПОЛНЕН!*");
        message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        message.AppendLine("");
        
        int gemsUsedAfter = GetGemsTransferredToday(userId);
        int gemsRemainingAfter = DAILY_GEMS_LIMIT - gemsUsedAfter;
        
        message.AppendLine("📊 *Лимиты сегодня:*");
        message.AppendLine($"• Использовано: {gemsUsedAfter}/{DAILY_GEMS_LIMIT} гемов");
        message.AppendLine($"• Осталось: {gemsRemainingAfter} гемов");
        message.AppendLine($"• Сбросится в: 00:00 UTC");
        message.AppendLine("");
        
        message.AppendLine("📤 *Отправитель:*");
        message.AppendLine($"👤 Аккаунт: `{senderTag}`");
        message.AppendLine($"👤 Имя: {senderAccount.Avatar.Name}");
        message.AppendLine($"💰 Новый баланс: {senderAccount.Avatar.Diamonds} гемов");
        message.AppendLine("");
        
        message.AppendLine("📥 *Получатель:*");
        message.AppendLine($"👤 Аккаунт: `{receiverTag}`");
        message.AppendLine($"👤 Имя: {receiverAccount.Avatar.Name}");
        message.AppendLine($"💰 Новый баланс: {receiverAccount.Avatar.Diamonds} гемов");
        message.AppendLine("");
        
        message.AppendLine("📋 *Детали перевода:*");
        message.AppendLine($"🎁 Передано: {amount} гемов");
        message.AppendLine($"💸 Комиссия: {commission} гемов (5%)");
        message.AppendLine($"📤 Списано всего: {totalToDeduct} гемов");
        message.AppendLine("");
        
        message.AppendLine("🔒 *Перевод защищен:*");
        message.AppendLine("• Проверка существования аккаунтов ✅");
        message.AppendLine("• Ежедневный лимит 4000 гемов ✅");
        message.AppendLine("• Комиссия предотвращает спам ✅");
        message.AppendLine("• Логирование операций ✅");
        
        // Кнопка для быстрого просмотра баланса
        var keyboard = new
        {
            inline_keyboard = new[]
            {
                new[]
                {
                    new { text = "💰 Мой баланс", callback_data = "check_balance" },
                    new { text = "📋 Мои аккаунты", callback_data = "my_accounts_list" }
                },
                new[]
                {
                    new { text = "📊 Лимиты", callback_data = "show_limits" },
                    new { text = "🔄 Ещё перевод", callback_data = "transfer_again" }
                }
            }
        };
        
        string keyboardJson = System.Text.Json.JsonSerializer.Serialize(keyboard);
        
        await _client.SendMessageWithKeyboardAsync(chatId, 
            message.ToString(), 
            keyboardJson,
            TelegramClient.ParseMode.MarkdownV2);

        // Отправляем уведомление получателю (если он привязан к Telegram)
        var receiverTelegramId = _linkManager.GetTelegramIdByAccountTag(receiverTag);
        if (receiverTelegramId.HasValue)
        {
            try
            {
                await _client.SendMessageAsync(receiverTelegramId.Value,
                    $"🎁 *ВЫ ПОЛУЧИЛИ ГЕМЫ!*\n\n" +
                    $"От: `{senderTag}` ({senderAccount.Avatar.Name})\n" +
                    $"Получено: **{amount}** гемов 💎\n" +
                    $"Ваш баланс: **{receiverAccount.Avatar.Diamonds}** гемов\n" +
                    $"Время: {DateTime.UtcNow:HH:mm:ss}",
                    TelegramClient.ParseMode.MarkdownV2);
            }
            catch { }
        }

    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TransferGems] Ошибка: {ex.Message}");
        
        await _client.SendMessageAsync(chatId,
            $"❌ *Ошибка при выполнении перевода!*\n\n" +
            $"```{ex.Message}```\n\n" +
            $"Попробуйте позже или обратитесь к администратору.",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

private const string LIMITS_FILE_PATH = "./daily_limits.json";

private void LoadDailyLimits()
{
    try
    {
        string filePath = LIMITS_FILE_PATH;
        Console.WriteLine($"[TransferGems] Загрузка лимитов из: {filePath}");
        
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            Console.WriteLine($"[TransferGems] JSON размер: {json.Length} байт");
            
            // Проверяем, не пустой ли файл
            if (string.IsNullOrWhiteSpace(json))
            {
                Console.WriteLine($"[TransferGems] Файл пустой, инициализируем пустым списком");
                json = "[]";
                File.WriteAllText(filePath, json);
            }
            
            var records = Newtonsoft.Json.JsonConvert.DeserializeObject<List<DailyLimitsRecord>>(json) 
                ?? new List<DailyLimitsRecord>();
            
            Console.WriteLine($"[TransferGems] Загружено {records.Count} записей");
            
            _dailyLimits.Clear(); // Очищаем перед загрузкой
            
            foreach (var record in records)
            {
                _dailyLimits[record.TelegramUserId] = record;
                Console.WriteLine($"[TransferGems] Загружен лимит для {record.TelegramUserId}: {record.GemsTransferred} гемов, дата: {record.LastTransferDate:dd.MM.yyyy}");
            }
            
            if (records.Count == 0)
            {
                Console.WriteLine($"[TransferGems] Нет записей в файле, создаем новую структуру");
            }
        }
        else
        {
            Console.WriteLine($"[TransferGems] Файл {filePath} не найден, создаем новый");
            File.WriteAllText(filePath, "[]");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TransferGems] КРИТИЧЕСКАЯ ошибка загрузки лимитов: {ex.Message}");
        Console.WriteLine($"[TransferGems] StackTrace: {ex.StackTrace}");
        
        // Создаем новый файл при ошибке
        try
        {
            File.WriteAllText(LIMITS_FILE_PATH, "[]");
            Console.WriteLine($"[TransferGems] Создан новый файл лимитов");
        }
        catch { }
    }
}

private void SaveDailyLimits()
{
    try
    {
        var records = _dailyLimits.Values.ToList();
        string json = Newtonsoft.Json.JsonConvert.SerializeObject(records, Newtonsoft.Json.Formatting.Indented);
        File.WriteAllText(LIMITS_FILE_PATH, json);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TransferGems] Ошибка сохранения лимитов: {ex.Message}");
    }
}

// Сохраняем периодически
private async Task StartDailyLimitsAutoSave()
{
    while (true)
    {
        try
        {
            await Task.Delay(TimeSpan.FromMinutes(5)); // Сохраняем каждые 5 минут
            SaveDailyLimits();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TransferGems] Ошибка автосохранения лимитов: {ex.Message}");
        }
    }
}






private async Task ShowTransferLimits(long chatId, long userId)
{
    int gemsUsedToday = GetGemsTransferredToday(userId);
    int gemsRemaining = DAILY_GEMS_LIMIT - gemsUsedToday;
    
    var timeUntilReset = DateTime.UtcNow.Date.AddDays(1) - DateTime.UtcNow;
    
    var message = new StringBuilder();
    message.AppendLine("📊 *ВАШИ ЛИМИТЫ ПЕРЕВОДОВ*");
    message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    message.AppendLine("");
    message.AppendLine("💰 *Гемы сегодня:*");
    message.AppendLine($"• Использовано: **{gemsUsedToday}**/{DAILY_GEMS_LIMIT} гемов");
    message.AppendLine($"• Доступно: **{gemsRemaining}** гемов");
    message.AppendLine($"• Процент: **{(gemsUsedToday * 100 / DAILY_GEMS_LIMIT)}%**");
    message.AppendLine("");
    
    // Прогресс-бар
    int progressBars = (gemsUsedToday * 10) / DAILY_GEMS_LIMIT;
    string progressBar = new string('▓', progressBars) + new string('░', 10 - progressBars);
    message.AppendLine($"📈 Прогресс: `{progressBar}`");
    message.AppendLine("");
    
    message.AppendLine("⏰ *Сброс лимитов:*");
    message.AppendLine($"• Время сброса: **00:00 UTC**");
    message.AppendLine($"• Осталось времени: **{timeUntilReset.Hours}ч {timeUntilReset.Minutes}м**");
    message.AppendLine($"• Дата сброса: **{DateTime.UtcNow.Date.AddDays(1):dd.MM.yyyy}**");
    message.AppendLine("");
    
    message.AppendLine("⚙️ *Основные правила:*");
    message.AppendLine($"• Максимум в день: **{DAILY_GEMS_LIMIT}** гемов");
    message.AppendLine($"• Минимум за раз: **10** гемов");
    message.AppendLine($"• Максимум за раз: **1000** гемов");
    message.AppendLine($"• Комиссия: **5%** (минимум 1 гем)");
    message.AppendLine("");
    
    message.AppendLine("💡 *Советы:*");
    if (gemsRemaining < 100)
    {
        message.AppendLine("• У вас почти исчерпан дневной лимит!");
    }
    else if (gemsRemaining < 1000)
    {
        message.AppendLine("• У вас осталось менее 1000 гемов до лимита");
    }
    else
    {
        message.AppendLine("• У вас еще много доступных гемов");
    }
    
    // Кнопки
    var keyboard = new
    {
        inline_keyboard = new[]
        {
            new[]
            {
                new { text = "💰 Сделать перевод", callback_data = "transfer_again" }
            },
            new[]
            {
                new { text = "📜 История переводов", callback_data = "transfer_history_callback" },
                new { text = "📋 Мои аккаунты", callback_data = "my_accounts_list" }
            }
        }
    };
    
    string keyboardJson = System.Text.Json.JsonSerializer.Serialize(keyboard);
    
    await _client.SendMessageWithKeyboardAsync(chatId, 
        message.ToString(), 
        keyboardJson,
        TelegramClient.ParseMode.MarkdownV2);
}


private async Task HandleTransferHistoryCommand(long chatId, long userId)
{
    try
    {
        string filePath = "./gems_transfers.json";
        if (!File.Exists(filePath))
        {
            await _client.SendMessageAsync(chatId,
                "📭 *История переводов пуста!*\n" +
                "Вы ещё не совершали переводов между аккаунтами.",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        string json = File.ReadAllText(filePath);
        var allTransfers = Newtonsoft.Json.JsonConvert.DeserializeObject<List<GemTransferRecord>>(json) 
            ?? new List<GemTransferRecord>();
        
        // Фильтруем по пользователю
        var userTransfers = allTransfers
            .Where(t => t.TelegramUserId == userId)
            .OrderByDescending(t => t.TransferTime)
            .Take(10)
            .ToList();
        
        if (!userTransfers.Any())
        {
            await _client.SendMessageAsync(chatId,
                "📭 *Ваша история переводов пуста!*",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        var message = new StringBuilder();
        message.AppendLine("📜 *ИСТОРИЯ ПЕРЕВОДОВ*");
        message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        message.AppendLine("");
        
        // Статистика
        int totalSent = userTransfers.Sum(t => t.Amount);
        int totalCommission = userTransfers.Sum(t => t.Commission);
        
        message.AppendLine("📊 *Статистика:*");
        message.AppendLine($"• Всего переводов: {userTransfers.Count}");
        message.AppendLine($"• Отправлено всего: {totalSent} гемов");
        message.AppendLine($"• Комиссий уплачено: {totalCommission} гемов");
        message.AppendLine($"• Списано всего: {userTransfers.Sum(t => t.TotalDeducted)} гемов");
        message.AppendLine("");
        
        message.AppendLine("🕐 *Последние переводы:*");
        foreach (var transfer in userTransfers.Take(5))
        {
            message.AppendLine($"`{transfer.SenderTag} → {transfer.ReceiverTag}`");
            message.AppendLine($"   💎 {transfer.Amount} гемов (комиссия: {transfer.Commission})");
            message.AppendLine($"   ⏰ {transfer.TransferTime:dd.MM HH:mm}");
            message.AppendLine($"   📊 Было лимита: {transfer.DailyRemainingBefore} гемов");
            message.AppendLine("");
        }
        
        message.AppendLine("🔄 *Команды:*");
        message.AppendLine("`/transfer_gems` - новый перевод");
        message.AppendLine("`/myaccounts` - мои аккаунты");
        message.AppendLine("`/account_info` - баланс");
        message.AppendLine("`/лимиты` - просмотр лимитов");
        
        await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ *Ошибка загрузки истории:* {ex.Message}",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

private async Task StartDailyLimitResetTask()
{
    while (true)
    {
        try
        {
            var now = DateTime.UtcNow;
            var nextReset = now.Date.AddDays(1); // Следующая полночь
            
            var timeUntilReset = nextReset - now;
            
            // Ждем до следующей полночи
            await Task.Delay(timeUntilReset);
            
            // Сбрасываем лимиты
            ResetDailyLimits();
            
            Console.WriteLine($"[TransferGems] Дневные лимиты сброшены в {DateTime.UtcNow:HH:mm:ss}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TransferGems] Ошибка сброса лимитов: {ex.Message}");
            await Task.Delay(TimeSpan.FromHours(1));
        }
    }
}


private async Task HandleShopResetCommand(long chatId, long userId)
{
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, "❌ Аккаунт не привязан!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    try
    {
        long accountId = TagToId(accountTag);
        var account = Accounts.Load(accountId);
        
        if (account?.Home == null)
        {
            await _client.SendMessageAsync(chatId, "❌ Аккаунт не найден!", TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Сбрасываем все покупки
        if (account.Home.OfferBundles != null)
        {
            int resetCount = 0;
            foreach (var offer in account.Home.OfferBundles)
            {
                if (offer.Purchased)
                {
                    offer.Purchased = false;
                    resetCount++;
                }
            }
            
            Accounts.Save(account);
            
            await _client.SendMessageAsync(chatId,
                $"🔄 *Магазин сброшен!*\n\n" +
                $"Сброшено {resetCount} покупок.\n" +
                $"Теперь вы можете заново забрать предложения.\n\n" +
                $"Используйте `/shop` для просмотра.",
                TelegramClient.ParseMode.MarkdownV2);
        }
    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ Ошибка: {ex.Message}",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

private async Task HandleShopClaimCommand(long chatId, long userId, string callbackData)
{
    try
    {
        // Извлекаем индекс
        string indexStr = callbackData.Replace("shop_claim_", "");
        if (!int.TryParse(indexStr, out int offerIndex))
        {
            await _client.SendMessageAsync(chatId, "❌ Ошибка индекса", TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        await _client.SendMessageAsync(chatId,
            $"🎁 *Забрано бесплатное предложение #{offerIndex + 1}!*\n\n" +
            $"Награда добавлена на ваш аккаунт.",
            TelegramClient.ParseMode.MarkdownV2);
    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ Ошибка: {ex.Message}",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

private async Task HandleShopBuyCommand(long chatId, long userId, string callbackData)
{
    try
    {
        // Извлекаем индекс
        string indexStr = callbackData.Replace("shop_buy_", "");
        if (!int.TryParse(indexStr, out int offerIndex))
        {
            await _client.SendMessageAsync(chatId, "❌ Ошибка индекса", TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        await _client.SendMessageAsync(chatId,
            $"🛒 *Покупка предложения #{offerIndex + 1}!*\n\n" +
            $"Товар приобретен и добавлен на ваш аккаунт.",
            TelegramClient.ParseMode.MarkdownV2);
    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ Ошибка: {ex.Message}",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

        private async Task HandleCommandAsync(long chatId, string commandText, long userId)
        {
            var parts = commandText.Split(' ', 2);
            var command = parts[0].ToLower();

            switch (command)
            {
                case "/start":
                    await HandleStartCommand(chatId);
                    break;
                case "/recover":
                    await HandleRecoverCommand(chatId, userId);
                    break;
                case "/reset_token":
                    await HandleResetTokenCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
                    break;
                case "/myaccounts":
                    await HandleMyAccountsCommand(chatId, userId);
                    break;
                case "/unlink":
                    await HandleUnlinkCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
                    break;
                case "/account_info":
                    await HandleAccountInfoCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
                    break;
                case "/quick_login":
                    await HandleQuickLoginCommand(chatId, userId);
                    break;
                case "/notifications":
                    await HandleNotificationsCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
                    break;
                case "/unlink_all":
                    await HandleUnlinkAllCommand(chatId, userId);
                    break;
                case "/spin":
                case "/колесо":
                case "/фортуна":
                    await HandleDailySpinCommand(chatId, userId);
                    break;
                    case "/transfer_gems":
case "/передать":
case "/transfer":
    await HandleTransferGemsCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
    break;
case "/лимиты":
case "/limits":
case "/transfer_limits":
    await ShowTransferLimits(chatId, userId);
    break;
case "/история_переводов":
case "/transfer_history":
    await HandleTransferHistoryCommand(chatId, userId);
    break;
                case "/santa_join":
                    await HandleSantaJoinCommand(chatId, userId);
                    break;
                case "/santa_list":
                    await HandleSantaListCommand(chatId);
                    break;
                case "/santa_gift":
                    await HandleSantaGiftCommand(chatId, userId, parts.Length > 1 ? parts[1].Split(' ') : Array.Empty<string>());
                    break;
                case "/santa_mygifts":
                    await HandleSantaMyGiftsCommand(chatId, userId);
                    break;
                case "/santa_top":
                    await HandleSantaTopCommand(chatId);
                    break;
                case "/santa_info":
                    await HandleSantaInfoCommand(chatId);
                    break;
                case "/santa_wish":
                    await HandleSantaWishCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
                    break;
                case "/santa_balance":
                    await HandleSantaBalanceCommand(chatId, userId);
                    break;
                case "/santa_stats":
                    await HandleSantaStatsCommand(chatId);
                    break;
                case "/santa_admin":
                    await HandleSantaAdminCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
                    break;
                case "/online":
                    await HandleOnlineCommand(chatId);
                    break;
                    case "/shop_view":
    string argument = parts.Length > 1 ? parts[1] : null;
    await HandleShopViewCommand(chatId, userId, argument);
    break;
                case "/resettg978256":
                    await HandleResetTelegramCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
                    break;
                case "/shop":
                    await HandleShopCommand(chatId, userId);
                    break;
                    case "/my_claims":
    await HandleClaimedOffersCommand(chatId, userId);
    break;
                    case "/skin_claims":
    await HandleSkinClaimsCommand(chatId, userId);
    break;
case "/skin_mark":
    await HandleSkinMarkCommand(chatId, userId, parts.Length > 1 ? parts[1] : null);
    break;
                case "/shop_refresh":
                    await HandleShopRefreshCommand(chatId, userId);
                    break;
                    case "/shop_fix9997272":
    await HandleQuickShopFixCommand(chatId, userId);
    break;
                    case "/sync_offers":
    await SyncOffersFromGame(chatId, userId);
    break;
case "/force_offers":
//    await HandleCreateTestOffersCommand(chatId, userId);
    break;
                case "/shop_debug":
                    await HandleShopDebugCommand(chatId, userId);
                    break;
                default:
                    await _client.SendMessageAsync(chatId, "❌ Неизвестная команда. Используйте /start для помощи.", TelegramClient.ParseMode.MarkdownV2);
                    break;
            }
        }

        private async Task HandleShopDebugCommand(long chatId, long userId)
{
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, 
            "❌ *Сначала привяжите аккаунт!*", 
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    long accountId = TagToId(accountTag);
    var account = Accounts.Load(accountId);
    
    var debugInfo = new StringBuilder();
    debugInfo.AppendLine("🔍 *ДЕБАГ МАГАЗИНА*");
    debugInfo.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    debugInfo.AppendLine("");
    
    if (account == null)
    {
        debugInfo.AppendLine("❌ Аккаунт не найден в базе данных");
    }
    else if (account.Home == null)
    {
        debugInfo.AppendLine("❌ ClientHome не инициализирован");
    }
    else if (account.Home.OfferBundles == null)
    {
        debugInfo.AppendLine("❌ OfferBundles = null (список предложений пуст)");
    }
    else
    {
        debugInfo.AppendLine($"✅ *Аккаунт:* `{accountTag}`");
        debugInfo.AppendLine($"✅ *Home:* Загружен");
        debugInfo.AppendLine($"✅ *Всего предложений:* {account.Home.OfferBundles.Count}");
        debugInfo.AppendLine("");
        
        int activeCount = 0;
        int freeCount = 0;
        
        foreach (var offer in account.Home.OfferBundles.Take(15))
        {
            bool isPurchased = offer.Purchased;
            bool isActive = offer.EndTime > DateTime.UtcNow;
            bool isFree = offer.Cost == 0;
            string status = isPurchased ? "🛒 Куплен" : (isActive ? "✅ Активен" : "⏰ Истек");
            
            // ИСПРАВЛЕНО: Не используем offer.Id
            debugInfo.AppendLine($"{status} *{offer.Title}*");
            debugInfo.AppendLine($"   Цена: {(isFree ? "БЕСПЛАТНО" : $"{offer.Cost}")}");
            debugInfo.AppendLine($"   Куплен: {isPurchased}");
            debugInfo.AppendLine($"   Действует до: {offer.EndTime:dd.MM.yyyy HH:mm}");
            debugInfo.AppendLine($"   Осталось: {(offer.EndTime - DateTime.UtcNow).TotalHours:F1} ч");
            debugInfo.AppendLine("");
            
            if (isActive && !isPurchased) activeCount++;
            if (isFree && !isPurchased) freeCount++;
        }
        
        debugInfo.AppendLine($"📊 *Статистика:*");
        debugInfo.AppendLine($"   • Активных: {activeCount}");
        debugInfo.AppendLine($"   • Бесплатных: {freeCount}");
        debugInfo.AppendLine($"   • Всего: {account.Home.OfferBundles.Count}");
    }
    
    await _client.SendMessageAsync(chatId, debugInfo.ToString(), TelegramClient.ParseMode.MarkdownV2);
}

        private async Task HandleShopRefreshCommand(long chatId, long userId)
        {
            if (!_linkManager.TryGetAccountId(userId, out string accountTag))
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ *Сначала привяжите аккаунт!*\n\nОтправьте свой игровой ТЭГ (например: `#2PP`)",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            long accountId = TagToId(accountTag);
            var account = Accounts.Load(accountId);
            
            if (account?.Home == null)
            {
                await _client.SendMessageAsync(chatId, "❌ *Ошибка загрузки аккаунта!*", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            try
            {
                // Попытка обновить акции в магазине
                bool refreshSuccess = await RefreshShopOffers(account);
                
                if (refreshSuccess)
                {
                    await _client.SendMessageAsync(chatId,
                        "🔄 *Магазин обновлён!*\n\n" +
                        "Используйте команду `/shop` для просмотра новых акций.",
                        TelegramClient.ParseMode.MarkdownV2);
                }
                else
                {
                    await _client.SendMessageAsync(chatId,
                        "⚠️ *Магазин уже содержит актуальные акции!*\n\n" +
                        "Используйте команду `/shop` для просмотра.",
                        TelegramClient.ParseMode.MarkdownV2);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TelegramShop] Ошибка обновления магазина: {ex.Message}");
                await _client.SendMessageAsync(chatId,
                    "❌ *Ошибка при обновлении магазина!*\n\n" +
                    "Попробуйте позже.",
                    TelegramClient.ParseMode.MarkdownV2);
            }
        }

        private async Task<bool> RefreshShopOffers(Account account)
        {
            try
            {
                // Проверяем текущие акции
                if (account.Home.OfferBundles == null)
                    account.Home.OfferBundles = new List<OfferBundle>();
                
                var currentCount = account.Home.OfferBundles.Count;
                
                // Здесь можно добавить логику для обновления акций
                // Например, добавить новые предложения или обновить существующие
                
                // Сохраняем изменения
                await Task.Run(() => Accounts.Save(account));
                
                Console.WriteLine($"[TelegramShop] Магазин обновлён для аккаунта {account.AccountId}");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TelegramShop] Ошибка обновления акций: {ex.Message}");
                return false;
            }
        }

        private async Task HandleShopCommand(long chatId, long userId)
{
    try
    {
        // Проверка привязки аккаунта
        if (!_linkManager.TryGetAccountId(userId, out string accountTag))
        {
            await _client.SendMessageAsync(chatId, 
                "❌ *Сначала привяжите аккаунт!*\n\nОтправьте свой игровой ТЭГ (например: `#2PP`)",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Загружаем аккаунт
        long accountId = TagToId(accountTag);
        var account = Accounts.Load(accountId);
        
        if (account?.Home?.OfferBundles == null)
        {
            await _client.SendMessageAsync(chatId, 
                "🛒 *МАГАЗИН ПУСТ!*\n\n",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        var allOffers = account.Home.OfferBundles;
        var claimedOffers = LoadClaimedOffers();
        
        Console.WriteLine($"[Shop] Загружено {allOffers.Count} предложений для {accountTag}");
        Console.WriteLine($"[Shop] Загружено {claimedOffers.Count} записей о забранных предложениях");

        // ФИЛЬТРАЦИЯ: активные + не забранные в кэше
        var activeOffers = new List<OfferBundle>();
        
        foreach (var offer in allOffers)
        {
            // Пропускаем купленные в игре
            if (offer.Purchased) continue;
            
            // Пропускаем истекшие
            if (offer.EndTime <= DateTime.UtcNow) continue;
            
            // Пропускаем если уже забрано в нашем кэше
            var mainItem = offer.Items?.FirstOrDefault();
            if (mainItem != null)
            {
                string offerHash = GenerateOfferHash(accountTag, offer.Title, offer.Cost, mainItem.Count);
                bool alreadyClaimed = claimedOffers.Any(c => 
                    c.TelegramUserId == userId && 
                    c.AccountTag == accountTag && 
                    c.OfferHash == offerHash);
                
                if (alreadyClaimed)
                {
                    Console.WriteLine($"[Shop] Пропускаем '{offer.Title}' - уже забрано в кэше");
                    continue;
                }
            }
            
            activeOffers.Add(offer);
        }

        // Сортируем: бесплатные первыми, затем по цене
        activeOffers = activeOffers
            .OrderByDescending(o => o.Cost == 0)
            .ThenBy(o => o.Cost)
            .Take(20)
            .ToList();

        // Логи для отладки
        Console.WriteLine($"[Shop] После фильтрации осталось {activeOffers.Count} активных предложений");
        if (activeOffers.Count > 0)
        {
            Console.WriteLine($"[Shop] Первое предложение: '{activeOffers[0].Title}' (Цена: {activeOffers[0].Cost})");
        }

        // Проверяем есть ли что показать
        if (!activeOffers.Any())
        {
            // Получаем статистику по забранным
            int userClaimsCount = claimedOffers.Count(c => 
                c.TelegramUserId == userId && c.AccountTag == accountTag);
            
            var message = new StringBuilder();
            message.AppendLine("🎉 *ВСЕ ПРЕДЛОЖЕНИЯ ЗАБРАНЫ!*");
            message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            message.AppendLine("");
            message.AppendLine($"Вы успешно забрали *{userClaimsCount}* предложений!");
            message.AppendLine("");
            message.AppendLine("🔄 *Что можно сделать:*");
            message.AppendLine("• Подождать новые предложения");
            message.AppendLine("• Использовать `/my_claims` чтобы посмотреть историю");
            message.AppendLine("• Использовать `/account_info` для проверки баланса\n\n/start");
            
            await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // СОЗДАЕМ СООБЩЕНИЕ С КНОПКАМИ
        var messageText = new StringBuilder();
        messageText.AppendLine("🛒 *МАГАЗИН INDUS BRAWL*");
        messageText.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        messageText.AppendLine("");
        messageText.AppendLine($"*Доступно:* {activeOffers.Count} предложений");
        
        // Добавляем информацию о забранных предложениях
        int userClaimsCount2 = claimedOffers.Count(c => 
            c.TelegramUserId == userId && c.AccountTag == accountTag);
        if (userClaimsCount2 > 0)
        {
            messageText.AppendLine($"*Уже забрано:* {userClaimsCount2} предложений");
        }
        
        messageText.AppendLine("");
        messageText.AppendLine("🎁 *Выберите предложение:*");

        // СОЗДАЕМ КНОПКИ
        var keyboardButtons = new List<object>();
        
        for (int i = 0; i < activeOffers.Count; i++)
        {
            var offer = activeOffers[i];
            string buttonText;
            
            // Укорачиваем длинные названия
            string shortTitle = offer.Title.Length > 20 
                ? offer.Title.Substring(0, 17) + "..." 
                : offer.Title;
            
            // Определяем эмодзи для типа
            string itemEmoji = "🎁";
            var mainItem = offer.Items?.FirstOrDefault();
            if (mainItem != null)
            {
                itemEmoji = mainItem.Type switch
                {
                    ShopItem.Gems => "💎",
                    ShopItem.Coin => "🪙",
                    ShopItem.Skin => "🎨",
                    ShopItem.PowerPoint => "⚡",
                    ShopItem.GuaranteedHero => "👤",
                    ShopItem.Titul => "🏷️",
                    ShopItem.RarityStarrDrop => "✨",
                    _ => "🎁"
                };
            }
            
            // Формируем текст кнопки
            if (offer.Cost == 0)
                buttonText = $"{itemEmoji} {shortTitle} (БЕСПЛАТНО)";
            else
                buttonText = $"{itemEmoji} {shortTitle} - {offer.Cost}";
            
            // Ограничиваем длину для Telegram API
            buttonText = buttonText.Length > 60 
                ? buttonText.Substring(0, 57) + "..." 
                : buttonText;
            
            keyboardButtons.Add(new[]
            {
                new
                {
                    text = buttonText,
                    callback_data = $"shop_view_{i}"
                }
            });
        }
        
        // ДОБАВЛЯЕМ ДОПОЛНИТЕЛЬНЫЕ КНОПКИ
        keyboardButtons.Add(new[]
        {
            new
            {
                text = "🔄 Обновить магазин",
                callback_data = "shop_refresh_list"
            },
            new
            {
                text = "📊 Мои покупки",
                callback_data = "my_claims_callback"
            }
        });
        
        keyboardButtons.Add(new[]
        {
            new
            {
                text = "🔧",
                callback_data = "shop_fix_callback999"
            },
            new
            {
                text = "📋 Статистика",
                callback_data = "shop_debug"
            }
        });

        var keyboard = new
        {
            inline_keyboard = keyboardButtons
        };
        
        string keyboardJson = System.Text.Json.JsonSerializer.Serialize(keyboard);
        
        // ОТПРАВЛЯЕМ СООБЩЕНИЕ
        await _client.SendMessageWithKeyboardAsync(chatId, 
            messageText.ToString(), 
            keyboardJson,
            TelegramClient.ParseMode.MarkdownV2);

    }
    catch (Exception ex)
    {
        Console.WriteLine($"[Shop] Критическая ошибка: {ex.Message}");
        Console.WriteLine($"[Shop] StackTrace: {ex.StackTrace}");
        
        await _client.SendMessageAsync(chatId,
            "❌ *Произошла ошибка при загрузке магазина!*\n\n",
            TelegramClient.ParseMode.MarkdownV2);
    }
}


private async Task HandleMyClaimsCommand(long chatId, long userId)
{
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, "❌ Аккаунт не привязан!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    var claimedOffers = LoadClaimedOffers()
        .Where(c => c.TelegramUserId == userId && c.AccountTag == accountTag)
        .OrderByDescending(c => c.ClaimedAt)
        .Take(15)
        .ToList();
    
    var message = new StringBuilder();
    message.AppendLine("📋 *МОИ ЗАБРАННЫЕ ПРЕДЛОЖЕНИЯ*");
    message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    message.AppendLine("");
    
    if (claimedOffers.Any())
    {
        message.AppendLine($"🎮 *Аккаунт:* `{accountTag}`");
        message.AppendLine($"");
        
        // Группируем по типам
        var gems = claimedOffers.Where(c => c.ItemType == ShopItem.Gems).Sum(c => c.ItemCount);
        var coins = claimedOffers.Where(c => c.ItemType == ShopItem.Coin).Sum(c => c.ItemCount);
        var powerPoints = claimedOffers.Where(c => c.ItemType == ShopItem.PowerPoint).Sum(c => c.ItemCount);
        var skins = claimedOffers.Count(c => c.ItemType == ShopItem.Skin);
        
        message.AppendLine("💰 *Общая статистика:*");
        if (gems > 0) message.AppendLine($"💎 Гемы: {gems}");
        if (coins > 0) message.AppendLine($"🪙 Монеты: {coins}");
        if (powerPoints > 0) message.AppendLine($"⚡ Очки силы: {powerPoints}");
        if (skins > 0) message.AppendLine($"🎨 Скины: {skins}");
        message.AppendLine($"");
        
        message.AppendLine("*Последние забранные:*");
        foreach (var claim in claimedOffers.Take(5))
        {
            string itemIcon = GetShopItemIcon(claim.ItemType);
            message.AppendLine($"• {itemIcon} **{claim.OfferTitle}**");
            message.AppendLine($"  🎁 {claim.ItemCount} | ⏰ {claim.ClaimedAt:dd.MM HH:mm}");
            message.AppendLine("");
        }
        
        message.AppendLine($"📊 *Всего забрано:* {claimedOffers.Count} предложений");
        message.AppendLine("");
        message.AppendLine("🔄 *Команды:*");
        message.AppendLine("`/shop` - вернуться в магазин");
    }
    else
    {
        message.AppendLine("📭 *Вы ещё не забирали предложения!*");
        message.AppendLine("");
        message.AppendLine("🎁 *Начните здесь:*");
        message.AppendLine("`/shop` - перейти в магазин");
    }
    
    // Кнопка возврата
    var keyboard = new
    {
        inline_keyboard = new[]
        {
            new[]
            {
                new { text = "← Назад в магазин", callback_data = "shop_back_to_list" }
            }
        }
    };
    
    string keyboardJson = System.Text.Json.JsonSerializer.Serialize(keyboard);
    
    await _client.SendMessageWithKeyboardAsync(chatId, 
        message.ToString(), 
        keyboardJson,
        TelegramClient.ParseMode.MarkdownV2);
}


// Метод для обрезки текста
private string Truncate(string text, int maxLength)
{
    if (string.IsNullOrEmpty(text) || text.Length <= maxLength)
        return text;
    
    return text.Substring(0, maxLength - 3) + "...";
}

// Запасной метод: отправка магазина в текстовом виде
private async Task SendShopAsText(long chatId, List<OfferBundle> activeOffers, string accountTag)
{
    var messageText = new StringBuilder();
    messageText.AppendLine("🛒 *МАГАЗИН INDUS BRAWL*");
    messageText.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    messageText.AppendLine("");
    messageText.AppendLine($"*Найдено:* {activeOffers.Count} предложений");
    messageText.AppendLine("");
    
    for (int i = 0; i < activeOffers.Count; i++)
    {
        var offer = activeOffers[i];
        messageText.AppendLine($"`#{i + 1}` *{offer.Title}*");
        
        if (offer.Cost == 0)
            messageText.AppendLine($"   🎁 *БЕСПЛАТНО*");
        else
            messageText.AppendLine($"   💰 {GetPriceInfo(offer)}");
            
        messageText.AppendLine("");
    }

    messageText.AppendLine("🔧 *КАК ИСПОЛЬЗОВАТЬ:*");
    messageText.AppendLine("`/shop_view [номер]` - просмотреть детали");
    messageText.AppendLine("*Пример:* `/shop_view 1`");
    messageText.AppendLine("");
    messageText.AppendLine("🔄 *ДРУГИЕ КОМАНДЫ:*");
    messageText.AppendLine("`/shop_debug` - диагностика");

    await _client.SendMessageAsync(chatId, messageText.ToString(), TelegramClient.ParseMode.MarkdownV2);
}

private async Task ProcessFreeOfferClaim(long chatId, long userId, int offerIndex)
{
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, "❌ Ошибка: аккаунт не найден!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    long accountId = TagToId(accountTag);
    var account = Accounts.Load(accountId);
    
    if (account?.Home?.OfferBundles == null)
    {
        await _client.SendMessageAsync(chatId, "❌ Магазин недоступен!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    var allOffers = account.Home.OfferBundles;
    
    // Получаем активные предложения
    var activeOffers = allOffers
        .Where(o => !o.Purchased && o.EndTime > DateTime.UtcNow)
        .OrderByDescending(o => o.Cost == 0)
        .ThenBy(o => o.Cost)
        .Take(20)
        .ToList();
    
    if (offerIndex < 0 || offerIndex >= activeOffers.Count)
    {
        await _client.SendMessageAsync(chatId, "❌ Предложение не найдено!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    var offer = activeOffers[offerIndex];
    var mainItem = offer.Items?.FirstOrDefault();
    
    if (mainItem == null)
    {
        await _client.SendMessageAsync(chatId, "❌ Ошибка в предложении!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }
    
    // ПРОВЕРКА 1: Уже забрано в нашем кэше?
    if (IsOfferAlreadyClaimed(userId, accountTag, offer.Title, offer.Cost, mainItem.Count))
    {
        await _client.SendMessageAsync(chatId, 
            $"❌ *Вы уже забирали это предложение!*\n\n" +
            $"🎁 **{offer.Title}**\n" +
            $"💰 *Стоимость:* {GetPriceInfo(offer)}\n\n" +
            $"⚠️ Нельзя забрать одно и то же предложение дважды!",
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }
    
    // ПРОВЕРКА 2: Если вдруг в игре помечено как купленное
    if (offer.Purchased)
    {
        // Добавляем в наш кэш на всякий случай
        MarkOfferAsClaimed(userId, accountTag, offer);
        
        await _client.SendMessageAsync(chatId, 
            $"❌ *Это предложение уже забрано!*\n\n" +
            $"🎁 **{offer.Title}**\n" +
            $"💰 *Стоимость:* {GetPriceInfo(offer)}",
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }
    
    // ПРОВЕРКА 3: Время действия
    if (offer.EndTime <= DateTime.UtcNow)
    {
        await _client.SendMessageAsync(chatId, "❌ Срок действия предложения истек!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }
    
    try
    {
        // ВЫДАЁМ НАГРАДУ
        var rewardsSummary = new StringBuilder();
        bool hasSkin = false;
        int skinId = 0;
        
        if (offer.Items != null)
        {
            foreach (var item in offer.Items)
            {
                if (item == null) continue;
                
                switch (item.Type)
                {
                    case ShopItem.Gems:
                        account.Avatar.Diamonds += item.Count;
                        rewardsSummary.AppendLine($"💎 +{item.Count} гемов");
                        break;
                        
                    case ShopItem.Coin:
                        account.Avatar.Gold += item.Count;
                        rewardsSummary.AppendLine($"🪙 +{item.Count} монет");
                        break;
                        
                    case ShopItem.PowerPoint:
                        account.Avatar.PowerPoints += item.Count;
                        rewardsSummary.AppendLine($"⚡ +{item.Count} очков силы");
                        break;
                        
                    case ShopItem.Skin:
                        hasSkin = true;
                        skinId = item.SkinDataId;
                        rewardsSummary.AppendLine($"🎨 Скин #{skinId}");
                        SaveSkinClaimRecord(userId, accountTag, skinId, offer.Title);
                        break;
                }
            }
        }
        
        // Сохраняем изменения в игре
        offer.Purchased = true;
        Accounts.Save(account);
        
        // ОТМЕЧАЕМ В НАШЕМ КЭШЕ КАК ЗАБРАННОЕ
        MarkOfferAsClaimed(userId, accountTag, offer);
        
        // Отправляем сообщение
        var message = new StringBuilder();
        message.AppendLine($"✅ *ПРЕДЛОЖЕНИЕ ЗАБРАНО!*");
        message.AppendLine($"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        message.AppendLine($"");
        message.AppendLine($"🎁 **{offer.Title}**");
        message.AppendLine($"👤 Аккаунт: `{accountTag}`");
        message.AppendLine($"");
        message.AppendLine($"💰 *Полученные награды:*");
        message.AppendLine(rewardsSummary.ToString());
        message.AppendLine($"");
        message.AppendLine($"🔄 *Используйте:*");
        message.AppendLine($"`/shop` - вернуться в магазин");
        
        await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
        
        if (hasSkin)
        {
            await NotifyAdminsAboutSkinClaim(userId, accountTag, skinId, offer.Title);
        }
    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ *Ошибка:* {ex.Message}",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

// Метод для сохранения записи о запросе скина
private void SaveSkinClaimRecord(long userId, string accountTag, int skinId, string offerTitle)
{
    try
    {
        string filePath = "./skin_claims.json";
        List<SkinClaimRecord> claims = new List<SkinClaimRecord>();
        
        if (File.Exists(filePath))
        {
            var json = File.ReadAllText(filePath);
            claims = Newtonsoft.Json.JsonConvert.DeserializeObject<List<SkinClaimRecord>>(json) ?? new List<SkinClaimRecord>();
        }
        
        claims.Add(new SkinClaimRecord
        {
            TelegramUserId = userId,
            AccountTag = accountTag,
            SkinId = skinId,
            OfferTitle = offerTitle,
            ClaimTime = DateTime.UtcNow,
            IsProcessed = false
        });
        
        var newJson = Newtonsoft.Json.JsonConvert.SerializeObject(claims, Newtonsoft.Json.Formatting.Indented);
        File.WriteAllText(filePath, newJson);
        
        Console.WriteLine($"[Shop] Запись о скине сохранена: {accountTag} -> скин {skinId}");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[Shop] Ошибка сохранения записи о скине: {ex.Message}");
    }
}

// В КОНЕЦ КЛАССА TelegramBot (перед последней }) добавь:
public static async Task StartRedirectBot()
{
    string token = "8296721330:AAGPNNz6Rv8a_FblxlVxo6piXTFzvtFgg34";
    
    Console.WriteLine($"🚀 Redirect bot запущен! → @dbmod1_bot");
    
    var client = new TelegramClient(token);
    int offset = 0;
    
    while (true)
    {
        try
        {
            var updates = await client.GetUpdatesAsync(offset);
            
            foreach (var update in updates)
            {
                offset = update.update_id + 1;
                
                if (update.message != null)
                {
                    // БЛЯДЬ ПРОСТО ССЫЛКА
                    await client.SendMessageAsync(update.message.chat.id,
                        "Мы переехали 👉 @dbmod1_bot",
                        TelegramClient.ParseMode.MarkdownV2);
                        
                    // Console.WriteLine($"➡️  Кинул ссылку");
                }
            }
            
            await Task.Delay(1000);
        }
        catch (Exception ex)
        {
           // Console.WriteLine($"Redirect error: {ex.Message}");
            await Task.Delay(5000);
        }
    }
}


private async Task HandleSkinClaimsCommand(long chatId, long userId)
{
    if (!IsAdmin(userId))
    {
        await _client.SendMessageAsync(chatId, "❌ *Нет доступа!*", TelegramClient.ParseMode.MarkdownV2);
        return;
    }
    
    try
    {
        string filePath = "./skin_claims.json";
        if (!File.Exists(filePath))
        {
            await _client.SendMessageAsync(chatId, "📭 *Нет запросов на скины!*", TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        var json = File.ReadAllText(filePath);
        var claims = Newtonsoft.Json.JsonConvert.DeserializeObject<List<SkinClaimRecord>>(json) ?? new List<SkinClaimRecord>();
        
        var pendingClaims = claims.Where(c => !c.IsProcessed).ToList();
        
        if (!pendingClaims.Any())
        {
            await _client.SendMessageAsync(chatId, 
                "✅ *Все запросы обработаны!*\n\n" +
                $"Всего записей: {claims.Count}\n" +
                $"Обработано: {claims.Count(c => c.IsProcessed)}",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        var message = new StringBuilder();
        message.AppendLine("🎨 *ОЖИДАЮЩИЕ ЗАПРОСЫ СКИНОВ*");
        message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        message.AppendLine("");
        
        for (int i = 0; i < Math.Min(pendingClaims.Count, 10); i++)
        {
            var claim = pendingClaims[i];
            message.AppendLine($"`#{i + 1}` *{claim.AccountTag}*");
            message.AppendLine($"   🎨 Скин: #{claim.SkinId}");
            message.AppendLine($"   🎁 Предложение: {claim.OfferTitle}");
            message.AppendLine($"   ⏰ Запрошен: {claim.ClaimTime:dd.MM HH:mm}");
            message.AppendLine($"   👤 Telegram: `{claim.TelegramUserId}`");
            message.AppendLine("");
        }
        
        message.AppendLine($"📊 *Статистика:*");
        message.AppendLine($"• Ожидает: {pendingClaims.Count}");
        message.AppendLine($"• Всего: {claims.Count}");
        message.AppendLine($"• Обработано: {claims.Count(c => c.IsProcessed)}");
        message.AppendLine("");
        message.AppendLine("⚙️ *Команды:*");
        message.AppendLine("`/skin_mark [номер]` - отметить как выполненное");
        
        await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ *Ошибка:* {ex.Message}",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

private async Task HandleSkinMarkCommand(long chatId, long userId, string input)
{
    if (!IsAdmin(userId))
    {
        await _client.SendMessageAsync(chatId, "❌ *Нет доступа!*", TelegramClient.ParseMode.MarkdownV2);
        return;
    }
    
    if (string.IsNullOrEmpty(input) || !int.TryParse(input, out int claimIndex) || claimIndex < 1)
    {
        await _client.SendMessageAsync(chatId,
            "ℹ️ *Использование:*\n" +
            "`/skin_mark [номер]`\n\n" +
            "Пример: `/skin_mark 1`",
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }
    
    try
    {
        string filePath = "./skin_claims.json";
        if (!File.Exists(filePath))
        {
            await _client.SendMessageAsync(chatId, "❌ Файл запросов не найден!", TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        var json = File.ReadAllText(filePath);
        var claims = Newtonsoft.Json.JsonConvert.DeserializeObject<List<SkinClaimRecord>>(json) ?? new List<SkinClaimRecord>();
        
        var pendingClaims = claims.Where(c => !c.IsProcessed).ToList();
        
        if (claimIndex > pendingClaims.Count)
        {
            await _client.SendMessageAsync(chatId,
                $"❌ Запрос #{claimIndex} не найден!\n" +
                $"Доступно: {pendingClaims.Count} запросов",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        var claim = pendingClaims[claimIndex - 1];
        claim.IsProcessed = true;
        
        var newJson = Newtonsoft.Json.JsonConvert.SerializeObject(claims, Newtonsoft.Json.Formatting.Indented);
        File.WriteAllText(filePath, newJson);
        
        await _client.SendMessageAsync(chatId,
            $"✅ *Запрос отмечен как выполненный!*\n\n" +
            $"👤 Аккаунт: `{claim.AccountTag}`\n" +
            $"🎨 Скин: #{claim.SkinId}\n" +
            $"🎁 Предложение: {claim.OfferTitle}\n\n" +
            $"📞 Можно уведомить пользователя:",
            TelegramClient.ParseMode.MarkdownV2);
        
        // Уведомляем пользователя
        try
        {
            await _client.SendMessageAsync(claim.TelegramUserId,
                $"🎨 *ВАШ СКИН ВЫДАН!*\n\n" +
                $"Администратор выдал вам скин:\n" +
                $"🎨 *{claim.OfferTitle}*\n" +
                $"👤 Аккаунт: `{claim.AccountTag}`\n\n" +
                $"✅ Скин добавлен в вашу коллекцию!\n" +
                $"🔄 Перезайдите в игру, чтобы увидеть изменения.",
                TelegramClient.ParseMode.MarkdownV2);
        }
        catch { }
    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ *Ошибка:* {ex.Message}",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

// Метод для уведомления администраторов
private async Task NotifyAdminsAboutSkinClaim(long userId, string accountTag, int skinId, string offerTitle)
{
    try
    {
        string message = $"🎨 *ЗАПРОС СКИНА*\n\n" +
                        $"👤 Пользователь: `{userId}`\n" +
                        $"🎮 Аккаунт: `{accountTag}`\n" +
                        $"🎨 Скин: #{skinId}\n" +
                        $"🎁 Предложение: {offerTitle}\n" +
                        $"⏰ Время: {DateTime.UtcNow:dd.MM.yyyy HH:mm}\n\n" +
                        $"📋 *Действие:*\n" +
                        $"1. Зайдите в игру как {accountTag}\n" +
                        $"2. Выдайте скин {skinId}\n" +
                        $"3. Отметьте как выполненное";
        
        foreach (var adminId in _adminIds)
        {
            try
            {
                await _client.SendMessageAsync(adminId, message, TelegramClient.ParseMode.MarkdownV2);
            }
            catch { }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[Shop] Ошибка уведомления администраторов: {ex.Message}");
    }
}

// Класс для записи о запросе скина
public class SkinClaimRecord
{
    public long TelegramUserId { get; set; }
    public string AccountTag { get; set; }
    public int SkinId { get; set; }
    public string OfferTitle { get; set; }
    public DateTime ClaimTime { get; set; }
    public bool IsProcessed { get; set; }
}

// Метод для попытки добавления скина разными способами
private void TryAddSkin(Account account, int skinId)
{
    try
    {
        Console.WriteLine($"[Shop] Пытаемся добавить скин {skinId}");
        var avatar = account.Avatar;
        
        // Метод 1: Попробуем добавить скин через героя
        // Найдем героя, которому принадлежит этот скин
        // Для этого нужно определить, какой бравлер использует этот скин
        
        // Попробуем найти героя по скину (предположим, что скин относится к какому-то герою)
        // В Indus Brawl скины обычно имеют ID типа: 16000000 + characterId * 1000 + skinIndex
        
        // Разберем skinId: например, 706
        // Нужно понять, к какому герою он относится
        
        // Метод 2: Попробуем найти метод в Hero классе
        if (avatar.Heroes != null && avatar.Heroes.Count > 0)
        {
            Console.WriteLine($"[Shop] Найдено {avatar.Heroes.Count} героев");
            
            // Попробуем добавить скин каждому герою
            foreach (var hero in avatar.Heroes)
            {
                var heroType = hero.GetType();
                Console.WriteLine($"[Shop] Тип Hero: {heroType.FullName}");
                
                // Выведем все методы Hero
                var methods = heroType.GetMethods();
                Console.WriteLine($"[Shop] Методы Hero с 'Skin' в названии:");
                foreach (var method in methods)
                {
                    if (method.Name.Contains("Skin", StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine($"[Shop]   {method.Name}");
                    }
                }
                
                // Выведем все свойства Hero
                var properties = heroType.GetProperties();
                Console.WriteLine($"[Shop] Свойства Hero ({properties.Length}):");
                foreach (var prop in properties)
                {
                    Console.WriteLine($"[Shop]   {prop.Name} ({prop.PropertyType.Name})");
                }
                
                // Попробуем найти методы для добавления скина
                string[] possibleMethods = 
                {
                    "AddSkin",
                    "UnlockSkin",
                    "GiveSkin",
                    "SetSkin",
                    "UnlockSkinId",
                    "AddSkinId"
                };
                
                foreach (var methodName in possibleMethods)
                {
                    var method = heroType.GetMethod(methodName);
                    if (method != null)
                    {
                        try
                        {
                            // Проверим параметры метода
                            var parameters = method.GetParameters();
                            if (parameters.Length == 1 && parameters[0].ParameterType == typeof(int))
                            {
                                method.Invoke(hero, new object[] { skinId });
                                Console.WriteLine($"[Shop] Успешно! Использован {methodName} для скина {skinId} у героя {hero.CharacterId}");
                                return;
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"[Shop] Ошибка при вызове {methodName}: {ex.Message}");
                        }
                    }
                }
                
                // Попробуем найти свойство для скинов
                string[] possibleProperties =
                {
                    "Skin",
                    "CurrentSkin",
                    "SelectedSkin",
                    "OwnedSkins",
                    "UnlockedSkins",
                    "Skins"
                };
                
                foreach (var propName in possibleProperties)
                {
                    var property = heroType.GetProperty(propName);
                    if (property != null)
                    {
                        try
                        {
                            if (property.PropertyType == typeof(int))
                            {
                                // Если это свойство для текущего скина
                                property.SetValue(hero, skinId);
                                Console.WriteLine($"[Shop] Установлен скин {skinId} через свойство {propName}");
                                return;
                            }
                            else if (property.PropertyType.IsGenericType && 
                                     property.PropertyType.GetGenericTypeDefinition() == typeof(List<>))
                            {
                                // Если это список скинов
                                var skins = property.GetValue(hero);
                                if (skins != null)
                                {
                                    var addMethod = property.PropertyType.GetMethod("Add");
                                    var containsMethod = property.PropertyType.GetMethod("Contains");
                                    
                                    if (containsMethod != null)
                                    {
                                        bool hasSkin = (bool)containsMethod.Invoke(skins, new object[] { skinId });
                                        if (!hasSkin && addMethod != null)
                                        {
                                            addMethod.Invoke(skins, new object[] { skinId });
                                            Console.WriteLine($"[Shop] Скин {skinId} добавлен в список через {propName}");
                                            return;
                                        }
                                        else if (hasSkin)
                                        {
                                            Console.WriteLine($"[Shop] Скин {skinId} уже есть в списке {propName}");
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"[Shop] Ошибка при работе со свойством {propName}: {ex.Message}");
                        }
                    }
                }
            }
        }
        
        // Метод 3: Если скин 706 - это скин "Hockey!", который относится к какому-то бравлеру
        // Давайте создадим временное решение для популярных скинов
        
        if (skinId == 706) // Hockey! скин
        {
            // Попробуем найти героя Shelly (ID 16000000)
            var shelly = avatar.GetHero(16000000);
            if (shelly != null)
            {
                // Попробуем установить скин напрямую
                Console.WriteLine($"[Shop] Найден герой Шелли, пытаемся установить скин {skinId}");
                
                // Попробуем найти поле или свойство для скина
                var heroType = shelly.GetType();
                var skinField = heroType.GetField("_skinId");
                var skinProperty = heroType.GetProperty("SkinId");
                
                if (skinField != null)
                {
                    skinField.SetValue(shelly, skinId);
                    Console.WriteLine($"[Shop] Установлен скин через поле _skinId");
                    return;
                }
                else if (skinProperty != null)
                {
                    skinProperty.SetValue(shelly, skinId);
                    Console.WriteLine($"[Shop] Установлен скин через свойство SkinId");
                    return;
                }
            }
        }
        
        Console.WriteLine($"[Shop] Не удалось найти способ добавления скина {skinId}");
        
        // Запасной вариант: добавим скин через уведомление
        Console.WriteLine($"[Shop] Будет создано уведомление о получении скина {skinId}");
        
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[Shop] Критическая ошибка при добавлении скина {skinId}: {ex.Message}");
        Console.WriteLine($"[Shop] StackTrace: {ex.StackTrace}");
    }
}


private bool CheckSkinAdded(Account account, int skinId)
{
    try
    {
        var avatar = account.Avatar;
        
        if (avatar.Heroes != null)
        {
            foreach (var hero in avatar.Heroes)
            {
                var heroType = hero.GetType();
                
                // Проверим разные возможные свойства для скина
                var properties = heroType.GetProperties();
                foreach (var prop in properties)
                {
                    // Ищем свойства связанные со скинами
                    if (prop.Name.Contains("Skin", StringComparison.OrdinalIgnoreCase))
                    {
                        try
                        {
                            var value = prop.GetValue(hero);
                            if (value != null)
                            {
                                if (prop.PropertyType == typeof(int))
                                {
                                    if ((int)value == skinId)
                                    {
                                        Console.WriteLine($"[Shop] Проверка: скин {skinId} найден в свойстве {prop.Name} = {value}");
                                        return true;
                                    }
                                }
                                else if (value is List<int> skinList)
                                {
                                    if (skinList.Contains(skinId))
                                    {
                                        Console.WriteLine($"[Shop] Проверка: скин {skinId} найден в списке {prop.Name}");
                                        return true;
                                    }
                                }
                                else if (value is System.Collections.IEnumerable enumerable)
                                {
                                    foreach (var item in enumerable)
                                    {
                                        if (item is int itemInt && itemInt == skinId)
                                        {
                                            Console.WriteLine($"[Shop] Проверка: скин {skinId} найден в коллекции {prop.Name}");
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                        catch
                        {
                            // Пропускаем ошибки при проверке свойств
                        }
                    }
                }
                
                // Проверим поля
                var fields = heroType.GetFields();
                foreach (var field in fields)
                {
                    if (field.Name.Contains("Skin", StringComparison.OrdinalIgnoreCase))
                    {
                        try
                        {
                            var value = field.GetValue(hero);
                            if (value != null)
                            {
                                if (field.FieldType == typeof(int))
                                {
                                    if ((int)value == skinId)
                                    {
                                        Console.WriteLine($"[Shop] Проверка: скин {skinId} найден в поле {field.Name} = {value}");
                                        return true;
                                    }
                                }
                            }
                        }
                        catch
                        {
                            // Пропускаем ошибки при проверке полей
                        }
                    }
                }
            }
        }
        
        Console.WriteLine($"[Shop] Проверка: скин {skinId} не найден ни у одного героя");
        return false;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[Shop] Ошибка при проверке скина: {ex.Message}");
        return false;
    }
}



private void AddSkinViaNotification(Account account, int skinId)
{
    try
    {
        // Создаем уведомление о получении скина
        if (account.Home != null)
        {
            var notification = new Notification
            {
                Id = 94,
                MessageEntry = $"Вы получили новый скин!",
                IsViewed = false,
                SkinID = skinId
            };
            
            if (account.Home.NotificationFactory == null)
            {
                account.Home.NotificationFactory = new NotificationFactory();
            }
            
            account.Home.NotificationFactory.Add(notification);
            Console.WriteLine($"[Shop] Создано уведомление о скине {skinId}");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[Shop] Ошибка при создании уведомления о скине: {ex.Message}");
    }
}

private async Task HandleShopViewCommand(long chatId, long userId, string input)
{
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, "❌ *Сначала привяжите аккаунт!*", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    if (string.IsNullOrEmpty(input) || !int.TryParse(input, out int offerNumber) || offerNumber < 1)
    {
        await _client.SendMessageAsync(chatId,
            "📋 *Использование:*\n" +
            "`/shop_view [номер]`\n\n" +
            "*Пример:*\n" +
            "`/shop_view 1` - посмотреть первое предложение\n" +
            "`/shop_view 3` - посмотреть третье предложение",
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    long accountId = TagToId(accountTag);
    var account = Accounts.Load(accountId);
    
    if (account?.Home?.OfferBundles == null)
    {
        await _client.SendMessageAsync(chatId, "❌ *Магазин недоступен!*", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    var allOffers = account.Home.OfferBundles;
    var activeOffers = allOffers
        .Where(b => !b.Purchased && b.EndTime > DateTime.UtcNow)
        .OrderByDescending(b => b.Cost == 0)
        .ThenBy(b => b.Cost)
        .Take(20)
        .ToList();

    if (offerNumber > activeOffers.Count)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ *Предложение #{offerNumber} не найдено!*\n" +
            $"Доступно предложений: {activeOffers.Count}",
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    var offer = activeOffers[offerNumber - 1]; // -1 потому что нумерация с 1
    
    // Создаем детальное сообщение
    var message = new StringBuilder();
    message.AppendLine($"🎁 *{offer.Title}*");
    message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    message.AppendLine("");
    
    // Содержимое
    message.AppendLine("📦 *Содержимое:*");
    if (offer.Items != null && offer.Items.Count > 0)
    {
        foreach (var item in offer.Items)
        {
            if (item == null) continue;
            
            string itemName = GetShopItemName(item.Type, item.SkinDataId, item.ItemDataId);
            string itemIcon = GetShopItemIcon(item.Type);
            
            message.AppendLine($"{itemIcon} {itemName} ×{item.Count}");
        }
    }
    else
    {
        message.AppendLine("⚠️ Нет информации о содержимом");
    }
    
    message.AppendLine("");
    
    // Цена
    message.AppendLine("💰 *Стоимость:*");
    if (offer.Cost == 0)
    {
        message.AppendLine("🎁 *БЕСПЛАТНО*");
    }
    else
    {
        message.AppendLine($"{GetPriceInfoDetailed(offer)}");
        
        if (offer.OldCost > 0 && offer.OldCost > offer.Cost)
        {
            int discount = 100 - (offer.Cost * 100 / offer.OldCost);
            message.AppendLine($"🔥 *Экономия: {discount}%*");
        }
    }
    
    message.AppendLine("");
    
    // Время действия
    message.AppendLine("⏰ *Акция действует до:*");
    message.AppendLine($"{offer.EndTime:dd.MM.yyyy HH:mm}");
    
    var timeLeft = offer.EndTime - DateTime.UtcNow;
    if (timeLeft.TotalDays > 0)
        message.AppendLine($"⏳ *Осталось: {timeLeft.Days}д {timeLeft.Hours}ч*");
    else if (timeLeft.TotalHours > 0)
        message.AppendLine($"⏳ *Осталось: {timeLeft.Hours}ч {timeLeft.Minutes}м*");
    
    message.AppendLine("");
    
    // Баланс
    message.AppendLine("💳 *Ваш баланс:*");
    message.AppendLine(GetBalanceInfo(account));
    
    message.AppendLine("");
    message.AppendLine("🔄 *Для возврата в магазин:*");
    message.AppendLine("`/shop`");

    await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
}

        private string GetOfferButtonText(OfferBundle offer, Offer mainItem)
{
    if (offer == null) return "Предложение";
    
    string itemType = "";
    
    if (mainItem != null)
    {
        itemType = mainItem.Type switch
        {
            ShopItem.Gems => "💎",
            ShopItem.Coin => "🪙",
            ShopItem.Skin => "🎨",
            ShopItem.Bling => "💠",
            ShopItem.PowerPoint => "⚡",
            ShopItem.GuaranteedHero => "👤",
            ShopItem.Titul => "🏷️",
            ShopItem.RarityStarrDrop => "✨",
            _ => "🎁"
        };
    }
    
    string priceInfo = GetPriceInfo(offer);
    
    if (offer.Cost == 0)
        return $"{itemType} {offer.Title}";
    else
        return $"{itemType} {offer.Title} - {priceInfo}";
}

        private async Task HandleShopViewCallback(long chatId, int messageId, long userId, string callbackData)
{
    try
    {
        // Извлекаем индекс
        string indexStr = callbackData.Replace("shop_view_", "");
        if (!int.TryParse(indexStr, out int offerIndex))
        {
            await _client.SendMessageAsync(chatId, "❌ Ошибка: неверный индекс предложения", TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        if (!_linkManager.TryGetAccountId(userId, out string accountTag))
        {
            await _client.SendMessageAsync(chatId, "❌ Аккаунт не привязан", TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        long accountId = TagToId(accountTag);
        var account = Accounts.Load(accountId);
        
        if (account?.Home?.OfferBundles == null)
        {
            await _client.SendMessageAsync(chatId, "❌ Магазин недоступен", TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        var allOffers = account.Home.OfferBundles;
        
        // Находим предложение по индексу из активного списка
        var activeOffers = allOffers
            .Where(b => !b.Purchased && b.EndTime > DateTime.UtcNow)
            .OrderByDescending(b => b.Cost == 0)
            .ThenBy(b => b.Cost)
            .Take(20)
            .ToList();

        if (offerIndex < 0 || offerIndex >= activeOffers.Count)
        {
            await _client.SendMessageAsync(chatId,
                $"❌ Предложение #{offerIndex + 1} не найдено!\nДоступно: {activeOffers.Count} предложений",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        var offer = activeOffers[offerIndex];
        
        // Создаем детальное сообщение
        var message = new StringBuilder();
        
        // Заголовок
        message.AppendLine($"🎁 *{offer.Title}*");
        message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        message.AppendLine("");
        
        // Содержимое
        message.AppendLine("📦 *Содержимое:*");
        if (offer.Items != null && offer.Items.Count > 0)
        {
            foreach (var item in offer.Items)
            {
                if (item == null) continue;
                
                string itemName = GetShopItemName(item.Type, item.SkinDataId, item.ItemDataId);
                string itemIcon = GetShopItemIcon(item.Type);
                
                message.AppendLine($"{itemIcon} {itemName} ×{item.Count}");
            }
        }
        else
        {
            message.AppendLine("⚠️ Нет информации о содержимом");
        }
        
        message.AppendLine("");
        
        // Цена
        message.AppendLine("💰 *Стоимость:*");
        if (offer.Cost == 0)
        {
            message.AppendLine("🎁 *БЕСПЛАТНО*");
        }
        else
        {
            message.AppendLine($"{GetPriceInfoDetailed(offer)}");
        }
        
        message.AppendLine("");
        
        // Время действия
        message.AppendLine("⏰ *Действует до:*");
        message.AppendLine($"{offer.EndTime:dd.MM.yyyy HH:mm}");
        
        var timeLeft = offer.EndTime - DateTime.UtcNow;
        if (timeLeft.TotalDays > 0)
            message.AppendLine($"⏳ *Осталось: {timeLeft.Days}д {timeLeft.Hours}ч*");
        else if (timeLeft.TotalHours > 0)
            message.AppendLine($"⏳ *Осталось: {timeLeft.Hours}ч {timeLeft.Minutes}м*");
        
        message.AppendLine("");
        
        // Статус
        if (offer.Purchased)
        {
            message.AppendLine("✅ *Уже забрано*");
        }
        
        // Создаем кнопки
        var keyboardButtons = new List<object>();
        
        if (!offer.Purchased && offer.Cost == 0)
        {
            // БЕСПЛАТНАЯ акция - кнопка "ЗАБРАТЬ"
            keyboardButtons.Add(new[]
            {
                new
                {
                    text = "🎁 ЗАБРАТЬ БЕСПЛАТНО",
                    callback_data = $"shop_claim_{offerIndex}"
                }
            });
        }
        else if (!offer.Purchased && offer.Cost > 0)
        {
            // ПЛАТНАЯ акция - проверяем баланс
            bool canAfford = CanAffordOffer(account, offer);
            
            if (canAfford)
            {
                string priceInfo = GetPriceInfo(offer);
                keyboardButtons.Add(new[]
                {
                    new
                    {
                        text = $"🛒 КУПИТЬ ЗА {priceInfo}",
                        callback_data = $"shop_buy_{offerIndex}"
                    }
                });
            }
            else
            {
                keyboardButtons.Add(new[]
                {
                    new
                    {
                        text = "❌ НЕДОСТАТОЧНО СРЕДСТВ",
                        callback_data = "shop_balance_warning"
                    }
                });
            }
        }
        
        // Кнопки навигации
        keyboardButtons.Add(new[]
        {
            new
            {
                text = "← Назад",
                callback_data = "shop_back_to_list"
            }
        });
        
        var keyboard = new
        {
            inline_keyboard = keyboardButtons
        };
        
        string keyboardJson = System.Text.Json.JsonSerializer.Serialize(keyboard);
        
        try
        {
            await _client.SendMessageWithKeyboardAsync(chatId, 
                message.ToString(), 
                keyboardJson,
                TelegramClient.ParseMode.MarkdownV2);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TelegramShop] Ошибка отправки сообщения: {ex.Message}");
            
            // Отправляем без кнопок как запасной вариант
            await _client.SendMessageAsync(chatId,
                message.ToString() + "\n\n*Используйте:*\n`/shop` - вернуться в магазин",
                TelegramClient.ParseMode.MarkdownV2);
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TelegramShop] Ошибка в HandleShopViewCallback: {ex.Message}");
        await _client.SendMessageAsync(chatId,
            $"❌ Ошибка: {ex.Message}\n\nИспользуйте `/shop` для возврата",
            TelegramClient.ParseMode.MarkdownV2);
    }
}
        
        
        private async Task HandleQuickShopFixCommand(long chatId, long userId)
{
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, 
            "❌ *Сначала привяжите аккаунт!*\n\nОтправьте свой ТЭГ (например: #2PP)",
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    try
    {
        long accountId = TagToId(accountTag);
        var account = Accounts.Load(accountId);
        
        if (account == null)
        {
            await _client.SendMessageAsync(chatId,
                $"❌ *Аккаунт `{accountTag}` не найден!*",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        if (account.Home == null)
        {
            await _client.SendMessageAsync(chatId,
                "❌ *ClientHome не инициализирован!*\n\n" +
                "Войдите в игру хотя бы раз.",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Создаем или очищаем список предложений
        if (account.Home.OfferBundles == null)
        {
            account.Home.OfferBundles = new List<OfferBundle>();
            Console.WriteLine($"[ShopFix] Создан новый список предложений");
        }
        else
        {
            Console.WriteLine($"[ShopFix] Очищаем {account.Home.OfferBundles.Count} старых предложений");
            account.Home.OfferBundles.Clear();
        }

        // Добавляем популярные предложения из Indus Brawl
        // 1. Скин "Hockey!"
        account.Home.OfferBundles.Add(CreateShopOffer(
            "hockey_skin_offer",
            "Hockey!",
            ShopItem.Skin,
            706, // Skin ID
            1,   // Count
            0,   // Cost (бесплатно)
            149  // Old cost
        ));

        // 2. 149 гемов
        account.Home.OfferBundles.Add(CreateShopOffer(
            "gems_149_offer", 
            "149 гемов",
            ShopItem.Gems,
            0,   // No skin
            149, // Count
            0,   // Cost (бесплатно)
            299  // Old cost
        ));

        // 3. 1000 монет
        account.Home.OfferBundles.Add(CreateShopOffer(
            "coins_1000_offer",
            "1000 монет", 
            ShopItem.Coin,
            0,    // No skin
            1000, // Count
            0,    // Cost (бесплатно)
            49    // Old cost
        ));

        // 4. Очки силы
        account.Home.OfferBundles.Add(CreateShopOffer(
            "powerpoints_500_offer",
            "500 очков силы",
            ShopItem.PowerPoint,
            0,    // No skin
            500,  // Count
            0,    // Cost (бесплатно)
            29    // Old cost
        ));

        // 5. Титул "Зима"
        account.Home.OfferBundles.Add(CreateShopOffer(
            "title_winter_offer",
            "Титул: Зима",
            ShopItem.Titul,
            100,  // Title ID
            1,    // Count
            0,    // Cost (бесплатно)
            59    // Old cost
        ));

        // Сохраняем изменения
        Accounts.Save(account);
        
        Console.WriteLine($"[ShopFix] Создано {account.Home.OfferBundles.Count} предложений для {accountTag}");

        await _client.SendMessageAsync(chatId,
            $"✅ *МАГАЗИН СОЗДАН!*\n\n" +
            $"🎮 *Аккаунт:* `{accountTag}`\n" +
            $"🎁 *Предложений:* {account.Home.OfferBundles.Count}\n" +
            $"📅 *Действуют до:* {DateTime.UtcNow.AddDays(30):dd.MM.yyyy}\n\n" +
            $"✨ *Теперь используйте:*\n" +
            $"`/shop` - просмотр магазина\n" +
            $"`/shop_debug` - диагностика\n\n" +
            $"🎅 *Если не видно предложений:*\n" +
            $"1. Подождите 1 минуту\n" +
            $"2. Используйте `/shop` снова",
            TelegramClient.ParseMode.MarkdownV2);

    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ *ОШИБКА:*\n```{ex.Message}```\n\n" +
            $"Stack Trace:\n```{ex.StackTrace?.Substring(0, Math.Min(ex.StackTrace.Length, 500))}...```",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

private OfferBundle CreateShopOffer(string id, string title, ShopItem itemType, int extraId, int count, int cost, int oldCost)
{
    return new OfferBundle
    {
     //   BundleId = id,
        Title = title,
        Purchased = false,
        EndTime = DateTime.UtcNow.AddDays(30),
        Cost = cost,
        OldCost = oldCost,
        Items = new List<Offer>
        {
            new Offer
            {
                Type = itemType,
                Count = count,
                SkinDataId = (itemType == ShopItem.Skin) ? extraId : 0,
                ItemDataId = (itemType == ShopItem.GuaranteedHero || itemType == ShopItem.Titul) ? extraId : 0
            }
        }
    };
}

        private string GetOfferIcon(OfferBundle offer)
        {
            if (offer.Cost == 0) return "🎁";
            
            var mainItem = offer.Items.FirstOrDefault();
            if (mainItem != null)
            {
                return mainItem.Type switch
                {
                    ShopItem.Skin => "🎨",
                    ShopItem.Gems => "💎",
                    ShopItem.GuaranteedHero => "👑",
                    ShopItem.RarityStarrDrop => "✨",
                    _ => "🛒"
                };
            }
            
            return "🛒";
        }

        private async Task HandleOnlineCommand(long chatId)
        {
            try
            {
                int onlineCount = Sessions.Count;
                
                string message = $"🟢 *Онлайн на сервере:* {onlineCount}";
                
                await _client.SendMessageAsync(chatId, message, TelegramClient.ParseMode.MarkdownV2);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TelegramBot] Ошибка получения онлайн: {ex.Message}");
                await _client.SendMessageAsync(chatId, 
                    "❌ *Не удалось получить информацию об онлайн!*",
                    TelegramClient.ParseMode.MarkdownV2);
            }
        }
        
        private string GetBalanceInfo(Account account)
        {
            if (account?.Avatar == null)
                return "Не удалось загрузить баланс";
            
            return $"💎 {account.Avatar.Diamonds} | 🪙 {account.Avatar.Gold} | ⚡ {account.Avatar.PowerPoints}";
        }

        private async Task HandleSantaJoinCommand(long chatId, long userId)
        {
            if (!IsSantaEventActive())
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ *Тайный Санта сейчас не активен!*\n\n{GetTimeRemaining()}",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (!_linkManager.TryGetAccountId(userId, out string accountTag))
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ *Сначала привяжи аккаунт!*\n\nОтправь свой игровой ТЭГ (например: `#2PP`)",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (_santaParticipants.ContainsKey(userId))
            {
                var participant = _santaParticipants[userId];
                await _client.SendMessageAsync(chatId, 
                    $"✅ *Ты уже участвуешь в Тайном Санте!*\n\n" +
                    $"🎁 *Статистика:*\n" +
                    $"• Отправлено подарков: {participant.TotalGiftsSent}\n" +
                    $"• Получено подарков: {participant.TotalGiftsReceived}\n" +
                    $"• Всего отправлено: {participant.TotalAmountSent}\n\n" +
                    $"📋 *Команды:*\n" +
                    $"• /santa_list - Список участников\n" +
                    $"• /santa_balance - Мой баланс\n" +
                    $"• /santa_mygifts - Мои подарки",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            _santaParticipants[userId] = new SantaParticipant
            {
                TelegramUserId = userId,
                AccountTag = accountTag,
                AccountId = TagToId(accountTag),
                JoinedAt = DateTime.UtcNow,
                IsActive = true,
                TotalGiftsSent = 0,
                TotalGiftsReceived = 0,
                TotalAmountSent = 0
            };

            SaveSantaData();

            await _client.SendMessageAsync(chatId, 
                $"🎅 *ТЫ В КОМАНДЕ САНТЫ!*\n\n" +
                $"🎄 *Твой тег:* `{accountTag}`\n" +
                $"👥 *Участников всего:* {_santaParticipants.Count}\n\n" +
                $"🎁 *Как дарить подарки:*\n" +
                $"`/santa_gift [тег] [кол-во] [тип]`\n" +
                $"*Пример:* `/santa_gift #89LJP 50 gems`\n\n" +
                $"📋 *Доступные команды:*\n" +
                $"• /santa_list - Все участники\n" +
                $"• /santa_top - Топ дарителей\n" +
                $"• /santa_mygifts - Мои подарки\n" +
                $"• /santa_balance - Мой баланс\n" +
                $"• /santa_wish [текст] - Пожелание\n\n" +
                $"{GetTimeRemaining()}",
                TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleSantaListCommand(long chatId)
        {
            if (!_santaParticipants.Any())
            {
                await _client.SendMessageAsync(chatId, 
                    "📭 *Пока никто не присоединился!*\n\n" +
                    "Стань первым участником:\n`/santa_join`",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            var activeParticipants = _santaParticipants.Values
                .Where(p => p.IsActive)
                .OrderBy(p => p.JoinedAt)
                .Take(30)
                .ToList();

            var message = new StringBuilder();
            message.AppendLine("🎄 *УЧАСТНИКИ ТАЙНОГО САНТЫ*");
            message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            message.AppendLine("");

            for (int i = 0; i < activeParticipants.Count; i++)
            {
                var p = activeParticipants[i];
                var giftInfo = $"🎁 {p.TotalGiftsSent} | 📥 {p.TotalGiftsReceived}";
                message.AppendLine($"`{i + 1}. {p.AccountTag}`");
                message.AppendLine($"   {giftInfo}");
                
                if (!string.IsNullOrEmpty(p.Wish))
                {
                    message.AppendLine($"   ✨ Желает: {p.Wish}");
                }
                message.AppendLine("");
            }

            message.AppendLine($"📊 *Всего участников:* {_santaParticipants.Count}");
            message.AppendLine($"🎅 *Активных:* {activeParticipants.Count}");
            message.AppendLine("");
            message.AppendLine("🎁 *Подарить подарок:*");
            message.AppendLine("`/santa_gift [тег] [кол-во] [тип]`");
            message.AppendLine("");
            message.AppendLine("📌 *Примеры:*");
            message.AppendLine("`/santa_gift #89LJP 50 gems`");
            message.AppendLine("`/santa_gift #89LJP 1000 coins`");
            message.AppendLine("`/santa_gift #89LJP 500 powerpoints`");

            await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleSantaGiftCommand(long chatId, long userId, string[] args)
        {
            if (!IsSantaEventActive())
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ *Тайный Санта завершён!*\n\n{GetTimeRemaining()}",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (args.Length < 3)
            {
                await _client.SendMessageAsync(chatId,
                    "❌ *Неправильный формат!*\n\n" +
                    "🎁 *Использование:*\n" +
                    "`/santa_gift [тег] [кол-во] [тип]`\n\n" +
                    "📌 *Примеры:*\n" +
                    "• `/santa_gift #89LJP 50 gems`\n" +
                    "• `/santa_gift #89LJP 1000 coins`\n" +
                    "• `/santa_gift #89LJP 500 powerpoints`\n\n" +
                    "💡 *Типы:* gems, coins, powerpoints",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            string targetTag = args[0].ToUpper();
            if (!int.TryParse(args[1], out int amount) || amount <= 0)
            {
                await _client.SendMessageAsync(chatId, "❌ *Неверное количество!*", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            string giftType = args[2].ToLower();
            if (!new[] { "gems", "coins", "powerpoints" }.Contains(giftType))
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ *Неверный тип!*\n\n" +
                    "Доступно: `gems`, `coins`, `powerpoints`",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (!_santaParticipants.ContainsKey(userId))
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ *Сначала присоединись к Тайному Санте!*\n\n" +
                    "Используй команду: `/santa_join`",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            var recipient = _santaParticipants.Values.FirstOrDefault(p => 
                p.AccountTag == targetTag && p.IsActive);
            
            if (recipient == null)
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ *Участник с тегом `{targetTag}` не найден!*\n\n" +
                    "Посмотреть всех участников:\n`/santa_list`",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (recipient.TelegramUserId == userId)
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ *Нельзя дарить подарки самому себе!* 🎅\n\n" +
                    "Подари подарок другому участнику!",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (!_dailyGiftLog.ContainsKey(userId))
            {
                _dailyGiftLog[userId] = new List<DateTime>();
            }

            var todayGifts = _dailyGiftLog[userId].Count(d => d.Date == DateTime.UtcNow.Date);
            if (todayGifts >= MAX_GIFTS_PER_DAY)
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ *Лимит подарков исчерпан!*\n\n" +
                    $"Максимально можно подарить {MAX_GIFTS_PER_DAY} подарков в день.\n" +
                    $"Завтра лимит обновится!",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            int maxAmount = giftType switch
            {
                "gems" => MAX_GEMS_PER_GIFT,
                "coins" => MAX_COINS_PER_GIFT,
                "powerpoints" => MAX_POWERPOINTS_PER_GIFT,
                _ => 100
            };

            if (amount > maxAmount)
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ *Слишком много!*\n\n" +
                    $"Максимально можно подарить {maxAmount} {GetGiftTypeName(giftType)} за раз.",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (!_linkManager.TryGetAccountId(userId, out string senderTag))
            {
                await _client.SendMessageAsync(chatId, "❌ *У тебя нет привязанного аккаунта!*", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            long senderAccountId = TagToId(senderTag);
            
            // ПЕРЕЗАГРУЖАЕМ аккаунт отправителя
            var senderAccount = Accounts.Load(senderAccountId);
            
            if (senderAccount?.Avatar == null)
            {
                await _client.SendMessageAsync(chatId, "❌ *Ошибка загрузки твоего аккаунта!*", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            bool hasEnough = giftType switch
            {
                "gems" => senderAccount.Avatar.Diamonds >= amount,
                "coins" => senderAccount.Avatar.Gold >= amount,
                "powerpoints" => senderAccount.Avatar.PowerPoints >= amount,
                _ => false
            };

            if (!hasEnough)
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ *Недостаточно {GetGiftTypeName(giftType)}!*\n\n" +
                    $"У тебя: *{GetResourceAmount(senderAccount, giftType)}*\n" +
                    $"Нужно: *{amount}*",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            long recipientAccountId = recipient.AccountId;
            
            // ПЕРЕЗАГРУЖАЕМ аккаунт получателя
            var recipientAccount = Accounts.Load(recipientAccountId);
            
            if (recipientAccount?.Avatar == null)
            {
                await _client.SendMessageAsync(chatId, $"❌ *Ошибка загрузки аккаунта получателя!*", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            // Логируем состояние ДО операции
            Console.WriteLine($"[Santa] ДО операции:");
            Console.WriteLine($"[Santa] Отправитель {senderTag}:");
            Console.WriteLine($"[Santa]   Diamonds: {senderAccount.Avatar.Diamonds}");
            Console.WriteLine($"[Santa]   Gold: {senderAccount.Avatar.Gold}");
            Console.WriteLine($"[Santa]   PowerPoints: {senderAccount.Avatar.PowerPoints}");
            Console.WriteLine($"[Santa] Получатель {targetTag}:");
            Console.WriteLine($"[Santa]   Diamonds: {recipientAccount.Avatar.Diamonds}");
            Console.WriteLine($"[Santa]   Gold: {recipientAccount.Avatar.Gold}");
            Console.WriteLine($"[Santa]   PowerPoints: {recipientAccount.Avatar.PowerPoints}");

            // ВЫПОЛНЯЕМ операцию
            switch (giftType)
            {
                case "gems":
                    senderAccount.Avatar.Diamonds -= amount;
                    recipientAccount.Avatar.Diamonds += amount;
                    break;
                case "coins":
                    senderAccount.Avatar.Gold -= amount;
                    recipientAccount.Avatar.Gold += amount;
                    break;
                case "powerpoints":
                    senderAccount.Avatar.PowerPoints -= amount;
                    recipientAccount.Avatar.PowerPoints += amount;
                    break;
            }

            // Логируем состояние ПОСЛЕ операции
            Console.WriteLine($"[Santa] ПОСЛЕ операции:");
            Console.WriteLine($"[Santa] Отправитель {senderTag}:");
            Console.WriteLine($"[Santa]   Diamonds: {senderAccount.Avatar.Diamonds}");
            Console.WriteLine($"[Santa]   Gold: {senderAccount.Avatar.Gold}");
            Console.WriteLine($"[Santa]   PowerPoints: {senderAccount.Avatar.PowerPoints}");
            Console.WriteLine($"[Santa] Получатель {targetTag}:");
            Console.WriteLine($"[Santa]   Diamonds: {recipientAccount.Avatar.Diamonds}");
            Console.WriteLine($"[Santa]   Gold: {recipientAccount.Avatar.Gold}");
            Console.WriteLine($"[Santa]   PowerPoints: {recipientAccount.Avatar.PowerPoints}");

            // СОХРАНЯЕМ оба аккаунта
            try
            {
                Console.WriteLine($"[Santa] Сохраняю отправителя...");
                Accounts.Save(senderAccount);
                Console.WriteLine($"[Santa] Отправитель сохранён");
                
                Console.WriteLine($"[Santa] Сохраняю получателя...");
                Accounts.Save(recipientAccount);
                Console.WriteLine($"[Santa] Получатель сохранён");
                
                Console.WriteLine($"[Santa] Оба аккаунта успешно сохранены!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Santa] Ошибка сохранения: {ex.Message}");
                Console.WriteLine($"[Santa] StackTrace: {ex.StackTrace}");
                await _client.SendMessageAsync(chatId, 
                    "❌ *Ошибка системы!* Попробуйте позже.",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            var giftId = Guid.NewGuid().ToString();
            var gift = new SantaGift
            {
                Id = giftId,
                FromUserId = userId,
                ToUserId = recipient.TelegramUserId,
                FromTag = senderTag,
                ToTag = targetTag,
                Amount = amount,
                GiftType = giftType,
                SentAt = DateTime.UtcNow,
                IsDelivered = true,
                Message = $"Подарок от {senderTag}"
            };
            
            _santaGifts[giftId] = gift;
            _dailyGiftLog[userId].Add(DateTime.UtcNow);

            if (_santaParticipants.TryGetValue(userId, out var senderParticipant))
            {
                senderParticipant.TotalGiftsSent++;
                senderParticipant.TotalAmountSent += amount;
                senderParticipant.LastGiftSent = DateTime.UtcNow;
            }

            if (_santaParticipants.TryGetValue(recipient.TelegramUserId, out var recipientParticipant))
            {
                recipientParticipant.TotalGiftsReceived++;
            }

            SaveSantaData();

            await _client.SendMessageAsync(chatId,
                $"🎁 *ПОДАРОК ОТПРАВЛЕН!*\n\n" +
                $"🎄 *Получатель:* `{targetTag}`\n" +
                $"🎁 *Подарок:* {amount} {GetGiftTypeName(giftType)}\n" +
                $"💰 *Твой баланс:* {GetResourceAmount(senderAccount, giftType)}\n" +
                $"📊 *Подарков сегодня:* {todayGifts + 1}/{MAX_GIFTS_PER_DAY}\n\n" +
                $"🎅 *Спасибо за участие в Тайном Санте!*",
                TelegramClient.ParseMode.MarkdownV2);

            try
            {
                await _client.SendMessageAsync(recipient.TelegramUserId,
                    $"🎁 *ТЫ ПОЛУЧИЛ ПОДАРОК!*\n\n" +
                    $"🎅 *От:* `{senderTag}`\n" +
                    $"🎁 *Подарок:* {amount} {GetGiftTypeName(giftType)}\n" +
                    $"💰 *Твой баланс:* {GetResourceAmount(recipientAccount, giftType)}\n\n" +
                    $"🎄 *Счастливого Рождества!*",
                    TelegramClient.ParseMode.MarkdownV2);
            }
            catch { }
        }

        private async Task HandleSantaMyGiftsCommand(long chatId, long userId)
        {
            if (!_santaParticipants.ContainsKey(userId))
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ *Ты не участвуешь в Тайном Санте!*\n\n" +
                    "Присоединись: `/santa_join`",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            var sentGifts = _santaGifts.Values
                .Where(g => g.FromUserId == userId)
                .OrderByDescending(g => g.SentAt)
                .Take(20)
                .ToList();

            var receivedGifts = _santaGifts.Values
                .Where(g => g.ToUserId == userId)
                .OrderByDescending(g => g.SentAt)
                .Take(20)
                .ToList();

            var participant = _santaParticipants[userId];

            var message = new StringBuilder();
            message.AppendLine("🎁 *МОИ ПОДАРКИ*");
            message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            message.AppendLine("");
            message.AppendLine($"📊 *Статистика:*");
            message.AppendLine($"• Отправлено: {participant.TotalGiftsSent}");
            message.AppendLine($"• Получено: {participant.TotalGiftsReceived}");
            message.AppendLine($"• Всего отправлено: {participant.TotalAmountSent}");
            message.AppendLine("");

            if (sentGifts.Any())
            {
                message.AppendLine("📤 *Отправленные:*");
                foreach (var gift in sentGifts.Take(5))
                {
                    message.AppendLine($"`→ {gift.ToTag}`: {gift.Amount} {GetGiftTypeName(gift.GiftType)}");
                    message.AppendLine($"  {gift.SentAt:dd.MM HH:mm}");
                    message.AppendLine("");
                }
            }

            if (receivedGifts.Any())
            {
                message.AppendLine("📥 *Полученные:*");
                foreach (var gift in receivedGifts.Take(5))
                {
                    message.AppendLine($"`← {gift.FromTag}`: {gift.Amount} {GetGiftTypeName(gift.GiftType)}");
                    message.AppendLine($"  {gift.SentAt:dd.MM HH:mm}");
                    message.AppendLine("");
                }
            }

            if (!sentGifts.Any() && !receivedGifts.Any())
            {
                message.AppendLine("📭 *Пока нет подарков!*\n");
                message.AppendLine("🎁 *Подари первым:*");
                message.AppendLine("`/santa_gift [тег] [кол-во] [тип]`");
            }

            await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleSantaTopCommand(long chatId)
        {
            var topGivers = _santaParticipants.Values
                .Where(p => p.TotalGiftsSent > 0)
                .OrderByDescending(p => p.TotalAmountSent)
                .ThenByDescending(p => p.TotalGiftsSent)
                .Take(15)
                .ToList();

            var topReceivers = _santaParticipants.Values
                .Where(p => p.TotalGiftsReceived > 0)
                .OrderByDescending(p => p.TotalGiftsReceived)
                .Take(15)
                .ToList();

            var message = new StringBuilder();
            message.AppendLine("🏆 *ТОП ТАЙНОГО САНТЫ*");
            message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            message.AppendLine("");

            if (topGivers.Any())
            {
                message.AppendLine("🎅 *ТОП ДАРИТЕЛЕЙ:*");
                for (int i = 0; i < Math.Min(topGivers.Count, 10); i++)
                {
                    var giver = topGivers[i];
                    string medal = i switch
                    {
                        0 => "🥇",
                        1 => "🥈",
                        2 => "🥉",
                        _ => $"`{i + 1}.`"
                    };
                    
                    message.AppendLine($"{medal} `{giver.AccountTag}`");
                    message.AppendLine($"   Подарков: {giver.TotalGiftsSent} | Всего: {giver.TotalAmountSent}");
                    message.AppendLine("");
                }
            }

            if (topReceivers.Any())
            {
                message.AppendLine("🎁 *ТОП ПОЛУЧАТЕЛЕЙ:*");
                for (int i = 0; i < Math.Min(topReceivers.Count, 10); i++)
                {
                    var receiver = topReceivers[i];
                    message.AppendLine($"`{i + 1}. {receiver.AccountTag}`");
                    message.AppendLine($"   Получено: {receiver.TotalGiftsReceived} подарков");
                    message.AppendLine("");
                }
            }

            if (!topGivers.Any() && !topReceivers.Any())
            {
                message.AppendLine("📊 *Пока нет статистики!*\n");
                message.AppendLine("🎁 *Стань первым в топе:*");
                message.AppendLine("`/santa_gift [тег] [кол-во] [тип]`");
            }

            message.AppendLine($"📈 *Общая статистика:*");
            message.AppendLine($"• Участников: {_santaParticipants.Count}");
            message.AppendLine($"• Всего подарков: {_santaGifts.Count}");
            message.AppendLine($"• Всего отправлено: {_santaParticipants.Values.Sum(p => p.TotalAmountSent)}");
            message.AppendLine("");
            message.AppendLine($"{GetTimeRemaining()}");

            await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleSantaInfoCommand(long chatId)
        {
            var message = new StringBuilder();
            message.AppendLine("🎅 *ТАЙНЫЙ САНТА*");
            message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            message.AppendLine("");
            message.AppendLine("🎄 *Как это работает:*");
            message.AppendLine("1. Присоединяешься: `/santa_join`");
            message.AppendLine("2. Даришь подарки другим участникам");
            message.AppendLine("3. Получаешь подарки от других");
            message.AppendLine("");
            message.AppendLine("🎁 *Команды:*");
            message.AppendLine("• `/santa_join` - Участвовать");
            message.AppendLine("• `/santa_list` - Участники");
            message.AppendLine("• `/santa_gift` - Подарить");
            message.AppendLine("• `/santa_mygifts` - Мои подарки");
            message.AppendLine("• `/santa_top` - Топ игроков");
            message.AppendLine("• `/santa_balance` - Мой баланс");
            message.AppendLine("• `/santa_wish [текст]` - Пожелание");
            message.AppendLine("");
            message.AppendLine("⚙️ *Лимиты:*");
            message.AppendLine($"• Максимально подарков в день: {MAX_GIFTS_PER_DAY}");
            message.AppendLine($"• Максимально гемов за раз: {MAX_GEMS_PER_GIFT}");
            message.AppendLine($"• Максимально монет за раз: {MAX_COINS_PER_GIFT}");
            message.AppendLine("");
            message.AppendLine($"{GetTimeRemaining()}");

            await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleSantaWishCommand(long chatId, long userId, string wishText)
        {
            if (!_santaParticipants.ContainsKey(userId))
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ *Сначала присоединись к Тайному Санте!*\n\n" +
                    "Используй команду: `/santa_join`",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (string.IsNullOrEmpty(wishText))
            {
                var currentWish = _santaParticipants[userId].Wish;
                if (!string.IsNullOrEmpty(currentWish))
                {
                    await _client.SendMessageAsync(chatId,
                        $"✨ *Твоё текущее пожелание:*\n\n" +
                        $"`{currentWish}`\n\n" +
                        $"Чтобы изменить, введи:\n" +
                        $"`/santa_wish [новое пожелание]`",
                        TelegramClient.ParseMode.MarkdownV2);
                }
                else
                {
                    await _client.SendMessageAsync(chatId,
                        "✨ *У тебя нет пожелания!*\n\n" +
                        "Расскажи, что ты хочешь получить:\n" +
                        "`/santa_wish [твоё пожелание]`\n\n" +
                        "*Пример:* `/santa_wish Хочу новый скин для Шелли!`",
                        TelegramClient.ParseMode.MarkdownV2);
                }
                return;
            }

            _santaParticipants[userId].Wish = wishText;
            SaveSantaData();

            await _client.SendMessageAsync(chatId,
                $"✨ *Пожелание сохранено!*\n\n" +
                $"`{wishText}`\n\n" +
                $"Теперь другие участники увидят твоё пожелание в списке!",
                TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleSantaBalanceCommand(long chatId, long userId)
        {
            if (!_linkManager.TryGetAccountId(userId, out string accountTag))
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ *У тебя нет привязанного аккаунта!*",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            long accountId = TagToId(accountTag);
            var account = Accounts.Load(accountId);
            
            if (account?.Avatar == null)
            {
                await _client.SendMessageAsync(chatId, "❌ *Ошибка загрузки аккаунта!*", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            var participant = _santaParticipants.ContainsKey(userId) ? _santaParticipants[userId] : null;

            var message = new StringBuilder();
            message.AppendLine("💰 *МОЙ БАЛАНС*");
            message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            message.AppendLine("");
            message.AppendLine($"👤 *Аккаунт:* `{accountTag}`");
            message.AppendLine("");
            message.AppendLine("💎 *Ресурсы:*");
            message.AppendLine($"• Гемы: {account.Avatar.Diamonds} ??");  // Ошибка в исходном коде - ?? должно быть числом
            message.AppendLine($"• Монеты: {account.Avatar.Gold} 🪙");
            message.AppendLine($"• Очки силы: {account.Avatar.PowerPoints} ⚡");
            message.AppendLine("");

            if (participant != null)
            {
                message.AppendLine("🎅 *Статистика Санты:*");
                message.AppendLine($"• Отправлено подарков: {participant.TotalGiftsSent}");
                message.AppendLine($"• Получено подарков: {participant.TotalGiftsReceived}");
                message.AppendLine($"• Всего отправлено: {participant.TotalAmountSent}");
                message.AppendLine("");
                
                var todayGifts = _dailyGiftLog.ContainsKey(userId) 
                    ? _dailyGiftLog[userId].Count(d => d.Date == DateTime.UtcNow.Date)
                    : 0;
                message.AppendLine($"*Сегодня:* {todayGifts}/{MAX_GIFTS_PER_DAY} подарков");
            }
            else
            {
                message.AppendLine("🎅 *Присоединись к Тайному Санте:*");
                message.AppendLine("`/santa_join`");
            }

            await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleSantaStatsCommand(long chatId)
        {
            var totalGifts = _santaGifts.Count;
            var totalAmount = _santaGifts.Values.Sum(g => g.Amount);
            var totalParticipants = _santaParticipants.Count;
            var activeParticipants = _santaParticipants.Values.Count(p => p.IsActive);

            var gemsGifted = _santaGifts.Values.Where(g => g.GiftType == "gems").Sum(g => g.Amount);
            var coinsGifted = _santaGifts.Values.Where(g => g.GiftType == "coins").Sum(g => g.Amount);
            var powerpointsGifted = _santaGifts.Values.Where(g => g.GiftType == "powerpoints").Sum(g => g.Amount);

            var message = new StringBuilder();
            message.AppendLine("📊 *СТАТИСТИКА ТАЙНОГО САНТЫ*");
            message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            message.AppendLine("");
            message.AppendLine("👥 *Участники:*");
            message.AppendLine($"• Всего: {totalParticipants}");
            message.AppendLine($"• Активных: {activeParticipants}");
            message.AppendLine("");
            message.AppendLine("🎁 *Подарки:*");
            message.AppendLine($"• Всего отправлено: {totalGifts}");
            message.AppendLine($"• Общая стоимость: {totalAmount}");
            message.AppendLine("");
            message.AppendLine("💰 *Распределение:*");
            message.AppendLine($"• Гемы: {gemsGifted} 💎");
            message.AppendLine($"• Монеты: {coinsGifted} 🪙");
            message.AppendLine($"• Очки силы: {powerpointsGifted} ⚡");
            message.AppendLine("");
            
            if (totalGifts > 0)
            {
                var avgGift = totalAmount / totalGifts;
                var giftsPerPerson = totalParticipants > 0 ? (double)totalGifts / totalParticipants : 0;
                
                message.AppendLine("📈 *Средние значения:*");
                message.AppendLine($"• Средний подарок: {avgGift}");
                message.AppendLine($"• Подарков на человека: {giftsPerPerson:F1}");
                message.AppendLine("");
            }

            message.AppendLine($"{GetTimeRemaining()}");

            await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleSantaAdminCommand(long chatId, long userId, string action)
        {
            if (!IsAdmin(userId))
            {
                await _client.SendMessageAsync(chatId, "❌ *Нет доступа!*", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (string.IsNullOrEmpty(action))
            {
                var stats = new StringBuilder();
                stats.AppendLine("🎅 *АДМИН ПАНЕЛЬ*");
                stats.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
                stats.AppendLine("");
                stats.AppendLine("📊 *Статистика:*");
                stats.AppendLine($"• Участников: {_santaParticipants.Count}");
                stats.AppendLine($"• Подарков: {_santaGifts.Count}");
                stats.AppendLine($"• Активных: {_santaParticipants.Values.Count(p => p.IsActive)}");
                stats.AppendLine("");
                stats.AppendLine("⚙️ *Команды:*");
                stats.AppendLine("• `/santa_admin stats` - Подробная статистика");
                stats.AppendLine("• `/santa_admin save` - Сохранить данные");
                stats.AppendLine("• `/santa_admin reset [участник]` - Сбросить участника");
                stats.AppendLine("• `/santa_admin remove_gift [id]` - Удалить подарок");
                stats.AppendLine("• `/santa_admin export` - Экспорт данных");
                
                await _client.SendMessageAsync(chatId, stats.ToString(), TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            var parts = action.Split(' ', 2);
            var subCommand = parts[0].ToLower();
            
            switch (subCommand)
            {
                case "stats":
                    await HandleSantaAdminStats(chatId);
                    break;
                case "save":
                    SaveSantaData();
                    await _client.SendMessageAsync(chatId, "✅ *Данные сохранены!*", TelegramClient.ParseMode.MarkdownV2);
                    break;
                case "reset":
                    if (parts.Length > 1)
                    {
                        var targetTag = parts[1].ToUpper();
                        var target = _santaParticipants.Values.FirstOrDefault(p => p.AccountTag == targetTag);
                        if (target != null)
                        {
                            _santaParticipants.TryRemove(target.TelegramUserId, out _);
                            await _client.SendMessageAsync(chatId, 
                                $"✅ *Участник {targetTag} сброшен!*",
                                TelegramClient.ParseMode.MarkdownV2);
                        }
                        else
                        {
                            await _client.SendMessageAsync(chatId, 
                                $"❌ *Участник не найден!*",
                                TelegramClient.ParseMode.MarkdownV2);
                        }
                    }
                    break;
                case "remove_gift":
                    if (parts.Length > 1 && _santaGifts.TryRemove(parts[1], out var gift))
                    {
                        await _client.SendMessageAsync(chatId,
                            $"✅ *Подарок удален!*\n{gift.FromTag} → {gift.ToTag}: {gift.Amount}",
                            TelegramClient.ParseMode.MarkdownV2);
                    }
                    break;
                case "export":
                    await HandleSantaAdminExport(chatId);
                    break;
                default:
                    await _client.SendMessageAsync(chatId, "❌ *Неизвестная команда!*", TelegramClient.ParseMode.MarkdownV2);
                    break;
            }
        }

        private async Task HandleSantaAdminStats(long chatId)
        {
            var top5Givers = _santaParticipants.Values
                .OrderByDescending(p => p.TotalAmountSent)
                .Take(5)
                .ToList();

            var top5Receivers = _santaParticipants.Values
                .OrderByDescending(p => p.TotalGiftsReceived)
                .Take(5)
                .ToList();

            var todayGifts = _santaGifts.Values.Count(g => g.SentAt.Date == DateTime.UtcNow.Date);
            var weekGifts = _santaGifts.Values.Count(g => g.SentAt >= DateTime.UtcNow.AddDays(-7));

            var message = new StringBuilder();
            message.AppendLine("📊 *ДЕТАЛЬНАЯ СТАТИСТИКА*");
            message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
            message.AppendLine("");
            message.AppendLine($"• Всего участников: {_santaParticipants.Count}");
            message.AppendLine($"• Активных: {_santaParticipants.Values.Count(p => p.IsActive)}");
            message.AppendLine($"• Всего подарков: {_santaGifts.Count}");
            message.AppendLine($"• Сегодня: {todayGifts} подарков");
            message.AppendLine($"• За неделю: {weekGifts} подарков");
            message.AppendLine($"• Общая сумма: {_santaGifts.Values.Sum(g => g.Amount)}");
            message.AppendLine("");
            
            message.AppendLine("🏆 *Топ 5 дарителей:*");
            foreach (var giver in top5Givers)
            {
                message.AppendLine($"`{giver.AccountTag}`: {giver.TotalGiftsSent} подарков, {giver.TotalAmountSent} всего");
            }
            message.AppendLine("");
            
            message.AppendLine("🎁 *Топ 5 получателей:*");
            foreach (var receiver in top5Receivers)
            {
                message.AppendLine($"`{receiver.AccountTag}`: {receiver.TotalGiftsReceived} подарков");
            }
            message.AppendLine("");
            
            message.AppendLine($"{GetTimeRemaining()}");

            await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleResetTelegramCommand(long chatId, long userId, string input)
{
    if (string.IsNullOrEmpty(input))
    {
        await _client.SendMessageAsync(chatId,
            "🔧 *Принудительная отвязка Telegram*\n\n" +
            "Использование: `/resettg978256 #ТЭГ`\n" +
            "Пример: `/resettg978256 #9UU0`\n\n" +
            "⚠️ *Будет сделано:*\n" +
            "1. Отвязка от Telegram\n" +
            "2. Сброс токена безопасности\n" +
            "3. Новая команда для входа",
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    string tag = input.ToUpper();
    
    // Проверяем формат тега
    if (!tag.StartsWith("#"))
    {
        await _client.SendMessageAsync(chatId,
            "❌ *Неверный формат тега!*\n" +
            "Тег должен начинаться с #\n" +
            "Пример: `#9UU0` или `#2PP`",
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    try
    {
        // 1. Отвязываем из системы привязок
        bool unlinked = false;
        string telegramId = "неизвестно";
        string filePath = "./TelegramLinks.json";
        
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            var data = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(json);
            
            if (data != null && 
                data.ContainsKey("AccountIdToTelegram") && 
                data.ContainsKey("TelegramToAccountId"))
            {
                // Находим Telegram ID
                if (data["AccountIdToTelegram"].TryGetValue(tag, out telegramId))
                {
                    // Удаляем из обоих словарей
                    data["AccountIdToTelegram"].Remove(tag);
                    data["TelegramToAccountId"].Remove(telegramId);
                    
                    // Сохраняем обратно
                    File.WriteAllText(filePath, 
                        Newtonsoft.Json.JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented));
                    
                    unlinked = true;
                    Console.WriteLine($"[USER {userId}] отвязал {tag} от Telegram {telegramId}");
                    
                    // ВАЖНО: Очищаем кэш в TelegramLinkManager
                    try
                    {
                        // Попробуем вызвать метод очистки кэша, если он существует
                        var linkManagerType = _linkManager.GetType();
                        var forceReloadMethod = linkManagerType.GetMethod("ForceReload");
                        var forceClearCacheMethod = linkManagerType.GetMethod("ForceClearCache");
                        var loadLinksMethod = linkManagerType.GetMethod("LoadLinks");
                        
                        if (forceReloadMethod != null)
                        {
                            forceReloadMethod.Invoke(_linkManager, null);
                            Console.WriteLine($"[USER {userId}] Вызван ForceReload()");
                        }
                        else if (forceClearCacheMethod != null)
                        {
                            forceClearCacheMethod.Invoke(_linkManager, null);
                            Console.WriteLine($"[USER {userId}] Вызван ForceClearCache()");
                        }
                        else if (loadLinksMethod != null)
                        {
                            loadLinksMethod.Invoke(_linkManager, null);
                            Console.WriteLine($"[USER {userId}] Вызван LoadLinks()");
                        }
                        else
                        {
                            // Если методы не найдены, пересоздадим объект
                            _linkManager = new TelegramLinkManager();
                            Console.WriteLine($"[USER {userId}] TelegramLinkManager пересоздан");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[USER {userId}] Ошибка при очистке кэша: {ex.Message}");
                        // Пересоздаем объект как fallback
                        _linkManager = new TelegramLinkManager();
                        Console.WriteLine($"[USER {userId}] TelegramLinkManager пересоздан (fallback)");
                    }
                }
            }
        }

        if (!unlinked)
        {
            await _client.SendMessageAsync(chatId,
                $"ℹ️ *Аккаунт `{tag}` не найден в привязках.*\n" +
                $"Возможно он не был привязан.",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // 2. Сбрасываем токен аккаунта в игре
        long accountId = TagToId(tag);
        var account = Accounts.Load(accountId);
        
        if (account == null)
        {
            await _client.SendMessageAsync(chatId,
                $"⚠️ *Аккаунт `{tag}` отвязан, но не найден в игре!*\n" +
                $"Нужно сбросить токен вручную: `/reset_token {tag}`",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        string newPassToken = GeneratePassToken();
        account.PassToken = newPassToken;
        SetAvatarPassToken(account, newPassToken);
        Accounts.Save(account);

        string newLoadCommand = $"/load {accountId} {newPassToken}";

        // 3. Кикаем если онлайн
        if (Sessions.IsSessionActive(accountId))
        {
            var session = Sessions.GetSession(accountId);
            if (session?.GameListener != null)
            {
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    ErrorCode = 8,
                    Message = "Аккаунт был отвязан. Требуется повторная привязка."
                });
            }
        }

        await _client.SendMessageAsync(chatId,
            $"✅ *ОТВЯЗКА ВЫПОЛНЕНА!*\n\n" +
            $"🎮 *Аккаунт:* `{tag}`\n" +
            $"📱 *Был привязан к:* `{telegramId}`\n" +
            $"🔄 *Токен сброшен:* ✅\n" +
            $"👤 *Игрок выгнан:* {(Sessions.IsSessionActive(accountId) ? "✅" : "не был онлайн")}\n\n" +
            $"🔐 *Новая команда для владельца:*\n" +
            $"`{newLoadCommand}`\n\n" +
            $"📋 *Что сообщить владельцу:*\n" +
            $"1. Используй команду выше для входа\n" +
            $"2. Привяжи новый Telegram через бота\n" +
            $"3. Сохрани команду в безопасном месте",
            TelegramClient.ParseMode.MarkdownV2);

        // 4. Логируем в файл для аудита
        string auditLog = $"[{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss}] ПОЛЬЗОВАТЕЛЬ {userId} -> Отвязал {tag} (Telegram: {telegramId})\n";
        File.AppendAllText("./admin_audit.log", auditLog);

    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ *Ошибка выполнения:*\n```{ex.Message}```\n\n" +
            $"Попробуй сделать вручную:\n" +
            $"1. Открой `TelegramLinks.json`\n" +
            $"2. Удали тег `{tag}`\n" +
            $"3. Используй `/reset_token {tag}`",
            TelegramClient.ParseMode.MarkdownV2);
        
        Console.WriteLine($"[ERROR] /resettg978256 от {userId}: {ex.Message}");
    }
}

        private async Task HandleSantaAdminExport(long chatId)
        {
            try
            {
                var exportData = new
                {
                    ExportDate = DateTime.UtcNow,
                    Participants = _santaParticipants.Values,
                    Gifts = _santaGifts.Values,
                    Statistics = new
                    {
                        TotalParticipants = _santaParticipants.Count,
                        TotalGifts = _santaGifts.Count,
                        TotalAmount = _santaGifts.Values.Sum(g => g.Amount),
                        EventPeriod = $"{_santaData.EventStart:dd.MM.yyyy} - {_santaData.EventEnd:dd.MM.yyyy}"
                    }
                };

                var json = Newtonsoft.Json.JsonConvert.SerializeObject(exportData, Newtonsoft.Json.Formatting.Indented);
                var fileName = $"SantaExport_{DateTime.UtcNow:yyyyMMdd_HHmmss}.json";
                File.WriteAllText(fileName, json);

                await _client.SendMessageAsync(chatId,
                    $"✅ *Экспорт завершен!*\n\n" +
                    $"Файл: `{fileName}`\n" +
                    $"Размер: {json.Length} байт",
                    TelegramClient.ParseMode.MarkdownV2);
            }
            catch (Exception ex)
            {
                await _client.SendMessageAsync(chatId,
                    $"❌ *Ошибка экспорта:* {ex.Message}",
                    TelegramClient.ParseMode.MarkdownV2);
            }
        }

        private string GetGiftTypeName(string giftType)
        {
            return giftType switch
            {
                "gems" => "гемов 💎",
                "coins" => "монет 🪙",
                "powerpoints" => "очков силы ⚡",
                _ => "ресурсов"
            };
        }

        private int GetResourceAmount(Account account, string giftType)
        {
            return giftType switch
            {
                "gems" => account.Avatar?.Diamonds ?? 0,
                "coins" => account.Avatar?.Gold ?? 0,
                "powerpoints" => account.Avatar?.PowerPoints ?? 0,
                _ => 0
            };
        }

        private async Task HandleStartCommand(long chatId)
{
    string welcomeMessage = 
@"👑 <b>DBMOD1 ID</b>
<b>🇮🇳 Indus Brawl</b>

🌐 <b>Личный кабинет управления аккаунтами!</b>

⚙️ <b>ОСНОВНЫЕ КОМАНДЫ:</b>
• Отправьте сюда свой ТЭГ (#2PP)
• /online - Онлайн на сервере
• /recover - Восстановить доступ
• /account_info - Личный кабинет
• /myaccounts - Мои аккаунты

💰 <b>ПЕРЕВОДЫ МЕЖДУ АККАУНТАМИ:</b>
• /transfer_gems - Передача гемов (лимит 4000/день)
• /limits - Просмотр ваших лимитов
• /transfer_history - История операций

🛒 <b>БЫСТРЫЙ МАГАЗИН:</b>
• /shop - Просмотреть предложения
• /shop_debug - Диагностика

🎰 <b>РАЗВЛЕЧЕНИЯ:</b>
• /spin - Колесо фортуны

🔐 <b>БЕЗОПАСНОСТЬ:</b>
• /reset_token - Сбросить токен
• /unlink - Отвязать аккаунт
• /unlink_all - Отвязать все аккаунты

🎅 <b>СЕЗОННЫЕ СОБЫТИЯ:</b>
• /santa_join - Присоединиться к Тайному Санте
• /santa_list - Список участников
• /santa_gift - Отправить подарок

🎀 <b>Tutorial:</b>
🎥 <b>YouTube:</b>
https://youtube.com/shorts/Pj9TEaGSF4o?si=kL3hprDfcfMYgL7i
🎥 <b>TikTok:</b>
https://vm.tiktok.com/ZMDL322Yh/

🫂 <b>Ваши аккаунты в безопасности</b>

👑 <b>❗ Обнаружили ошибку?</b>
<b>Пожалуйста, напишите мне в Telegram:</b>
<b>@theqarden_CEO</b>

<b>Telegram: @indusbrawl</b>

/start";

    await _client.SendMessageAsync(
        chatId,
        welcomeMessage,
        TelegramClient.ParseMode.Html
    );
}

        private long TagToId(string tag)
        {
            return LogicLongCodeGenerator.ToId(tag);
        }

        private string IdToTag(long id)
        {
            return LogicLongCodeGenerator.ToCode(id);
        }

        private async Task HandleAccountId(long chatId, long userId, string accountIdText)
        {
            string tag = accountIdText.ToUpper();

            if (_linkManager.IsTelegramLinked(userId))
            {
                await _client.SendMessageAsync(chatId, $"❌ Ваш Telegram уже привязан к другому игровому аккаунту.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (_linkManager.IsAccountLinked(tag))
            {
                await _client.SendMessageAsync(chatId, $"❌ Аккаунт `{tag}` уже привязан к другому Telegram.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            long targetAccountId;
            try
            {
                targetAccountId = TagToId(tag);
            }
            catch (ArgumentException ex)
            {
                await _client.SendMessageAsync(chatId, $"❌ Неверный формат тега аккаунта: {ex.Message}", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            Account account = Accounts.Load(targetAccountId);
            if (account == null)
            {
                await _client.SendMessageAsync(chatId, $"❌ Аккаунт с тегом `{tag}` не найден.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            string code = GenerateConfirmationCode();
            var expiry = DateTime.UtcNow.AddMinutes(5);

            _linkStates[userId] = new LinkState
            {
                TargetAccountId = tag,
                ConfirmationCode = code,
                Expiry = expiry,
                TelegramUserId = userId,
                AttemptsCount = 0
            };

            bool sent = await SendConfirmationNotificationToGame(targetAccountId, code);
            if (!sent)
            {
                await _client.SendMessageAsync(chatId, "❌ Не удалось отправить уведомление в игру. Попробуйте позже.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            await _client.SendMessageAsync(chatId, $"✅ Отлично! Я отправил код подтверждения на аккаунт `{tag}`.\n\n" +
                                                   $"*Введите код сюда, чтобы завершить привязку.*", TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleConfirmationCode(long chatId, string targetAccountId, long telegramUserId)
        {
            bool success = _linkManager.LinkAccount(telegramUserId, targetAccountId);
            if (success)
            {
                long targetAccountIdLong = TagToId(targetAccountId);
                bool skinSent = await SendSkinRewardNotificationToGame(targetAccountIdLong, 59);

                await _client.SendMessageAsync(chatId, $"✅ Успешно! Ваш Telegram привязан к аккаунту `{targetAccountId}`.\n\n" +
                                                       $"Теперь вы можете восстановить доступ через /recover." +
                                                       (skinSent ? $"\n🎁 Вам также выдан скин *Волшебник барли* за успешную привязку!" : ""), TelegramClient.ParseMode.MarkdownV2);
            }
            else
            {
                await _client.SendMessageAsync(chatId, "❌ Не удалось завершить привязку. Попробуйте позже.", TelegramClient.ParseMode.MarkdownV2);
            }
        }

        private async Task HandleRecoverCommand(long chatId, long userId)
{
    if (chatId != userId)
    {
        await _client.SendMessageAsync(chatId, "❌ Эта команда доступна только в личных сообщениях с ботом.", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    if (_linkManager.TryGetAccountId(userId, out string accountId))
    {
        long targetAccountIdLong = TagToId(accountId);
        Account account = Accounts.Load(targetAccountIdLong);
        if (account == null)
        {
            await _client.SendMessageAsync(chatId, "❌ Не удалось загрузить данные аккаунта для восстановления.", TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // Проверяем, онлайн ли пользователь
        bool isOnline = Sessions.IsSessionActive(targetAccountIdLong);
        
        // Генерируем команду
        string loadCommand = $"/load {targetAccountIdLong} {account.PassToken}";

        if (isOnline)
        {
            // Если онлайн - принудительно обновляем клиент
            ForceRefreshClient(targetAccountIdLong);
            
            await _client.SendMessageAsync(chatId, 
                $"🔑 *Восстановление доступа*\n\n" +
                $"👤 *Аккаунт:* `{accountId}`\n" +
                $"📱 *Статус:* 🟢 В игре\n\n" +
                $"📋 *Команда для входа:*\n",
                TelegramClient.ParseMode.MarkdownV2);
        }
        else
        {
            await _client.SendMessageAsync(chatId, 
                $"🔑 *Восстановление доступа*\n\n" +
                $"👤 *Аккаунт:* `{accountId}`\n" +
                $"📱 *Статус:* 🔴 Не в игре\n\n" +
                $"📋 *Команда для входа:*\n" +
                $"`{loadCommand}`\n\n" +
                $"📱 *Инструкция:*\n" +
                $"1. Зайдите в игру\n" +
                $"2. Создайте команду\n" +
                $"3. Введите команду в чате команды\n",
                TelegramClient.ParseMode.MarkdownV2);
        }
    }
    else
    {
        await _client.SendMessageAsync(chatId, "❌ Ваш Telegram не привязан ни к одному аккаунту.", TelegramClient.ParseMode.MarkdownV2);
    }
}

        private async Task HandleResetTokenCommand(long chatId, long userId, string tag)
        {
            if (chatId != userId)
            {
                await _client.SendMessageAsync(chatId, "❌ Эта команда доступна только в личных сообщениях с ботом.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (!_linkManager.TryGetAccountId(userId, out string linkedTag))
            {
                await _client.SendMessageAsync(chatId, "❌ Ваш Telegram не привязан ни к одному аккаунту. Невозможно сбросить токен.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (string.IsNullOrEmpty(tag))
            {
                tag = linkedTag;
            }
            else
            {
                if (tag.ToUpper() != linkedTag.ToUpper())
                {
                    await _client.SendMessageAsync(chatId, $"❌ Вы можете сбросить токен только для своего аккаунта!(`{linkedTag}`).", TelegramClient.ParseMode.MarkdownV2);
                    return;
                }
            }

            long accountId;
            try
            {
                accountId = TagToId(tag);
            }
            catch (ArgumentException ex)
            {
                await _client.SendMessageAsync(chatId, $"❌ Неверный формат тега аккаунта: {ex.Message}", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            Account account = Accounts.Load(accountId);
            if (account == null)
            {
                await _client.SendMessageAsync(chatId, $"❌ Аккаунт с тегом `{tag}` не найден.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            string newPassToken = GeneratePassToken();

            account.PassToken = newPassToken;
            
            SetAvatarPassToken(account, newPassToken);
            
            Accounts.Save(account);

            if (Sessions.IsSessionActive(accountId))
            {
                var session = Sessions.GetSession(accountId);
                if (session?.GameListener != null)
                {
                    session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                    {
                        ErrorCode = 10,
                        Message = "Токен аккаунта был сброшен. Вам нужно восстановить доступ."
                    });
                }
            }

            string newLoadCommand = $"/load {accountId} {newPassToken}";

            await _client.SendMessageAsync(chatId, $"✅ Токен аккаунта `{tag}` успешно сброшен!\n\n" +
                                                   $"Теперь войти в аккаунт может только его владелец.\n\n" +
                                                   $"Ваша новая команда для входа:\n" +
                                                   $"`{newLoadCommand}`\n" +
                                                   $"*Используйте её для восстановления доступа.*\n\n/start", TelegramClient.ParseMode.MarkdownV2);
        }

        private void SetAvatarPassToken(Account account, string passToken)
        {
            if (account.Avatar != null)
            {
                account.Avatar.PassToken = passToken;
            }
        }

        private async Task HandleMyAccountsCommand(long chatId, long userId)
        {
            var linkedAccounts = _linkManager.GetAllLinkedAccounts(userId);
            
            if (linkedAccounts.Any())
            {
                var message = "🔗 *Ваши привязанные аккаунты:*\n\n";
                foreach (var account in linkedAccounts)
                {
                    message += $"• `{account}`\n";
                }
                message += $"\nВсего аккаунтов: {linkedAccounts.Count}";
                await _client.SendMessageAsync(chatId, message, TelegramClient.ParseMode.MarkdownV2);
            }
            else
            {
                await _client.SendMessageAsync(chatId, "❌ У вас нет привязанных аккаунтов.", TelegramClient.ParseMode.MarkdownV2);
            }
        }

        private async Task HandleUnlinkCommand(long chatId, long userId, string tag)
        {
            if (string.IsNullOrEmpty(tag))
            {
                await _client.SendMessageAsync(chatId, 
                    "ℹ️ Использование: `/unlink #ТЭГ`\nПример: `/unlink #2PP`", 
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            tag = tag.ToUpper();
            
            if (!_linkManager.IsAccountOwnedByUser(userId, tag))
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ Аккаунт `{tag}` не привязан к вашему Telegram или не существует.", 
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            if (_linkManager.UnlinkAccount(userId, tag))
            {
                await _client.SendMessageAsync(chatId, 
                    $"✅ Аккаунт `{tag}` успешно отвязан от вашего Telegram.", 
                    TelegramClient.ParseMode.MarkdownV2);
            }
            else
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ Не удалось отвязать аккаунт `{tag}`.", 
                    TelegramClient.ParseMode.MarkdownV2);
            }
        }

        private async Task HandleUnlinkAllCommand(long chatId, long userId)
        {
            var accounts = _linkManager.GetAllLinkedAccounts(userId);
            if (!accounts.Any())
            {
                await _client.SendMessageAsync(chatId, "❌ У вас нет привязанных аккаунтов.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            _linkManager.UnlinkAllAccounts(userId);
            await _client.SendMessageAsync(chatId, 
                $"✅ Все аккаунты ({accounts.Count}) были отвязаны от вашего Telegram.", 
                TelegramClient.ParseMode.MarkdownV2);
        }

        private async Task HandleAccountInfoCommand(long chatId, long userId, string tag)
        {
            if (string.IsNullOrEmpty(tag))
            {
                if (_linkManager.TryGetAccountId(userId, out string linkedTag))
                {
                    tag = linkedTag;
                }
                else
                {
                    await _client.SendMessageAsync(chatId, 
                        "❌ Укажите тег аккаунта: `/account_info #ТЭГ`\nИли привяжите аккаунт отправив свой ТЭГ", 
                        TelegramClient.ParseMode.MarkdownV2);
                    return;
                }
            }

            tag = tag.ToUpper();
            
            if (!_linkManager.IsAccountOwnedByUser(userId, tag))
            {
                await _client.SendMessageAsync(chatId, 
                    $"❌ Аккаунт `{tag}` не привязан к вашему Telegram.", 
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            long accountId = TagToId(tag);
            Account account = Accounts.Load(accountId);

            if (account == null)
            {
                await _client.SendMessageAsync(chatId, $"❌ Аккаунт `{tag}` не найден.", TelegramClient.ParseMode.MarkdownV2);
                return;
            }

            var info = GetExtendedAccountInfo(account, accountId, tag);
            await _client.SendMessageAsync(chatId, info, TelegramClient.ParseMode.MarkdownV2);
        }

        private string GetExtendedAccountInfo(Account account, long accountId, string tag)
        {
            var avatar = account.Avatar;
            
            bool isOnline = Sessions.IsSessionActive(accountId);
            string favoriteBrawler = GetFavoriteBrawlerName(avatar);
            
            int currentWinStreak = avatar.WinStreak;
            int maxWinStreak = avatar.MaxWinstreak;
            int totalWins = avatar.TrioWins + avatar.DuoWins + avatar.SoloWins;

            var info = $"🎮 *ЛИЧНЫЙ КАБИНЕТ*\n" +
                       $"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n" +
                       
                       $"👤 *Основная информация*\n" +
                       $"• Тег: `{tag}`\n" +
                       $"• Никнейм: {avatar.Name}\n" +
                       $"• Трофеи: {avatar.Trophies} 🏆\n" +
                       $"• Бравлеры: {avatar.GetUnlockedHeroesCount()}\n\n" +
                       
                       $"📈 *Статистика побед*\n" +
                       $"• Всего побед: {totalWins} 🏅\n" +
                       $"• 3x3: {avatar.TrioWins}\n" +
                       $"• Парное столкновение: {avatar.DuoWins}\n" +
                       $"• Одиночное столкновение: {avatar.SoloWins}\n" +
                       $"• Текущий винстрик: *{currentWinStreak}*\n" +
                       $"• Макс. винстрик: *{maxWinStreak}*\n\n" +
                       
                       $"💰 *Ресурсы*\n" +
                       $"• Монеты: {avatar.Gold} 🪙\n" +
                       $"• Гемы: {avatar.Diamonds} 💎\n" +
                       $"• Очки силы: {avatar.PowerPoints} ⚡\n" +
                       $"• Блинги: {avatar.Blings} 💠\n\n" +
                       
                       $"👑 *Достижения*\n" +
                       $"• Любимый бравлер: {favoriteBrawler}\n" +
                       $"• Клуб: {GetClubInfo(avatar)}\n" +
                       $"• Рекорд трофеев: {avatar.HighestTrophies} 🏆\n\n" +
                       
                       $"🔒 *Безопасность*\n" +
                       $"• Привязка Telegram: ✅\n" +
                       $"• Статус: {(isOnline ? "🟢 В сети" : "🔴 Не в сети")}\n\n" +
                       
                       $"🎰 /spin - Колесо фортуны\n" +
                       $"🚀 /quick_login - Быстрый вход\n" +
                       $"📋 /start - Все команды";

            return info;
        }

        private string GetFavoriteBrawlerName(ClientAvatar avatar)
        {
            if (avatar == null || avatar.Heroes == null || avatar.Heroes.Count == 0)
                return "Неизвестно";
            
            var favorite = avatar.Heroes.OrderByDescending(h => h.Trophies).FirstOrDefault();
            if (favorite != null)
            {
                try
                {
                    int characterIndex = favorite.CharacterId - 16000000;
                    var characterData = DataTables.Get(16)
                        .GetDataWithId<CharacterData>(characterIndex);
                    
                    if (characterData != null)
                    {
                        var type = characterData.GetType();
                        
                        var nameProp = type.GetProperty("Name");
                        if (nameProp != null)
                        {
                            string name = (string)nameProp.GetValue(characterData);
                            if (!string.IsNullOrEmpty(name))
                                return $"{name} ({favorite.Trophies}🏆)";
                        }
                        
                        var tidNameProp = type.GetProperty("TID_Name");
                        if (tidNameProp != null)
                        {
                            string tidName = (string)tidNameProp.GetValue(characterData);
                            if (!string.IsNullOrEmpty(tidName))
                                return $"{tidName} ({favorite.Trophies}🏆)";
                        }
                        
                        var getNameMethod = type.GetMethod("GetName");
                        if (getNameMethod != null)
                        {
                            string name = (string)getNameMethod.Invoke(characterData, null);
                            if (!string.IsNullOrEmpty(name))
                                return $"{name} ({favorite.Trophies}🏆)";
                        }
                    }
                    
                    return $"Бравлер #{favorite.CharacterId} ({favorite.Trophies}🏆)";
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TelegramBot] Ошибка получения имени бравлера: {ex.Message}");
                    return $"Неизвестно ({favorite.Trophies}🏆)";
                }
            }
            
            return "Неизвестно";
        }

        private string GetAccountStatus(int trophies)
        {
            if (trophies >= 30000) return "БОГ";
            if (trophies >= 20000) return "Легенда";
            if (trophies >= 15000) return "Ветеран"; 
            if (trophies >= 10000) return "Опытный";
            if (trophies >= 5000) return "Активный";
            if (trophies >= 1000) return "Начинающий";
            return "Новый игрок";
        }

        private int GetAccountLevel(Account account)
        {
            return 1;
        }

        private int GetAccountTrophies(Account account)
        {
            return account.Avatar?.Trophies ?? 0;
        }

        private string GetAccountName(Account account)
        {
            return account.Avatar?.Name ?? "Не установлен";
        }

        private DateTime GetCreationDate(Account account)
        {
            var type = account.GetType();
            var creationDateProp = type.GetProperty("CreationDate");
            var createdProp = type.GetProperty("Created");
            var dateCreatedProp = type.GetProperty("DateCreated");

            DateTime result = DateTime.Now;
            
            if (creationDateProp != null)
                result = (DateTime)creationDateProp.GetValue(account);
            else if (createdProp != null)
                result = (DateTime)createdProp.GetValue(account);
            else if (dateCreatedProp != null)
                result = (DateTime)dateCreatedProp.GetValue(account);

            if (result > DateTime.Now)
                return DateTime.Now.AddYears(-1);
            
            return result;
        }

        private int GetBrawlersCount(Account account)
        {
            return account.Avatar?.GetUnlockedHeroesCount() ?? 0;
        }

        private int GetTotalPowerPoints(Account account)
        {
            return account.Avatar?.PowerPoints ?? 0;
        }

        private int GetTotalCoins(Account account)
        {
            return account.Avatar?.Gold ?? 0;
        }

        private int GetTotalGems(Account account)
        {
            return account.Avatar?.Diamonds ?? 0;
        }

        private int GetStarPoints(Account account)
        {
            return account.Avatar?.StarPoints ?? 0;
        }

        private int GetClubCoins(Account account)
        {
            return 0;
        }

        private int GetExperience(Account account)
        {
            return 0;
        }

        private string GetClubInfo(ClientAvatar avatar)
        {
            if (avatar == null) return "Не в клубе";
            
            if (avatar.AllianceId > 0)
            {
                string roleName = avatar.AllianceRole switch
                {
                    AllianceRole.Leader => "Президент",
                    AllianceRole.CoLeader => "Вице-президент", 
                    AllianceRole.Elder => "Ветеран",
                    AllianceRole.Member => "Участник",
                    _ => "Участник"
                };
                
                return $"{roleName} (ID: {avatar.AllianceId})";
            }
            
            return "Не в клубе";
        }

        private string GetLastPlayedTime(Account account)
        {
            try
            {
                var type = account.GetType();
                var lastPlayedProp = type.GetProperty("LastPlayed");
                var lastActivityProp = type.GetProperty("LastActivity");

                if (lastPlayedProp != null)
                {
                    var lastPlayed = (DateTime)lastPlayedProp.GetValue(account);
                    return GetTimeAgo(lastPlayed);
                }
                if (lastActivityProp != null)
                {
                    var lastActivity = (DateTime)lastActivityProp.GetValue(account);
                    return GetTimeAgo(lastActivity);
                }
            }
            catch { }
            
            return "Неизвестно";
        }

        private string GetLastLoginTime(Account account)
        {
            try
            {
                var type = account.GetType();
                var lastLoginProp = type.GetProperty("LastLogin");
                var lastSessionProp = type.GetProperty("LastSession");

                if (lastLoginProp != null)
                {
                    var lastLogin = (DateTime)lastLoginProp.GetValue(account);
                    return GetTimeAgo(lastLogin);
                }
                if (lastSessionProp != null)
                {
                    var lastSession = (DateTime)lastSessionProp.GetValue(account);
                    return GetTimeAgo(lastSession);
                }
            }
            catch { }
            
            return "Неизвестно";
        }

        private string GetTimeAgo(DateTime date)
        {
            var timeSpan = DateTime.UtcNow - date;
            
            if (timeSpan.TotalMinutes < 1) return "только что";
            if (timeSpan.TotalHours < 1) return $"{(int)timeSpan.TotalMinutes} мин назад";
            if (timeSpan.TotalDays < 1) return $"{(int)timeSpan.TotalHours} ч назад";
            if (timeSpan.TotalDays < 7) return $"{(int)timeSpan.TotalDays} дн назад";
            
            return date.ToString("dd.MM.yyyy");
        }

        private async Task HandleQuickLoginCommand(long chatId, long userId)
        {
            if (_linkManager.TryGetAccountId(userId, out string accountId))
            {
                long accountIdLong = TagToId(accountId);
                Account account = Accounts.Load(accountIdLong);
                
                if (account != null)
                {
                    string loadCommand = $"/load {accountIdLong} {account.PassToken}";
                    
                    await _client.SendMessageAsync(chatId,
                        $"🚀 *Быстрый вход в аккаунт* `{accountId}`\n\n" +
                        $"💬 Команда для входа:\n" +
                        $"`{loadCommand}`\n\n" +
                        $"*❗ \n1. Создайте команду в игре.\n2. Введите эту команду в чате команды.\n3. После этого вы будете перенаправлены в свой аккаунт.*\n\n/start",
                        TelegramClient.ParseMode.MarkdownV2);
                }
            }
            else
            {
                await _client.SendMessageAsync(chatId, 
                    "❌ У вас нет привязанных аккаунтов.", 
                    TelegramClient.ParseMode.MarkdownV2);
            }
        }

        private async Task HandleNotificationsCommand(long chatId, long userId, string action)
        {
            if (action == "on")
            {
                _notificationSettings[userId] = true;
                await _client.SendMessageAsync(chatId,
                    "🔔 *Уведомления включены*\n\nВы будете получать уведомления о входах в ваш аккаунт.",
                    TelegramClient.ParseMode.MarkdownV2);
            }
            else if (action == "off")
            {
                _notificationSettings[userId] = false;
                await _client.SendMessageAsync(chatId,
                    "🔕 *Уведомления выключены*",
                    TelegramClient.ParseMode.MarkdownV2);
            }
            else
            {
                bool isEnabled = _notificationSettings.GetValueOrDefault(userId, true);
                await _client.SendMessageAsync(chatId,
                    $"ℹ️ *Управление уведомлениями:*\n\n" +
                    $"Текущий статус: {(isEnabled ? "🔔 Включены" : "🔕 Выключены")}\n\n" +
                    "/notifications on - Включить уведомления\n" +
                    "/notifications off - Выключить уведомления\n\n/start",
                    TelegramClient.ParseMode.MarkdownV2);
            }
        }

        private async Task HandleDailySpinCommand(long chatId, long userId)
{
    if (chatId != userId)
    {
        await _client.SendMessageAsync(chatId, "❌ Эта команда доступна только в личных сообщениях.", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    // Проверяем привязку аккаунта
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, "❌ Сначала привяжите аккаунт, чтобы использовать колесо фортуны!", TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    // Проверяем, крутили ли уже сегодня
    if (_lastSpinTimes.TryGetValue(userId, out DateTime lastSpin))
    {
        if (lastSpin.Date == DateTime.UtcNow.Date)
        {
            var nextSpinTime = lastSpin.AddDays(1).Date;
            var timeUntilNextSpin = nextSpinTime - DateTime.UtcNow;
            
            await _client.SendMessageAsync(chatId,
                $"⏳ *ВЫ УЖЕ КРУТИЛИ КОЛЕСО СЕГОДНЯ!*\n\n" +
                $"🕐 *Последний спин:* {lastSpin:HH:mm:ss}\n" +
                $"🔥 *Текущая серия:* {_dailyStreaks.GetValueOrDefault(userId, 0)} дней\n" +
                $"⏰ *До следующего спина:* {timeUntilNextSpin.Hours}ч {timeUntilNextSpin.Minutes}м\n\n" +
                $"🎰 *Приходите завтра за новой наградой!*\n/start",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }
    }

    // Создаем кнопку
    var keyboard = new
    {
        inline_keyboard = new[]
        {
            new[]
            {
                new
                {
                    text = "🎡 КРУТИТЬ КОЛЕСО!",
                    callback_data = $"spin_wheel_{userId}"
                }
            }
        }
    };

    string keyboardJson = System.Text.Json.JsonSerializer.Serialize(keyboard);

    // Получаем текущую серию
    int currentStreak = _dailyStreaks.GetValueOrDefault(userId, 0);
    
    // Формируем сообщение
    var message = new StringBuilder();
    message.AppendLine("🎰 *ДНЕВНОЕ КОЛЕСО ФОРТУНЫ*");
    message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
    message.AppendLine("");
    message.AppendLine("🔸 *Правила:*");
    message.AppendLine("• 1 спин в сутки (сбрасывается в 00:00 UTC)");
    message.AppendLine("• Чем дольше серия, тем лучше награды");
    message.AppendLine("• За пропущенный день серия сбрасывается");
    message.AppendLine("");
    message.AppendLine("🎁 *Возможные награды:*");
    message.AppendLine("• 💎 Гемы (5-100)");
    message.AppendLine("• 🪙 Монеты (100-1000)");
    message.AppendLine("• ⚡ Очки силы (10-500)");
    message.AppendLine("• 👤 Новые бравлеры (шанс)");
    message.AppendLine("");
    message.AppendLine($"🔥 *Ваша серия:* **{currentStreak}** дней подряд");
    message.AppendLine($"🎁 *Бонус серии:* **+{Math.Min(currentStreak * 3, 50)}%** к награде");
    message.AppendLine("");
    message.AppendLine("🍀 *Нажмите кнопку ниже, чтобы попытать удачу!*");

    await _client.SendMessageWithKeyboardAsync(chatId,
        message.ToString(),
        keyboardJson,
        TelegramClient.ParseMode.MarkdownV2);
}

        private async Task ProcessWheelSpin(long chatId, int messageId, long userId)
{
    Console.WriteLine($"[WheelSpin] Начало обработки спина для пользователя {userId} в {DateTime.UtcNow:HH:mm:ss}");
    
    try
    {
        // Получаем тег аккаунта
        if (!_linkManager.TryGetAccountId(userId, out string accountTag))
        {
            await _client.SendMessageAsync(chatId, "❌ Ошибка: аккаунт не найден!", TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        // ЗАПИСЫВАЕМ ВРЕМЯ СПИНА СРАЗУ - ЭТО ГЛАВНОЕ ИСПРАВЛЕНИЕ!
        DateTime spinTime = DateTime.UtcNow;
        _lastSpinTimes[userId] = spinTime;
        
        Console.WriteLine($"[WheelSpin] Пользователь {userId} ({accountTag}) начал спин в {spinTime:HH:mm:ss}");
        
        // Вычисляем серию
        int currentStreak = 1;
        if (_lastSpinTimes.TryGetValue(userId, out DateTime lastSpin))
        {
            if (lastSpin.Date == spinTime.Date.AddDays(-1))
            {
                // Крутил вчера - увеличиваем серию
                currentStreak = _dailyStreaks.GetValueOrDefault(userId, 0) + 1;
            }
            else if (lastSpin.Date == spinTime.Date)
            {
                // Уже крутил сегодня (не должно случиться из-за проверки выше)
                currentStreak = _dailyStreaks.GetValueOrDefault(userId, 0);
            }
            else
            {
                // Пропустил день или больше - сбрасываем серию
                currentStreak = 1;
            }
        }
        
        _dailyStreaks[userId] = currentStreak;
        Console.WriteLine($"[WheelSpin] Серия пользователя {userId}: {currentStreak} дней");
        
        // Генерируем награду
        var reward = GenerateDailyReward(currentStreak);
        Console.WriteLine($"[WheelSpin] Сгенерирована награда: {reward.Gems} гемов, {reward.Coins} монет, {reward.PowerPoints} ОС");
        
        // Отправляем награду в игру
        bool rewardSent = await SendRewardToGame(accountTag, reward);
        
        if (!rewardSent)
        {
            // ВАЖНО: Если награда не отправлена, НЕ откатываем время спина!
            // Пользователь должен обратиться к админу, а не пытаться снова
            Console.WriteLine($"[WheelSpin] ОШИБКА: Не удалось отправить награду пользователю {userId}");
            
            await _client.SendMessageAsync(chatId,
                "❌ Не удалось выдать награду. Свяжитесь с администратором @theqarden_CEO\n\n" +
                "⚠️ Время спина уже зафиксировано, повторная попытка невозможна!",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }
        
        Console.WriteLine($"[WheelSpin] Награда успешно отправлена пользователю {userId}");
        
        // Формируем сообщение о выигрыше
        var resultMessage = new StringBuilder();
        resultMessage.AppendLine($"🎉 *ВЫ ВЫИГРАЛИ!*");
        resultMessage.AppendLine($"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        resultMessage.AppendLine($"");
        resultMessage.AppendLine($"👤 *Аккаунт:* `{accountTag}`");
        resultMessage.AppendLine($"⏰ *Время спина:* {spinTime:HH:mm:ss}");
        resultMessage.AppendLine($"");
        resultMessage.AppendLine($"🎁 *Награды:*");
        
        if (reward.Gems > 0)
            resultMessage.AppendLine($"💎 **{reward.Gems}** гемов");
        if (reward.Coins > 0)
            resultMessage.AppendLine($"🪙 **{reward.Coins}** монет");
        if (reward.PowerPoints > 0)
            resultMessage.AppendLine($"⚡ **{reward.PowerPoints}** очков силы");
        
        if (reward.HasBrawlerChance && reward.BrawlerId > 0)
        {
            string brawlerName = GetBrawlerNameById(reward.BrawlerId);
            resultMessage.AppendLine($"👤 **Новый бравлер:** {brawlerName}!");
            
            if (reward.BrawlerPowerPoints > 0)
                resultMessage.AppendLine($"⚡ **+{reward.BrawlerPowerPoints}** очков силы для бравлера");
        }
        
        resultMessage.AppendLine($"");
        resultMessage.AppendLine($"📊 *Статистика:*");
        resultMessage.AppendLine($"🔥 Серия: **{currentStreak}** дней подряд");
        resultMessage.AppendLine($"🎁 Бонус серии: **+{reward.StreakBonus}%**");
        resultMessage.AppendLine($"");
        resultMessage.AppendLine($"⏰ *Следующий спин:* завтра в 00:00 UTC");
        resultMessage.AppendLine($"/start");
        
        // Отправляем сообщение
        await _client.SendMessageAsync(chatId, resultMessage.ToString(), TelegramClient.ParseMode.MarkdownV2);
        
        Console.WriteLine($"[WheelSpin] Успешно завершен спин для пользователя {userId}");

    }
    catch (Exception ex)
    {
        Console.WriteLine($"[WheelSpin] КРИТИЧЕСКАЯ ОШИБКА для {userId}: {ex.Message}");
        Console.WriteLine($"[WheelSpin] StackTrace: {ex.StackTrace}");
        
        await _client.SendMessageAsync(chatId,
            "❌ Произошла критическая ошибка. Свяжитесь с администратором @theqarden_CEO",
            TelegramClient.ParseMode.MarkdownV2);
    }
}

        private DailyReward GenerateDailyReward(int streak)
{
    var random = new Random(Guid.NewGuid().GetHashCode()); // Уникальное seed для каждого вызова
    
    // Базовые значения
    int baseGems = random.Next(5, 21);
    int baseCoins = random.Next(100, 501);
    int basePowerPoints = random.Next(10, 51);
    
    // Бонус за серию (макс +50%)
    int streakBonusPercent = Math.Min(streak * 3, 50);
    int streakBonus = (streakBonusPercent * 100) / 100; // Процент в коэффициенте
    
    // Применяем бонус
    int totalGems = baseGems + (baseGems * streakBonus / 100);
    int totalCoins = baseCoins + (baseCoins * streakBonus / 100);
    int totalPowerPoints = basePowerPoints + (basePowerPoints * streakBonus / 100);
    
    // Шанс получить бравлера
    bool hasBrawlerChance = false;
    int brawlerId = 0;
    int brawlerPowerPoints = 0;
    
    // Шанс получить бравлера растет с серией
    int brawlerChance = Math.Min(5 + (streak * 1), 25); // От 5% до 25%
    
    if (random.Next(0, 100) < brawlerChance)
    {
        hasBrawlerChance = true;
        
        // Чем больше серия, тем выше редкость бравлера
        int[] commonBrawlers = { 16000000, 16000001, 16000002 }; // Shelly, Nita, Colt
        int[] rareBrawlers = { 16000003, 16000004, 16000005 }; // Bull, Jessie, Brock
        int[] superRareBrawlers = { 16000006, 16000007, 16000008 }; // Dynamike, Bo, Tick
        int[] epicBrawlers = { 16000009, 16000010, 16000011 }; // El Primo, Barley, Poco
        int[] mythicBrawlers = { 16000012, 16000013, 16000014 }; // Mortis, Tara, Gene
        int[] legendaryBrawlers = { 16000015, 16000016, 16000017 }; // Crow, Leon, Sandy
        
        int chanceTier = random.Next(0, 100);
        
        if (streak >= 30 && chanceTier < 1) // 1% шанс на легендарного при 30+ днях
            brawlerId = legendaryBrawlers[random.Next(legendaryBrawlers.Length)];
        else if (streak >= 21 && chanceTier < 5) // 5% шанс на мифического при 21+ днях
            brawlerId = mythicBrawlers[random.Next(mythicBrawlers.Length)];
        else if (streak >= 14 && chanceTier < 15) // 15% шанс на эпического при 14+ днях
            brawlerId = epicBrawlers[random.Next(epicBrawlers.Length)];
        else if (streak >= 7 && chanceTier < 30) // 30% шанс на супер-редкого при 7+ днях
            brawlerId = superRareBrawlers[random.Next(superRareBrawlers.Length)];
        else if (chanceTier < 50) // 50% шанс на редкого
            brawlerId = rareBrawlers[random.Next(rareBrawlers.Length)];
        else // Остальной шанс на обычного
            brawlerId = commonBrawlers[random.Next(commonBrawlers.Length)];
        
        // Очки силы для бравлера
        brawlerPowerPoints = random.Next(10, 31);
    }
    
    Console.WriteLine($"[WheelSpin] Сгенерирована награда: {totalGems}г/{totalCoins}м/{totalPowerPoints}ос, " +
                     $"серия: {streak} дней, бонус: +{streakBonusPercent}%, " +
                     $"шанс бравлера: {brawlerChance}% ({(hasBrawlerChance ? "выпал" : "не выпал")})");
    
    return new DailyReward
    {
        Gems = totalGems,
        Coins = totalCoins,
        PowerPoints = totalPowerPoints,
        BrawlerId = brawlerId,
        HasBrawlerChance = hasBrawlerChance,
        StreakBonus = streakBonusPercent,
        BrawlerPowerPoints = brawlerPowerPoints
    };
}

        private string GetRewardDescription(DailyReward reward)
        {
            string description = "";
            
            if (reward.Gems > 0)
                description += $"💎 {reward.Gems} гемов\n";
            if (reward.Coins > 0)
                description += $"🪙 {reward.Coins} монет\n";
            if (reward.PowerPoints > 0)
                description += $"⚡ {reward.PowerPoints} очков силы\n";
            if (reward.BrawlerPowerPoints > 0)
                description += $"⚡ {reward.BrawlerPowerPoints} очков силы для бравлера\n";
            
            if (reward.HasBrawlerChance && reward.BrawlerId > 0)
            {
                string brawlerName = GetBrawlerNameById(reward.BrawlerId);
                description += $"👤 Новый бравлер: {brawlerName}!\n";
            }
            
            return description.Trim();
        }

        private async Task<bool> SendRewardToGame(string accountTag, DailyReward reward)
{
    try
    {
        long accountId = TagToId(accountTag);
        Account account = Accounts.Load(accountId);
        
        if (account == null || account.Avatar == null)
        {
            Console.WriteLine($"[WheelSpin] ОШИБКА: Аккаунт {accountTag} не найден или нет Avatar");
            return false;
        }
        
        Console.WriteLine($"[WheelSpin] Загружен аккаунт {accountTag}, баланс до: " +
                         $"{account.Avatar.Diamonds}💎/{account.Avatar.Gold}🪙/{account.Avatar.PowerPoints}⚡");
        
        // Выдаем награды
        account.Avatar.Diamonds += reward.Gems;
        account.Avatar.Gold += reward.Coins;
        account.Avatar.PowerPoints += reward.PowerPoints;
        
        Console.WriteLine($"[WheelSpin] Начислено: +{reward.Gems}💎, +{reward.Coins}🪙, +{reward.PowerPoints}⚡");
        
        // Выдаем бравлера если есть
        if (reward.HasBrawlerChance && reward.BrawlerId > 0)
        {
            // Проверяем ID бравлера (добавляем смещение если нужно)
            int brawlerId = reward.BrawlerId;
            if (brawlerId < 16000000 && brawlerId > 0)
            {
                brawlerId += 16000000; // Добавляем смещение для ID бравлера
            }
            
            if (brawlerId >= 16000000 && brawlerId <= 16000077)
            {
                if (!account.Avatar.HasHero(brawlerId))
                {
                    account.Avatar.UnlockHero(brawlerId);
                    Console.WriteLine($"[WheelSpin] Выдан новый бравлер ID: {brawlerId}");
                    
                    // Выдаем очки силы бравлеру
                    if (reward.BrawlerPowerPoints > 0)
                    {
                        var hero = account.Avatar.GetHero(brawlerId);
                        if (hero != null)
                        {
                            hero.PowerPoints += reward.BrawlerPowerPoints;
                            Console.WriteLine($"[WheelSpin] Добавлено {reward.BrawlerPowerPoints} ОС бравлеру {brawlerId}");
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"[WheelSpin] Бравлер ID {brawlerId} уже есть у игрока");
                    
                    // Если бравлер уже есть, конвертируем в очки силы
                    int convertedPowerPoints = reward.BrawlerPowerPoints * 2;
                    account.Avatar.PowerPoints += convertedPowerPoints;
                    Console.WriteLine($"[WheelSpin] Конвертировано в {convertedPowerPoints} ОС (бравлер уже был)");
                }
            }
        }
        
        // Сохраняем изменения
        Accounts.Save(account);
        
        Console.WriteLine($"[WheelSpin] Аккаунт {accountTag} сохранен, баланс после: " +
                         $"{account.Avatar.Diamonds}💎/{account.Avatar.Gold}🪙/{account.Avatar.PowerPoints}⚡");
        
        return true;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[WheelSpin] КРИТИЧЕСКАЯ ОШИБКА при выдаче награды {accountTag}: {ex.Message}");
        Console.WriteLine($"[WheelSpin] StackTrace: {ex.StackTrace}");
        return false;
    }
}

        private string GetShopItemIcon(ShopItem itemType)
        {
            return itemType switch
            {
                ShopItem.Gems => "💎",
                ShopItem.Coin => "🪙",
                ShopItem.Skin => "🎨",
                ShopItem.Bling => "💠",
                ShopItem.PowerPoint => "⚡",
                ShopItem.GuaranteedHero => "👤",
                ShopItem.Titul => "🏷️",
                ShopItem.RarityStarrDrop => "✨",
                _ => "🎁"
            };
        }

        private string GetPriceInfo(OfferBundle offer)
        {
            if (offer.Cost == 0)
                return "БЕСПЛАТНО";
            
            // Определяем тип валюты по наличию других свойств или по значениям
            bool isGems = false;
            bool isCoins = false;
            
            // Проверяем, есть ли свойство для определения валюты
            var type = offer.GetType();
            var currencyTypeProp = type.GetProperty("CurrencyType");
            var costTypeProp = type.GetProperty("CostType");
            var currencyProp = type.GetProperty("Currency");
            
            if (currencyTypeProp != null)
            {
                int currencyType = (int)currencyTypeProp.GetValue(offer);
                isGems = currencyType == 0;
                isCoins = currencyType == 1;
            }
            else if (costTypeProp != null)
            {
                int costType = (int)costTypeProp.GetValue(offer);
                isGems = costType == 0;
                isCoins = costType == 1;
            }
            else if (currencyProp != null)
            {
                string currency = (string)currencyProp.GetValue(offer);
                isGems = currency == "gems" || currency == "diamonds";
                isCoins = currency == "coins" || currency == "gold";
            }
            else
            {
                // Если свойство не найдено, делаем предположение по диапазону значений
                isGems = offer.Cost < 10000; // Гемы обычно дешевле
                isCoins = offer.Cost >= 10000; // Монеты обычно в большем количестве
            }
            
            return $"{offer.Cost} {(isGems ? "гемов" : "монет")}";
        }

        private string GetPriceInfoDetailed(OfferBundle offer)
        {
            if (offer.Cost == 0)
                return "🎁 БЕСПЛАТНО";
            
            bool isGems = false;
            bool isCoins = false;
            
            // Проверяем, есть ли свойство для определения валюты
            var type = offer.GetType();
            var currencyTypeProp = type.GetProperty("CurrencyType");
            var costTypeProp = type.GetProperty("CostType");
            var currencyProp = type.GetProperty("Currency");
            
            if (currencyTypeProp != null)
            {
                int currencyType = (int)currencyTypeProp.GetValue(offer);
                isGems = currencyType == 0;
                isCoins = currencyType == 1;
            }
            else if (costTypeProp != null)
            {
                int costType = (int)costTypeProp.GetValue(offer);
                isGems = costType == 0;
                isCoins = costType == 1;
            }
            else if (currencyProp != null)
            {
                string currency = (string)currencyProp.GetValue(offer);
                isGems = currency == "gems" || currency == "diamonds";
                isCoins = currency == "coins" || currency == "gold";
            }
            else
            {
                // Если свойство не найдено, делаем предположение
                isGems = offer.Cost < 10000;
                isCoins = offer.Cost >= 10000;
            }
            
            if (offer.OldCost > 0 && offer.OldCost > offer.Cost)
            {
                return $"~~{offer.OldCost}~~ → **{offer.Cost}** {(isGems ? "гемов" : "монет")}";
            }
            
            return $"{offer.Cost} {(isGems ? "гемов" : "монет")}";
        }

        private bool CanAffordOffer(Account account, OfferBundle offer)
        {
            if (account?.Avatar == null)
                return false;
            
            if (offer.Cost == 0)
                return true;
            
            bool isGems = false;
            
            // Проверяем, есть ли свойство для определения валюты
            var type = offer.GetType();
            var currencyTypeProp = type.GetProperty("CurrencyType");
            var costTypeProp = type.GetProperty("CostType");
            var currencyProp = type.GetProperty("Currency");
            
            if (currencyTypeProp != null)
            {
                int currencyType = (int)currencyTypeProp.GetValue(offer);
                isGems = currencyType == 0;
            }
            else if (costTypeProp != null)
            {
                int costType = (int)costTypeProp.GetValue(offer);
                isGems = costType == 0;
            }
            else if (currencyProp != null)
            {
                string currency = (string)currencyProp.GetValue(offer);
                isGems = currency == "gems" || currency == "diamonds";
            }
            else
            {
                // Если свойство не найдено, делаем предположение
                isGems = offer.Cost < 10000;
            }
            
            if (isGems) // Гемы
                return account.Avatar.Diamonds >= offer.Cost;
            else // Монеты
                return account.Avatar.Gold >= offer.Cost;
        }

        private async Task<bool> ProcessPurchase(Account account, int offerIndex)
        {
            try
            {
                // Загружаем аккаунт заново
                account = Accounts.Load(account.AccountId);
                if (account?.Home == null) return false;
                
                // Вызываем метод покупки - если он возвращает void, просто вызываем его
                account.Home.PurchaseOffer(offerIndex);
                
                // Сохраняем изменения
                await Task.Run(() => Accounts.Save(account));
                
                Console.WriteLine($"[TelegramShop] Покупка акции #{offerIndex} для аккаунта {account.AccountId}");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TelegramShop] Ошибка покупки: {ex.Message}");
                Console.WriteLine($"[TelegramShop] StackTrace: {ex.StackTrace}");
                return false;
            }
        }

        private string GetSkinNameById(int skinId)
        {
            try
            {
                // Замените на вашу реализацию получения имени скина
                return $"Скин #{skinId}";
            }
            catch
            {
                return $"Скин #{skinId}";
            }
        }

        private string GeneratePassToken()
        {
            return Helpers.RandomString(40);
        }
        
        
        
        private async Task SyncOffersFromGame(long chatId, long userId)
{
    if (!_linkManager.TryGetAccountId(userId, out string accountTag))
    {
        await _client.SendMessageAsync(chatId, 
            "❌ *Сначала привяжите аккаунт!*", 
            TelegramClient.ParseMode.MarkdownV2);
        return;
    }

    long accountId = TagToId(accountTag);
    
    try
    {
        // 1. Загружаем аккаунт
        var account = Accounts.Load(accountId);
        if (account?.Home == null)
        {
            await _client.SendMessageAsync(chatId,
                "❌ *Аккаунт не загружен!*\n" +
                "Войдите в игру, чтобы создать предложения.",
                TelegramClient.ParseMode.MarkdownV2);
            return;
        }

        // 2. Проверяем, есть ли предложения в игре
        if (account.Home.OfferBundles == null || account.Home.OfferBundles.Count == 0)
        {
            // Пытаемся вызвать метод создания предложений
            bool offersCreated = await ForceCreateOffersInGame(account);
            
            if (!offersCreated)
            {
                await _client.SendMessageAsync(chatId,
                    "⚠️ *Предложений нет!*\n\n" +
                    "Войдите в игру, чтобы:\n" +
                    "1. Создать предложения магазина\n" +
                    "2. Вернитесь в бота и используйте команду снова",
                    TelegramClient.ParseMode.MarkdownV2);
                return;
            }
            
            // Перезагружаем аккаунт
            account = Accounts.Load(accountId);
        }

        // 3. Показываем информацию о предложениях
        int totalOffers = account.Home.OfferBundles?.Count ?? 0;
        int activeOffers = account.Home.OfferBundles?
            .Count(o => !o.Purchased && o.EndTime > DateTime.UtcNow) ?? 0;
        
        var message = new StringBuilder();
        message.AppendLine("🔄 *СИНХРОНИЗАЦИЯ ПРЕДЛОЖЕНИЙ*");
        message.AppendLine("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        message.AppendLine("");
        message.AppendLine($"✅ *Синхронизировано с игрой!*");
        message.AppendLine($"");
        message.AppendLine($"📊 *Статистика:*");
        message.AppendLine($"• Всего предложений: {totalOffers}");
        message.AppendLine($"• Активных: {activeOffers}");
        message.AppendLine($"• Тег аккаунта: `{accountTag}`");
        message.AppendLine($"");
        message.AppendLine("💡 *Что дальше:*");
        message.AppendLine("1. Используйте `/shop` для просмотра");
        message.AppendLine("2. Используйте `/shop_debug` для деталей");
        
        // Показываем первые несколько предложений
        if (activeOffers > 0)
        {
            message.AppendLine($"");
            message.AppendLine($"🎁 *Примеры предложений:*");
            var sampleOffers = account.Home.OfferBundles
                .Where(o => !o.Purchased && o.EndTime > DateTime.UtcNow)
                .Take(3)
                .ToList();
            
            foreach (var offer in sampleOffers)
            {
                message.AppendLine($"• {offer.Title} - {GetPriceInfo(offer)}");
            }
        }

        await _client.SendMessageAsync(chatId, message.ToString(), TelegramClient.ParseMode.MarkdownV2);

    }
    catch (Exception ex)
    {
        await _client.SendMessageAsync(chatId,
            $"❌ *Ошибка синхронизации:*\n```{ex.Message}```\n\n" +
            $"Войдите в игру и создайте предложения магазина.",
            TelegramClient.ParseMode.MarkdownV2);
        
        Console.WriteLine($"[TelegramBot] Ошибка синхронизации: {ex.Message}");
    }
}

// Добавьте в класс TelegramBot
private void ForceRefreshClient(long accountId)
{
    try
    {
        if (Sessions.IsSessionActive(accountId))
        {
            var session = Sessions.GetSession(accountId);
            if (session?.GameListener != null)
            {
                // Отправляем "пустое" сообщение, чтобы клиент обновился
                var keepAlive = new KeepAliveMessage(); // или любое другое сообщение
                session.GameListener.SendTCPMessage(keepAlive);
                
                Console.WriteLine($"[ForceRefresh] Отправлен keep-alive для {accountId}");
            }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[ForceRefresh] Ошибка: {ex.Message}");
    }
}


private async Task<bool> ForceCreateOffersInGame(Account account)
{
    try
    {
        // Попытка вызвать метод создания предложений из ClientHome
        var homeType = account.Home.GetType();
        
        // Ищем метод создания предложений
        var createOffersMethod = homeType.GetMethod("CreateOffers");
        var generateOffersMethod = homeType.GetMethod("GenerateOffers");
        var initShopMethod = homeType.GetMethod("InitializeShop");
        
        if (createOffersMethod != null)
        {
            createOffersMethod.Invoke(account.Home, null);
            Console.WriteLine($"[TelegramBot] Вызван CreateOffers()");
        }
        else if (generateOffersMethod != null)
        {
            generateOffersMethod.Invoke(account.Home, null);
            Console.WriteLine($"[TelegramBot] Вызван GenerateOffers()");
        }
        else if (initShopMethod != null)
        {
            initShopMethod.Invoke(account.Home, null);
            Console.WriteLine($"[TelegramBot] Вызван InitializeShop()");
        }
        else
        {
            Console.WriteLine($"[TelegramBot] Не найден метод создания предложений");
            return false;
        }
        
        // Сохраняем изменения
        Accounts.Save(account);
        
        Console.WriteLine($"[TelegramBot] Предложения созданы для аккаунта {account.AccountId}");
        return true;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[TelegramBot] Ошибка создания предложений: {ex.Message}");
        return false;
    }
}
        
        
        private async Task<bool> SendConfirmationNotificationToGame(long accountId, string code)
        {
            try
            {
                var account = Accounts.Load(accountId);
                if (account == null) return false;

                var clientHome = account.Home;
                if (clientHome == null) return false;

                var notification = new Notification
                {
                    Id = 81,
                    MessageEntry = $"Ваш код для привязки в DBMOD1 ID: {code}",
                    IsViewed = false
                };

                if (clientHome.NotificationFactory == null)
                {
                    clientHome.NotificationFactory = new NotificationFactory();
                }
                
                clientHome.NotificationFactory.Add(notification);

                Accounts.Save(account);

                if (Sessions.IsSessionActive(accountId))
                {
                    var session = Sessions.GetSession(accountId);
                    if (session?.GameListener != null)
                    {
                        session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                        {
                            Message = $"Вам пришёл код подтверждения привязки к аккаунту Telegram!"
                        });
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TelegramBot] Ошибка при отправке уведомления: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> SendSkinRewardNotificationToGame(long accountId, int skinId)
        {
            try
            {
                var account = Accounts.Load(accountId);
                if (account == null) return false;

                var clientHome = account.Home;
                if (clientHome == null) return false;

                var notification = new Notification
                {
                    Id = 94,
                    MessageEntry = "Успешная привязка к аккаунту Telegram!",
                    IsViewed = false,
                    SkinID = skinId
                };

                if (clientHome.NotificationFactory == null)
                {
                    clientHome.NotificationFactory = new NotificationFactory();
                }
                
                clientHome.NotificationFactory.Add(notification);

                Accounts.Save(account);

                if (Sessions.IsSessionActive(accountId))
                {
                    var session = Sessions.GetSession(accountId);
                    if (session?.GameListener != null)
                    {
                        session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                        {
                            Message = $"Поздравляем! Вам выдан новый скин."
                        });
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TelegramBot] Ошибка при отправке скина: {ex.Message}");
                return false;
            }
        }

        private string GenerateConfirmationCode()
        {
            return new Random().Next(100000, 999999).ToString();
        }

        private bool IsAccountId(string text)
        {
            text = text.ToUpper().TrimStart('#');
            const string Base32 = "0289PYLQGRJCUV";
            return text.Length > 0 && text.All(c => Base32.Contains(c));
        }
    }
}