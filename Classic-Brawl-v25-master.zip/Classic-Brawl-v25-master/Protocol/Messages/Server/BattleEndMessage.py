from ByteStream.Writer import Writer


class BattleEndMessage(Writer):

    def __init__(self, client, player, type, result, players):
        super().__init__(client)
        self.id = 23456
        self.player  = player
        self.type    = type
        self.result  = result
        self.players = players

    def encode(self):
        self.writeVInt(self.type)
        self.writeVInt(self.result)
        self.writeVInt(0) # Tokens Gained
        self.writeVInt(0) # Trophies Result
        self.writeVInt(0) # Power Play Points Gained
        self.writeVInt(0) # Doubled Tokens
        self.writeVInt(0) # Double Token Event
        self.writeVInt(0) # Token Doubler Remaining
        self.writeVInt(0) # Big Game/Robo Rumble Time and Boss Fight Level Cleared
        self.writeVInt(0) # Epic Win Power Play Points Gained
        self.writeVInt(0) # Championship Level Passed
        self.writeVInt(0) # Challenge Reward Type (0 = Star Points, 1 = Star Tokens)
        self.writeVInt(0) # Challenge Reward Ammount
        self.writeVInt(0) # Championship Losses Left
        self.writeVInt(0) # Championship Maximun Losses
        self.writeVInt(0) # Coin Shower Event
        self.writeVInt(32) # Battle Result Type ((-16)-(-1) = Power Play Battle End, 0-15 = Practice Battle End, 16-31 = Matchmaking Battle End, 32-47 = Friendly Game Battle End, 48-63  = Spectate and Replay Battle End, 64-79 = Championship Battle End)
        self.writeVInt(0) # Championship Cleared and Beta Quests

        self.writeVInt(len(self.players))

        for player in self.players:
            self.brawler  = self.players[player]['Brawler']
            self.skin     = self.players[player]['Skin']
            self.team     = self.players[player]['Team']
            self.username = self.players[player]['Name']

            if self.type == 5:
                if self.team == 0:
                    self.writeVInt(player)
                else:
                    self.writeVInt(2)

            elif self.type == 2:
                if self.team != 0:
                    self.writeVInt(2 if self.team != 0 else 1)

            else:
               self.writeVInt(self.team if self.team != 1 else 2)

            self.writeDataReference(16, self.brawler)if self.brawler != -1 else self.writeVInt(0)
            self.writeDataReference(29, self.skin)   if self.skin != -1 else self.writeVInt(0)

            self.writeVInt(99999)
            self.writeVInt(0)
            self.writeVInt(10)

            self.writeBool(False)

            # sub_64DF74
            self.writeString(self.username)
            self.writeVInt(100)
            self.writeVInt(28000000)
            self.writeVInt(43000000)

        self.writeBool(False)
        self.writeBool(False)
        self.writeBool(False)

        self.writeDataReference(28, 0)

        self.writeBool(False)