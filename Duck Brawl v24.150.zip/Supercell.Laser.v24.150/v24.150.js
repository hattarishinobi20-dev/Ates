const base = Module.findBaseAddress('libg.so');

Interceptor.attach(Module.findExportByName('libc.so', 'getaddrinfo'), {
    onEnter(args) {
        this.str = args[0] = Memory.allocUtf8String('1.1.1.1');
        args[1].writeUtf8String('9339');
    }
});

Interceptor.attach(base.add(0x4CD86C), { //  randombytes
    onEnter(args) {
        this.buffer = args[0];
        console.log(args[0])
    },
    onLeave(retval) {
        this.buffer.writeByteArray(CLIENT_SECRET_KEY);
        log("client secret replaced");
        console.log(this.buffer)
    }
});