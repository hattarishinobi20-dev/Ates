const path = require('path')
const Logger = require('./Logger')
const Configuration = require('./Settings/Configuration')
const Resources = require('./Resources')
const ExitHandler = require('./Handler/ExitHandler')
const CmdHandler = require('./Handler/CmdHandler')

class Program {
  static SERVER_VERSION = '1.2'
  static BUILD_TYPE = 'Beta'
  static started = false

  static start () {
    if (this.started) return
    this.started = true

    process.title = 'BrawlStars - server emulator v' + this.SERVER_VERSION + ' Build: ' + this.BUILD_TYPE

    Logger.init()
    Configuration.instance = Configuration.loadFromFile(path.join(__dirname, '../config.json'))
    Resources.initDatabase()
    Resources.initLogic()
    Resources.initNetwork()
    Logger.print("Server started! Let's play Brawl Stars!")

    ExitHandler.init()
    CmdHandler.start()
  }

  static saveAll () {
    ExitHandler.saveAll()
  }
}

module.exports = Program
