const Configuration = require('./Settings/Configuration')
const Fingerprint = require('./Settings/Fingerprint')
const Accounts = require('./Database/Accounts')
const Alliances = require('./Database/Alliances')
const DataTables = require('../Logic/Data/DataTables')
const LogicServerListener = require('../Logic/Listener/LogicServerListener')
const Events = require('./Logic/Game/Events')
const Leaderboards = require('./Logic/Game/Leaderboards')
const Teams = require('./Logic/Game/Teams')
const Battles = require('./Logic/Game/Battles')
const Matchmaking = require('./Logic/Game/Matchmaking')
const UDPGateway = require('./Networking/UDP/UDPGateway')
const ServerListener = require('./Logic/ServerListener')
const Sessions = require('./Networking/Session/Sessions')
const Connections = require('./Networking/Connections')
const Processor = require('./Message/Processor')

class Resources {
  static initDatabase () {
    Accounts.init(Configuration.instance.databaseName)
    Alliances.init(Configuration.instance.databaseName)
  }

  static initLogic () {
    Fingerprint.load()
    DataTables.load()
    Events.init()
    Sessions.init()
    Leaderboards.init()
    Battles.init()
    Matchmaking.init()
    Teams.init()
  }

  static initNetwork () {
    Processor.init()
    Connections.init()
    LogicServerListener.instance = new ServerListener()
    UDPGateway.init('0.0.0.0', Configuration.instance.udpPort)
  }
}

module.exports = Resources
