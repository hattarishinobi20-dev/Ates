const DataTables = require('../../Logic/Data/DataTables')
const DataType = require('../../Logic/Data/DataType')
const GlobalId = require('../../Logic/Data/Helper/GlobalId')
const ClientHome = require('../../Logic/Home/ClientHome')
const HomeMode = require('../../Logic/Home/HomeMode')
const Hero = require('../../Logic/Home/Structures/Hero')
const DeliveryUnit = require('../../Logic/Home/Gatcha/DeliveryUnit')
const GatchaDrop = require('../../Logic/Home/Gatcha/GatchaDrop')
const LogicGiveDeliveryItemsCommand = require('../../Logic/Command/Home/LogicGiveDeliveryItemsCommand')
const LogicServerListener = require('../../Logic/Listener/LogicServerListener')
const AvailableServerCommandMessage = require('../../Protocol/Messages/Server/AvailableServerCommandMessage')
const FriendListUpdateMessage = require('../../Protocol/Messages/Server/FriendListUpdateMessage')
const Alliances = require('../Database/Alliances')
const Events = require('../Logic/Game/Events')
const Teams = require('../Logic/Game/Teams')
const Logger = require('../Logger')

class CommandManager {
  constructor (homeMode, connection) {
    this.homeMode = homeMode
    this.connection = connection
  }

  receiveCommand (command) {
    try {
      switch (command.getCommandType()) {
        case 500: return this.logicGatchaReceived(command)
        case 503: return this.logicClaimDailyRewardReceived(command)
        case 505: return this.logicSetPlayerThumbnailReceived(command)
        case 506: return this.logicSelectSkinReceived(command)
        case 509: return this.logicPurchaseDoubleCoinsReceived(command)
        case 514: return this.logicDeleteNotificationReceived(command)
        case 515: return this.logicClearShopTickersReceived(command)
        case 520: return this.logicLevelUpReceived(command)
        case 517: return this.logicClaimRankUpRewardReceived(command)
        case 519: return this.logicPurchaseOfferReceived(command)
        case 521: return this.logicPurchaseHeroLvlUpMaterialReceived(command)
        case 522: return this.logicHeroSeenReceived(command)
        case 525: return this.logicSelectCharacterReceived(command)
        case 527: return this.logicSetPlayerNameColorReceived(command)
        case 528: return this.logicViewInboxNotificationReceived(command)
        case 529: return this.logicSelectStarPowerReceived(command)
        case 533: return this.logicQuestsSeenReceived(command)
        case 534: return this.logicPurchaseBrawlPassReceived(command)
        case 535: return this.logicClaimTailRewardReceived(command)
        case 536: return this.logicPurchaseBrawlPassProgressReceived(command)
        default:
          Logger.print(`CommandManager::ReceiveCommand - no case for ${command.constructor.name} (${command.getCommandType()})`)
          return false
      }
    } catch (e) {
      Logger.error(`CommandManager::ReceiveCommand - exception in ${command.constructor.name}: ${e.stack || e}`)
      return false
    }
  }

  get avatar () {
    return this.homeMode.avatar
  }

  get home () {
    return this.homeMode.home
  }

  sendDelivery (command) {
    const message = new AvailableServerCommandMessage()
    message.command = command
    this.homeMode.gameListener.sendMessage(message)
  }

  updateFriendEntries (update) {
    for (const friend of this.avatar.friends.slice()) {
      const friendAvatar = friend.avatar
      if (friendAvatar == null) continue
      const entry = friendAvatar.getFriendById(this.avatar.accountId)
      if (entry == null || entry.displayData == null) continue
      update(entry.displayData)

      if (LogicServerListener.instance.isPlayerOnline(friendAvatar.accountId)) {
        const message = new FriendListUpdateMessage()
        message.entry = entry
        const listener = LogicServerListener.instance.getGameListener(friend.accountId)
        if (listener != null) listener.sendTCPMessage(message)
      }
    }
  }

  updateAllianceMember (update) {
    if (this.avatar.allianceId <= 0) return
    const alliance = Alliances.load(this.avatar.allianceId)
    if (alliance == null) {
      this.avatar.allianceId = -1
      return
    }
    const member = alliance.getMemberById(this.avatar.accountId)
    if (member == null || member.displayData == null) return
    update(member.displayData)
  }

  getTeamMember () {
    if (!(this.avatar.teamId > 0)) return null
    const team = Teams.get(this.avatar.teamId)
    if (team == null) return null
    const member = team.getMember(this.avatar.accountId)
    if (member == null) return null
    return { team, member }
  }

  logicHeroSeenReceived (command) {
    if (command.characterId === 0) return false
    const h = this.avatar.getHero(command.characterId)
    if (h == null) return false
    h.isNew = false
    return true
  }

  logicPurchaseBrawlPassProgressReceived (command) {
    const target = ClientHome.getBrawlPassTierEnd(this.home.brawlPassTokens)
    if (target == null) return false
    if (!this.avatar.useDiamonds(ClientHome.BRAWL_PASS_TIER_PRICE)) return false
    this.home.brawlPassTokens = target
    return true
  }

  getNotification (index) {
    const factory = this.home.notificationFactory
    if (!Number.isInteger(index) || index < 0 || index >= factory.notificationList.length) return null
    return factory.notificationList[index]
  }

  logicViewInboxNotificationReceived (command) {
    const notification = this.getNotification(command.notificationIndex)
    if (notification == null) return false
    if (notification.isViewed) return false

    if (notification.id === 79 && Array.isArray(notification.starpointsAwarded)) {
      for (const a of notification.starpointsAwarded) {
        this.avatar.starPoints += a
      }
    }

    if (notification.id === 89) {
      const delivery = new LogicGiveDeliveryItemsCommand()
      const unit = new DeliveryUnit(100)
      const reward = new GatchaDrop(8)
      reward.count = notification.donationCount
      unit.addDrop(reward)
      delivery.deliveryUnits.push(unit)
      delivery.execute(this.homeMode)
      this.sendDelivery(delivery)
    }

    notification.isViewed = true
    return true
  }

  logicDeleteNotificationReceived (command) {
    const notification = this.getNotification(command.notificationIndex)
    if (notification == null) return false
    if (notification.isViewed) return false
    const list = this.home.notificationFactory.notificationList
    list.splice(list.indexOf(notification), 1)
    return true
  }

  logicClaimTailRewardReceived (command) {
    if (this.home.brawlPassTokens < 500) return false
    this.home.brawlPassTokens -= 500

    const delivery = new LogicGiveDeliveryItemsCommand()
    const unit = new DeliveryUnit(12)
    this.homeMode.simulateGatcha(unit)
    delivery.deliveryUnits.push(unit)
    delivery.execute(this.homeMode)
    this.sendDelivery(delivery)
    return true
  }

  logicSelectStarPowerReceived (command) {
    const cards = DataTables.get(DataType.Card)
    const card = cards.getDataByGlobalId(GlobalId.createGlobalId(DataType.Card, command.starpowerInstanceId))
    if (card == null) return false
    if (!this.avatar.starpowers.includes(card.getGlobalId())) return false

    const heroData = DataTables.get(DataType.Character).getData(card.name.split('_')[0])
    if (heroData == null) return false
    const h = this.avatar.getHero(heroData.getGlobalId())
    if (h == null) return false

    const selected = this.avatar.selectedStarpowers
    const remove = (id) => {
      let index
      while ((index = selected.indexOf(id)) !== -1) selected.splice(index, 1)
    }

    if (card.metaType !== 5) {
      const m = card.name.replace('_2', '').replace('_3', '')
      const card1 = cards.getData(m)
      const card2 = cards.getData(m + '_2')
      const card3 = cards.getData(m + '_3')

      h.hasStarpower = true
      if (card1 != null) remove(card1.getGlobalId())
      if (card2 != null) remove(card2.getGlobalId())
      if (card3 != null) remove(card3.getGlobalId())
      selected.push(card.getGlobalId())
    } else {
      for (const wildCard of HomeMode.getGadgetCards(heroData)) {
        remove(wildCard.getGlobalId())
      }
      selected.push(card.getGlobalId())
    }

    const teamInfo = this.getTeamMember()
    if (teamInfo != null && teamInfo.member.characterId === heroData.getGlobalId()) {
      if (card.metaType !== 5) {
        teamInfo.member.starpower = card.getGlobalId()
      } else {
        teamInfo.member.gadget = card.getGlobalId()
      }
      teamInfo.team.teamUpdated()
    }

    return true
  }

  logicQuestsSeenReceived (command) {
    if (this.home.quests == null) return true
    for (const quest of this.home.quests.questList.slice()) {
      quest.questSeen = true
    }
    return true
  }

  logicPurchaseBrawlPassReceived (command) {
    if (this.home.hasPremiumPass) return false
    const price = command.withTiers ? ClientHome.BRAWL_PASS_BUNDLE_PRICE : ClientHome.BRAWL_PASS_PRICE
    if (!this.avatar.useDiamonds(price)) return false

    this.home.hasPremiumPass = true
    if (command.withTiers) this.home.addBrawlPassTiers(ClientHome.BRAWL_PASS_BUNDLE_TIERS)
    this.updateAllianceMember(displayData => { displayData.highNameColorId = this.home.nameColorId })
    this.updateFriendEntries(displayData => { displayData.highNameColorId = this.home.nameColorId })
    return true
  }

  logicGatchaReceived (command) {
    return command.execute(this.homeMode) === 0
  }

  logicSelectSkinReceived (command) {
    const skin = GlobalId.createGlobalId(DataType.Skin, command.skinId)
    const skinData = DataTables.get(DataType.Skin).getDataByGlobalId(skin)
    if (skinData == null) return false

    if (command.skinId !== 63) {
      if (!skinData.name.endsWith('Default') && !this.home.unlockedSkins.includes(skin)) return false
    }

    const sk = DataTables.get(DataType.SkinConf).getData(skinData.conf)
    if (sk == null) return false
    const c = DataTables.get(DataType.Character).getData(sk.character)
    if (c == null) return false
    if (!this.avatar.hasHero(c.getGlobalId())) return false

    this.home.characterId = c.getGlobalId()
    this.homeMode.onCharacterChanged(c.getGlobalId())

    while (this.home.selectedSkins.length <= c.getInstanceId()) this.home.selectedSkins.push(0)
    this.home.selectedSkins[c.getInstanceId()] = command.skinId

    const teamInfo = this.getTeamMember()
    if (teamInfo != null) {
      teamInfo.member.skinId = skin
      teamInfo.team.teamUpdated()
    }

    return true
  }

  logicClaimDailyRewardReceived (command) {
    if (!Events.hasSlot(command.slot)) return false
    if (Events.collectEvent(this.avatar.accountId, command.slot)) {
      this.avatar.addTokens(10)
    }
    return true
  }

  logicLevelUpReceived (command) {
    const hero = this.avatar.getHero(command.characterId)
    if (hero == null) return false
    if (hero.powerLevel < 0 || hero.powerLevel >= Hero.MaxPowerLevel) return false
    if (hero.powerPoints < Hero.UpgradePowerPointsTable[hero.powerLevel]) return false
    if (!this.avatar.useGold(Hero.UpgradeCostTable[hero.powerLevel])) return false
    hero.powerLevel++
    return true
  }

  logicPurchaseOfferReceived (command) {
    return this.home.purchaseOffer(command.offerIndex)
  }

  logicSelectCharacterReceived (command) {
    const globalId = GlobalId.createGlobalId(DataType.Character, command.characterInstanceId)
    if (!this.avatar.hasHero(globalId)) return false

    this.home.characterId = globalId
    this.homeMode.onCharacterChanged(globalId)

    const teamInfo = this.getTeamMember()
    if (teamInfo != null) {
      const { team, member } = teamInfo
      const hero = this.avatar.getHero(globalId)
      const cd = DataTables.get(DataType.Character).getDataByGlobalId(hero.characterId)
      const cards = DataTables.get(DataType.Card)

      member.starpower = 0
      if (hero.hasStarpower && cd != null) {
        const card = cards.getData(cd.name + '_unique')
        const card2 = cards.getData(cd.name + '_unique_2')
        const ids = [card, card2].filter(x => x != null).map(x => x.getGlobalId())
        const chosen = ids.find(id => this.avatar.selectedStarpowers.includes(id)) ||
          ids.find(id => this.avatar.starpowers.includes(id))
        if (chosen != null) {
          member.heroLevel = 9
          member.starpower = chosen
        }
      }

      member.gadget = 0
      if (hero.powerLevel > 5 && cd != null) {
        for (const wildCard of HomeMode.getGadgetCards(cd)) {
          if (this.avatar.starpowers.includes(wildCard.getGlobalId())) {
            member.gadget = wildCard.getGlobalId()
            break
          }
        }
      }

      const skinInstanceId = this.home.selectedSkins[GlobalId.getInstanceId(this.home.characterId)] | 0
      member.skinId = skinInstanceId > 0 ? GlobalId.createGlobalId(DataType.Skin, skinInstanceId) : 0
      team.teamUpdated()
    }

    return true
  }

  logicSetPlayerThumbnailReceived (command) {
    if (command.thumbnailInstanceId < 0) return false
    if (command.thumbnailInstanceId >= DataTables.get(DataType.PlayerThumbnail).count) return false
    this.home.thumbnailId = GlobalId.createGlobalId(DataType.PlayerThumbnail, command.thumbnailInstanceId)

    this.updateAllianceMember(displayData => { displayData.thumbnailId = this.home.thumbnailId })
    this.updateFriendEntries(displayData => { displayData.thumbnailId = this.home.thumbnailId })
    return true
  }

  logicSetPlayerNameColorReceived (command) {
    if (command.nameColorInstanceId < 0) return false
    if (command.nameColorInstanceId >= DataTables.get(DataType.NameColor).count) return false
    this.home.nameColorId = GlobalId.createGlobalId(DataType.NameColor, command.nameColorInstanceId)

    this.updateAllianceMember(displayData => { displayData.nameColorId = this.home.nameColorId })
    this.updateFriendEntries(displayData => { displayData.nameColorId = this.home.nameColorId })
    return true
  }

  logicClearShopTickersReceived (command) {
    for (const bundle of this.home.offerBundles.slice()) {
      bundle.state = 2
    }
    return true
  }

  logicPurchaseDoubleCoinsReceived (command) {
    if (this.avatar.useDiamonds(40)) {
      this.home.tokenDoublers += 1000
      return true
    }
    return false
  }

  logicPurchaseHeroLvlUpMaterialReceived (command) {
    if (command.packIndex < 0 || command.packIndex >= ClientHome.GoldPacksAmount.length) return false
    if (!this.avatar.useDiamonds(ClientHome.GoldPacksPrice[command.packIndex])) return false
    this.avatar.addGold(ClientHome.GoldPacksAmount[command.packIndex])
    return true
  }

  logicClaimRankUpRewardReceived (command) {
    return command.execute(this.homeMode) === 0
  }
}

module.exports = CommandManager
