const AllianceRole = require('../../Logic/Avatar/AllianceRole')
const AllianceStreamEntry = require('../../Logic/Stream/Entry/AllianceStreamEntry')
const LogicLongCodeGenerator = require('../../Logic/Util/LogicLongCodeGenerator')
const Notification = require('../../Logic/Home/Items/Notification')
const OfferBundle = require('../../Logic/Home/Items/OfferBundle')
const Offer = require('../../Logic/Home/Items/Offer')
const ShopItem = require('../../Logic/Home/Items/ShopItem')
const GlobalId = require('../../Logic/Data/Helper/GlobalId')
const LogicAddNotificationCommand = require('../../Logic/Command/Home/LogicAddNotificationCommand')
const AllianceStreamEntryMessage = require('../../Protocol/Messages/Server/AllianceStreamEntryMessage')
const AvailableServerCommandMessage = require('../../Protocol/Messages/Server/AvailableServerCommandMessage')
const AuthenticationFailedMessage = require('../../Protocol/Messages/Server/AuthenticationFailedMessage')
const CreateAccountOkMessage = require('../../Protocol/Messages/Server/CreateAccountOkMessage')
const DebugOpenMessage = require('../../Protocol/Messages/Server/DebugOpenMessage')
const Accounts = require('../Database/Accounts')
const AccountCache = require('../Database/Cache/AccountCache')
const AllianceCache = require('../Database/Cache/AllianceCache')
const Sessions = require('../Networking/Session/Sessions')
const Fingerprint = require('../Settings/Fingerprint')

const ADMIN_ACCOUNT_ID = 2
const NO_RIGHTS = 'You don\'t have right to use this command'
const STAR_POINTS_TROPHIES_START = [550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1050, 1100, 1150, 1200, 1250, 1300, 1350, 1400]
const STAR_POINTS_TROPHIES_END = [599, 649, 699, 749, 799, 849, 899, 949, 999, 1049, 1099, 1149, 1199, 1249, 1299, 1349, 1399, 1000000]
const STAR_POINTS_SEASON_REWARD_AMOUNT = [70, 120, 160, 200, 220, 240, 260, 280, 300, 320, 340, 360, 380, 400, 420, 440, 460, 480]
const STAR_POINTS_TROPHIES_IN_RESET = [525, 550, 600, 650, 700, 725, 750, 775, 800, 825, 850, 875, 900, 925, 950, 975, 1000, 1025]

class AllianceChatCommandHandler {
  constructor (messageManager, alliance) {
    this.messageManager = messageManager
    this.connection = messageManager.connection
    this.homeMode = messageManager.homeMode
    this.alliance = alliance
  }

  static formatDate (time) {
    const d = new Date(time)
    const p = value => String(value).padStart(2, '0')
    return `${p(d.getUTCDate())}.${p(d.getUTCMonth() + 1)}.${d.getUTCFullYear()} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())}`
  }

  static addMonths (time, months) {
    const d = new Date(time)
    d.setUTCMonth(d.getUTCMonth() + months)
    return d.getTime()
  }

  static formatUptime (seconds) {
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = Math.floor(seconds % 60)
    return (days > 0 ? `${days} Days, ` : '') +
      (hours > 0 || days > 0 ? `${hours} Hours, ` : '') +
      (minutes > 0 || hours > 0 ? `${minutes} Minutes, ` : '') +
      (secs > 0 ? `${secs} Seconds` : '')
  }

  get avatar () {
    return this.homeMode.avatar
  }

  get isAdmin () {
    return this.avatar.accountId === ADMIN_ACCOUNT_ID
  }

  reply (text) {
    const entry = new AllianceStreamEntry()
    entry.authorName = 'Alliance Bot'
    entry.authorId = this.avatar.accountId + 1
    entry.id = this.alliance.stream.entryIdCounter + 1
    entry.authorRole = AllianceRole.Member
    entry.type = 2
    entry.message = text

    const response = new AllianceStreamEntryMessage()
    response.entry = entry
    this.connection.send(response)
  }

  loadAccount (tag) {
    if (tag == null) return null
    const id = LogicLongCodeGenerator.toId(tag).toNumber()
    if (id <= 0) return null
    return Accounts.load(id)
  }

  kickSession (id) {
    if (!Sessions.isSessionActive(id)) return
    const session = Sessions.getSession(id)
    const message = new AuthenticationFailedMessage()
    message.message = 'Some data changed, please re-enter game!'
    session.connection.send(message)
    Sessions.remove(id)
  }

  sendNotification (account, notification) {
    account.home.notificationFactory.add(notification)
    if (!Sessions.isSessionActive(account.accountId)) return
    const command = new LogicAddNotificationCommand()
    command.notification = notification
    const message = new AvailableServerCommandMessage()
    message.command = command
    Sessions.getSession(account.accountId).connection.send(message)
  }

  forEachAccount (action) {
    const lastAccId = Accounts.getMaxAvatarId()
    for (let accid = 1; accid <= lastAccId; accid++) {
      const thisAcc = Accounts.loadNoChache(accid)
      if (thisAcc == null) continue
      try {
        action(thisAcc)
        Accounts.save(thisAcc)
      } catch (e) {
        continue
      }
    }
  }

  static resolveField (account, name) {
    if (name == null || name.length === 0) return null
    const field = name[0].toLowerCase() + name.substring(1)
    for (const target of [account.avatar, account.home]) {
      if (!Object.prototype.hasOwnProperty.call(target, field)) continue
      const value = target[field]
      if (value !== null && typeof value === 'object') continue
      if (typeof value === 'function') continue
      return { target, field }
    }
    return null
  }

  handle (text) {
    const cmd = text.substring(1).split(' ')
    if (cmd.length === 0) return

    switch (cmd[0]) {
      case 'status': return this.status()
      case 'help':
        return this.reply('Avaliable commands:\n/help - show all server commands list\n/status - show server status')
      case 'debug':
        this.reply('Debug open!')
        this.connection.send(new DebugOpenMessage())
        return
      case 'showToken': return this.showToken(cmd)
      case 'loadbyid': return this.loadById(cmd)
      case 'getval': return this.getVal(cmd)
      case 'mute': return this.setMute(cmd, true)
      case 'unmute': return this.setMute(cmd, false)
      case 'giveprem':
      case 'givevip':
        return this.givePremium(cmd)
      case 'ban': return this.ban(cmd)
      case 'unban': return this.unban(cmd)
      case 'addGems': return this.addGemsNotification(cmd)
      case 'addgems': return this.addGems(cmd)
      case 'maintance': return this.maintenance()
      case 'load': return this.load(cmd)
      case 'link': return this.link(cmd)
      case 'addstshellypr': return this.addShellyOffer()
      case 'addMega': return this.addMegaOffer()
      case 'fixallstuffplease': return this.fixAllStuff()
      case 'resetBrawlPass': return this.resetBrawlPass()
      case 'resetseason': return this.resetSeason()
      default:
        return this.reply(`Unknown command /${cmd[0]}!`)
    }
  }

  status () {
    const megabytesUsed = Math.trunc(process.memoryUsage().rss / (1024 * 1024))
    this.reply('Server Status:\n' +
      `Server Game Version: v${Fingerprint.version}\n` +
      'Server Build: v1.1 from 30.09.2024\n' +
      `Resources Sha: ${Fingerprint.sha}\n` +
      'Environment: Prod\n' +
      `Server Time: ${AllianceChatCommandHandler.formatDate(Date.now())} UTC\n` +
      `Players Online: ${Sessions.count}\n` +
      `Memory Used: ${megabytesUsed} MB\n` +
      `Uptime: ${AllianceChatCommandHandler.formatUptime(process.uptime())}\n`)
  }

  showToken (cmd) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Fail: account not found!')
    this.reply('Token: ' + account.passToken + ' Id: ' + account.accountId)
  }

  loadById (cmd) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Invalid tag or code')
    const message = new CreateAccountOkMessage()
    message.accountId = account.accountId
    message.passToken = account.passToken
    this.connection.send(message)
  }

  getVal (cmd) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    if (cmd.length !== 3) return this.reply('Usage: /getval [TAG] [FieldName]')
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Fail: account not found!')
    const resolved = AllianceChatCommandHandler.resolveField(account, cmd[2])
    if (resolved == null) return this.reply(`Fail: LogicClientAvatar::${cmd[2]} not found!`)
    this.reply(`LogicClientAvatar::${cmd[2]} = ${resolved.target[resolved.field]}`)
  }

  setMute (cmd, state) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Fail: account not found!')
    account.avatar.isCommunityBanned = state
    account.home.notificationFactory.add(new Notification({
      id: 81,
      messageEntry: state
        ? 'Для твоего аккаунта временно отключены социальные функции\nЕсли ты думаешь что произошла ошибка, свяжись с администрацией'
        : '<c25c42b>Блокировка чата твоего аккаунта была снята досрочно</c>'
    }))
    this.kickSession(account.accountId)
    this.reply('Done!')
  }

  givePremium (cmd) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    if (cmd.length !== 2) return this.reply(`Usage: /${cmd[0]} [TAG]`)
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Fail: account not found!')

    const now = Date.now()
    account.home.premiumEndTime = AllianceChatCommandHandler.addMonths(account.home.premiumEndTime < now ? now : account.home.premiumEndTime, 1)
    account.avatar.premiumLevel = 1

    this.sendNotification(account, new Notification({
      id: 89,
      donationCount: 30,
      messageEntry: `<c6>Vip статус активирован/продлён до ${AllianceChatCommandHandler.formatDate(account.home.premiumEndTime)} UTC, спасибо за поддержку сервера!</c>`
    }))
    this.reply('Done!')
  }

  ban (cmd) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    if (cmd.length !== 2) return this.reply('Usage: /ban [TAG]')
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Fail: account not found!')

    const now = Date.now()
    account.home.banEndTime = AllianceChatCommandHandler.addMonths(account.home.banEndTime < now ? now : account.home.banEndTime, 1)
    account.avatar.banned = true

    if (Sessions.isSessionActive(account.accountId)) {
      const message = new AuthenticationFailedMessage()
      message.errorCode = 11
      Sessions.getSession(account.accountId).connection.send(message)
      Sessions.remove(account.accountId)
    }
    this.reply('Done! This user banned! Tag: ' + cmd[1])
  }

  unban (cmd) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    if (cmd.length !== 2) return this.reply('Usage: /unban [TAG]')
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Fail: account not found!')

    account.home.banEndTime = Date.now()
    account.avatar.banned = false
    this.reply('Done! This user unbanned! Tag: ' + cmd[1])
  }

  addGemsNotification (cmd) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    if (cmd.length !== 3 || !/^\d+$/.test(cmd[2])) return this.reply('Usage: /addGems [TAG] [Amount]')
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Fail: account not found!')

    this.sendNotification(account, new Notification({
      id: 89,
      donationCount: parseInt(cmd[2], 10),
      messageEntry: '<c6>Thanks for donation!</c>'
    }))
    this.reply('Done! Gems added!')
  }

  addGems (cmd) {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    if (cmd.length !== 3 || !/^\d+$/.test(cmd[2])) return this.reply('Usage: /addgems [TAG] [Amount]')
    const account = this.loadAccount(cmd[1])
    if (account == null) return this.reply('Fail: account not found!')

    account.avatar.addDiamonds(parseInt(cmd[2], 10))
    this.kickSession(account.accountId)
    this.reply('Done!')
  }

  maintenance () {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    this.reply('Done!')
    Sessions.startShutdown()
    AccountCache.saveAll()
    AllianceCache.saveAll()

    AccountCache.started = false
    AllianceCache.started = false
  }

  load (cmd) {
    if (cmd.length !== 3) return this.reply('Usage: /load [Account tag in #XXX format] [password]')
    const t = this.loadAccount(cmd[1])
    if (t == null || t.avatar.password == null || cmd[2] !== t.avatar.password) {
      return this.reply('Неверный пароль, попробуйте еще раз!')
    }

    this.reply('Вы успешно вошли!')

    const accountOk = new CreateAccountOkMessage()
    accountOk.accountId = t.accountId
    accountOk.passToken = t.passToken
    this.connection.send(accountOk)

    const failed = new AuthenticationFailedMessage()
    failed.errorCode = 1
    failed.message = 'Done!'
    this.connection.send(failed)
  }

  link (cmd) {
    if (this.avatar.password == null) {
      if (cmd.length !== 2 || cmd[1].length === 0) return this.reply('Usage: /link [password]')
      this.avatar.setPasword(cmd[1])
      this.reply('Вы успешно привязали аккаунт!\nВаш пароль: ' + cmd[1] + '\nЗапомните его и не передавайте 3-им лицам!')
    } else {
      this.reply('Вы уже привязали аккаунт!\nВаш пароль: ' + this.avatar.password + '\nНе передавайте его 3-им лицам!')
    }
  }

  addShellyOffer () {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    this.forEachAccount(thisAcc => {
      if (thisAcc.home.unlockedSkins.includes(29000052)) return
      const bundle = new OfferBundle()
      bundle.title = 'SPECIAL OFFER <3'
      bundle.isDailyDeals = false
      bundle.endTime = Date.now() + 3 * 24 * 60 * 60 * 1000
      bundle.backgroundExportName = 'offer_special'
      bundle.cost = 0

      bundle.items.push(new Offer(ShopItem.Skin, 1, 0, GlobalId.getInstanceId(29000052)))
      thisAcc.home.offerBundles.push(bundle)
    })
    this.reply('Done!')
  }

  addMegaOffer () {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    this.forEachAccount(thisAcc => {
      const bundle = new OfferBundle()
      bundle.title = 'Mega Boxes'
      bundle.isDailyDeals = false
      bundle.endTime = Date.now() + 3 * 24 * 60 * 60 * 1000
      bundle.backgroundExportName = 'offer_special'
      bundle.cost = 360
      bundle.oldCost = 80 * 14
      bundle.currency = 0

      bundle.items.push(new Offer(ShopItem.MegaBox, 14))
      thisAcc.home.offerBundles.push(bundle)
    })
    this.reply('Done!')
  }

  fixAllStuff () {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    this.forEachAccount(thisAcc => {
      thisAcc.home.lastRotateDate = 0
    })
    this.reply('Done!')
  }

  resetBrawlPass () {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    this.forEachAccount(thisAcc => {
      thisAcc.home.hasPremiumPass = false
      thisAcc.home.brawlPassProgress = 0
      thisAcc.home.brawlPassTokens = 0
      thisAcc.home.premiumPassProgress = 0
    })
    this.reply('Done!')
  }

  resetSeason () {
    if (!this.isAdmin) return this.reply(NO_RIGHTS)
    this.forEachAccount(thisAcc => {
      if (thisAcc.avatar.trophies < 550) return

      const hhh = []
      const ht = []
      const htr = []
      const sa = []
      for (const h of thisAcc.avatar.heroes) {
        if (h.trophies < STAR_POINTS_TROPHIES_START[0]) continue
        hhh.push(h.characterId)
        ht.push(h.trophies)

        for (let i = 0; i < STAR_POINTS_TROPHIES_START.length; i++) {
          if (h.trophies < STAR_POINTS_TROPHIES_START[i] || h.trophies > STAR_POINTS_TROPHIES_END[i]) continue
          if (STAR_POINTS_TROPHIES_START[i] !== 1400) {
            htr.push(h.trophies - STAR_POINTS_TROPHIES_IN_RESET[i])
            h.trophies = STAR_POINTS_TROPHIES_IN_RESET[i]
            sa.push(STAR_POINTS_SEASON_REWARD_AMOUNT[i])
          } else {
            const b = Math.max(0, Math.trunc((h.trophies - 1440) / 2))
            htr.push(h.trophies - STAR_POINTS_TROPHIES_IN_RESET[i] - b)
            h.trophies = STAR_POINTS_TROPHIES_IN_RESET[i] + b
            sa.push(STAR_POINTS_SEASON_REWARD_AMOUNT[i] + Math.trunc(b / 2))
          }
          break
        }
      }

      if (hhh.length > 0) {
        thisAcc.home.notificationFactory.add(new Notification({
          id: 79,
          heroesIds: hhh,
          heroesTrophies: ht,
          heroesTrophiesReseted: htr,
          starpointsAwarded: sa
        }))
      }
    })
    this.reply('Done!')
  }
}

module.exports = AllianceChatCommandHandler
