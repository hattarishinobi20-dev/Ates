const crypto = require('crypto')
const HomeMode = require('../../Logic/Home/HomeMode')
const AllianceRole = require('../../Logic/Avatar/AllianceRole')
const LogicServerListener = require('../../Logic/Listener/LogicServerListener')
const LogicChangeAvatarNameCommand = require('../../Logic/Command/Avatar/LogicChangeAvatarNameCommand')
const ServerHelloMessage = require('../../Protocol/Messages/Server/ServerHelloMessage')
const AuthenticationFailedMessage = require('../../Protocol/Messages/Server/AuthenticationFailedMessage')
const AuthenticationOkMessage = require('../../Protocol/Messages/Server/AuthenticationOkMessage')
const OwnHomeDataMessage = require('../../Protocol/Messages/Server/OwnHomeDataMessage')
const KeepAliveServerMessage = require('../../Protocol/Messages/Server/KeepAliveServerMessage')
const LobbyInfoMessage = require('../../Protocol/Messages/Server/LobbyInfoMessage')
const AvailableServerCommandMessage = require('../../Protocol/Messages/Server/AvailableServerCommandMessage')
const FriendListMessage = require('../../Protocol/Messages/Server/FriendListMessage')
const FriendOnlineStatusEntryMessage = require('../../Protocol/Messages/Server/FriendOnlineStatusEntryMessage')
const AllianceOnlineStatusUpdatedMessage = require('../../Protocol/Messages/Server/AllianceOnlineStatusUpdatedMessage')
const AllianceDataMessage = require('../../Protocol/Messages/Server/AllianceDataMessage')
const MyAllianceMessage = require('../../Protocol/Messages/Server/MyAllianceMessage')
const AllianceStreamMessage = require('../../Protocol/Messages/Server/AllianceStreamMessage')
const AllianceStreamEntryMessage = require('../../Protocol/Messages/Server/AllianceStreamEntryMessage')
const OutOfSyncMessage = require('../../Protocol/Messages/Server/OutOfSyncMessage')
const FriendListUpdateMessage = require('../../Protocol/Messages/Server/FriendListUpdateMessage')
const AddFriendFailedMessage = require('../../Protocol/Messages/Server/AddFriendFailedMessage')
const AllianceResponseMessage = require('../../Protocol/Messages/Server/AllianceResponseMessage')
const JoinableAllianceListMessage = require('../../Protocol/Messages/Server/JoinableAllianceListMessage')
const TeamMessage = require('../../Protocol/Messages/Server/TeamMessage')
const TeamLeftMessage = require('../../Protocol/Messages/Server/TeamLeftMessage')
const TeamInvitationMessage = require('../../Protocol/Messages/Server/TeamInvitationMessage')
const TeamMember = require('../../Logic/Team/TeamMember')
const PlayerMap = require('../../Logic/Home/Structures/PlayerMap')
const BattlePlayerMap = require('../../Logic/Battle/Structures/BattlePlayerMap')
const PlayerMapsMessage = require('../../Protocol/Messages/Server/PlayerMapsMessage')
const CreatePlayerMapResponseMessage = require('../../Protocol/Messages/Server/CreatePlayerMapResponseMessage')
const UpdatePlayerMapResponseMessage = require('../../Protocol/Messages/Server/UpdatePlayerMapResponseMessage')
const DeletePlayerMapResponseMessage = require('../../Protocol/Messages/Server/DeletePlayerMapResponseMessage')
const TeamEntry = require('../../Logic/Team/TeamEntry')
const TeamInviteEntry = require('../../Logic/Team/TeamInviteEntry')
const ChatStreamEntry = require('../../Logic/Team/Stream/ChatStreamEntry')
const QuickChatStreamEntry = require('../../Logic/Team/Stream/QuickChatStreamEntry')
const GlobalId = require('../../Logic/Data/Helper/GlobalId')
const Friend = require('../../Logic/Friends/Friend')
const PlayerDisplayData = require('../../Logic/Avatar/Structures/PlayerDisplayData')
const Alliance = require('../../Logic/Club/Alliance')
const AllianceMember = require('../../Logic/Club/AllianceMember')
const AllianceStreamEntry = require('../../Logic/Stream/Entry/AllianceStreamEntry')
const DataTables = require('../../Logic/Data/DataTables')
const DataType = require('../../Logic/Data/DataType')
const PlayerProfileMessage = require('../../Protocol/Messages/Server/PlayerProfileMessage')
const SeasonRewardsMessage = require('../../Protocol/Messages/Server/SeasonRewardsMessage')
const LeaderboardMessage = require('../../Protocol/Messages/Server/LeaderboardMessage')
const ReportUserStatusMessage = require('../../Protocol/Messages/Server/ReportUserStatusMessage')
const LatencyTestStatusMessage = require('../../Protocol/Messages/Server/LatencyTestStatusMessage')
const LogicInviteBlockingChangedCommand = require('../../Logic/Command/Home/LogicInviteBlockingChangedCommand')
const Profile = require('../../Logic/Home/Structures/Profile')
const LogicLongCodeGenerator = require('../../Logic/Util/LogicLongCodeGenerator')
const Notification = require('../../Logic/Home/Items/Notification')
const Accounts = require('../Database/Accounts')
const Alliances = require('../Database/Alliances')
const Sessions = require('../Networking/Session/Sessions')
const HomeGameListener = require('../Logic/HomeGameListener')
const Events = require('../Logic/Game/Events')
const Leaderboards = require('../Logic/Game/Leaderboards')
const Teams = require('../Logic/Game/Teams')
const Battles = require('../Logic/Game/Battles')
const Matchmaking = require('../Logic/Game/Matchmaking')
const UDPGateway = require('../Networking/UDP/UDPGateway')
const UDPGameListener = require('../Networking/UDP/Game/UDPGameListener')
const Configuration = require('../Settings/Configuration')
const BattleEndMessage = require('../../Protocol/Messages/Server/BattleEndMessage')
const StartLoadingMessage = require('../../Protocol/Messages/Server/StartLoadingMessage')
const UdpConnectionInfoMessage = require('../../Protocol/Messages/Server/UdpConnectionInfoMessage')
const MatchMakingCancelledMessage = require('../../Protocol/Messages/Server/MatchMakingCancelledMessage')
const CommandManager = require('../Command/CommandManager')
const AllianceChatCommandHandler = require('./AllianceChatCommandHandler')
const Logger = require('../Logger')
const Fingerprint = require('../Settings/Fingerprint')
const AccountCache = require('../Database/Cache/AccountCache')
const AllianceCache = require('../Database/Cache/AllianceCache')
const Helpers = require('../Utils/Helpers')
const LogicAddNotificationCommand = require('../../Logic/Command/Home/LogicAddNotificationCommand')
const SyncSSIDResponce = require('../../Protocol/Messages/Server/SyncSSIDResponce')

const KEEP_ALIVE_TIMEOUT_SECONDS = 30
const API_STAR_POINTS_TROPHIES_START = [550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1050, 1100, 1150, 1200, 1250, 1300, 1350, 1400]
const API_STAR_POINTS_TROPHIES_END = [599, 649, 699, 749, 799, 849, 899, 949, 999, 1049, 1099, 1149, 1199, 1249, 1299, 1349, 1399, 1000000]
const API_STAR_POINTS_SEASON_REWARD_AMOUNT = [70, 120, 160, 200, 220, 240, 260, 280, 300, 320, 340, 360, 380, 400, 420, 440, 460, 480]
const API_STAR_POINTS_TROPHIES_IN_RESET = [549, 599, 649, 699, 749, 799, 849, 899, 924, 949, 974, 1024, 1049, 1074, 1099, 1124, 1149, 1174]
const MAX_NAME_LENGTH = 15

class MessageManager {
  constructor (connection) {
    this.connection = connection
    this.homeMode = null
    this.commandManager = null
    this.lastKeepAlive = Date.now()
    this.spectatedBattle = null
  }

  isAlive () {
    return Math.trunc((Date.now() - this.lastKeepAlive) / 1000) < KEEP_ALIVE_TIMEOUT_SECONDS
  }

  getPingIconByMs (ms) {
    let str = '▂   '
    if (ms <= 75) {
      str = '▂▄▆█'
    } else if (ms <= 125) {
      str = '▂▄▆ '
    } else if (ms <= 300) {
      str = '▂▄  '
    }
    return str
  }

  showLobbyInfo () {
    let abd = `Connection: ${this.getPingIconByMs(0)} (---ms)\n`
    if (this.connection.ping !== 0) {
      abd = `Connection: ${this.getPingIconByMs(this.connection.ping)} (${this.connection.ping}ms)\n`
    }

    const b = new LobbyInfoMessage()
    b.lobbyData = `LakeyStars prod\n${abd}Players Online: ${Sessions.count}\n` + '\n'.repeat(44) + "zachem ti eto chitaeh'"
    b.playersCount = 0
    this.connection.send(b)
  }

  receiveMessage (message) {
    switch (message.getMessageType()) {
      case 10100:
        this.clientHelloReceived(message)
        break
      case 10101:
        this.loginReceived(message)
        break
      case 10108:
        this.lastKeepAlive = Date.now()
        this.connection.send(new KeepAliveServerMessage())
        if (this.homeMode != null) {
          this.showLobbyInfo()
          if (!Sessions.isSessionActive(this.homeMode.avatar.accountId)) {
            Sessions.create(this.homeMode, this.connection)
          }
        }
        break
      case 10107:
        this.clientCapabilitesReceived(message)
        break
      case 10110:
        this.showLobbyInfo()
        break
      case 10119:
        this.reportAllianceStreamReceived(message)
        break
      case 10212:
        this.changeName(message)
        break
      case 10501:
        this.acceptFriendReceived(message)
        break
      case 10502:
        this.addFriendReceived(message)
        break
      case 10504:
        this.askForFriendListReceived(message)
        break
      case 10506:
        this.removeFriendReceived(message)
        break
      case 10576:
        this.setBlockFriendRequestsReceived(message)
        break
      case 10177:
        this.clientInfoReceived(message)
        break
      case 10555:
        break
      case 12100:
        this.createPlayerMapReceived(message)
        break
      case 12101:
        this.deletePlayerMapReceived(message)
        break
      case 12102:
        this.getPlayerMapsReceived(message)
        break
      case 12103:
        this.updatePlayerMapReceived(message)
        break
      case 12108:
        this.goHomeFromMapEditorReceived(message)
        break
      case 12110:
        this.teamSetPlayerMapReceived(message)
        break
      case 14101:
        this.goHomeReceived(message)
        break
      case 14103:
        this.matchmakeRequestReceived(message)
        break
      case 14104:
        this.startSpectateReceived(message)
        break
      case 14106:
        this.cancelMatchMaking(message)
        break
      case 14107:
        this.stopSpectateReceived(message)
        break
      case 14109:
        this.goHomeFromOfflinePractiseReceived(message)
        break
      case 14110:
        this.askForBattleEndReceived(message)
        break
      case 14102:
        this.endClientTurnReceived(message)
        break
      case 14113:
        this.getPlayerProfile(message)
        break
      case 14166:
        break
      case 14277:
        this.getSeasonRewardsReceived(message)
        break
      case 14301:
        this.createAllianceReceived(message)
        break
      case 14302:
        this.askForAllianceDataReceived(message)
        break
      case 14303:
        this.askForJoinableAllianceListReceived(message)
        break
      case 14305:
        this.joinAllianceReceived(message)
        break
      case 14306:
        this.changeAllianceMemberRoleReceived(message)
        break
      case 14307:
        this.kickAllianceMemberReceived(message)
        break
      case 14308:
        this.leaveAllianceReceived(message)
        break
      case 14315:
        this.chatToAllianceStreamReceived(message)
        break
      case 14316:
        this.changeAllianceSettingsReceived(message)
        break
      case 14350:
        this.teamCreateReceived(message)
        break
      case 14353:
        this.teamLeaveReceived(message)
        break
      case 14354:
        this.teamChangeMemberSettingsReceived(message)
        break
      case 14355:
        this.teamSetMemberReadyReceived(message)
        break
      case 14357:
        this.teamToggleMemberSideReceived(message)
        break
      case 14358:
        this.teamSpectateMessageReceived(message)
        break
      case 14359:
        this.teamChatReceived(message)
        break
      case 14361:
        this.teamMemberStatusReceived(message)
        break
      case 14362:
        this.teamSetEventReceived(message)
        break
      case 14363:
        this.teamSetLocationReceived(message)
        break
      case 14365:
        this.teamInviteReceived(message)
        break
      case 14366:
        this.playerStatusReceived(message)
        this.showLobbyInfo()
        break
      case 14367:
        this.teamClearInviteReceived(message)
        break
      case 14369:
        this.teamPremadeChatReceived(message)
        break
      case 14370:
        this.teamInviteReceived(message)
        break
      case 14373:
        this.teamBotSlotDisableReceived(message)
        break
      case 14403:
        this.getLeaderboardReceived(message)
        break
      case 14479:
        this.teamInvitationResponseReceived(message)
        break
      case 14600:
        this.avatarNameCheckRequestReceived(message)
        break
      case 14777:
        this.setInvitesBlockedReceived(message)
        break
      case 14881:
        this.teamRequestJoinReceived(message)
        break
      case 19001:
        this.latencyTestResultReceived(message)
        break
      case 11000:
        this.requestSyncSSIDReceived(message)
        break
      case 19996:
        this.requestMaintenanceReceived(message)
        break
      case 19997:
        this.requestSaveAllReceived(message)
        break
      case 19998:
        this.requestDBChangesReceived(message)
        break
      case 19999:
        this.requestServerReceived(message)
        break
      default:
        Logger.print(`MessageManager::ReceiveMessage - no case for ${message.constructor.name} (${message.getMessageType()})`)
        break
    }
  }

  isApiAuthorized (authPass) {
    const pass = Configuration.instance != null ? Configuration.instance.apiAuthPass : ''
    return typeof pass === 'string' && pass.length > 0 && authPass === pass
  }

  apiReply (text) {
    this.connection.write(Buffer.from(text, 'utf8'))
  }

  static formatApiDate (time) {
    const d = new Date(time)
    const p = value => String(value).padStart(2, '0')
    return `${p(d.getUTCMonth() + 1)}/${p(d.getUTCDate())}/${d.getUTCFullYear()} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())}`
  }

  static addApiDays (time, days) {
    return time + days * 24 * 60 * 60 * 1000
  }

  static addApiMonths (time, months) {
    const d = new Date(time)
    d.setUTCMonth(d.getUTCMonth() + months)
    return d.getTime()
  }

  requestSyncSSIDReceived (message) {
    if (!this.isApiAuthorized(message.authPass)) {
      return
    }
    for (const [key, value] of message.requests) {
      Sessions.registratedSSID.set(key, value)
    }
    for (const k of message.disposeRequests) {
      Sessions.registratedSSID.delete(k)
    }
    const response = new SyncSSIDResponce()
    response.requests = Sessions.requestedSSID
    response.recAccs = Sessions.leaveJoin
    this.connection.send(response)
    Sessions.requestedSSID = new Map()
    Sessions.leaveJoin = new Map()
  }

  requestMaintenanceReceived (message) {
    if (!this.isApiAuthorized(message.authPass)) {
      this.apiReply('dsadas')
      return
    }
    Sessions.startShutdown()
    AccountCache.saveAll()
    AllianceCache.saveAll()

    AccountCache.started = false
    AllianceCache.started = false

    this.apiReply('Done!')
  }

  requestSaveAllReceived (message) {
    if (!this.isApiAuthorized(message.authPass)) {
      this.apiReply('dsadas')
      return
    }
    AccountCache.saveAll()
    AllianceCache.saveAll()

    this.apiReply('Done!')
  }

  parseApiTarget (value) {
    if (value == null) return null
    if (value.startsWith('#')) {
      const id = LogicLongCodeGenerator.toId(value).toNumber()
      if (!(id > 0)) return null
      return { id, display: value }
    }
    if (!/^\d+$/.test(value)) return null
    const id = Number(value)
    if (!(id > 0) || !Number.isSafeInteger(id)) return null
    return { id, display: LogicLongCodeGenerator.toCode(id) }
  }

  parseApiInt (value) {
    if (value == null || !/^-?\d+$/.test(value)) return null
    const result = parseInt(value, 10)
    if (result > 2147483647 || result < -2147483648) return null
    return result
  }

  sendApiNotification (account, notification) {
    account.home.notificationFactory.add(notification)
    if (LogicServerListener.instance.isPlayerOnline(account.avatar.accountId)) {
      const command = new LogicAddNotificationCommand()
      command.notification = notification
      const message = new AvailableServerCommandMessage()
      message.command = command
      LogicServerListener.instance.getGameListener(account.avatar.accountId).sendTCPMessage(message)
    }
  }

  kickForApiChange (id) {
    if (Sessions.isSessionActive(id)) {
      const session = Sessions.getSession(id)
      const message = new AuthenticationFailedMessage()
      message.message = 'Some data changed, please re-enter game!'
      session.connection.send(message)
      Sessions.remove(id)
    }
  }

  resolveApiField (target, name) {
    if (target == null || name == null || name.length === 0) return null
    for (const field of [name, name[0].toLowerCase() + name.substring(1)]) {
      if (!Object.prototype.hasOwnProperty.call(target, field)) continue
      const value = target[field]
      if (value !== null && typeof value === 'object') continue
      if (typeof value === 'function') continue
      return field
    }
    return null
  }

  requestDBChangesReceived (message) {
    if (!this.isApiAuthorized(message.authPass)) {
      this.apiReply('dsadas')
      return
    }

    if (message.message == null || message.message.length < 2) {
      this.apiReply('Error: Invalid usage')
      return
    }

    const cmd = message.message.substring(1).split(' ')
    const usage = {
      giveprem: 2,
      chat_unmute: 3,
      chat_mute: 3,
      addgems: 3,
      settrophy: 4,
      addgold: 3,
      addspints: 3,
      addbrawler: 3,
      addskin: 3,
      addstartokens: 3,
      getusrinfo: 2
    }

    if (cmd[0] === 'resetseason') {
      this.apiResetSeason()
      this.apiReply('Done!')
      return
    }

    if (usage[cmd[0]] != null) {
      if (cmd.length !== usage[cmd[0]]) {
        this.apiReply('Error: Invalid usage')
        return
      }
    } else if (cmd[0] === 'resettoken') {
      if (cmd.length < 2) {
        this.apiReply('Error: Invalid usage')
        return
      }
    } else if (cmd[0] === 'chname') {
      if (cmd.length < 3) {
        this.apiReply('Error: Invalid usage')
        return
      }
    } else if (cmd.length !== 4) {
      this.apiReply('Error: Invalid usage')
      return
    }

    const target = this.parseApiTarget(cmd[1])
    const account = target != null ? Accounts.load(target.id) : null
    if (account == null) {
      this.apiReply(`Error: Invalid tag: ${target != null ? target.id : cmd[1]}`)
      return
    }
    const id = target.id
    const d = target.display

    switch (cmd[0]) {
      case 'giveprem': {
        const now = Date.now()
        if (account.home.premiumEndTime < now) {
          account.home.premiumEndTime = MessageManager.addApiMonths(now, 1)
        } else {
          account.home.premiumEndTime = MessageManager.addApiMonths(account.home.premiumEndTime, 1)
        }

        account.avatar.premiumLevel = 1
        const until = MessageManager.formatApiDate(account.home.premiumEndTime)
        this.sendApiNotification(account, new Notification({
          id: 89,
          donationCount: 30,
          messageEntry: `<c6>Vip статус активирован/продлён до ${until} UTC, спасибо за поддержку сервера!</c>`
        }))
        Accounts.save(account)
        this.apiReply(`Done: set vip status for ${d} activated/extended to ${until} UTC!`)
        return
      }
      case 'chat_unmute': {
        account.home.chatBanEndTime = 0
        this.sendApiNotification(account, new Notification({
          id: 81,
          messageEntry: '<c25c42b>Блокировка чата твоего аккаунта была снята досрочно</c>'
        }))
        Accounts.save(account)
        this.apiReply(`Done: unmuted ${d}`)
        return
      }
      case 'chat_mute': {
        const days = this.parseApiInt(cmd[2])
        if (days == null) {
          this.apiReply('Error: Invalid usage')
          return
        }
        account.home.chatBanEndTime = MessageManager.addApiDays(Date.now(), days)
        this.sendApiNotification(account, new Notification({
          id: 81,
          messageEntry: `Твоему аккаунт был временно отключён чат за нарушение правил.\n<ceb4034>Блокировка продлиться до ${MessageManager.formatApiDate(account.home.chatBanEndTime)} UTC</c>\nПоследующие нарушения могут привести к блокировке чата навсегда`
        }))
        Accounts.save(account)
        this.apiReply(`Done: muted ${d} for ${days}d`)
        return
      }
      case 'addgems':
      case 'addgold':
      case 'addspints':
      case 'addstartokens': {
        const amount = this.parseApiInt(cmd[2])
        if (amount == null) {
          this.apiReply('Error: Invalid usage')
          return
        }
        this.sendApiNotification(account, new Notification({
          id: cmd[0] === 'addgems' ? 89 : 90,
          donationCount: amount,
          messageEntry: '<c6>Thanks for donation!</c>'
        }))
        Accounts.save(account)
        const names = { addgems: 'gems', addgold: 'gold', addspints: 'starpoints', addstartokens: 'startokens' }
        this.apiReply(`Done: added ${amount} ${names[cmd[0]]} for ${d}!`)
        return
      }
      case 'settrophy': {
        const characterId = this.parseApiInt(cmd[2])
        const trophies = this.parseApiInt(cmd[3])
        const h = characterId != null ? account.avatar.getHero(characterId) : null
        if (h == null || trophies == null || trophies < 0) {
          this.apiReply('Error: Invalid usage')
          return
        }
        h.trophies = trophies
        if (h.trophies > h.highestTrophies) {
          h.highestTrophies = h.trophies
        }
        if (account.avatar.trophies > account.avatar.highestTrophies) {
          account.avatar.highestTrophies = account.avatar.trophies
        }
        Accounts.save(account)
        this.kickForApiChange(id)
        this.apiReply(`Done: set ${trophies} trophies for brawler ${characterId} for ${d}!`)
        return
      }
      case 'addbrawler':
      case 'addskin': {
        const value = this.parseApiInt(cmd[2])
        if (value == null) {
          this.apiReply('Error: Invalid usage')
          return
        }
        this.sendApiNotification(account, new Notification({
          id: cmd[0] === 'addbrawler' ? 93 : 94,
          donationCount: 0,
          messageEntry: '<c6>Thanks for donation!</c>'
        }))
        Accounts.save(account)
        this.apiReply(`Done: added ${cmd[0] === 'addbrawler' ? 'brawler' : 'skin'} ${value} for ${d}!`)
        return
      }
      case 'getusrinfo': {
        this.apiReply(`Done: Information of ${d}!\nName: ${account.avatar.name}\nTrophies: ${account.avatar.trophies}\nHighest Trophies: ${account.avatar.highestTrophies}\nLast Online: ${MessageManager.formatApiDate(account.avatar.lastOnline || 0)} UTC\nOnline: ${Sessions.isSessionActive(id)}`)
        return
      }
      case 'resettoken': {
        account.passToken = Helpers.randomString(40)
        account.avatar.passToken = account.passToken
        Accounts.save(account)
        this.kickForApiChange(id)
        this.apiReply(`Done: reseted pass token for ${d}!`)
        return
      }
      case 'chname': {
        const parts = message.message.substring(1).split('##!')
        const name = parts[1]
        if (name == null || name.trim().length === 0 || name.length > 15) {
          this.apiReply('Error: Invalid usage')
          return
        }
        account.avatar.name = name
        if (account.avatar.allianceId >= 0) {
          const a = Alliances.load(account.avatar.allianceId)
          if (a != null) {
            const m = a.getMemberById(account.avatar.accountId)
            if (m != null && m.displayData != null) m.displayData.name = name
          }
        }
        for (const friend of account.avatar.friends) {
          const friendAccount = Accounts.load(friend.accountId)
          if (friendAccount == null) continue
          const entry = friendAccount.avatar.getFriendById(account.avatar.accountId)
          if (entry == null) continue
          if (entry.displayData != null) entry.displayData.name = account.avatar.name
          if (LogicServerListener.instance.isPlayerOnline(friend.accountId)) {
            const update = new FriendListUpdateMessage()
            update.entry = entry
            const listener = LogicServerListener.instance.getGameListener(friend.accountId)
            if (listener != null) listener.sendTCPMessage(update)
          }
        }
        Accounts.save(account)
        this.kickForApiChange(id)
        this.apiReply(`Done: changed name for ${d} to ${name}!`)
        return
      }
    }

    const req = cmd[2].split('.')
    const isAvatar = req[0] === 'Avatar'
    const targetObject = isAvatar ? account.avatar : account.home
    const field = req.length === 2 ? this.resolveApiField(targetObject, req[1]) : null
    if (field == null) {
      this.apiReply(`Error: Invalid tag: ${cmd[2]} - is unknwon field`)
      return
    }
    const current = targetObject[field]
    let value = cmd[3]
    if (cmd[3] === 'true' || cmd[3] === 'false') {
      if (typeof current !== 'boolean' && current != null) {
        this.apiReply(`Error: Invalid tag: ${cmd[2]} - is not a boolean`)
        return
      }
      value = cmd[3] === 'true'
    } else if (typeof current === 'number') {
      if (!/^-?\d+$/.test(cmd[3])) {
        this.apiReply(`Error: Invalid tag: ${cmd[2]} - is a number`)
        return
      }
      value = parseInt(cmd[3], 10)
    } else if (typeof current === 'boolean') {
      this.apiReply(`Error: Invalid tag: ${cmd[2]} - is a boolean`)
      return
    }
    targetObject[field] = value

    Accounts.save(account)
    this.kickForApiChange(id)
    this.apiReply(`Done: set ${cmd[2]} to ${cmd[3]} for ${d}`)
  }

  apiResetSeason () {
    const lastAccId = Accounts.getMaxAvatarId()
    for (let accid = 1; accid <= lastAccId; accid++) {
      const thisAcc = Accounts.loadNoChache(accid)
      if (thisAcc == null) continue
      if (thisAcc.avatar.trophies >= 550) {
        const hhh = []
        const ht = []
        const htr = []
        const sa = []
        for (const h of thisAcc.avatar.heroes) {
          if (h.trophies < API_STAR_POINTS_TROPHIES_START[0]) continue
          hhh.push(h.characterId)
          ht.push(h.trophies)
          for (let i = 0; i < API_STAR_POINTS_TROPHIES_START.length; i++) {
            if (h.trophies < API_STAR_POINTS_TROPHIES_START[i] || h.trophies > API_STAR_POINTS_TROPHIES_END[i]) continue
            if (API_STAR_POINTS_TROPHIES_START[i] !== 1400) {
              htr.push(h.trophies - API_STAR_POINTS_TROPHIES_IN_RESET[i])
              h.trophies = API_STAR_POINTS_TROPHIES_IN_RESET[i]
              sa.push(API_STAR_POINTS_SEASON_REWARD_AMOUNT[i])
            } else {
              const b = Math.max(0, Math.trunc((h.trophies - 1440) / 2))
              htr.push(h.trophies - API_STAR_POINTS_TROPHIES_IN_RESET[i] - b)
              h.trophies = API_STAR_POINTS_TROPHIES_IN_RESET[i] + b
              sa.push(API_STAR_POINTS_SEASON_REWARD_AMOUNT[i] + Math.trunc(b / 2))
            }
            break
          }
        }
        if (hhh.length > 0) {
          thisAcc.home.notificationFactory.add(new Notification({
            id: 79,
            heroesIds: hhh,
            heroesTrophies: ht,
            heroesTrophiesReseted: htr,
            starpointsAwarded: sa
          }))
        }
      }
      Accounts.save(thisAcc)
    }
  }

  requestServerReceived (message) {
    const megabytesUsed = Math.trunc(process.memoryUsage().rss / (1024 * 1024))
    const seconds = process.uptime()
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = Math.floor(seconds % 60)
    const formattedTime = (days > 0 ? `${days} Days, ` : '') +
      (hours > 0 || days > 0 ? `${hours} Hours, ` : '') +
      (minutes > 0 || hours > 0 ? `${minutes} Minutes, ` : '') +
      (secs > 0 ? `${secs} Seconds` : '')

    const msg = 'Server Status:\n' +
      `Server Game Version: v${Fingerprint.version}\n` +
      'Server Build: v1.0 from 10.02.2024\n' +
      `Resources Sha: ${Fingerprint.sha}\n` +
      'Environment: Prod\n' +
      `Server Time: ${MessageManager.formatApiDate(Date.now())} UTC\n` +
      `Players Online: ${Sessions.count}\n` +
      `Memory Used: ${megabytesUsed} MB\n` +
      `Uptime: ${formattedTime}\n` +
      `Accounts Cached: ${AccountCache.count}\n` +
      `Alliances Cached: ${AllianceCache.count}\n` +
      `Teams Cached: ${Teams.count}\n`
    this.apiReply(msg)
  }

  isValidName (name) {
    if (typeof name !== 'string') return false
    const trimmed = name.trim()
    return trimmed.length > 0 && name.length <= MAX_NAME_LENGTH
  }

  applyNameChange (name) {
    const command = new LogicChangeAvatarNameCommand()
    command.name = name
    command.changeNameCost = 0

    if (this.homeMode.avatar.allianceId >= 0) {
      const a = Alliances.load(this.homeMode.avatar.allianceId)
      if (a != null) {
        const m = a.getMemberById(this.homeMode.avatar.accountId)
        if (m != null && m.displayData != null) m.displayData.name = name
      }
    }

    command.execute(this.homeMode)

    const serverCommandMessage = new AvailableServerCommandMessage()
    serverCommandMessage.command = command
    this.connection.send(serverCommandMessage)
  }

  avatarNameCheckRequestReceived (message) {
    if (this.homeMode == null) throw new Error('AvatarNameCheckRequest received before login')
    if (!this.isValidName(message.name)) return
    this.applyNameChange(message.name)
  }

  changeName (message) {
    if (this.homeMode == null) throw new Error('ChangeAvatarName received before login')
    if (!this.isValidName(message.name)) return
    this.applyNameChange(message.name)
  }

  goHomeReceived (message) {
    if (this.connection.home != null && this.connection.avatar != null) {
      this.connection.home.events = Events.getEventsById(this.homeMode.home.powerPlayGamesPlayed, this.connection.avatar.accountId)
      const ohd = new OwnHomeDataMessage()
      ohd.home = this.connection.home
      ohd.avatar = this.connection.avatar
      this.connection.send(ohd)
      this.showLobbyInfo()
    }
  }

  goHomeFromOfflinePractiseReceived (message) {
    if (this.connection.home != null && this.connection.avatar != null) {
      if (this.connection.avatar.isTutorialState()) {
        this.connection.avatar.skipTutorial()
      }

      this.connection.home.events = Events.getEventsById(this.homeMode.home.powerPlayGamesPlayed, this.connection.avatar.accountId)

      const ohd = new OwnHomeDataMessage()
      ohd.home = this.connection.home
      ohd.avatar = this.connection.avatar
      this.showLobbyInfo()
      this.connection.send(ohd)
    }
  }

  getPlayerMapsReceived (message) {
    if (this.homeMode == null) return
    const response = new PlayerMapsMessage()
    response.maps = this.homeMode.home.playerMaps.slice()
    this.connection.send(response)
  }
  createPlayerMapReceived (message) {
    if (this.homeMode == null) return
    const home = this.homeMode.home
    const avatar = this.homeMode.avatar

    let mapId = crypto.randomInt(0, 2147483647)
    while (home.playerMaps.some(map => map.mapId === mapId)) mapId = crypto.randomInt(0, 2147483647)

    const map = new PlayerMap()
    map.mapEnvironmentData = message.pmed
    map.mapName = message.name
    map.gmv = message.gmv
    map.mapId = mapId
    map.accountId = avatar.accountId
    map.avatarName = avatar.name
    home.playerMaps.push(map)

    const response = new CreatePlayerMapResponseMessage()
    response.map = map
    this.connection.send(response)
  }
  updatePlayerMapReceived (message) {
    if (this.homeMode == null) return
    const map = this.homeMode.home.playerMaps.find(map => map.mapId === message.mapId)
    const response = new UpdatePlayerMapResponseMessage()
    if (map == null) {
      response.errorCode = 1
      this.connection.send(response)
      return
    }
    map.mapData = message.mapData
    response.mapId = message.mapId
    this.connection.send(response)
  }
  deletePlayerMapReceived (message) {
    if (this.homeMode == null) return
    const home = this.homeMode.home
    const map = home.playerMaps.find(map => map.mapId === message.mapId)
    const response = new DeletePlayerMapResponseMessage()
    if (map == null) {
      response.errorCode = 1
      this.connection.send(response)
      return
    }
    home.playerMaps.splice(home.playerMaps.indexOf(map), 1)
    response.mapId = message.mapId
    this.connection.send(response)
  }
  teamSetPlayerMapReceived (message) {
    if (this.homeMode == null) return
    if (!(this.homeMode.avatar.teamId > 0)) return
    const team = this.getTeam()
    if (team == null) return

    const map = this.homeMode.home.playerMaps.find(map => map.mapId === message.mapid)
    if (map == null) return

    team.battlePlayerMap = new BattlePlayerMap(map)
    team.type = 1
    team.teamUpdated()
  }
  goHomeFromMapEditorReceived (message) {
    if (this.connection.home != null && this.connection.avatar != null) {
      const ohd = new OwnHomeDataMessage()
      ohd.home = this.connection.home
      ohd.avatar = this.connection.avatar
      this.connection.send(ohd)
    }
  }
  playerStatusReceived (message) {
    if (this.homeMode == null) return
    if (!(message.status >= 0)) return

    const avatar = this.homeMode.avatar
    const home = this.homeMode.home
    const oldstatus = avatar.playerStatus
    const newstatus = message.status

    avatar.playerStatus = newstatus
    if (oldstatus === 3 && newstatus === 8) {
      avatar.battleStartTime = Date.now()
    }
    if (oldstatus === 8 && newstatus === 3) {
      const h = avatar.getHero(home.characterId)
      const lose = h != null ? MessageManager.getLeaveTrophies(h.trophies) : 0
      if (h != null) h.addTrophies(lose)
      home.powerPlayGamesPlayed = Math.max(0, home.powerPlayGamesPlayed - 1)
      home.trophiesReward = 0
      Logger.print(`Player ${LogicLongCodeGenerator.toCode(avatar.accountId)} left battle!`)
      avatar.battleStartTime = 0
      if (home.notificationFactory.notificationList.length < 5) {
        const notification = new Notification()
        notification.id = 81
        notification.messageEntry = `Because of leaving match, you recieved leave penalty: ${lose} trophies!`
        home.notificationFactory.add(notification)
      }
    }

    const entryMessage = new FriendOnlineStatusEntryMessage()
    entryMessage.avatarId = avatar.accountId
    entryMessage.playerStatus = avatar.playerStatus

    for (const friend of avatar.friends.slice()) {
      if (LogicServerListener.instance.isPlayerOnline(friend.accountId)) {
        const listener = LogicServerListener.instance.getGameListener(friend.accountId)
        if (listener != null) listener.sendTCPMessage(entryMessage)
      }
    }

    if (avatar.allianceRole !== AllianceRole.None && avatar.allianceId > 0) {
      const alliance = Alliances.load(avatar.allianceId)
      if (alliance != null) {
        const allianceOnlineStatusUpdatedMessage = new AllianceOnlineStatusUpdatedMessage()
        allianceOnlineStatusUpdatedMessage.avatarId = avatar.accountId
        allianceOnlineStatusUpdatedMessage.members = alliance.members.length
        allianceOnlineStatusUpdatedMessage.playerStatus = avatar.playerStatus
        for (const member of alliance.members.slice()) {
          this.sendToPlayer(member.accountId, allianceOnlineStatusUpdatedMessage)
        }
      }
    }
  }

  endClientTurnReceived (message) {
    if (this.homeMode == null || this.commandManager == null) return

    for (const command of message.commands) {
      if (!this.commandManager.receiveCommand(command)) {
        Logger.print(`EndClientTurn - command ${command.getCommandType()} rejected for ${LogicLongCodeGenerator.toCode(this.homeMode.avatar.accountId)}`)
        this.connection.send(new OutOfSyncMessage())
      }
    }

    this.homeMode.clientTurnReceived(message.tick, message.checksum, message.commands)

    if (message.commands.length > 0) Accounts.save(Accounts.load(this.homeMode.avatar.accountId))
  }

  onChangeCharacter (characterId) {
    if (!(this.homeMode.avatar.teamId > 0)) return
    const team = Teams.get(this.homeMode.avatar.teamId)
    if (team == null) return
    const member = team.getMember(this.homeMode.avatar.accountId)
    if (member == null) return
    if (characterId === 0) {
      team.teamUpdated()
      return
    }
    const hero = this.homeMode.avatar.getHero(characterId)
    if (hero == null) return
    member.characterId = characterId
    member.heroTrophies = hero.trophies
    member.heroHighestTrophies = hero.highestTrophies
    member.heroLevel = hero.powerLevel
    team.teamUpdated()
  }

  clientCapabilitesReceived (message) {
    this.connection.pingUpdated(message.ping)
    this.showLobbyInfo()
  }

  setBlockFriendRequestsReceived (message) {
    if (this.homeMode == null) return
    this.homeMode.home.blockFriendRequests = message.state
  }

  reportAllianceStreamReceived (message) {
    if (this.homeMode == null) return
    const avatar = this.homeMode.avatar
    const home = this.homeMode.home
    if (avatar.allianceId < 0) return
    const myAlliance = Alliances.load(avatar.allianceId)
    if (myAlliance == null) return

    if (home.reportsIds.length > 5) {
      const status = new ReportUserStatusMessage()
      status.status = 2
      this.connection.send(status)
      return
    }

    const entries = myAlliance.stream.getEntries()
    const index = entries.findIndex(e => e.id === message.messageIndex)
    if (index === -1) return
    const e = entries[index]

    if (home.reportsIds.includes(e.authorId)) {
      const status = new ReportUserStatusMessage()
      status.status = 3
      this.connection.send(status)
      return
    }

    const reporterTag = LogicLongCodeGenerator.toCode(avatar.accountId)
    const reporterName = avatar.name
    const susTag = LogicLongCodeGenerator.toCode(e.authorId)
    const susName = e.authorName
    home.reportsIds.push(e.authorId)

    let text = ''
    for (let i = Math.max(0, index - 5); i <= Math.min(entries.length - 1, index + 5); i++) {
      const entry = entries[i]
      text += new Date(entry.sendTime).toISOString() + ' ' + LogicLongCodeGenerator.toCode(entry.authorId) + ' ' + entry.authorName + '>>> ' + entry.message + '\n'
    }

    Logger.handleReport(`Player ${reporterName}, ${reporterTag} reported player ${susName}, ${susTag}, in this msgs:\n` + '`\n' + text + '`')

    const status = new ReportUserStatusMessage()
    status.status = 1
    this.connection.send(status)
  }

  getSeasonRewardsReceived (message) {
    this.connection.send(new SeasonRewardsMessage())
  }

  setInvitesBlockedReceived (message) {
    if (this.homeMode == null) return
    const avatar = this.homeMode.avatar
    avatar.doNotDisturb = message.state

    const command = new LogicInviteBlockingChangedCommand()
    command.state = message.state
    const serverCommandMessage = new AvailableServerCommandMessage()
    serverCommandMessage.command = command
    this.connection.send(serverCommandMessage)

    if (avatar.allianceId >= 0) {
      const a = Alliances.load(avatar.allianceId)
      if (a == null) return
      const m = a.getMemberById(avatar.accountId)
      if (m == null) return
      m.doNotDisturb = message.state

      const dataMessage = new AllianceDataMessage()
      dataMessage.alliance = a
      dataMessage.isMyAlliance = true
      a.sendToAlliance(dataMessage)
    }
  }

  latencyTestResultReceived (message) {
    const l = new LatencyTestStatusMessage()
    l.ping = this.connection.ping
    this.connection.send(l)
  }

  getLeaderboardReceived (message) {
    if (this.homeMode == null) return
    const ownAvatarId = this.homeMode.avatar.accountId
    const region = message.isRegional ? 'RU' : null

    if (message.leaderboardType === 1 || message.leaderboardType === 3) {
      const leaderboard = new LeaderboardMessage()
      leaderboard.leaderboardType = message.leaderboardType
      leaderboard.region = region
      for (const data of Leaderboards.getAvatarRankingList()) {
        leaderboard.avatars.push([data.home, data.avatar])
      }
      leaderboard.ownAvatarId = ownAvatarId
      this.connection.send(leaderboard)
    } else if (message.leaderboardType === 2) {
      const leaderboard = new LeaderboardMessage()
      leaderboard.leaderboardType = 2
      leaderboard.region = region
      leaderboard.allianceList.push(...Leaderboards.getAllianceRankingList())
      this.connection.send(leaderboard)
    } else if (message.leaderboardType === 0) {
      const accounts = (Leaderboards.getBrawlersRankingList().get(message.charachterId) || []).slice()
      const trophiesOf = account => {
        const hero = account.avatar.getHero(message.charachterId)
        return hero != null ? hero.trophies : 0
      }
      accounts.sort((a, b) => trophiesOf(b) - trophiesOf(a))

      const leaderboard = new LeaderboardMessage()
      leaderboard.leaderboardType = 0
      leaderboard.region = region
      leaderboard.charachterId = message.charachterId
      leaderboard.brawlers = accounts.slice(0, 200).map(account => [account.home, account.avatar])
      leaderboard.ownAvatarId = ownAvatarId
      this.connection.send(leaderboard)
    }
  }

  getPlayerProfile (message) {
    if (message.accountId === 0) {
      const a = new PlayerProfileMessage()
      a.profile = Profile.createConsole()
      this.connection.send(a)
      return
    }

    const data = Accounts.load(message.accountId)
    if (data == null) return

    const profileMessage = new PlayerProfileMessage()
    profileMessage.profile = Profile.create(data.home, data.avatar)
    if (data.avatar.allianceId >= 0) {
      const alliance = Alliances.load(data.avatar.allianceId)
      if (alliance != null) {
        profileMessage.allianceHeader = alliance.header
        profileMessage.allianceRole = data.avatar.allianceRole
      }
    }
    this.connection.send(profileMessage)
  }

  sendToPlayer (accountId, message) {
    if (!LogicServerListener.instance.isPlayerOnline(accountId)) return
    const listener = LogicServerListener.instance.getGameListener(accountId)
    if (listener != null) listener.sendTCPMessage(message)
  }

  sendFriendUpdate (accountId, entry) {
    const update = new FriendListUpdateMessage()
    update.entry = entry
    if (accountId === this.homeMode.avatar.accountId) {
      this.connection.send(update)
    } else {
      this.sendToPlayer(accountId, update)
    }
  }

  acceptFriendReceived (message) {
    if (this.homeMode == null) return
    const me = this.homeMode.avatar
    if (message.avatarId === me.accountId) return

    const data = Accounts.load(message.avatarId)
    if (data == null) return

    const entry = me.getRequestFriendById(message.avatarId)
    if (entry == null) return

    const oldFriend = me.getAcceptedFriendById(message.avatarId)
    if (oldFriend != null) {
      me.friends.splice(me.friends.indexOf(entry), 1)
      this.connection.send(new OutOfSyncMessage())
      return
    }

    if (entry.friendState !== 3) return

    const avatar = data.avatar
    const otherEntry = avatar.getFriendById(me.accountId)
    if (otherEntry == null) {
      me.friends.splice(me.friends.indexOf(entry), 1)
      entry.friendState = 0
      this.sendFriendUpdate(me.accountId, entry)
      return
    }

    entry.friendReason = 0
    entry.friendState = 4
    this.sendFriendUpdate(me.accountId, entry)

    otherEntry.friendState = 4
    otherEntry.friendReason = 0
    this.sendFriendUpdate(avatar.accountId, otherEntry)
  }

  removeFriendReceived (message) {
    if (this.homeMode == null) return
    const me = this.homeMode.avatar

    const myEntry = me.getFriendById(message.avatarId)
    if (myEntry == null) return

    myEntry.friendState = 0
    me.friends.splice(me.friends.indexOf(myEntry), 1)
    this.sendFriendUpdate(me.accountId, myEntry)

    const data = Accounts.load(message.avatarId)
    if (data == null) return

    const avatar = data.avatar
    const otherEntry = avatar.getFriendById(me.accountId)
    if (otherEntry == null) return

    otherEntry.friendState = 0
    avatar.friends.splice(avatar.friends.indexOf(otherEntry), 1)
    this.sendFriendUpdate(avatar.accountId, otherEntry)
  }

  addFriendReceived (message) {
    if (this.homeMode == null) return
    const me = this.homeMode.avatar
    const sendFailed = reason => {
      const failed = new AddFriendFailedMessage()
      failed.reason = reason
      this.connection.send(failed)
    }

    const data = Accounts.load(message.avatarId)
    if (data == null) return sendFailed(5)
    if (data.avatar.accountId === me.accountId) return sendFailed(4)

    const avatar = data.avatar

    const requestEntry = me.getFriendById(message.avatarId)
    if (requestEntry != null) {
      if (requestEntry.friendState === 3) {
        const accept = { avatarId: message.avatarId }
        this.acceptFriendReceived(accept)
        return
      }
      if (requestEntry.friendState === 2 || requestEntry.friendState === 4) return
      me.friends.splice(me.friends.indexOf(requestEntry), 1)
    }

    if (data.home.blockFriendRequests) return sendFailed(0)

    const staleEntry = avatar.getFriendById(me.accountId)
    if (staleEntry != null) {
      avatar.friends.splice(avatar.friends.indexOf(staleEntry), 1)
    }

    const home = this.homeMode.home
    const friendEntry = new Friend()
    friendEntry.accountId = me.accountId
    friendEntry.displayData = new PlayerDisplayData(home.hasPremiumPass, home.thumbnailId, home.nameColorId, me.name)
    friendEntry.friendReason = message.reason
    friendEntry.friendState = 3
    avatar.friends.push(friendEntry)

    const request = new Friend()
    request.accountId = avatar.accountId
    request.displayData = new PlayerDisplayData(data.home.hasPremiumPass, data.home.thumbnailId, data.home.nameColorId, avatar.name)
    request.friendReason = 0
    request.friendState = 2
    me.friends.push(request)

    this.sendFriendUpdate(avatar.accountId, friendEntry)
    if (LogicServerListener.instance.isPlayerOnline(avatar.accountId)) {
      const entryMessage = new FriendOnlineStatusEntryMessage()
      entryMessage.avatarId = me.accountId
      entryMessage.playerStatus = me.playerStatus
      this.sendToPlayer(avatar.accountId, entryMessage)
    }

    this.sendFriendUpdate(me.accountId, request)
    const entryMessage2 = new FriendOnlineStatusEntryMessage()
    entryMessage2.avatarId = avatar.accountId
    entryMessage2.playerStatus = LogicServerListener.instance.isPlayerOnline(avatar.accountId) ? avatar.playerStatus : 0
    this.connection.send(entryMessage2)
  }

  askForFriendListReceived (message) {
    if (this.homeMode == null) return
    const friendList = new FriendListMessage()
    friendList.friends = this.homeMode.avatar.friends.slice()
    this.connection.send(friendList)
  }

  sendAllianceResponse (responseType, accountId) {
    const response = new AllianceResponseMessage()
    response.responseType = responseType
    if (accountId == null) {
      this.connection.send(response)
    } else {
      this.sendToPlayer(accountId, response)
    }
  }

  sendMyAllianceTo (accountId, alliance, role) {
    const myAlliance = new MyAllianceMessage()
    if (alliance != null) {
      myAlliance.role = role
      myAlliance.onlineMembers = alliance.onlinePlayers
      myAlliance.allianceHeader = alliance.header
    }
    if (accountId == null) {
      this.connection.send(myAlliance)
    } else {
      this.sendToPlayer(accountId, myAlliance)
    }
  }

  addAllianceEvent (alliance, playerId, playerName, event) {
    const avatar = this.homeMode.avatar
    const entry = new AllianceStreamEntry()
    entry.authorId = avatar.accountId
    entry.authorName = avatar.name
    entry.id = ++alliance.stream.entryIdCounter
    entry.playerId = playerId
    entry.playerName = playerName
    entry.type = 4
    entry.event = event
    entry.authorRole = avatar.allianceRole
    alliance.addStreamEntry(entry)
  }

  isValidAllianceText (text, maxLength) {
    return text != null && !text.includes('</c') && text.length <= maxLength
  }

  getAllianceBadge (badgeId) {
    if (badgeId >= 8000000 && badgeId < 8000000 + DataTables.get(DataType.AllianceBadge).count) {
      return badgeId
    }
    return 8000000
  }

  changeAllianceSettingsReceived (message) {
    if (this.homeMode == null) return
    const avatar = this.homeMode.avatar
    if (avatar.allianceId < 0) return
    if (avatar.allianceRole !== AllianceRole.Leader && avatar.allianceRole !== AllianceRole.CoLeader) return

    const alliance = Alliances.load(avatar.allianceId)
    if (alliance == null) return

    const description = message.description != null ? message.description : ''
    if (!this.isValidAllianceText(description, 250)) return

    alliance.allianceBadgeId = this.getAllianceBadge(message.badgeId)
    alliance.type = message.type === 1 ? 1 : 3
    alliance.description = description
    alliance.requiredTrophies = Math.max(0, message.requiredTrophies)

    this.sendAllianceResponse(10)
    this.sendMyAllianceTo(null, alliance, avatar.allianceRole)
  }

  kickAllianceMemberReceived (message) {
    if (this.homeMode == null) return
    const me = this.homeMode.avatar
    if (me.allianceId < 0) return
    if (me.allianceRole === AllianceRole.Member || me.allianceRole === AllianceRole.None) return
    if (message.accountId === me.accountId) return

    const alliance = Alliances.load(me.allianceId)
    if (alliance == null) return

    const member = alliance.getMemberById(message.accountId)
    if (member == null) return

    const data = Accounts.load(message.accountId)
    const avatar = data != null ? data.avatar : null
    const targetRole = avatar != null ? avatar.allianceRole : member.role

    if (Alliance.getRoleRank(me.allianceRole) <= Alliance.getRoleRank(targetRole)) return

    alliance.members.splice(alliance.members.indexOf(member), 1)
    if (avatar != null) {
      avatar.allianceId = -1
      avatar.allianceRole = AllianceRole.None
    }

    const name = avatar != null ? avatar.name : (member.displayData != null ? member.displayData.name : null)
    this.addAllianceEvent(alliance, message.accountId, name, 1)

    this.sendAllianceResponse(70)

    this.sendAllianceResponse(100, message.accountId)
    this.sendMyAllianceTo(message.accountId, null)
  }

  joinAllianceReceived (message) {
    if (this.homeMode == null) return
    const avatar = this.homeMode.avatar
    const alliance = Alliances.load(message.allianceId)
    if (avatar.allianceId >= 0) return
    if (alliance == null) return
    if (alliance.members.length >= 100) return
    if (alliance.type !== 1) return
    if (alliance.requiredTrophies > avatar.trophies) return

    this.addAllianceEvent(alliance, avatar.accountId, avatar.name, 3)

    avatar.allianceRole = AllianceRole.Member
    avatar.allianceId = alliance.id
    alliance.members.push(new AllianceMember(avatar))

    this.sendAllianceResponse(40)
    this.sendMyAllianceData(alliance)
  }

  leaveAllianceReceived (message) {
    if (this.homeMode == null) return
    const avatar = this.homeMode.avatar
    if (avatar.allianceId < 0 || avatar.allianceRole === AllianceRole.None) return

    const alliance = Alliances.load(avatar.allianceId)
    if (alliance == null) return

    if (avatar.allianceRole === AllianceRole.Leader) {
      const nextLeader = alliance.getNextRoleMember()
      if (nextLeader != null) {
        nextLeader.role = AllianceRole.Leader
        const target = Accounts.load(nextLeader.accountId)
        if (target != null) {
          target.avatar.allianceRole = AllianceRole.Leader
          this.sendAllianceResponse(101, target.accountId)
          this.sendMyAllianceTo(target.accountId, alliance, AllianceRole.Leader)
        }
      }
    }

    alliance.removeMemberById(avatar.accountId)
    if (alliance.members.length < 1) {
      Alliances.delete(avatar.allianceId)
    } else {
      this.addAllianceEvent(alliance, avatar.accountId, avatar.name, 4)
    }

    avatar.allianceId = -1
    avatar.allianceRole = AllianceRole.None

    this.sendAllianceResponse(80)
    this.sendMyAllianceTo(null, null)
  }

  createAllianceReceived (message) {
    if (this.homeMode == null) return
    const avatar = this.homeMode.avatar
    if (avatar.allianceId >= 0) return

    const name = message.name != null ? message.name.trim() : ''
    const description = message.description != null ? message.description : ''
    if (name.length === 0 || !this.isValidAllianceText(name, 20) || !this.isValidAllianceText(description, 250)) {
      this.sendAllianceResponse(21)
      return
    }

    const alliance = new Alliance()
    alliance.name = name
    alliance.description = description
    alliance.requiredTrophies = Math.max(0, message.requiredTrophies)
    alliance.type = message.type === 1 ? 1 : 3
    alliance.allianceBadgeId = this.getAllianceBadge(message.badgeId)

    avatar.allianceRole = AllianceRole.Leader
    alliance.members.push(new AllianceMember(avatar))

    Alliances.create(alliance)

    avatar.allianceId = alliance.id

    this.sendAllianceResponse(20)
    this.sendMyAllianceData(alliance)
  }

  askForAllianceDataReceived (message) {
    if (this.homeMode == null) return
    const alliance = Alliances.load(message.allianceId)
    if (alliance == null) return

    const data = new AllianceDataMessage()
    data.alliance = alliance
    data.isMyAlliance = message.allianceId === this.homeMode.avatar.allianceId
    this.connection.send(data)
  }

  changeAllianceMemberRoleReceived (message) {
    if (this.homeMode == null) return
    const me = this.homeMode.avatar
    if (me.allianceId < 0) return
    if (me.allianceRole === AllianceRole.Member || me.allianceRole === AllianceRole.None) return
    if (message.accountId === me.accountId) return

    const alliance = Alliances.load(me.allianceId)
    if (alliance == null) return

    const member = alliance.getMemberById(message.accountId)
    if (member == null) return

    const data = Accounts.load(message.accountId)
    if (data == null) return
    const avatar = data.avatar

    const myRank = Alliance.getRoleRank(me.allianceRole)

    if (alliance.getRoleVector(member.role, message.role)) {
      const newRole = message.role
      if (newRole === AllianceRole.Leader) {
        if (me.allianceRole !== AllianceRole.Leader) return
      } else if (myRank <= Alliance.getRoleRank(newRole)) {
        return
      }

      if (newRole === AllianceRole.Leader) {
        me.allianceRole = AllianceRole.CoLeader
        this.addAllianceEvent(alliance, me.accountId, me.name, 6)

        const myMember = alliance.getMemberById(me.accountId)
        if (myMember != null) myMember.role = me.allianceRole
      }

      avatar.allianceRole = newRole
      member.role = newRole

      this.addAllianceEvent(alliance, avatar.accountId, avatar.name, 5)

      this.sendAllianceResponse(81)
      this.sendMyAllianceTo(null, alliance, me.allianceRole)

      this.sendAllianceResponse(101, avatar.accountId)
      this.sendMyAllianceTo(avatar.accountId, alliance, avatar.allianceRole)
    } else {
      const currentRole = member.role
      let newRole
      if (currentRole === AllianceRole.Elder) {
        newRole = AllianceRole.Member
      } else if (currentRole === AllianceRole.CoLeader) {
        newRole = AllianceRole.Elder
      } else {
        return
      }
      if (myRank <= Alliance.getRoleRank(currentRole)) return

      avatar.allianceRole = newRole
      member.role = newRole

      this.addAllianceEvent(alliance, avatar.accountId, avatar.name, 6)

      this.sendAllianceResponse(82)
      this.sendMyAllianceTo(null, alliance, me.allianceRole)

      this.sendAllianceResponse(102, avatar.accountId)
      this.sendMyAllianceTo(avatar.accountId, alliance, avatar.allianceRole)
    }
  }

  askForJoinableAllianceListReceived (message) {
    if (this.homeMode == null) return
    const list = new JoinableAllianceListMessage()
    for (const alliance of Alliances.getRandomAlliances(this.homeMode.avatar, 20)) {
      list.joinableAlliances.push(alliance.header)
    }
    this.connection.send(list)
  }

  sendConsoleEntry (alliance, text) {
    const entry = new AllianceStreamEntry()
    entry.authorName = 'Console'
    entry.authorId = 0
    entry.id = alliance.stream.entryIdCounter + 1
    entry.authorRole = AllianceRole.Member
    entry.message = text
    entry.type = 2

    const response = new AllianceStreamEntryMessage()
    response.entry = entry
    this.connection.send(response)
  }

  chatToAllianceStreamReceived (message) {
    if (this.homeMode == null) return
    const avatar = this.homeMode.avatar
    if (avatar.allianceId < 0) return
    const alliance = Alliances.load(avatar.allianceId)
    if (alliance == null) return
    if (alliance.getMemberById(avatar.accountId) == null) return

    const text = message.message
    if (text == null || text.trim().length === 0) return

    if (text.startsWith('/')) {
      new AllianceChatCommandHandler(this, alliance).handle(text)
      return
    }

    const isChatBanned = avatar.isCommunityBanned || this.homeMode.home.chatBanEndTime > Date.now()
    if (!isChatBanned && text.length < 100) {
      alliance.sendChatMessage(avatar.accountId, text)
    } else if (isChatBanned) {
      this.sendConsoleEntry(alliance, 'Это сообщение не видят другие учасники, для общения в чате дождись конца блокривки!')
    } else {
      this.sendConsoleEntry(alliance, 'Unknown error occured. We are working on this...')
    }
  }

  getTeam () {
    return Teams.get(this.homeMode.avatar.teamId)
  }

  getMyTeam () {
    if (!(this.homeMode.avatar.teamId > 0)) return null
    const team = this.getTeam()
    if (team == null) return null
    if (team.getMember(this.homeMode.avatar.accountId) == null) return null
    return team
  }

  createTeamMember (isOwner, state) {
    const home = this.homeMode.home
    const avatar = this.homeMode.avatar
    const hero = avatar.getHero(home.characterId)
    if (hero == null) return null

    const member = new TeamMember()
    member.accountId = avatar.accountId
    member.characterId = home.characterId
    member.displayData = new PlayerDisplayData(home.hasPremiumPass, home.thumbnailId, home.nameColorId, avatar.name)
    member.heroLevel = hero.powerLevel

    const cd = DataTables.get(DataType.Character).getDataByGlobalId(hero.characterId)
    const cards = DataTables.get(DataType.Card)

    member.starpower = 0
    if (hero.hasStarpower && cd != null) {
      const ids = [cards.getData(cd.name + '_unique'), cards.getData(cd.name + '_unique_2')]
        .filter(card => card != null)
        .map(card => card.getGlobalId())
      const chosen = ids.find(id => avatar.selectedStarpowers.includes(id)) ||
        ids.find(id => avatar.starpowers.includes(id))
      if (chosen != null) {
        member.heroLevel = 9
        member.starpower = chosen
      }
    }

    member.gadget = 0
    if (hero.powerLevel > 5 && cd != null) {
      for (const wildCard of HomeMode.getGadgetCards(cd)) {
        if (avatar.starpowers.includes(wildCard.getGlobalId())) {
          member.gadget = wildCard.getGlobalId()
          break
        }
      }
    }

    const skinInstanceId = home.selectedSkins[GlobalId.getInstanceId(home.characterId)] | 0
    member.skinId = skinInstanceId > 0 ? GlobalId.createGlobalId(DataType.Skin, skinInstanceId) : 0
    member.heroTrophies = hero.trophies
    member.heroHighestTrophies = hero.highestTrophies

    member.isOwner = isOwner
    member.state = state
    return member
  }

  removeFromTeam (team) {
    const avatar = this.homeMode.avatar
    avatar.teamId = -1
    if (team == null) return

    const entry = team.getMember(avatar.accountId)
    if (entry == null) return

    team.members.splice(team.members.indexOf(entry), 1)

    if (team.members.length === 0) {
      Teams.remove(team.id)
      return
    }

    if (entry.isOwner && !team.members.some(member => member.isOwner)) {
      team.members[0].isOwner = true
    }
    team.teamUpdated()
  }

  leaveCurrentTeam () {
    if (!(this.homeMode.avatar.teamId > 0)) return
    this.removeFromTeam(this.getTeam())
  }

  teamCreateReceived (message) {
    if (this.homeMode == null) return
    const member = this.createTeamMember(true, 2)
    if (member == null) return

    this.leaveCurrentTeam()

    const team = Teams.create()
    team.type = message.teamType
    const events = Events.getEvents()
    team.locationId = events.length > 0 ? events[0].locationId : 0
    team.members.push(member)

    this.homeMode.avatar.teamId = team.id

    const teamMessage = new TeamMessage()
    teamMessage.team = team
    this.connection.send(teamMessage)
    this.sendTeamStatusToFriends(team)
  }

  teamLeaveReceived (message) {
    if (this.homeMode == null) return
    if (!(this.homeMode.avatar.teamId > 0)) return

    const team = this.getTeam()
    if (team == null) {
      Logger.print('TeamLeave - Team is NULL!')
    }

    this.removeFromTeam(team)
    this.connection.send(new TeamLeftMessage())
    this.sendTeamStatusToFriends(null)
  }

  teamChangeMemberSettingsReceived (message) {
    if (this.homeMode == null) return
    const team = Teams.get(this.homeMode.avatar.teamId)
    if (team == null) return
    const member = team.getMember(this.homeMode.avatar.accountId)
    if (member == null) return
    const current = this.createTeamMember(member.isOwner, member.state)
    if (current != null) {
      member.characterId = current.characterId
      member.skinId = current.skinId
      member.heroTrophies = current.heroTrophies
      member.heroHighestTrophies = current.heroHighestTrophies
      member.heroLevel = current.heroLevel
      member.starpower = current.starpower
      member.gadget = current.gadget
      member.displayData = current.displayData
    }
    team.teamUpdated()
  }

  teamSetMemberReadyReceived (message) {
    if (this.homeMode == null) return
    const team = this.getTeam()
    if (team == null) return

    const member = team.getMember(this.homeMode.avatar.accountId)
    if (member == null) return

    member.isReady = message.isReady

    team.teamUpdated()
  }

  teamSpectateMessageReceived (message) {
    if (this.homeMode == null) return
    const team = Teams.get(message.teamId)
    if (team == null) return
    if (team.getMember(this.homeMode.avatar.accountId) != null) return

    const member = this.createTeamMember(false, 2)
    if (member == null) return

    this.leaveCurrentTeam()

    this.homeMode.avatar.teamId = team.id
    team.members.push(member)
    team.teamUpdated()
  }

  teamChatReceived (message) {
    if (this.homeMode == null) return
    const avatar = this.homeMode.avatar
    if (avatar.isCommunityBanned || this.homeMode.home.chatBanEndTime > Date.now()) return

    const team = this.getMyTeam()
    if (team == null) return

    const text = message.message
    if (text == null || text.trim().length === 0 || text.length >= 100) return

    const entry = new ChatStreamEntry()
    entry.accountId = avatar.accountId
    entry.name = avatar.name
    entry.message = text

    team.addStreamEntry(entry)
  }

  teamPremadeChatReceived (message) {
    if (this.homeMode == null) return
    const team = this.getMyTeam()
    if (team == null) return

    const entry = new QuickChatStreamEntry()
    entry.accountId = this.homeMode.avatar.accountId
    entry.targetId = message.targetId
    entry.name = this.homeMode.avatar.name

    if (message.targetId > 0) {
      const member = team.getMember(message.targetId)
      if (member != null) {
        entry.targetPlayerName = member.displayData.name
      }
    }

    entry.messageDataId = message.messageDataId
    entry.unknown1 = message.unknown1
    entry.unknown2 = message.unknown2

    team.addStreamEntry(entry)
  }

  teamMemberStatusReceived (message) {
    if (this.homeMode == null) return
    if (message.status < 0) return
    const team = this.getTeam()
    if (team == null) return

    const member = team.getMember(this.homeMode.avatar.accountId)
    if (member == null) return

    member.state = message.status
    team.teamUpdated()
  }

  teamSetEventReceived (message) {
    if (this.homeMode == null) return
    const team = this.getMyTeam()
    if (team == null) return

    const data = Events.getEvent(message.eventSlot)
    if (data == null) return

    team.eventSlot = message.eventSlot
    team.locationId = data.locationId
    team.battlePlayerMap = null
    team.type = 0
    team.teamUpdated()
    this.sendTeamStatusToFriends(team)
  }

  teamSetLocationReceived (message) {
    if (this.homeMode == null) return
    const team = this.getMyTeam()
    if (team == null) return

    if (GlobalId.getClassId(message.locid) === 15 && DataTables.get(DataType.Location).getDataByGlobalId(message.locid) != null) {
      team.locationId = message.locid
    }
    team.customModifiers = message.customModifiers.slice()
    team.battlePlayerMap = null
    team.type = 1
    team.teamUpdated()
    this.sendTeamStatusToFriends(team)
  }
  sendTeamStatusToFriends (team) {
    const avatar = this.homeMode.avatar
    const entryMessage = new FriendOnlineStatusEntryMessage()
    entryMessage.avatarId = avatar.accountId
    entryMessage.playerStatus = avatar.playerStatus

    for (const friend of avatar.friends.slice()) {
      if (LogicServerListener.instance.isPlayerOnline(friend.accountId)) {
        const listener = LogicServerListener.instance.getGameListener(friend.accountId)
        if (listener != null) listener.sendTCPMessage(entryMessage)
      }
    }
  }
  teamBotSlotDisableReceived (message) {
    if (this.homeMode == null) return
    if (!(this.homeMode.avatar.teamId > 0)) return
    const team = this.getTeam()
    if (team == null) return

    const index = team.disabledBots.indexOf(message.botSlot)
    if (message.disable) {
      if (index === -1) team.disabledBots.push(message.botSlot)
    } else if (index !== -1) {
      team.disabledBots.splice(index, 1)
    }
    team.teamUpdated()
  }
  teamToggleMemberSideReceived (message) {
    if (this.homeMode == null) return
    if (!(this.homeMode.avatar.teamId > 0)) return
    const team = this.getTeam()
    if (team == null) return
    if (message.longs.length === 0) return

    const member = team.getMember(message.longs[0])
    if (member == null) return

    member.teamIndex = message.unk1 >= 3 ? 1 : 0
    team.teamUpdated()
  }
  teamRequestJoinReceived (message) {
    if (this.homeMode == null) return
    const team = Teams.get(message.teamId)
    if (team == null) return

    const avatar = this.homeMode.avatar
    if (team.getMember(avatar.accountId) != null) return
    if (team.members.length >= TeamEntry.CAPACITY) return

    const member = this.createTeamMember(false, 0)
    if (member == null) return

    const team1 = Teams.get(avatar.teamId)
    if (team1 != null) {
      if (team1.getMember(avatar.accountId) == null) return
      this.removeFromTeam(team1)
      this.connection.send(new TeamLeftMessage())
    }

    const invite = team.getInviteById(avatar.accountId)
    if (invite != null) team.invites.splice(team.invites.indexOf(invite), 1)

    team.members.push(member)
    avatar.teamId = team.id
    team.teamUpdated()
  }

  teamInviteReceived (message) {
    if (this.homeMode == null) return
    const me = this.homeMode.avatar
    const team = this.getMyTeam()
    if (team == null) return
    if (message.avatarId === me.accountId) return
    if (team.getMember(message.avatarId) != null) return

    const data = Accounts.load(message.avatarId)
    if (data == null) return

    const oldInvite = team.getInviteById(message.avatarId)
    if (oldInvite != null) {
      team.invites.splice(team.invites.indexOf(oldInvite), 1)
    }

    const entry = new TeamInviteEntry()
    entry.slot = message.team
    entry.name = data.avatar.name
    entry.id = message.avatarId
    entry.inviterId = me.accountId

    team.invites.push(entry)

    team.teamUpdated()

    const home = this.homeMode.home
    const friendEntry = new Friend()
    friendEntry.accountId = me.accountId
    friendEntry.displayData = new PlayerDisplayData(home.hasPremiumPass, home.thumbnailId, home.nameColorId, me.name)
    friendEntry.trophies = me.trophies

    const teamInvitationMessage = new TeamInvitationMessage()
    teamInvitationMessage.teamId = team.id
    teamInvitationMessage.unknown = 1
    teamInvitationMessage.friendEntry = friendEntry
    this.sendToPlayer(message.avatarId, teamInvitationMessage)
  }

  teamClearInviteReceived (message) {
    if (this.homeMode == null) return
    const team = this.getMyTeam()
    if (team == null) return

    const before = team.invites.length
    team.invites = team.invites.filter(invite => invite.slot !== message.slot)
    if (team.invites.length !== before) team.teamUpdated()
  }

  teamInvitationResponseReceived (message) {
    if (this.homeMode == null) return
    const isAccept = message.response === 1

    const team = Teams.get(message.teamId)
    if (team == null) return

    const avatar = this.homeMode.avatar
    const invite = team.getInviteById(avatar.accountId)
    if (invite == null) return

    team.invites.splice(team.invites.indexOf(invite), 1)

    if (isAccept && team.getMember(avatar.accountId) == null && team.members.length < TeamEntry.CAPACITY) {
      const member = this.createTeamMember(false, 0)
      if (member != null) {
        this.leaveCurrentTeam()
        team.members.push(member)
        avatar.teamId = team.id
      }
    }

    team.teamUpdated()
  }

  askForBattleEndReceived (message) {
    if (this.homeMode == null) return

    const home = this.homeMode.home
    const avatar = this.homeMode.avatar
    let ownPlayer = null

    const location = DataTables.get(DataType.Location).getDataWithId(message.locationId)
    if (location == null || location.disabled) {
      return
    }
    if (Date.now() > home.premiumEndTime && avatar.premiumLevel > 0) {
      avatar.premiumLevel = 0
      const notification = new Notification()
      notification.id = 81
      notification.messageEntry = 'Привет!\n У тебя закончился твой vip статус\nпродлить его можно у одного из администраторов, тг: @nnsprkdv'
      home.notificationFactory.add(notification)
    }

    let isPvP = true

    for (const battlePlayer of message.battlePlayers) {
      if (ownPlayer == null && battlePlayer.displayData.name === avatar.name) {
        const hero = avatar.getHero(battlePlayer.characterId)
        if (hero == null) {
          return
        }
        battlePlayer.accountId = avatar.accountId
        ownPlayer = battlePlayer
        ownPlayer.heroPowerLevel = hero.powerLevel + (hero.hasStarpower ? 1 : 0)
        ownPlayer.trophies = hero.trophies
        ownPlayer.highestTrophies = hero.highestTrophies
        ownPlayer.powerPlayScore = home.powerPlayScore
        battlePlayer.displayData = new PlayerDisplayData(home.hasPremiumPass, home.thumbnailId, home.nameColorId, avatar.name)
      } else {
        battlePlayer.displayData = new PlayerDisplayData(false, 28000000, 43000000, 'Bot ' + battlePlayer.displayData.name)
      }
    }

    if (ownPlayer == null) {
      return
    }

    const gameModeName = location.gameMode
    const isRankedMode = ['BountyHunter', 'CoinRush', 'AttackDefend', 'LaserBall', 'RoboWars', 'KingOfHill'].includes(gameModeName)
    const isShowdown = gameModeName === 'BattleRoyale' || gameModeName === 'BattleRoyaleTeam'

    if (isShowdown) {
      const maxRank = gameModeName === 'BattleRoyale' ? 10 : 5
      if (!(message.rank >= 1 && message.rank <= maxRank)) return
    } else if (!(message.battleResult >= 0 && message.battleResult <= 2)) {
      if (gameModeName !== 'Raid' && gameModeName !== 'Raid_TownCrush') return
    }

    const startExperience = home.experience
    let experienceRewards = [8, 4, 6]
    let tokensRewards = [14, 7, 10]

    const starToken = false
    let gameMode = 0
    let trophies = new Array(10).fill(0)
    let trophiesResult = 0
    let underdogTrophiesResult = 0
    let experienceResult = 0
    let totalTokensResult = 0
    let tokensResult = 0
    let doubledTokensResult = 0
    let milestoneReward = 0
    let starExperienceResult = 0
    const milestoneRewards = []
    let powerPlayScoreGained = 0
    let powerPlayEpicScoreGained = 0
    let isPowerPlay = false
    let hasNoTokens = false
    let q = []

    const battleSeconds = (Date.now() - avatar.battleStartTime) / 1000

    const updateQuests = (gameModeVariation) => {
      if (home.quests != null) {
        q = home.quests.updateQuestsProgress(gameModeVariation, ownPlayer.characterId, 0, 0, 0, home)
      }
    }
    const questModes = { BountyHunter: 3, CoinRush: 0, AttackDefend: 2, LaserBall: 5, RoboWars: 11 }

    if (isPvP) {
      const hero = avatar.getHero(ownPlayer.characterId)
      if (hero == null) {
        return
      }
      const slot = Events.slotsLocations.has(message.locationId) ? Events.slotsLocations.get(message.locationId) : -1

      const brawlerTrophies = hero.trophies
      if (slot === 9) {
        if (home.powerPlayGamesPlayed < 3) {
          isPvP = false
          isPowerPlay = true
          const powerPlayAwards = [30, 5, 15]
          powerPlayScoreGained = powerPlayAwards[message.battleResult]
          home.powerPlayTrophiesReward = powerPlayScoreGained
          home.powerPlayGamesPlayed++
          home.powerPlayScore += powerPlayScoreGained

          if (message.battleResult === 0) {
            avatar.trioWins++
            const epicSeconds = { CoinRush: 90, LaserBall: 30, AttackDefend: 45, RoboWars: 45 }[gameModeName]
            if (epicSeconds != null && battleSeconds <= epicSeconds) {
              home.powerPlayTrophiesReward += 3
              home.powerPlayScore += 3
              powerPlayEpicScoreGained = 3
            }
          }
          if (home.powerPlayScore >= home.powerPlayHighestScore) {
            home.powerPlayHighestScore = home.powerPlayScore
          }
          if (questModes[gameModeName] != null) {
            updateQuests(questModes[gameModeName])
          }
        }
      } else if (isRankedMode) {
        if (message.battleResult === 0) {
          ownPlayer.isStarplayer = true
          starExperienceResult = 4
        } else {
          const others = message.battlePlayers.filter(player => player !== ownPlayer)
          if (others.length > 0) {
            others[Math.floor(Math.random() * others.length)].isStarplayer = true
          }
        }

        if (brawlerTrophies <= 49) {
          trophies[0] = 8
          trophies[1] = 0
        } else if (brawlerTrophies <= 799) {
          trophies[0] = 8
          trophies[1] = -Math.floor(brawlerTrophies / 100) - 1
        } else if (brawlerTrophies <= 1199) {
          trophies[0] = 7 - (Math.floor(brawlerTrophies / 100) - 8)
          trophies[1] = -Math.floor(brawlerTrophies / 100) - 1
        } else {
          trophies[0] = 3
          trophies[1] = -12
        }

        gameMode = 1
        trophiesResult = trophies[message.battleResult]
        home.trophiesReward = Math.max(trophiesResult, 0)

        if (message.battleResult === 0) {
          avatar.trioWins++
          const underdogSeconds = { CoinRush: 90, LaserBall: 30 }[gameModeName]
          if (underdogSeconds != null && battleSeconds <= underdogSeconds) {
            underdogTrophiesResult += Math.round(trophies[message.battleResult] / 4)
            trophiesResult += underdogTrophiesResult
            home.trophiesReward = Math.max(trophiesResult, 0)
          }

          if (questModes[gameModeName] != null) {
            updateQuests(questModes[gameModeName])
          }
        }

        tokensResult = tokensRewards[message.battleResult]
        totalTokensResult = tokensResult

        experienceResult = experienceRewards[message.battleResult]
      } else if (gameModeName === 'BattleRoyale') {
        if (brawlerTrophies >= 0 && brawlerTrophies <= 49) {
          trophies = [10, 8, 7, 6, 4, 2, 2, 1, 0, 0]
        } else if (brawlerTrophies <= 99) {
          trophies = [10, 8, 7, 6, 3, 2, 2, 0, -1, -2]
        } else if (brawlerTrophies <= 199) {
          trophies = [10, 8, 7, 6, 3, 1, 0, -1, -2, -2]
        } else if (brawlerTrophies <= 299) {
          trophies = [10, 8, 6, 5, 3, 1, 0, -2, -3, -3]
        } else if (brawlerTrophies <= 399) {
          trophies = [10, 8, 6, 5, 2, 0, 0, -3, -4, -4]
        } else if (brawlerTrophies <= 499) {
          trophies = [10, 8, 6, 5, 2, -1, -2, -3, -5, -5]
        } else if (brawlerTrophies <= 599) {
          trophies = [10, 8, 6, 4, 2, -1, -2, -5, -6, -6]
        } else if (brawlerTrophies <= 699) {
          trophies = [10, 8, 6, 4, 1, -2, -2, -5, -7, -8]
        } else if (brawlerTrophies <= 799) {
          trophies = [10, 8, 6, 4, 1, -3, -4, -5, -8, -9]
        } else if (brawlerTrophies <= 899) {
          trophies = [9, 7, 5, 2, 0, -3, -4, -7, -9, -10]
        } else if (brawlerTrophies <= 999) {
          trophies = [8, 6, 4, 1, -1, -3, -6, -8, -10, -11]
        } else if (brawlerTrophies <= 1099) {
          trophies = [6, 5, 3, 1, -2, -5, -6, -9, -11, -12]
        } else if (brawlerTrophies <= 1199) {
          trophies = [5, 4, 1, 0, -2, -6, -7, -10, -12, -13]
        } else {
          trophies = [5, 3, 0, -1, -2, -6, -8, -11, -12, -13]
        }

        gameMode = 2
        trophiesResult = trophies[message.rank - 1]

        experienceRewards = [15, 12, 9, 6, 5, 4, 3, 2, 1, 0]
        tokensRewards = [30, 24, 21, 15, 12, 8, 6, 4, 2, 0]

        home.trophiesReward = Math.max(trophiesResult, 0)

        if (message.rank === 1) {
          avatar.soloWins++
        }
        if (message.rank < 5) updateQuests(6)
        tokensResult = tokensRewards[message.rank - 1]
        totalTokensResult = tokensResult

        experienceResult = experienceRewards[message.rank - 1]
      } else if (gameModeName === 'BattleRoyaleTeam') {
        if (brawlerTrophies >= 0 && brawlerTrophies <= 49) {
          trophies[0] = 9
          trophies[1] = 7
          trophies[2] = 4
          trophies[3] = 0
          trophies[4] = 0
        } else if (brawlerTrophies <= 999) {
          trophies[0] = 9
          trophies[1] = 7
          const rankDiff = Math.trunc((brawlerTrophies - 100) / 100)
          trophies[2] = Math.max(3 - rankDiff, 0)
          trophies[3] = Math.max(-1 - rankDiff, -3)
          trophies[4] = Math.max(-2 - rankDiff, -4)
        } else if (brawlerTrophies <= 1099) {
          trophies[0] = 5
          trophies[1] = 4
          const rankDiff = Math.trunc((brawlerTrophies - 1000) / 100)
          trophies[2] = Math.max(-4 - rankDiff, -6)
          trophies[3] = Math.max(-9 - rankDiff, -10)
          trophies[4] = Math.max(-11 - rankDiff, -12)
        } else {
          trophies[0] = 4
          trophies[1] = 2
          trophies[2] = -6
          trophies[3] = -10
          trophies[4] = -12
        }

        gameMode = 5
        trophiesResult = trophies[message.rank - 1]

        experienceRewards = [14, 8, 4, 2, 0]
        tokensRewards = [32, 20, 8, 4, 0]

        home.trophiesReward = Math.max(trophiesResult, 0)

        if (message.rank < 3) {
          avatar.duoWins++
          updateQuests(9)
        }
        tokensResult = tokensRewards[message.rank - 1]
        totalTokensResult = tokensResult

        experienceResult = experienceRewards[message.rank - 1]
      } else if (gameModeName === 'BossFight') {
        gameMode = 4
      } else if (gameModeName === 'Raid_TownCrush' || gameModeName === 'Raid') {
        isPvP = false
        message.battleResult = 0
        gameMode = 6
      }

      if (avatar.premiumLevel > 0 && (isRankedMode || isShowdown) && !isPowerPlay) {
        const base = isRankedMode ? trophies[0] : Math.abs(trophies[message.rank - 1])
        let bonus = 0
        switch (avatar.premiumLevel) {
          case 1:
            bonus = Math.floor(base / 2)
            break
          case 2:
            bonus = Math.floor(base / 2) + Math.round(base / 4)
            break
          case 3:
            bonus = Math.floor(base * 2 * 1.5)
            break
        }
        underdogTrophiesResult += bonus
        trophiesResult += bonus
        home.trophiesReward = Math.max(trophiesResult, 0)
      }

      if (home.battleTokens > 0) {
        if (home.battleTokens - tokensResult < 0) {
          tokensResult = home.battleTokens
          totalTokensResult = tokensResult
          home.battleTokens = 0
        } else {
          home.battleTokens -= tokensResult
        }
        if (home.battleTokensRefreshStart === 0) {
          home.battleTokensRefreshStart = Date.now()
        }
      } else {
        tokensResult = 0
        totalTokensResult = 0
        hasNoTokens = true
      }

      const milestones = DataTables.get(DataType.Milestone)

      const startExp = home.experience
      home.experience += experienceResult
      home.experience += starExperienceResult
      const endExp = home.experience

      for (let i = 34; i < 500; i++) {
        const m = milestones.getDataByGlobalId(GlobalId.createGlobalId(DataType.Milestone, i))
        if (m == null) break
        const trr = m.progressStart + m.progress
        if (startExp < trr && endExp >= trr) {
          milestoneReward = GlobalId.createGlobalId(DataType.Milestone, i)
          milestoneRewards.push(milestoneReward)
          avatar.starPoints += m.secondaryLvlUpRewardCount
          home.starPointsGained += m.secondaryLvlUpRewardCount
          totalTokensResult += m.primaryLvlUpRewardCount
          break
        }
      }

      const startHighest = hero.highestTrophies
      avatar.addTrophies(trophiesResult)
      hero.addTrophies(trophiesResult)
      if (hero.trophies < 0) hero.trophies = 0
      const endHighest = hero.highestTrophies
      for (let i = 0; i < 34; i++) {
        const m = milestones.getDataByGlobalId(GlobalId.createGlobalId(DataType.Milestone, i))
        if (m == null) break
        const trr = m.progressStart + m.progress
        if (startHighest < trr && endHighest >= trr) {
          milestoneReward = GlobalId.createGlobalId(DataType.Milestone, i)
          milestoneRewards.push(milestoneReward)
          avatar.starPoints += m.secondaryLvlUpRewardCount
          home.starPointsGained += m.secondaryLvlUpRewardCount
          totalTokensResult += m.primaryLvlUpRewardCount
          break
        }
      }

      if (home.tokenDoublers > 0) {
        doubledTokensResult = Math.min(totalTokensResult, home.tokenDoublers)
        home.tokenDoublers -= doubledTokensResult
        totalTokensResult += doubledTokensResult
      }
      home.brawlPassTokens += totalTokensResult
      home.tokenReward += totalTokensResult
    } else {
      if (['BountyHunter', 'CoinRush', 'AttackDefend', 'LaserBall', 'RoboWars'].includes(gameModeName)) {
        gameMode = 1
      } else if (gameModeName === 'BattleRoyale') {
        gameMode = 2
      } else if (gameModeName === 'BattleRoyaleTeam') {
        gameMode = 5
      } else if (gameModeName === 'BossFight') {
        gameMode = 4
      }
    }

    const results = ['win', 'lose', 'draw']
    const code = LogicLongCodeGenerator.toCode(avatar.accountId)
    if (isShowdown) {
      Logger.bLog(`Player ${code} ended battle! Battle Rank: ${message.rank} in ${battleSeconds}s gamemode: ${gameModeName}!`)
    } else {
      Logger.bLog(`Player ${code} ended battle! Battle Result: ${results[message.battleResult]} in ${battleSeconds}s gamemode: ${gameModeName}!`)
    }
    avatar.battleStartTime = 0

    const battleEnd = new BattleEndMessage()
    battleEnd.gameMode = gameMode
    battleEnd.result = message.battleResult
    battleEnd.starToken = starToken
    battleEnd.isPowerPlay = isPowerPlay
    battleEnd.isPvP = isPvP
    battleEnd.pp = message.battlePlayers
    battleEnd.ownPlayer = ownPlayer
    battleEnd.trophiesReward = trophiesResult
    battleEnd.experienceReward = experienceResult
    battleEnd.starExperienceReward = starExperienceResult
    battleEnd.doubledTokensReward = doubledTokensResult
    battleEnd.tokenDoublersLeft = home.tokenDoublers
    battleEnd.tokensReward = tokensResult
    battleEnd.experience = startExperience
    battleEnd.milestoneReward = milestoneReward
    battleEnd.progressiveQuests = q
    battleEnd.underdogTrophies = underdogTrophiesResult
    battleEnd.powerPlayScoreGained = powerPlayScoreGained
    battleEnd.powerPlayEpicScoreGained = powerPlayEpicScoreGained
    battleEnd.hasNoTokens = hasNoTokens
    battleEnd.milestoneRewards = milestoneRewards

    this.connection.send(battleEnd)
  }

  clientInfoReceived (message) {
    const info = new UdpConnectionInfoMessage()
    info.sessionId = this.connection.udpSessionId
    info.serverAddress = Configuration.instance.udpHost
    info.serverPort = Configuration.instance.udpPort
    this.connection.send(info)
  }

  cancelMatchMaking (message) {
    Matchmaking.cancelMatchmake(this.connection)
    this.connection.send(new MatchMakingCancelledMessage())
  }

  matchmakeRequestReceived (message) {
    if (this.homeMode == null) return
    let slot = message.eventSlot

    const characterData = DataTables.get(DataType.Character).getDataByGlobalId(this.homeMode.home.characterId)
    if (characterData == null || characterData.disabled) {
      this.connection.send(new OutOfSyncMessage())
      return
    }

    if (!Events.hasSlot(slot)) {
      slot = 1
    }

    Matchmaking.requestMatchmake(this.connection, slot)
  }

  stopSpectateReceived (message) {
    if (this.spectatedBattle != null) {
      this.spectatedBattle.removeSpectator(this.connection.udpSessionId)
      this.spectatedBattle = null
    }

    if (this.connection.home != null && this.connection.avatar != null) {
      const ohd = new OwnHomeDataMessage()
      ohd.home = this.connection.home
      ohd.avatar = this.connection.avatar
      this.connection.send(ohd)
    }
  }

  startSpectateReceived (message) {
    if (this.homeMode == null) return
    const data = Accounts.load(message.accountId)
    if (data == null) return

    const battle = Battles.get(data.avatar.battleId)
    if (battle == null) return

    if (this.spectatedBattle != null) {
      this.spectatedBattle.removeSpectator(this.connection.udpSessionId)
    }

    this.spectatedBattle = battle
    const socket = UDPGateway.createSocket()
    socket.battle = battle
    socket.isSpectator = true
    socket.tcpConnection = this.connection
    this.connection.udpSessionId = socket.sessionId
    battle.addSpectator(socket.sessionId, new UDPGameListener(socket, this.connection))

    const startLoading = new StartLoadingMessage()
    startLoading.locationId = battle.location.getGlobalId()
    startLoading.teamIndex = 0
    startLoading.ownIndex = 0
    startLoading.gameMode = battle.getGameModeVariation() === 6 ? 6 : 1
    startLoading.players.push(...battle.getPlayers())
    startLoading.spectateMode = 1

    this.connection.send(startLoading)

    const info = new UdpConnectionInfoMessage()
    info.sessionId = this.connection.udpSessionId
    info.serverAddress = Configuration.instance.udpHost
    info.serverPort = Configuration.instance.udpPort
    this.connection.send(info)
  }

  sendLoginFailed (errorCode, text, updateUrl) {
    const loginFailed = new AuthenticationFailedMessage()
    loginFailed.errorCode = errorCode
    if (text !== undefined) loginFailed.message = text
    if (updateUrl !== undefined) loginFailed.updateUrl = updateUrl
    this.connection.send(loginFailed)
  }

  loginReceived (message) {
    if (this.homeMode != null) return

    if (message.major !== 39) {
      this.sendLoginFailed(8, 'Update!', '')
      return
    }

    if (Sessions.maintenance) {
      this.sendLoginFailed(10)
      return
    }

    let account = null
    if (message.accountId === 0) {
      account = Accounts.create()
    } else {
      account = Accounts.load(message.accountId)
      if (account != null && account.passToken !== message.passToken) {
        account = null
      }
    }

    if (account == null) {
      this.sendLoginFailed(1, 'Unknown Error occured while loading account')
      return
    }

    if (account.avatar.banned) {
      this.sendLoginFailed(11)
      return
    }

    if (account.avatar.shouldRedirect) {
      const t = Accounts.load(account.avatar.redirectId)
      if (t == null) {
        this.sendLoginFailed(1, 'Unknown Error occured while loading account')
        return
      }
      account = t
    }

    const loginOk = new AuthenticationOkMessage()
    loginOk.accountId = account.accountId
    loginOk.passToken = account.passToken
    loginOk.major = message.major
    loginOk.minor = message.minor
    loginOk.build = message.build
    loginOk.serverEnvironment = 'prod'
    this.connection.send(loginOk)

    this.homeMode = HomeMode.loadHomeState(new HomeGameListener(this.connection), account.home, account.avatar, Events.getEventsById(account.home.powerPlayGamesPlayed, account.avatar.accountId))
    this.homeMode.characterChanged.push(characterId => this.onChangeCharacter(characterId))
    this.homeMode.home.ipAddress = this.connection.remoteEndPoint.split(' ')[0]
    this.homeMode.home.device = message.deviceId

    if (this.homeMode.avatar.highestTrophies === 0 && this.homeMode.avatar.trophies !== 0) {
      this.homeMode.avatar.highestTrophies = this.homeMode.avatar.trophies
    }

    this.commandManager = new CommandManager(this.homeMode, this.connection)

    if (this.homeMode.avatar.battleStartTime !== 0) {
      const h = this.homeMode.avatar.getHero(this.homeMode.home.characterId)
      if (h != null) {
        h.addTrophies(MessageManager.getLeaveTrophies(h.trophies))
      }
      this.homeMode.home.powerPlayGamesPlayed = Math.max(0, this.homeMode.home.powerPlayGamesPlayed - 1)
      this.homeMode.home.events = Events.getEventsById(this.homeMode.home.powerPlayGamesPlayed, this.homeMode.avatar.accountId)
      this.homeMode.avatar.battleStartTime = 0
    }

    let battle = null
    if (this.homeMode.avatar.battleId > 0) {
      battle = Battles.get(this.homeMode.avatar.battleId)
      if (battle != null && !battle.getPlayers().some(player => player.accountId === this.homeMode.avatar.accountId)) {
        battle = null
      }
      if (battle == null) {
        this.homeMode.avatar.battleId = 0
      }
    }

    if (battle == null) {
      const ohd = new OwnHomeDataMessage()
      ohd.home = this.homeMode.home
      ohd.avatar = this.homeMode.avatar
      this.connection.send(ohd)
    } else {
      const startLoading = new StartLoadingMessage()
      startLoading.locationId = battle.location.getGlobalId()
      startLoading.teamIndex = this.homeMode.avatar.teamIndex
      startLoading.ownIndex = this.homeMode.avatar.ownIndex
      startLoading.gameMode = battle.getGameModeVariation() === 6 ? 6 : 1
      startLoading.players.push(...battle.getPlayers())
      const socket = UDPGateway.createSocket()
      socket.tcpConnection = this.connection
      socket.battle = battle
      this.connection.udpSessionId = socket.sessionId
      battle.changePlayerSessionId(this.homeMode.avatar.udpSessionId, socket.sessionId)
      this.homeMode.avatar.udpSessionId = socket.sessionId
      this.connection.send(startLoading)
    }

    this.homeMode.avatar.lastOnline = Date.now()
    Sessions.create(this.homeMode, this.connection)

    const friendList = new FriendListMessage()
    friendList.friends = this.homeMode.avatar.friends.slice()
    this.connection.send(friendList)

    if (this.homeMode.avatar.allianceRole !== AllianceRole.None && this.homeMode.avatar.allianceId > 0) {
      const alliance = Alliances.load(this.homeMode.avatar.allianceId)
      if (alliance != null) {
        this.sendMyAllianceData(alliance)
        const data = new AllianceDataMessage()
        data.alliance = alliance
        data.isMyAlliance = true
        this.connection.send(data)

        for (const member of alliance.members.slice()) {
          if (LogicServerListener.instance.isPlayerOnline(member.accountId)) {
            const memberAvatar = member.avatar
            if (memberAvatar == null) continue
            const allianceOnlineStatusUpdatedMessage = new AllianceOnlineStatusUpdatedMessage()
            allianceOnlineStatusUpdatedMessage.avatarId = member.accountId
            allianceOnlineStatusUpdatedMessage.members = alliance.members.length
            allianceOnlineStatusUpdatedMessage.playerStatus = memberAvatar.playerStatus
            this.connection.send(allianceOnlineStatusUpdatedMessage)
          }
        }
      }
    }

    for (const entry of this.homeMode.avatar.friends.slice()) {
      if (LogicServerListener.instance.isPlayerOnline(entry.accountId)) {
        const friendAvatar = entry.avatar
        if (friendAvatar == null) continue
        const statusEntryMessage = new FriendOnlineStatusEntryMessage()
        statusEntryMessage.avatarId = entry.accountId
        statusEntryMessage.playerStatus = friendAvatar.playerStatus
        this.connection.send(statusEntryMessage)
      }
    }

    if (this.homeMode.avatar.teamId > 0) {
      const team = Teams.get(this.homeMode.avatar.teamId)
      const member = team != null ? team.getMember(this.homeMode.avatar.accountId) : null
      if (member != null) {
        const teamMessage = new TeamMessage()
        teamMessage.team = team
        this.connection.send(teamMessage)
        member.state = 0
        team.teamUpdated()
      } else {
        this.homeMode.avatar.teamId = -1
      }
    }
  }

  static getLeaveTrophies (brawlerTrophies) {
    if (brawlerTrophies <= 49) return 0
    if (brawlerTrophies >= 1100) return -12
    return -Math.floor(brawlerTrophies / 100) - 1
  }

  sendMyAllianceData (alliance) {
    const myAlliance = new MyAllianceMessage()
    myAlliance.role = this.homeMode.avatar.allianceRole
    myAlliance.onlineMembers = alliance.onlinePlayers
    myAlliance.allianceHeader = alliance.header
    this.connection.send(myAlliance)

    const stream = new AllianceStreamMessage()
    stream.entries = alliance.stream.getEntries()
    this.connection.send(stream)
  }

  clientHelloReceived (message) {
    this.connection.messaging.seed = message.clientSeed
    this.connection.messaging.serversc = crypto.randomInt(1, 256)

    const hello = new ServerHelloMessage()
    hello.client = { connection: this.connection }
    hello.serversc = this.connection.messaging.serversc
    hello.setServerHelloToken(this.connection.messaging.sessionToken)
    this.connection.send(hello)
  }
}

module.exports = MessageManager
