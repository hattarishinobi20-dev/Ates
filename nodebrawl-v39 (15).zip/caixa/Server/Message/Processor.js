const Logger = require('../Logger')

const MAX_QUEUE_SIZE = 1024

class Processor {
  static incomingQueue = []
  static outgoingQueue = []
  static receiveScheduled = false
  static sendScheduled = false

  static init () {
    this.incomingQueue = []
    this.outgoingQueue = []
    this.receiveScheduled = false
    this.sendScheduled = false
  }

  static receive (connection, message) {
    if (message == null) return false

    if (this.incomingQueue.length >= MAX_QUEUE_SIZE) {
      Logger.print(`Processor: Incoming message queue full. Message of type ${message.getMessageType()} discarded.`)
      return false
    }

    this.incomingQueue.push({ connection, message })

    if (!this.receiveScheduled) {
      this.receiveScheduled = true
      setImmediate(() => this.updateReceive())
    }

    return true
  }

  static send (connection, message) {
    if (message == null) return

    if (this.outgoingQueue.length >= MAX_QUEUE_SIZE) {
      Logger.print(`Processor: Outgoing message queue full. Message of type ${message.getMessageType()} discarded.`)
      return
    }

    this.outgoingQueue.push({ connection, message })

    if (!this.sendScheduled) {
      this.sendScheduled = true
      setImmediate(() => this.updateSend())
    }
  }

  static updateReceive () {
    this.receiveScheduled = false

    while (this.incomingQueue.length > 0) {
      const item = this.incomingQueue.shift()
      try {
        item.connection.messageManager.receiveMessage(item.message)
      } catch (e) {
        Logger.error(`Processor: exception while handling message ${item.message.getMessageType()} (${item.message.constructor.name}): ${e.stack || e}`)
      }
    }
  }

  static updateSend () {
    this.sendScheduled = false

    while (this.outgoingQueue.length > 0) {
      const item = this.outgoingQueue.shift()
      try {
        item.connection.messaging.encryptAndWrite(item.message)
      } catch (e) {
        Logger.error(`Processor: exception while sending message ${item.message.getMessageType()} (${item.message.constructor.name}): ${e.stack || e}`)
      }
    }
  }
}

module.exports = Processor
