const path = require('path')
const JsonTable = require('./JsonTable')
const AllianceCache = require('./Cache/AllianceCache')
const Logger = require('../Logger')

class Alliances {
  static allianceIdCounter = 0
  static table = null

  static init (databaseName) {
    this.table = new JsonTable(path.join(__dirname, '../..', databaseName, 'alliances.json'))
    this.table.load()

    AllianceCache.init()

    this.allianceIdCounter = this.getMaxAllianceId()
  }

  static serialize (alliance) {
    return JSON.parse(JSON.stringify(alliance))
  }

  static deserialize (data) {
    const Alliance = require('../../Logic/Club/Alliance')
    return Alliance.fromJSON(data)
  }

  static getMaxAllianceId () {
    return this.table.getMaxId()
  }

  static create (alliance) {
    if (alliance == null) return

    alliance.id = ++this.allianceIdCounter

    this.table.insert({ Id: alliance.id, Name: alliance.name, Trophies: alliance.trophies, Data: this.serialize(alliance) })

    AllianceCache.cache(alliance)
  }

  static save (alliance) {
    if (alliance == null) return

    this.table.update(alliance.id, { Name: alliance.name, Trophies: alliance.trophies, Data: this.serialize(alliance) })
  }

  static load (id) {
    if (AllianceCache.isAllianceCached(id)) {
      return AllianceCache.getAlliance(id)
    }

    const row = this.table.select(id)
    if (row != null) {
      const alliance = this.deserialize(row.Data)
      AllianceCache.cache(alliance)
      return alliance
    }

    return null
  }

  static delete (id) {
    this.table.delete(id)
    AllianceCache.removeAlliance(id)
  }

  static getRankingList () {
    const list = []

    try {
      const rows = this.table.selectAll().sort((a, b) => b.Trophies - a.Trophies).slice(0, 200)
      for (const row of rows) {
        list.push(this.deserialize(row.Data))
      }
    } catch (e) {
      Logger.error('Alliance ranking list error: ' + (e.stack || e))
    }

    return list
  }

  static getRandomAlliances (avatar, maxCount) {
    const ids = this.table.getIds()
    for (let i = ids.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      const temp = ids[i]
      ids[i] = ids[j]
      ids[j] = temp
    }

    const list = []
    for (const id of ids) {
      if (list.length >= maxCount) break

      try {
        const alliance = this.load(id)
        if (alliance == null) continue
        if (alliance.requiredTrophies > avatar.trophies) continue
        if (alliance.members.length >= 100) continue
        if (alliance.type === 2) continue

        list.push(alliance)
      } catch (e) {
        Logger.error('Random alliances error: ' + (e.stack || e))
      }
    }

    return list
  }

  static flush () {
    if (this.table != null) this.table.flush()
  }
}

module.exports = Alliances
