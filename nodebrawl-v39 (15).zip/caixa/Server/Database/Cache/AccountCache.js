const Logger = require('../../Logger')

class AccountCache {
  static cachedAccounts = new Map()
  static timer = null
  static started = true

  static get count () {
    return this.cachedAccounts.size
  }

  static init () {
    this.cachedAccounts = new Map()
    if (this.timer != null) clearInterval(this.timer)
    this.timer = setInterval(() => this.update(), 1000 * 30 * 10)
  }

  static update () {
    if (!this.started) return
    this.saveAll()
  }

  static saveAll () {
    const Accounts = require('../Accounts')

    for (const account of Array.from(this.cachedAccounts.values())) {
      try {
        Accounts.save(account)
      } catch (e) {
        Logger.error('Unhandled exception while saving account: ' + e.message + ' trace: ' + e.stack)
      }
    }
  }

  static isAccountCached (id) {
    return this.cachedAccounts.has(id)
  }

  static getAccount (id) {
    return this.cachedAccounts.get(id) || null
  }

  static cache (account) {
    this.cachedAccounts.set(account.accountId, account)
  }
}

module.exports = AccountCache
