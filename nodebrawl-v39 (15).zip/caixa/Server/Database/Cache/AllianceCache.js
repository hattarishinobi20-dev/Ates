const Logger = require('../../Logger')

class AllianceCache {
  static cachedAlliances = new Map()
  static timer = null
  static started = true

  static get count () {
    return this.cachedAlliances.size
  }

  static init () {
    this.cachedAlliances = new Map()
    if (this.timer != null) clearInterval(this.timer)
    this.timer = setInterval(() => this.update(), 1000 * 30 * 10)
  }

  static update () {
    if (!this.started) return
    this.saveAll()
  }

  static saveAll () {
    const Alliances = require('../Alliances')

    for (const alliance of Array.from(this.cachedAlliances.values())) {
      try {
        Alliances.save(alliance)
      } catch (e) {
        Logger.error('Unhandled exception while saving alliance: ' + e.message + ' trace: ' + e.stack)
      }
    }
  }

  static isAllianceCached (id) {
    return this.cachedAlliances.has(id)
  }

  static getAlliance (id) {
    return this.cachedAlliances.get(id) || null
  }

  static removeAlliance (id) {
    this.cachedAlliances.delete(id)
  }

  static cache (alliance) {
    this.cachedAlliances.set(alliance.id, alliance)
  }
}

module.exports = AllianceCache
