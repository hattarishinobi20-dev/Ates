const LogicServerListener = require('../../Logic/Listener/LogicServerListener')
const Accounts = require('../Database/Accounts')
const Sessions = require('../Networking/Session/Sessions')

class ServerListener extends LogicServerListener {
  getAvatar (id) {
    const account = Accounts.load(id)
    return account != null ? account.avatar : null
  }

  getGameListener (id) {
    if (Sessions.isSessionActive(id)) {
      return Sessions.getSession(id).gameListener
    }
    return null
  }

  getHomeMode (id) {
    if (Sessions.isSessionActive(id)) {
      return Sessions.getSession(id).home
    }
    return null
  }

  isPlayerOnline (id) {
    return Sessions.isSessionActive(id)
  }
}

module.exports = ServerListener
