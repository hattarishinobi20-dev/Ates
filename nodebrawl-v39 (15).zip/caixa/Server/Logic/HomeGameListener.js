const LogicGameListener = require('../../Logic/Listener/LogicGameListener')

class HomeGameListener extends LogicGameListener {
  constructor (connection) {
    super()
    this.connection = connection
  }

  sendMessage (message) {
    this.connection.send(message)
  }

  sendTCPMessage (message) {
    this.connection.send(message)
  }
}

module.exports = HomeGameListener
