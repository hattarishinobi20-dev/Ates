class Battles {
  static battleIdCounter = 0
  static battles = new Map()
  static timer = null

  static init () {
    this.battles = new Map()
    this.battleIdCounter = 0

    if (this.timer != null) clearInterval(this.timer)
    this.timer = setInterval(() => this.update(), 1000)
  }

  static update () {
    for (const battle of Array.from(this.battles.values())) {
      if (battle.isGameOver) {
        this.battles.delete(battle.id)
      }
    }
  }

  static add (battle) {
    const id = ++this.battleIdCounter
    this.battles.set(id, battle)
    return id
  }

  static get (id) {
    return this.battles.get(id) || null
  }
}

module.exports = Battles
