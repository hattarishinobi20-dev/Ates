const fs = require('fs')
const path = require('path')
const LogicJSONParser = require('../../../Titan/Json/LogicJSONParser')
const DataTables = require('../../../Logic/Data/DataTables')
const DataType = require('../../../Logic/Data/DataType')
const EventData = require('../../../Logic/Home/Items/EventData')
const LogicDayChangedCommand = require('../../../Logic/Command/Home/LogicDayChangedCommand')
const AvailableServerCommandMessage = require('../../../Protocol/Messages/Server/AvailableServerCommandMessage')
const Logger = require('../../Logger')

const MODIFIERS = Object.freeze([1, 2, 3, 5])

function nextInt (min, max) {
  if (max <= min) return min
  return min + Math.floor(Math.random() * (max - min))
}

class Events {
  static REFRESH_MINUTES = 6 * 60

  static refreshTimer = null
  static configSlots = []
  static slots = new Map()
  static slotsLocations = new Map()
  static locations = []
  static slotsCollected = new Map()
  static slotsPlayed = new Map()

  static init () {
    this.loadSettings()
    this.slots = new Map()
    this.slotsLocations = new Map()
    this.locations = []

    if (this.refreshTimer != null) clearInterval(this.refreshTimer)
    this.refreshTimerElapsed()
    this.refreshTimer = setInterval(() => this.refreshTimerElapsed(), this.REFRESH_MINUTES * 60 * 1000 - 1)
  }

  static stop () {
    if (this.refreshTimer != null) clearInterval(this.refreshTimer)
    this.refreshTimer = null
  }

  static generateEvents () {
    const slots = new Map()
    this.slotsLocations = new Map()
    this.slotsCollected = new Map()
    this.slotsPlayed = new Map()
    this.locations = []

    for (const config of this.configSlots) {
      const eventspair = this.generateEvent(config.allowedModes, config.slot)
      if (eventspair.length === 0) continue
      for (const event of eventspair) {
        slots.set(event.slot, event)
      }
    }

    this.slots = slots
  }

  static refreshTimerElapsed () {
    try {
      this.generateEvents()
    } catch (e) {
      Logger.error('Events: failed to generate events: ' + (e.stack || e))
      return
    }

    const Sessions = require('../../Networking/Session/Sessions')

    for (const session of Array.from(Sessions.activeSessions.values())) {
      const home = session.home.home
      home.events = this.getEventsById(home.powerPlayGamesPlayed, session.home.avatar.accountId)

      const newday = new LogicDayChangedCommand()
      newday.home = home
      const eventupdated = new AvailableServerCommandMessage()
      eventupdated.command = newday
      session.connection.send(eventupdated)
    }
  }

  static registerEvent (event) {
    this.locations.push(event.locationId)
    this.slotsLocations.set(event.locationId, event.slot)
    this.slotsCollected.set(event.slot, [])
    this.slotsPlayed.set(event.slot, [])
  }

  static createEvent (location, slot, modifiers) {
    const ev = new EventData()
    ev.endTime = Date.now() + this.REFRESH_MINUTES * 60 * 1000
    ev.locationId = location.getGlobalId()
    ev.slot = slot
    ev.modifiers = modifiers
    return ev
  }

  static generateEvent (gameModes, slot) {
    const candidates = DataTables.get(DataType.Location).getDatas()
      .filter(location => location != null && !location.disabled && gameModes.includes(location.gameMode))
      .filter(location => !this.slotsLocations.has(location.getGlobalId()))

    if (candidates.length === 0) {
      Logger.warning(`Events: no location available for slot ${slot}`)
      return []
    }

    const sel = [
      MODIFIERS[nextInt(0, MODIFIERS.length)],
      MODIFIERS[nextInt(0, MODIFIERS.length)],
      MODIFIERS[nextInt(0, MODIFIERS.length)]
    ]

    const pool = candidates.slice()
    while (pool.length > 0) {
      const index = nextInt(0, pool.length)
      const location = pool[index]
      pool.splice(index, 1)

      if (slot !== 2) {
        const ev = this.createEvent(location, slot, slot !== 9 ? sel : [])
        this.registerEvent(ev)
        return [ev]
      }

      let sep = 'l'
      if (location.name.split('l')[0].includes('Graves')) sep = 's'
      const mode = location.name.split(sep)
      if (mode.length < 2) continue

      const duoName = mode[0] + sep + 'Team' + mode[1]
      const locationa = DataTables.get(DataType.Location).getData(duoName)
      if (locationa == null) continue

      const ev = this.createEvent(location, slot, sel)
      const evs = this.createEvent(locationa, 5, sel)
      this.registerEvent(ev)
      this.registerEvent(evs)
      return [ev, evs]
    }

    Logger.warning(`Events: no valid location pair for slot ${slot}`)
    return []
  }

  static loadSettings () {
    const settings = LogicJSONParser.parseObject(fs.readFileSync(path.join(__dirname, '../../../Assets/gameplay.json'), 'utf8'))
    const slots = settings != null ? settings.getJSONArray('slots') : null
    this.configSlots = []
    if (slots == null) return

    for (let i = 0; i < slots.size(); i++) {
      const slot = slots.getJSONObject(i)
      if (slot == null) continue

      const slotNumber = slot.getJSONNumber('slot')
      const gameModes = slot.getJSONArray('game_modes')
      if (slotNumber == null || gameModes == null) continue

      const allowedModes = []
      for (let j = 0; j < gameModes.size(); j++) {
        const mode = gameModes.getJSONString(j)
        if (mode != null) allowedModes.push(mode.getStringValue())
      }

      this.configSlots.push({ slot: slotNumber.getIntValue(), allowedModes })
    }
  }

  static collectEvent (id, slot) {
    if (!this.hasSlot(slot)) return false
    const collected = this.slotsCollected.get(slot)
    if (collected.includes(id)) return false
    collected.push(id)
    return true
  }

  static playSlot (id, slot) {
    if (!this.hasSlot(slot)) return false
    if (this.slotsPlayed.get(slot).includes(id)) return false

    if (slot === 5 || slot === 2) {
      for (const s of [2, 5]) {
        if (this.slotsPlayed.has(s)) this.slotsPlayed.get(s).push(id)
      }
    } else {
      this.slotsPlayed.get(slot).push(id)
    }
    return true
  }

  static hasEventBonus (id, slot) {
    const collected = this.slotsCollected.get(slot)
    return collected != null && collected.includes(id)
  }

  static getEvent (i) {
    if (this.hasSlot(i)) {
      return this.slots.get(i)
    }
    return null
  }

  static hasSlot (slot) {
    return this.slots.has(slot)
  }

  static hasLocation (location) {
    return this.locations.includes(location)
  }

  static getEvents () {
    return Array.from(this.slots.values())
  }

  static getEventsById (a, id) {
    return Array.from(this.slots.values()).map(source => {
      const e = source.clone()
      const collected = this.slotsCollected.get(e.slot)
      e.isBonusCollected = collected != null && collected.includes(id)
      e.powerPlayGamesPlayed = a
      return e
    })
  }

  static getSecondaryEvents () {
    return Array.from(this.slots.values()).map(source => {
      const e = source.clone()
      e.isSecondary = true
      return e
    })
  }
}

module.exports = Events
