const TeamEntry = require('../../../Logic/Team/TeamEntry')
const TeamGameStartingMessage = require('../../../Protocol/Messages/Server/TeamGameStartingMessage')
const Sessions = require('../../Networking/Session/Sessions')

class Teams {
  static entries = new Map()
  static teamIdCounter = 0

  static init () {
    this.entries = new Map()
    this.teamIdCounter = 0
  }

  static get count () {
    return this.entries.size
  }

  static create () {
    const entry = new TeamEntry()
    entry.id = ++this.teamIdCounter
    this.entries.set(entry.id, entry)
    return entry
  }

  static remove (id) {
    this.entries.delete(id)
  }

  static startGame (team) {
    let Matchmaking = null
    try {
      Matchmaking = require('./Matchmaking')
    } catch (e) {
      return
    }

    for (const member of team.members.slice()) {
      const session = Sessions.getSession(member.accountId)
      if (session == null) continue
      const message = new TeamGameStartingMessage()
      message.locationId = team.locationId
      session.connection.send(message)
      Matchmaking.requestMatchmake(session.connection, team.eventSlot, team.id)
      member.isReady = false
    }
  }

  static get (id) {
    return this.entries.get(id) || null
  }
}

module.exports = Teams
