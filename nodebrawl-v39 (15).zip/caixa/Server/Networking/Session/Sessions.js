const Session = require('./Session')
const LogicServerListener = require('../../../Logic/Listener/LogicServerListener')
const LogicLongCodeGenerator = require('../../../Logic/Util/LogicLongCodeGenerator')
const ShutdownStartedMessage = require('../../../Protocol/Messages/Server/ShutdownStartedMessage')
const AuthenticationFailedMessage = require('../../../Protocol/Messages/Server/AuthenticationFailedMessage')
const DisconnectedMessage = require('../../../Protocol/Messages/Server/DisconnectedMessage')
const FriendOnlineStatusEntryMessage = require('../../../Protocol/Messages/Server/FriendOnlineStatusEntryMessage')
const AllianceOnlineStatusUpdatedMessage = require('../../../Protocol/Messages/Server/AllianceOnlineStatusUpdatedMessage')
const AllianceRole = require('../../../Logic/Avatar/AllianceRole')
const Accounts = require('../../Database/Accounts')

class Sessions {
  static maintenance = false
  static activeSessions = new Map()
  static requestedSSID = new Map()
  static leaveJoin = new Map()
  static registratedSSID = new Map()

  static get count () {
    return this.activeSessions.size
  }

  static init () {
    this.activeSessions = new Map()
    this.requestedSSID = new Map()
    this.registratedSSID = new Map()
    this.leaveJoin = new Map()
  }

  static startShutdown () {
    this.maintenance = true

    for (const session of Array.from(this.activeSessions.values())) {
      session.connection.send(new ShutdownStartedMessage())
      session.home.avatar.battleStartTime = 0
    }

    return new Promise(resolve => {
      setTimeout(() => {
        for (const session of Array.from(this.activeSessions.values())) {
          const message = new AuthenticationFailedMessage()
          message.errorCode = 10
          session.connection.send(message)
        }
        resolve()
      }, 1000 * 10)
    })
  }

  static remove (id, connection) {
    const session = this.activeSessions.get(id)
    if (session == null) return
    if (connection != null && session.connection !== connection) return

    const avatar = session.home.avatar
    const code = LogicLongCodeGenerator.toCode(avatar.accountId)
    this.requestedSSID.delete(code)
    this.registratedSSID.delete(code)

    avatar.lastOnline = Date.now()
    avatar.playerStatus = 0

    const entryMessage = new FriendOnlineStatusEntryMessage()
    entryMessage.avatarId = avatar.accountId
    entryMessage.playerStatus = 0

    for (const friend of avatar.friends.slice()) {
      if (LogicServerListener.instance.isPlayerOnline(friend.accountId)) {
        const listener = LogicServerListener.instance.getGameListener(friend.accountId)
        if (listener != null) listener.sendTCPMessage(entryMessage)
      }
    }

    if (avatar.allianceRole !== AllianceRole.None && avatar.allianceId > 0) {
      const Alliances = require('../../Database/Alliances')
      const alliance = Alliances.load(avatar.allianceId)
      if (alliance != null) {
        const allianceOnlineStatusUpdatedMessage = new AllianceOnlineStatusUpdatedMessage()
        allianceOnlineStatusUpdatedMessage.avatarId = avatar.accountId
        allianceOnlineStatusUpdatedMessage.members = alliance.members.length
        allianceOnlineStatusUpdatedMessage.playerStatus = 0
        for (const member of alliance.members.slice()) {
          if (member.accountId === avatar.accountId) continue
          if (LogicServerListener.instance.isPlayerOnline(member.accountId)) {
            const listener = LogicServerListener.instance.getGameListener(member.accountId)
            if (listener != null) listener.sendTCPMessage(allianceOnlineStatusUpdatedMessage)
          }
        }
      }
    }

    if (avatar.teamId > 0) {
      const Teams = require('../../Logic/Game/Teams')
      const team = Teams.get(avatar.teamId)
      if (team != null) {
        const member = team.getMember(id)
        if (member != null) {
          member.state = 0
          team.teamUpdated()
        }
      }
    }

    this.activeSessions.delete(id)

    Accounts.save(Accounts.load(id))
  }

  static create (home, connection) {
    const accountId = home.avatar.accountId

    if (this.activeSessions.has(accountId)) {
      const oldSession = this.activeSessions.get(accountId)
      const message = new DisconnectedMessage()
      message.reason = 1
      oldSession.connection.send(message)

      const s = new Session(home, connection)
      this.activeSessions.set(accountId, s)
      return s
    }

    const session = new Session(home, connection)
    this.activeSessions.set(accountId, session)
    return session
  }

  static isSessionActive (id) {
    return this.activeSessions.has(id)
  }

  static getSession (id) {
    return this.activeSessions.get(id) || null
  }
}

module.exports = Sessions
