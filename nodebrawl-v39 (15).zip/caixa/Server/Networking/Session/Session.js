class Session {
  constructor (home, connection) {
    this.home = home
    this.connection = connection
  }

  get gameListener () {
    return this.home.gameListener
  }
}

module.exports = Session
