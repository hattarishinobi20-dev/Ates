const crypto = require('crypto')
const Processor = require('../Message/Processor')

const HEADER_LENGTH = 7
const MAX_MESSAGE_LENGTH = 0x100000

class Messaging {
  constructor (connection) {
    this.connection = connection
    this.sessionToken = crypto.randomBytes(24)
    this.serversc = 1
    this.seed = 0
    this.buffer = Buffer.alloc(0)
  }

  send (message) {
    const type = message.getMessageType()
    if (type === 20100 || type === 24115) {
      this.encryptAndWrite(message)
    } else {
      Processor.send(this.connection, message)
    }
  }

  encryptAndWrite (message) {
    if (message.getEncodingLength() === 0) message.encode()

    const payload = message.getMessageBytes()
    const length = payload.length
    const messageType = message.getMessageType()
    const version = message.getVersion()

    const stream = Buffer.alloc(length + HEADER_LENGTH * 2)
    stream.writeUInt16BE(messageType & 0xFFFF, 0)
    stream.writeUIntBE(length, 2, 3)
    stream.writeUInt16BE(version & 0xFFFF, 5)
    payload.copy(stream, HEADER_LENGTH)

    this.connection.write(stream)
  }

  onReceive (data) {
    this.buffer = this.buffer.length === 0 ? data : Buffer.concat([this.buffer, data])

    const messages = []
    let offset = 0

    while (this.buffer.length - offset >= HEADER_LENGTH) {
      const id = this.buffer.readUInt16BE(offset)
      const length = this.buffer.readUIntBE(offset + 2, 3)
      const version = this.buffer.readUInt16BE(offset + 5)

      if (length > MAX_MESSAGE_LENGTH) {
        this.buffer = Buffer.alloc(0)
        return null
      }

      if (this.buffer.length - offset - HEADER_LENGTH < length) break

      const start = offset + HEADER_LENGTH
      messages.push({ id, len: length, version, payload: Buffer.from(this.buffer.subarray(start, start + length)) })
      offset = start + length
    }

    if (offset > 0) {
      this.buffer = Buffer.from(this.buffer.subarray(offset))
    }

    return messages
  }

  readNewMessage (message) {
    if (message.getMessageType() === 10100) {
      this.connection.messageManager.receiveMessage(message)
    } else {
      Processor.receive(this.connection, message)
    }
  }
}

module.exports = Messaging
