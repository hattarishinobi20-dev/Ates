const Sessions = require('./Session/Sessions')

class Connections {
  static activeConnections = []
  static timer = null

  static get count () {
    return this.activeConnections.length
  }

  static init () {
    this.activeConnections = []
    if (this.timer != null) clearInterval(this.timer)
    this.timer = setInterval(() => this.update(), 1000)
  }

  static update () {
    for (const connection of this.activeConnections.slice()) {
      if (!connection.messageManager.isAlive()) {
        if (connection.messageManager.homeMode != null) {
          Sessions.remove(connection.avatar.accountId, connection)
        }
        connection.close()
        this.removeConnection(connection)
      }
    }
  }

  static addConnection (connection) {
    this.activeConnections.push(connection)
  }

  static removeConnection (connection) {
    const index = this.activeConnections.indexOf(connection)
    if (index !== -1) this.activeConnections.splice(index, 1)
  }
}

module.exports = Connections
