const ByteStream = require('../../../Titan/DataStream/ByteStream')
const UDPGateway = require('./UDPGateway')

class UDPSocket {
  constructor (sessionId) {
    this.sessionId = sessionId
    this.endPoint = null
    this.battle = null
    this.tcpConnection = null
    this.isSpectator = false
  }

  get isConnected () {
    return this.endPoint != null
  }

  setEndPoint (endPoint) {
    this.endPoint = { address: endPoint.address, port: endPoint.port }
  }

  sendMessage (message) {
    if (message.getEncodingLength() === 0) message.encode()

    const stream = new ByteStream(10)
    stream.writeLong(this.sessionId)
    stream.writeShort(0)
    stream.writeVInt(message.getMessageType())
    stream.writeVInt(message.getEncodingLength())
    stream.writeBytesWithoutLength(message.getMessageBytes(), message.getEncodingLength())

    UDPGateway.sendTo(stream.getByteArray(), 0, stream.getOffset(), this.endPoint)
  }

  processReceive (stream) {
    setImmediate(() => {
      try {
        const type = stream.readVInt()
        const length = stream.readVInt()
        if (length < 0 || length > 2000) return
        const data = stream.readBytes(length, 2000)
        if (data == null) return

        const factory = UDPGateway.messageFactory
        const MessageClass = factory != null ? factory.handle(type) : null
        if (MessageClass == null) return

        const message = new MessageClass(Buffer.from(data), null)
        message.decode()
        this.handleMessage(message)
      } catch (e) { }
    })
  }

  handleMessage (message) {
    if (message.getMessageType() === 10555) {
      if (this.battle == null) return
      while (message.inputs.length > 0) {
        const clientInput = message.inputs.shift()
        if (!this.isSpectator) {
          this.battle.addClientInput(clientInput, this.sessionId)
        } else {
          this.battle.handleSpectatorInput(clientInput, this.sessionId)
        }
      }
    }
  }
}

module.exports = UDPSocket
