const crypto = require('crypto')

const STRING_CHARACTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'

class Helpers {
  static randomString (length) {
    let result = ''

    for (let i = 0; i < length; i++) {
      result += STRING_CHARACTERS[crypto.randomInt(STRING_CHARACTERS.length)]
    }

    return result
  }
}

module.exports = Helpers
