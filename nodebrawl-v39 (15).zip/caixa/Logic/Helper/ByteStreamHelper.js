const GlobalId = require('../Data/Helper/GlobalId')
const LogicLong = require('../../Titan/Math/LogicLong')

class ByteStreamHelper {
  static writeDataReference (stream, data) {
    if (data == null) {
      stream.writeVInt(0)
      return
    }

    if (typeof data === 'number') {
      if (data <= 0) {
        stream.writeVInt(0)
        return
      }

      stream.writeVInt(GlobalId.getClassId(data))
      stream.writeVInt(GlobalId.getInstanceId(data))
      return
    }

    stream.writeVInt(data.getClassId())
    stream.writeVInt(data.getInstanceId())
  }

  static writeBitDataReference (bitStream, globalId) {
    bitStream.writePositiveInt(GlobalId.getClassId(globalId), 5)
    bitStream.writePositiveInt(GlobalId.getInstanceId(globalId), 8)
  }

  static writeObjectRunningId (bitStream, globalId) {
    bitStream.writePositiveVIntMax65535(GlobalId.getInstanceId(globalId))
  }

  static readDataReference (stream) {
    const classId = stream.readVInt()
    if (classId <= 0) return 0
    const instanceId = stream.readVInt()
    return GlobalId.createGlobalId(classId, instanceId)
  }

  static readIntList (stream, max) {
    const list = []
    const count = stream.readVInt()
    for (let i = count; i > 0; i--) {
      const value = stream.readVInt()
      if (list.length < max) list.push(value)
    }
    return list
  }

  static decodeLogicLong (stream) {
    const high = stream.readVInt()
    const low = stream.readVInt()
    return new LogicLong(high, low)
  }

  static encodeLogicLong (stream, value) {
    const logicLong = LogicLong.from(value)
    stream.writeVInt(logicLong.getHigherInt())
    stream.writeVInt(logicLong.getLowerInt())
  }

  static writeBattlePlayerMap (stream, map) {
    if (map == null) {
      stream.writeBoolean(false)
    } else {
      stream.writeBoolean(true)
      map.encode(stream)
    }
  }

  static writeIntList (stream, list) {
    const array = Array.from(list)
    stream.writeVInt(array.length)
    for (let i = 0; i < array.length; i++) {
      stream.writeVInt(array[i])
    }
  }
}

module.exports = ByteStreamHelper
