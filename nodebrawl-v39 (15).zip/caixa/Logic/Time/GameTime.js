class GameTime {
  constructor () {
    this.tick = 0
  }

  reset () {
    this.tick = 0
  }

  increaseTick () {
    this.tick++
  }

  getTick () {
    return this.tick
  }
}

module.exports = GameTime
