class LogicGameListener {
  constructor () {
    this.handledInputs = 0
  }

  sendMessage (message) {
    throw new Error('LogicGameListener::sendMessage is abstract')
  }

  sendTCPMessage (message) {
    throw new Error('LogicGameListener::sendTCPMessage is abstract')
  }
}

module.exports = LogicGameListener
