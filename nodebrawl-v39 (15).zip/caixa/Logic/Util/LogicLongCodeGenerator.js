const Debugger = require('../../Titan/Debug/Debugger')
const LogicLong = require('../../Titan/Math/LogicLong')

const HASHTAG = '#'
const CONVERSION_CHARS = '0289PYLQGRJCUV'

class LogicLongCodeGenerator {
  static toCode (value) {
    const logicLong = LogicLong.from(value)
    const highValue = logicLong.getHigherInt()

    if (highValue >= 0 && highValue < 256) {
      return HASHTAG + LogicLongCodeGenerator.convert((BigInt(logicLong.getLowerInt() >>> 0) << 8n) | BigInt(highValue))
    }

    return null
  }

  static toId (code) {
    if (code != null) {
      code = String(code).trim().toUpperCase().replace(/O/g, '0')

      if (code.startsWith(HASHTAG)) {
        code = code.substring(1)
      }

      if (code.length > 0 && code.length < 14) {
        const id = LogicLongCodeGenerator.convertCode(code)

        if (id !== -1n) {
          return new LogicLong(Number(id % 256n), Number((id >> 8n) & 0x7FFFFFFFn))
        }
      } else if (code.length >= 14) {
        Debugger.warning('Cannot convert the string to code. String is too long.')
      }
    }

    return new LogicLong(-1, -1)
  }

  static convertCode (code) {
    let id = 0n
    const conversionCharsCount = BigInt(CONVERSION_CHARS.length)

    for (let i = 0; i < code.length; i++) {
      const charIndex = CONVERSION_CHARS.indexOf(code[i])

      if (charIndex === -1) {
        return -1n
      }

      id = id * conversionCharsCount + BigInt(charIndex)
    }

    return id
  }

  static convert (value) {
    if (value < 0n) {
      return null
    }

    const conversionCharsCount = BigInt(CONVERSION_CHARS.length)
    let code = ''

    do {
      code = CONVERSION_CHARS[Number(value % conversionCharsCount)] + code
      value /= conversionCharsCount
    } while (value !== 0n && code.length < 12)

    return code
  }
}

module.exports = LogicLongCodeGenerator
