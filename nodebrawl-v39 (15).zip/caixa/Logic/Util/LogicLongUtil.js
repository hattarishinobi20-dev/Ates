const LogicLong = require('../../Titan/Math/LogicLong')

class LogicLongUtil {
  static getHigherInt (value) {
    return LogicLong.from(value).getHigherInt()
  }

  static getLowerInt (value) {
    return LogicLong.from(value).getLowerInt()
  }
}

module.exports = LogicLongUtil
