const AllianceRole = require('../../Avatar/AllianceRole')

const JSON_FIELDS = ['id', 'authorId', 'authorName', 'message', 'authorRole', 'sendTime', 'playerId', 'playerName', 'type', 'event']

class AllianceStreamEntry {
  constructor () {
    this.id = 0
    this.authorId = 0
    this.authorName = null
    this.message = null
    this.authorRole = AllianceRole.None
    this.sendTime = Date.now()
    this.playerId = 0
    this.playerName = null
    this.type = 0
    this.event = 0
  }

  encode (stream) {
    stream.writeVInt(this.type)
    stream.writeVLong(this.id)
    stream.writeVLong(this.authorId)
    stream.writeString(this.authorName)
    stream.writeVInt(this.authorRole)
    stream.writeVInt(Math.trunc((Date.now() - this.sendTime) / 1000))
    stream.writeVInt(0)
    if (this.type === 4) {
      stream.writeVInt(this.event)
      stream.writeVInt(1)
      stream.writeVLong(this.playerId)
      stream.writeString(this.playerName)
    } else {
      stream.writeString(this.message)
    }
  }

  toJSON () {
    const data = {}
    for (const field of JSON_FIELDS) data[field] = this[field]
    return data
  }

  static fromJSON (data) {
    const entry = new AllianceStreamEntry()
    for (const field of JSON_FIELDS) {
      if (data[field] !== undefined) entry[field] = data[field]
    }
    return entry
  }
}

module.exports = AllianceStreamEntry
