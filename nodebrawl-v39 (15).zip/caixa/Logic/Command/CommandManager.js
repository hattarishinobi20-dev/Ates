const Debugger = require('../../Titan/Debug/Debugger')

const COMMAND_TYPES = {
  500: './Home/LogicGatchaCommand',
  503: './Home/LogicClaimDailyRewardCommand',
  505: './Home/LogicSetPlayerThumbnailCommand',
  506: './Home/LogicSelectSkinCommand',
  509: './Home/LogicPurchaseDoubleCoinsCommand',
  514: './Home/LogicDeleteNotificationCommand',
  515: './Home/LogicClearShopTickersCommand',
  517: './Home/LogicClaimRankUpRewardCommand',
  519: './Home/LogicPurchaseOfferCommand',
  520: './Home/LogicLevelUpCommand',
  521: './Home/LogicPurchaseHeroLvlUpMaterialCommand',
  522: './Home/LogicHeroSeenCommand',
  525: './Home/LogicSelectCharacterCommand',
  527: './Home/LogicSetPlayerNameColorCommand',
  528: './Home/LogicViewInboxNotificationCommand',
  529: './Home/LogicSelectStarPowerCommand',
  533: './Home/LogicQuestsSeenCommand',
  534: './Home/LogicPurchaseBrawlPassCommand',
  535: './Home/LogicClaimTailRewardCommand',
  536: './Home/LogicPurchaseBrawlPassProgressCommand'
}

class CommandManager {
  static decodeCommand (stream) {
    const type = stream.readVInt()
    const command = CommandManager.createCommand(type)
    if (command == null) {
      Debugger.warning('Command is unhandled: ' + type)
      return null
    }

    command.decode(stream)
    return command
  }

  static createCommand (type) {
    if (Object.prototype.hasOwnProperty.call(COMMAND_TYPES, type)) {
      const CommandClass = require(COMMAND_TYPES[type])
      return new CommandClass()
    }
    return null
  }
}

module.exports = CommandManager
