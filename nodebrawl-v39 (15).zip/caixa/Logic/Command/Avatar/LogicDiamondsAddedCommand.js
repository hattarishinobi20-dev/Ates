const Command = require('../Command')

class LogicDiamondsAddedCommand extends Command {
  constructor () {
    super()
    this.amount = 0
  }

  encode (stream) {
    stream.writeVInt(0)
    stream.writeVInt(1)
  }

  execute (homeMode) {
    homeMode.avatar.addDiamonds(this.amount)
    return 0
  }

  getCommandType () {
    return 202
  }
}

module.exports = LogicDiamondsAddedCommand
