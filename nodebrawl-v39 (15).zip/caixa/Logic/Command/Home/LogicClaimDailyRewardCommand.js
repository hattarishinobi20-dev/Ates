const Command = require('../Command')

class LogicClaimDailyRewardCommand extends Command {
  constructor () {
    super()
    this.slot = 0
  }

  decode (stream) {
    super.decode(stream)
    this.slot = stream.readVInt()
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 503
  }
}

module.exports = LogicClaimDailyRewardCommand
