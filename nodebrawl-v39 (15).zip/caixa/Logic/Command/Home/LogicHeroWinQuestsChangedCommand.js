const Command = require('../Command')

class LogicHeroWinQuestsChangedCommand extends Command {
  constructor () {
    super()
    this.quests = null
  }

  encode (stream) {
    if (stream.writeBoolean(this.quests != null)) {
      this.quests.encode(stream)
    }
    stream.writeVInt(0)
    super.encode(stream)
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 220
  }
}

module.exports = LogicHeroWinQuestsChangedCommand
