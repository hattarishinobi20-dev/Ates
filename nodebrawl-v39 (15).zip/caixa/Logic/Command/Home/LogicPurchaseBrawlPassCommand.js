const Command = require('../Command')
const ClientHome = require('../../Home/ClientHome')

class LogicPurchaseBrawlPassCommand extends Command {
  constructor () {
    super()
    this.season = 0
    this.withTiers = false
  }

  decode (stream) {
    super.decode(stream)
    this.season = stream.readVInt()
    this.withTiers = stream.readBoolean()
  }

  execute (homeMode) {
    if (homeMode.home.hasPremiumPass) return -2
    const price = this.withTiers ? ClientHome.BRAWL_PASS_BUNDLE_PRICE : ClientHome.BRAWL_PASS_PRICE
    if (homeMode.avatar.useDiamonds(price)) {
      homeMode.home.hasPremiumPass = true
      if (this.withTiers) homeMode.home.addBrawlPassTiers(ClientHome.BRAWL_PASS_BUNDLE_TIERS)
      return 0
    }
    return -1
  }

  getCommandType () {
    return 534
  }
}

module.exports = LogicPurchaseBrawlPassCommand
