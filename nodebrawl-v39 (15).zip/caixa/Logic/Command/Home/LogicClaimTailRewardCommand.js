const Command = require('../Command')

class LogicClaimTailRewardCommand extends Command {
  constructor () {
    super()
  }

  decode (stream) {
    super.decode(stream)
    stream.readVInt()
    stream.readVInt()
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 535
  }
}

module.exports = LogicClaimTailRewardCommand
