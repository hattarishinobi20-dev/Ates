const Command = require('../Command')

class LogicPurchaseHeroLvlUpMaterialCommand extends Command {
  constructor () {
    super()
    this.packIndex = 0
  }

  decode (stream) {
    super.decode(stream)
    this.packIndex = stream.readVInt()
  }

  execute (homeMode) {
    const ClientHome = require('../../Home/ClientHome')
    if (this.packIndex < 0 || this.packIndex >= ClientHome.GoldPacksAmount.length) return -1
    if (!homeMode.avatar.useDiamonds(ClientHome.GoldPacksPrice[this.packIndex])) return -2
    homeMode.avatar.addGold(ClientHome.GoldPacksAmount[this.packIndex])
    return 0
  }

  getCommandType () {
    return 521
  }
}

module.exports = LogicPurchaseHeroLvlUpMaterialCommand
