const Command = require('../Command')

class LogicDayChangedCommand extends Command {
  constructor () {
    super()
    this.home = null
  }

  encode (stream) {
    stream.writeVInt(1)
    this.home.logicConfData(stream, new Date())
    super.encode(stream)
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 204
  }
}

module.exports = LogicDayChangedCommand
