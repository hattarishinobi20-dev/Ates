const Command = require('../Command')

class LogicQuestsSeenCommand extends Command {
  constructor () {
    super()
  }

  decode (stream) {
    super.decode(stream)
  }

  execute (homeMode) {
    if (homeMode.home.quests == null) return 0
    for (const quest of homeMode.home.quests.questList.slice()) {
      quest.questSeen = true
    }
    return 0
  }

  getCommandType () {
    return 533
  }
}

module.exports = LogicQuestsSeenCommand
