const Command = require('../Command')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

class LogicHeroSeenCommand extends Command {
  constructor () {
    super()
    this.characterId = 0
  }

  decode (stream) {
    super.decode(stream)
    this.characterId = ByteStreamHelper.readDataReference(stream)
  }

  execute (homeMode) {
    return 0
  }

  getCommandType () {
    return 522
  }
}

module.exports = LogicHeroSeenCommand
