const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

class EventData {
  constructor () {
    this.isBonusCollected = false
    this.slot = 0
    this.modifiers = []
    this.locationId = 0
    this.powerPlayGamesPlayed = 0
    this.endTime = 0
    this.isSecondary = false
  }

  get location () {
    return DataTables.get(DataType.Location).getDataByGlobalId(this.locationId)
  }

  getSecondsLeft () {
    return Math.trunc((this.endTime - Date.now()) / 1000)
  }

  clone () {
    const event = new EventData()
    event.isBonusCollected = this.isBonusCollected
    event.slot = this.slot
    event.modifiers = this.modifiers.slice()
    event.locationId = this.locationId
    event.powerPlayGamesPlayed = this.powerPlayGamesPlayed
    event.endTime = this.endTime
    event.isSecondary = this.isSecondary
    return event
  }

  encode (encoder) {
    encoder.writeVInt(0)
    encoder.writeVInt(this.slot)
    encoder.writeVInt(this.isSecondary ? this.getSecondsLeft() : 0)
    encoder.writeVInt(this.getSecondsLeft())
    encoder.writeVInt(10)
    ByteStreamHelper.writeDataReference(encoder, this.location)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeString(null)
    encoder.writeVInt(0)
    encoder.writeVInt(this.powerPlayGamesPlayed)
    encoder.writeVInt(3)
    encoder.writeVInt(this.modifiers.length)
    for (const modifier of this.modifiers) {
      encoder.writeVInt(modifier)
    }
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeBoolean(false)
    encoder.writeVInt(0)
    encoder.writeBoolean(false)
    encoder.writeVInt(0)
    encoder.writeVInt(0)
    encoder.writeBoolean(false)
    encoder.writeBoolean(false)
    encoder.writeBoolean(false)
    encoder.writeVInt(0)
    encoder.writeBoolean(false)
  }
}

module.exports = EventData
