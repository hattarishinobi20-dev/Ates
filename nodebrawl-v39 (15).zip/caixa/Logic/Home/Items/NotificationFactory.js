const Notification = require('./Notification')

class NotificationFactory {
  constructor () {
    this.notificationList = []
  }

  add (notification) {
    notification.index = this.getIndex()
    this.notificationList.push(notification)
  }

  getIndex () {
    return this.notificationList.length
  }

  encode (stream) {
    stream.writeVInt(this.notificationList.length)
    for (const notification of this.notificationList) {
      notification.encode(stream)
    }
  }

  toJSON () {
    return { notification_list: this.notificationList }
  }

  static fromJSON (data) {
    const factory = new NotificationFactory()
    if (data != null && Array.isArray(data.notification_list)) {
      factory.notificationList = data.notification_list.map(notification => Notification.fromJSON(notification))
    }
    return factory
  }
}

module.exports = NotificationFactory
