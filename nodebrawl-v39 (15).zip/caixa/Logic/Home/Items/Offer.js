const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

class Offer {
  constructor (type, count, itemGlobalId, skinGlobalId) {
    this.type = type != null ? type : 0
    this.count = count != null ? count : 0
    this.itemDataId = itemGlobalId != null ? itemGlobalId : 0
    this.skinDataId = skinGlobalId != null ? skinGlobalId : 0
  }

  encode (stream) {
    stream.writeVInt(this.type)
    stream.writeVInt(this.count)
    ByteStreamHelper.writeDataReference(stream, this.itemDataId)
    stream.writeVInt(this.skinDataId)
  }

  toJSON () {
    return { type: this.type, count: this.count, itemDataId: this.itemDataId, skinDataId: this.skinDataId }
  }

  static fromJSON (data) {
    return new Offer(data.type, data.count, data.itemDataId, data.skinDataId)
  }
}

module.exports = Offer
