const JSON_FIELDS = [
  'id', 'index', 'isViewed', 'timePassed', 'messageEntry', 'primaryMessageEntry', 'secondaryMessageEntry',
  'buttonMessageEntry', 'fileLocation', 'fileSha', 'extLint', 'heroesIds', 'heroesTrophies', 'heroesTrophiesReseted',
  'starpointsAwarded', 'donationCount'
]

class Notification {
  constructor (data) {
    this.id = 0
    this.index = 0
    this.isViewed = false
    this.timePassed = 0
    this.messageEntry = null
    this.primaryMessageEntry = null
    this.secondaryMessageEntry = null
    this.buttonMessageEntry = null
    this.fileLocation = null
    this.fileSha = null
    this.extLint = null
    this.heroesIds = null
    this.heroesTrophies = null
    this.heroesTrophiesReseted = null
    this.starpointsAwarded = null
    this.donationCount = 0

    if (data != null) {
      for (const field of JSON_FIELDS) {
        if (data[field] !== undefined) this[field] = data[field]
      }
    }
  }

  encode (stream) {
    stream.writeVInt(this.id)
    stream.writeInt(this.index)
    stream.writeBoolean(this.isViewed)
    stream.writeInt(this.timePassed)
    stream.writeString(this.messageEntry)
    if (this.id === 83) {
      stream.writeInt(0)
      stream.writeStringReference(this.primaryMessageEntry)
      stream.writeInt(0)
      stream.writeStringReference(this.secondaryMessageEntry)
      stream.writeInt(0)
      stream.writeStringReference(this.buttonMessageEntry)
      stream.writeStringReference(this.fileLocation)
      stream.writeStringReference(this.fileSha)
      stream.writeStringReference(this.extLint)
    }
    if (this.id === 79) {
      const heroesIds = this.heroesIds || []
      stream.writeVInt(heroesIds.length)
      for (let i = 0; i < heroesIds.length; i++) {
        stream.writeVInt(heroesIds[i])
        stream.writeVInt(this.heroesTrophies[i])
        stream.writeVInt(this.heroesTrophiesReseted[i])
        stream.writeVInt(this.starpointsAwarded[i])
      }
    } else {
      stream.writeVInt(0)
    }
    if (this.id === 89) {
      stream.writeVInt(this.donationCount)
    }
  }

  toJSON () {
    const data = {}
    for (const field of JSON_FIELDS) data[field] = this[field]
    return data
  }

  static fromJSON (data) {
    return new Notification(data)
  }
}

module.exports = Notification
