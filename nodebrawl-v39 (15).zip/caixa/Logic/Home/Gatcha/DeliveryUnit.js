class DeliveryUnit {
  constructor (type) {
    this.type = type
    this.drops = []
  }

  addDrop (drop) {
    if (drop != null) {
      this.drops.push(drop)
    }
  }

  getDrops () {
    return this.drops.slice()
  }

  encode (stream) {
    stream.writeVInt(this.type)
    stream.writeVInt(this.drops.length)
    for (const drop of this.drops) {
      drop.encode(stream)
    }
  }
}

module.exports = DeliveryUnit
