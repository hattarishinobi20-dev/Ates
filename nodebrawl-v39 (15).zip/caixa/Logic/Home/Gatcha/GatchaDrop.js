const DataTables = require('../../Data/DataTables')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

class GatchaDrop {
  constructor (type) {
    this.count = 0
    this.dataGlobalId = 0
    this.skinGlobalId = 0
    this.cardGlobalId = 0
    this.pinGlobalId = 0
    this.type = type
    this.isExecuted = false
  }

  doDrop (homeMode) {
    const avatar = homeMode.avatar
    switch (this.type) {
      case 1: {
        const characterData = DataTables.get(16).getDataByGlobalId(this.dataGlobalId)
        if (characterData == null) return
        let cardData = DataTables.get(23).getData(characterData.name + '_unlock')
        if (cardData == null && characterData.name === 'Duplicator') cardData = DataTables.get(23).getDataByGlobalId(23000427)
        if (cardData == null) return
        avatar.unlockHero(characterData.getGlobalId(), cardData.getGlobalId())
        break
      }
      case 2:
        homeMode.home.tokenDoublers += this.count
        break
      case 4:
        avatar.starpowers.push(this.cardGlobalId)
        break
      case 6: {
        const hero = avatar.getHero(this.dataGlobalId)
        if (hero == null) return
        hero.powerPoints += this.count
        break
      }
      case 7:
        avatar.addGold(this.count)
        break
      case 8:
        avatar.addDiamonds(this.count)
        break
      case 9:
        homeMode.home.unlockedSkins.push(this.skinGlobalId)
        break
      case 10:
        homeMode.home.unlockedEmotes.push(this.dataGlobalId)
        break
      case 11:
        homeMode.home.unlockedEmotes.push(this.pinGlobalId !== 0 ? this.pinGlobalId : this.dataGlobalId)
        break
    }
  }

  encode (stream) {
    stream.writeVInt(this.count)
    ByteStreamHelper.writeDataReference(stream, this.dataGlobalId)
    stream.writeVInt(this.type)
    ByteStreamHelper.writeDataReference(stream, this.skinGlobalId)
    ByteStreamHelper.writeDataReference(stream, this.pinGlobalId)
    ByteStreamHelper.writeDataReference(stream, this.cardGlobalId)
    stream.writeVInt(0)
    stream.writeVInt(0)
  }
}

module.exports = GatchaDrop
