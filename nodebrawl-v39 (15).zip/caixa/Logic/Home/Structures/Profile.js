const PlayerDisplayData = require('../../Avatar/Structures/PlayerDisplayData')
const LogicVector2 = require('../../../Titan/Math/LogicVector2')

class Profile {
  constructor () {
    this.displayData = new PlayerDisplayData()
    this.accountId = 0
    this.heroes = []
    this.stats = []
  }

  addStat (key, value) {
    this.stats.push(new LogicVector2(key, value))
  }

  encode (stream) {
    stream.writeVLong(this.accountId)
    stream.writeVInt(0)

    stream.writeVInt(this.heroes.length)
    for (const hero of this.heroes) {
      hero.encode(stream)
    }

    stream.writeVInt(this.stats.length)
    for (const stat of this.stats) {
      stat.encode(stream)
    }

    this.displayData.encode(stream)
  }

  static create (home, avatar) {
    const profile = new Profile()

    profile.accountId = avatar.accountId

    const playerDisplayData = new PlayerDisplayData()
    playerDisplayData.thumbnailId = home.thumbnailId
    playerDisplayData.nameColorId = home.nameColorId
    playerDisplayData.highNameColorId = home.hasPremiumPass || home.nameColorId === 43000012 ? home.nameColorId : 0
    playerDisplayData.name = avatar.name
    profile.displayData = playerDisplayData

    profile.heroes = avatar.heroes.slice()

    profile.addStat(1, avatar.trioWins)
    profile.addStat(2, home.experience)
    profile.addStat(3, avatar.trophies)
    profile.addStat(4, avatar.highestTrophies)
    profile.addStat(5, profile.heroes.length)
    profile.addStat(7, home.thumbnailId)
    profile.addStat(8, avatar.soloWins)
    profile.addStat(11, avatar.duoWins)
    profile.addStat(13, home.powerPlayHighestScore)

    return profile
  }

  static createConsole () {
    const profile = new Profile()

    profile.accountId = 0

    const playerDisplayData = new PlayerDisplayData()
    playerDisplayData.thumbnailId = 28000000
    playerDisplayData.nameColorId = 43000012
    playerDisplayData.highNameColorId = 43000012
    playerDisplayData.name = 'Console'
    profile.displayData = playerDisplayData

    profile.heroes = []

    profile.addStat(1, -1)
    profile.addStat(2, 1257450 + 5020)
    profile.addStat(3, 50000)
    profile.addStat(4, 50000)
    profile.addStat(5, 0)
    profile.addStat(7, 28000000)
    profile.addStat(8, -1)
    profile.addStat(11, -1)
    profile.addStat(13, -1)

    return profile
  }
}

module.exports = Profile
