const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const ByteStreamHelper = require('../../Helper/ByteStreamHelper')
const LogicMath = require('../../../Titan/Math/LogicMath')

const JSON_FIELDS = ['characterId', 'cardId', 'trophies', 'highestTrophies', 'powerPoints', 'powerLevel', 'hasStarpower', 'isNew']

class Hero {
  static UpgradePowerPointsTable = Object.freeze([20, 50, 100, 180, 310, 520, 860, 1410, 2300, 2300 + 1440])
  static UpgradeCostTable = Object.freeze([20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800])
  static MaxPowerLevel = 8

  constructor (characterId, cardId) {
    this.characterId = characterId
    this.cardId = cardId
    this.trophies = 0
    this.highestTrophies = 0
    this.powerPoints = 0
    this.powerLevel = 0
    this.hasStarpower = false
    this.isNew = false
  }

  get characterData () {
    return DataTables.get(DataType.Character).getDataByGlobalId(this.characterId)
  }

  get cardData () {
    return DataTables.get(DataType.Card).getDataByGlobalId(this.cardId)
  }

  addTrophies (trophies) {
    this.trophies += trophies
    this.highestTrophies = LogicMath.max(this.highestTrophies, this.trophies)
  }

  encode (stream) {
    ByteStreamHelper.writeDataReference(stream, this.characterData)
    ByteStreamHelper.writeDataReference(stream, null)
    stream.writeVInt(this.trophies)
    stream.writeVInt(this.highestTrophies)
    stream.writeVInt(this.powerLevel + 1 + (this.hasStarpower ? 1 : 0))
  }

  toJSON () {
    const data = {}
    for (const field of JSON_FIELDS) data[field] = this[field]
    return data
  }

  static fromJSON (data) {
    const hero = new Hero(data.characterId | 0, data.cardId | 0)
    for (const field of JSON_FIELDS) {
      if (data[field] !== undefined) hero[field] = data[field]
    }
    return hero
  }
}

module.exports = Hero
