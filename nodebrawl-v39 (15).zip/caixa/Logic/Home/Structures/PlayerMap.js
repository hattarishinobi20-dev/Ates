const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

class PlayerMap {
  constructor () {
    this.mapId = 0
    this.mapName = null
    this.gmv = 0
    this.mapEnvironmentData = 0
    this.mapData = null
    this.accountId = 0
    this.avatarName = null
  }

  encode (stream) {
    ByteStreamHelper.encodeLogicLong(stream, this.mapId)
    stream.writeString(this.mapName)
    stream.writeVInt(this.gmv)
    stream.writeVInt(54)
    stream.writeVInt(this.mapEnvironmentData)
    if (this.mapData != null) stream.writeBytes(this.mapData, this.mapData.length)
    else stream.writeBytes(null, 1)
    ByteStreamHelper.encodeLogicLong(stream, this.accountId)
    stream.writeString(this.avatarName)
    stream.writeVInt(1)
    stream.writeLong(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
    stream.writeVInt(0)
  }

  toJSON () {
    return {
      mapId: this.mapId,
      mapName: this.mapName,
      gmv: this.gmv,
      mapEnvironmentData: this.mapEnvironmentData,
      mapData: this.mapData != null ? Buffer.from(this.mapData).toString('base64') : null,
      accountId: this.accountId,
      avatarName: this.avatarName
    }
  }

  static fromJSON (data) {
    const map = new PlayerMap()
    if (data == null) return map
    if (data.mapId != null) map.mapId = data.mapId
    if (data.mapName !== undefined) map.mapName = data.mapName
    if (data.gmv != null) map.gmv = data.gmv
    if (data.mapEnvironmentData != null) map.mapEnvironmentData = data.mapEnvironmentData
    if (data.mapData != null) map.mapData = Buffer.from(data.mapData, 'base64')
    if (data.accountId != null) map.accountId = data.accountId
    if (data.avatarName !== undefined) map.avatarName = data.avatarName
    return map
  }
}

module.exports = PlayerMap
