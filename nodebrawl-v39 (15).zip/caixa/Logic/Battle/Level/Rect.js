class Rect {
  constructor (startX, startY, endX, endY) {
    this.startX = startX
    this.startY = startY
    this.endX = endX
    this.endY = endY
  }

  destruct () {
  }

  getStartX () {
    return this.startX
  }

  getStartY () {
    return this.startY
  }

  getEndX () {
    return this.endX
  }

  getEndY () {
    return this.endY
  }

  isInside (x, y) {
    if (x instanceof Rect) {
      const rect = x
      if (this.startX <= rect.startX) {
        if (this.startY <= rect.startY) {
          return this.endX > rect.endX && this.endY > rect.endY
        }
      }

      return false
    }

    if (this.startX <= x) {
      if (this.startY <= y) {
        return this.endX >= x && this.endY >= y
      }
    }

    return false
  }
}

module.exports = Rect
