const fs = require('fs')
const TileMap = require('../TileMap')
const LogicJSONParser = require('../../../../Titan/Json/LogicJSONParser')

let jsonObject = null

class TileMapFactory {
  static getJSONObject () {
    if (jsonObject == null) {
      jsonObject = LogicJSONParser.parseObject(fs.readFileSync('Assets/tilemaps.json', 'utf8').replace(/^\uFEFF/, ''))
    }
    return jsonObject
  }

  static createTileMap (mapName) {
    const obj = TileMapFactory.getJSONObject().getJSONObject(mapName)
    if (obj == null) throw new Error(`TileMapFactory: map ${mapName} not found`)

    return new TileMap(obj.getJSONNumber('WIDTH').getIntValue(),
      obj.getJSONNumber('HEIGHT').getIntValue(),
      obj.getJSONString('Data').getStringValue())
  }

  static createPlayerMap (data) {
    const text = data != null ? String(data) : ''
    const width = 21
    const height = 33
    return new TileMap(width, height, text.padEnd(width * height, '.'))
  }
}

module.exports = TileMapFactory
