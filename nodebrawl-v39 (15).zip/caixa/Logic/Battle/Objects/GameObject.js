const GlobalId = require('../../Data/Helper/GlobalId')
const LogicVector2 = require('../../../Titan/Math/LogicVector2')
const LogicMath = require('../../../Titan/Math/LogicMath')

class GameObject {
  constructor (classIdOrData, instanceId) {
    if (classIdOrData != null && typeof classIdOrData === 'object') {
      this.dataId = GlobalId.createGlobalId(classIdOrData.getClassId(), classIdOrData.getInstanceId())
    } else {
      this.dataId = GlobalId.createGlobalId(classIdOrData, instanceId)
    }

    this.gameObjectManager = null
    this.index = 0
    this.teamIndex = -1
    this.fadeCounter = 10
    this.objectGlobalId = 0
    this.cloneOfObjectGlobalId = 0
    this.isInRealm = false
    this.position = new LogicVector2()
    this.z = 0
    this.renderZ = -1
    this.scale = 100
    this.uid = 0
  }

  get ticksGone () {
    return this.getBattle().getTicksGone()
  }

  tick () {
  }

  encode (bitStream, isOwnObject, visionTeam = 0) {
    const type = this.getObjectType()
    let signedPosition = false

    if (type === 1 && this.projectileData != null) {
      const travelType = this.projectileData.travelType

      if (travelType === 8 || travelType === 11) signedPosition = true
    }

    const x = this.position.x
    const y = this.position.y

    if (type === 3 && this.itemData != null && this.itemData.alignToTiles) {
      bitStream.writePositiveIntMax63(Math.trunc(x / 300))
      bitStream.writePositiveIntMax63(Math.trunc(y / 300))
    } else {
      if (type === 1 && this.projectileData != null && this.projectileData.ignoreLevelBoarder) {
        bitStream.writeIntMax65535(x)
        bitStream.writeIntMax65535(y)
      } else if (signedPosition) {
        bitStream.writeIntMax65535(x)
        bitStream.writeIntMax65535(y)
      } else {
        bitStream.writePositiveVIntMax65535(LogicMath.clamp(x, 0, 65535))
        bitStream.writePositiveVIntMax65535(LogicMath.clamp(y, 0, 65535))
      }
    }

    const z = this.renderZ !== -1 ? this.renderZ : this.z
    bitStream.writePositiveVIntMax65535(LogicMath.clamp(z, 0, 65535))

    bitStream.writePositiveVInt(this.index, 3)

    let fade = this.getFadeCounter()

    if (type === 0) {
      if (isOwnObject) {
        fade = 15
      } else {
        const player = this.getPlayer()
        if (player != null && player.teamIndex === visionTeam) {
          fade = 15
        }
      }
    }

    if (type !== 1) {
      bitStream.writePositiveIntMax15(fade)
    }
  }

  resetEventsOnTick () {
  }

  setForcedVisible () {
    this.fadeCounter = 10
  }

  setForcedInvisible () {
    this.fadeCounter = 0
  }

  getGameObjectManager () {
    return this.gameObjectManager
  }

  incrementFadeCounter () {
    if (this.fadeCounter < 10) this.fadeCounter++
  }

  decrementFadeCounter () {
    if (this.fadeCounter > 0) this.fadeCounter--
  }

  setFadeCounter (counter) {
    this.fadeCounter = counter
  }

  getFadeCounter () {
    return this.fadeCounter
  }

  setPosition (x, y, z) {
    this.position.set(x, y)
    this.z = z
  }

  getPosition () {
    return this.position.clone()
  }

  getPlayer () {
    if (this.gameObjectManager == null) return null
    const battle = this.gameObjectManager.getBattle()
    const teamIndex = Math.trunc(this.index / 16)
    const ownIndex = this.index % 16
    for (const battlePlayer of battle.getPlayers()) {
      if (battlePlayer.teamIndex === teamIndex && battlePlayer.playerIndex === ownIndex) return battlePlayer
    }
    return null
  }

  getViewerPlayer () {
    const battle = this.gameObjectManager.getBattle()

    for (const battlePlayer of battle.getPlayers()) {
      if (battlePlayer.playerIndex === 0) return battlePlayer
    }

    return null
  }

  getGlobalID () {
    return this.objectGlobalId
  }

  getCloneOfObjectGlobalId () {
    return this.cloneOfObjectGlobalId
  }

  setCloneOfObjectGlobalId (i) {
    this.cloneOfObjectGlobalId = i
  }

  getDataId () {
    return this.dataId
  }

  getCardValueForPassiveFromPlayer (a2, a3) {
    if (this.getIndex() === -16) return -1
    const v1 = this.getPlayer()
    if (v1 == null) return -1
    return v1.getCardValueForPassive(a2, a3)
  }

  attachGameObjectManager (gameObjectManager, globalId) {
    this.gameObjectManager = gameObjectManager
    this.objectGlobalId = globalId
  }

  shouldDestruct () {
    return false
  }

  onDestruct () {
  }

  getBattle () {
    return this.gameObjectManager.getBattle()
  }

  getX () {
    return this.position.x
  }

  getY () {
    return this.position.y
  }

  getZ () {
    return this.z
  }

  setIndex (i) {
    this.index = i
  }

  getIndex () {
    return this.index
  }

  getTeamIndex () {
    return Math.trunc(this.index / 16)
  }

  isAlive () {
    return true
  }

  getRadius () {
    return this.scale
  }

  getSize () {
    return 100
  }

  getObjectType () {
    return -1
  }
}

module.exports = GameObject
