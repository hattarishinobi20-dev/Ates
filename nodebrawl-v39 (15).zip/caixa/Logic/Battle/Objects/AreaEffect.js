const GameObject = require('./GameObject')
const GameObjectFactory = require('./GameObjectFactory')
const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const GamePlayUtil = require('../../Util/GamePlayUtil')
const LogicMath = require('../../../Titan/Math/LogicMath')

function teamOf (index) {
  return Math.trunc(index / 16)
}

function getCharacterClass () {
  return require('./Character')
}

function getProjectileClass () {
  return require('./Projectile')
}

class AreaEffect extends GameObject {
  constructor (dataOrClassId, instanceId) {
    super(dataOrClassId, instanceId)

    this.source = null
    this.ticksElapsed = 0
    this.damage = 0
    this.normalDMG = 0
    this._alreadyDamagedList = []
    this.skillType = 0
    this.deployedTick = 0
    this.endingTick = 0
    this.bulletAngle = 0
    this.bulletDelta = 0
    this.stun = 0
    this.effectTimer = 0
    this.lifeTimeConsumedPercent = 0
    this.shouldBeDestructed = false
    this.canHealOwner = false
    this.skinAreaEffectData = null
    this.cantPushback = false
    this.aoeDot = 0
    this.isActive = false
    this.displayScale = 0
    this.preyOnTheWeakDamage = 0
    this.preyOnTheWeakPercent = 0
    this.payback = 0
    this.lastAddFrozenTick = 0
    this.kohUID = 0
    this.radius = 0

    if (dataOrClassId != null && typeof dataOrClassId === 'object') {
      this.areaEffectData = dataOrClassId
      this.skinAreaEffectData = dataOrClassId

      if (this.areaEffectData.parentAreaEffectForSkin) {
        const parent = DataTables.get(DataType.AreaEffect).getData(this.areaEffectData.parentAreaEffectForSkin)
        if (parent != null) this.areaEffectData = parent
      }

      if (!this.areaEffectData.delayFirstTick) this.effectTimer = 20
      this.damage = this.areaEffectData.damage
    } else {
      this.areaEffectData = DataTables.get(DataType.AreaEffect).getData(instanceId)
      this.skinAreaEffectData = this.areaEffectData
    }
  }

  get mapHeight () {
    return this.gameObjectManager.getBattle().getTileMap().logicHeight
  }

  get mapWidth () {
    return this.gameObjectManager.getBattle().getTileMap().logicWidth
  }

  get effectData () {
    return DataTables.get(DataType.AreaEffect).getDataByGlobalId(this.dataId)
  }

  get slowStrength () {
    return this.areaEffectData.freezeStrength
  }

  setPreyOnTheWeak (percent, damage) {
    this.preyOnTheWeakPercent = percent
    this.preyOnTheWeakDamage = damage
  }

  getDamage (a2) {
    if (this.source != null && this.skillType <= 2) {
      let d = this.damage
      d += Math.trunc(d * this.source.getDamageBuffTemporary() / 100)
      d -= Math.trunc(d * this.source.cripplePercent / 100)
      return d + a2
    }

    return this.damage
  }

  isInsideRange (character, radius) {
    const range = radius + character.characterData.collisionRadius - 50
    const dx = character.getX() - this.getX()
    const dy = character.getY() - this.getY()

    if (LogicMath.abs(dx) > range || LogicMath.abs(dy) > range) return false
    return dx * dx + dy * dy <= range * range
  }

  getCharacters () {
    return this.gameObjectManager.getGameObjects().filter(gameObject => gameObject.getObjectType() === 0)
  }

  trigger () {
    const data = this.areaEffectData
    const ticks = this.ticksGone

    this.deployedTick = ticks
    this.ticksElapsed = ticks
    this.endingTick = Math.trunc(data.timeMs / 50) + ticks

    const v5 = data.type

    if (v5 === 'Damage' || v5 === 'Stun' || (v5 === 'BulletExplosion' && data.name === 'ClusterBombExplosion') || v5 === 'HealAndDamage' || v5 === 'SetOnFire' || v5 === 'SetOnFireIce' || v5 === 'Pushback' || v5 === 'DamageAndTag' || v5 === 'PoisonWillow') {
      const tileMap = this.gameObjectManager.getBattle().getTileMap()
      const source = this.source

      let v219 = -1
      if (source != null && source.getCardValueForPassive('pushback_self', 1) >= 0) v219 = data.pushbackStrengthSelf

      if (data.name === 'RuffsSupplyExplosion') {
        const itemData = DataTables.get(DataType.Item).getData('RuffsBuff')
        const item = GameObjectFactory.createGameObjectByData(itemData)

        if (item != null) {
          item.setPosition(this.getX(), this.getY(), 0)
          item.setIndex(this.getIndex())
          this.gameObjectManager.addGameObject(item)
        }
      }

      const v197 = v5 === 'Stun' || v5 === 'SetOnFire' || v5 === 'Pushback' || v5 === 'SetOnFireIce'

      if (this.radius === 0) this.radius = data.radius

      for (const v10 of this.getCharacters()) {
        if (!v10.isAlive()) continue
        if (v10.characterData.isCarryable()) continue

        const immune = v10.isImmuneAndBulletsGoThrough(this.isInRealm)

        if (immune || (v10.getIndex() !== -16 && teamOf(v10.getIndex()) === teamOf(this.getIndex()))) {
          if (v219 < 1 || source !== v10 || immune) continue
        }

        if (!this.isInsideRange(v10, this.radius)) continue

        let v30 = this.getDamage(0)

        if (v5 === 'PoisonWillow') {
          v10.applyPoison(this.getIndex() % 16, v30, this.normalDMG, true, source, 4)
        }

        if (data.name === 'VoodooAttackWater') {
          if (!v10.isImmuneAndBulletsGoThrough(this.isInRealm)) v10.giveSpeedSlowerBuff(-this.slowStrength, 35)
        }

        if (!v197 && source !== v10) {
          if (source != null && source.getCardValueForPassive('explosion_damage_increase', 1) >= 1 && data.name === 'SpawnerDudeExplosion') {
            if (source.chargeUp >= 2000) {
              v30 = Math.round(v30 + (v30 * 0.4))
            }
          }

          if (v5 === 'PoisonWillow') v30 = 0

          if (v10.causeDamage(source, v30, this.normalDMG, this.skillType === 2, data, true)) {
            if (data.name.startsWith('StickyBomb') && source != null) {
              source.chargeUlti(650, false, true, this.getPlayer(), source)
            }

            if (this.stun >= 1) v10.triggerStun(this.stun, false)

            if (this.getCardValueForPassiveFromPlayer('ulti_area_slow', 1) >= 1) {
              v10.giveSpeedSlowerBuff(-this.getCardValueForPassiveFromPlayer('ulti_area_slow', 1), this.getCardValueForPassiveFromPlayer('ulti_area_slow', 0))
            }
          }
        }

        if (v5 === 'DamageAndTag') {
          if (source != null) v10.setCharacterTagged(0, this.ticksGone, source)
        }

        if (v5 === 'Stun') {
          v10.triggerStun(data.customValue, false)
        }

        if (data.name === 'LeaperUltiAreaExplosion' && source != null) {
          if (source.characterData.name === 'Skater') {
            v10.triggerStun(40, false)
          }
        }

        if (this.skinAreaEffectData.type === 'SetOnFireIce') {
          v10.applyPoison(this.getIndex() % 16, v30, this.normalDMG, true, source, 8)
        } else if (v5 === 'SetOnFire') {
          v10.applyPoison(this.getIndex() % 16, v30, this.normalDMG, true, source, 2)
        }

        let v37

        if (source === v10) {
          v37 = v219
          if (v219 <= 0) continue
        } else {
          v37 = data.pushbackStrength
          if (!v37) continue
        }

        if (this.cantPushback) continue

        if (data.pushbackDeadzone >= 1) {
          const Character = getCharacterClass()
          const v206 = Character.transformPushBackStrengthToLength(v37)
          const v43 = GamePlayUtil.getDistanceBetween(this.getX(), this.getY(), v10.getX(), v10.getY())
          const v44 = v43 - data.pushbackDeadzone

          if (v44 < v206) {
            const v46 = LogicMath.max(150, LogicMath.abs(v44))
            const v47 = LogicMath.sign(v44) * v46
            v37 = Character.transformPushBackLengthToStrength(v47) * LogicMath.sign(v37)
          }
        }

        if (source != null && source !== v10 && source.getCardValueForPassive('stun_trap', 1) >= 0) {
          v10.triggerStun(source.getCardValueForPassive('stun_trap', 1), false)
          continue
        }

        v10.triggerPushback(this.getX(), this.getY(), v37, v37 > 0, 1, source === v10, false, false, false, false, false, data.canStopGrapple, 0)

        if (source === v10) {
          v10.viusalChargeType = 3
        }
      }

      tileMap.destroyEnvironment(this.getX(), this.getY(), data.radius, !data.destroysEnvironment)

      if (v5 !== 'HealAndDamage') return
    }

    if (data.type === 'Heal' || data.type === 'HealRegen' || data.type === 'HealAndDamage') {
      for (const v61 of this.getCharacters()) {
        if (teamOf(v61.getIndex()) !== teamOf(this.getIndex())) continue
        if (!v61.isAlive() || !v61.characterData.isHero()) continue
        if (!(this.canHealOwner || v5 === 'HealAndDamage' || this.source !== v61)) continue
        if (!this.isInsideRange(v61, data.radius)) continue

        if (data.type === 'Heal') {
          v61.heal(this.getIndex(), -this.getDamage(0), true, data)
        } else if (v5 === 'HealAndDamage') {
          v61.heal(this.getIndex(), this.getDamage(0), true, data)
        } else if (data.type === 'HealRegen') {
          v61.addExtraHealthRegen(-this.getDamage(0), data.customValue, this.source != null ? this.source.getIndex() : -1)
        }
      }

      return
    }

    if (data.type === 'WallSpawn') {
      const x = Math.trunc(this.getX() / 300)
      const y = Math.trunc(this.getY() / 300)
      const tileMap = this.getBattle().getTileMap()
      const radius = Math.trunc(data.radius / 300)
      const xMin = LogicMath.clamp(x - radius, 0, tileMap.width - 1)
      const yMin = LogicMath.clamp(y - radius, 0, tileMap.height - 1)
      const xMax = LogicMath.clamp(x + radius, 0, tileMap.width - 1)
      const yMax = LogicMath.clamp(y + radius, 0, tileMap.height - 1)

      for (let i = xMin; i <= xMax; i++) {
        for (let j = yMin; j <= yMax; j++) {
          const tile = tileMap.getTile(i, j, true)
          if (tile == null) continue

          if (GamePlayUtil.getDistanceSquaredBetween(tile.x + 150, tile.y + 150, x * 300 + 150, y * 300 + 150) < data.radius * data.radius) {
            const current = tile.replacement != null ? tile.replacement : tile

            if (!current.data.blocksMovement) {
              tileMap.placeNewTile(i, j, this.skinAreaEffectData.customValue, this.getIndex())
            }
          }
        }
      }
    }

    if (data.type === 'PetrolDistribution') {
      const tileMap = this.getBattle().getTileMap()
      const v108 = data.radius
      const v110 = Math.trunc(v108 / 300)
      const v112 = Math.trunc(this.getX() / 300)
      const v115 = Math.trunc(this.getY() / 300)
      const v236 = v112 * 300 + 150
      const v231 = v115 * 300 + 150
      const v116 = v108 * v108

      for (let v113 = v112 - v110; v113 <= v112 + v110; v113++) {
        for (let v118 = v115 - v110; v118 <= v115 + v110; v118++) {
          if (v113 < 0 || v118 < 0 || v113 >= tileMap.width || v118 >= tileMap.height) continue

          const v119 = tileMap.getTile(v113, v118, true)
          const v120 = v113 * 300 + 150
          const v121 = v118 * 300 + 150

          if (GamePlayUtil.getDistanceSquaredBetween(v236, v231, v120, v121) < v116 && !(v119.data.blocksMovement && !v119.data.blocksProjectiles && !v119.data.isDestructibleNormalWeapon)) {
            const petrol = this.getBattle().addPetrol(v113, v118, 150, this.getIndex(), teamOf(this.getIndex()), 0)
            petrol.slowing = this.source != null ? this.source.getGearBoost(13) : 0
          }
        }
      }

      return
    }

    if (v5 === 'BulletExplosion') {
      let v127 = data.customValue
      let v218 = data.bulletExplosionBullet ? DataTables.getProjectileByName(data.bulletExplosionBullet) : null

      if (this.skillType === 2 && data.name === 'CrowUltiKnifes') {
        const v128 = this.getPlayer()

        if (v128 != null && v128.skinId !== 0) {
          const skinData = DataTables.get(DataType.Skin).getDataByGlobalId(v128.skinId)
          const skinConfData = skinData != null && skinData.conf ? DataTables.get(DataType.SkinConf).getData(skinData.conf) : null
          const ultiProjectile = skinConfData != null && skinConfData.ultiProjectile ? DataTables.get(DataType.Projectile).getData(skinConfData.ultiProjectile) : null
          if (ultiProjectile != null) v218 = ultiProjectile
        }
      }

      let v131 = data.bulletExplosionBulletDistance
      if (this.source != null && this.skillType !== 2) v131 += this.source.getGearBoost(18)

      let v208
      let v213

      if (this.bulletAngle < 0) {
        v208 = 0
        v213 = 0
      } else {
        const v134 = 26 * this.bulletDelta
        v213 = LogicMath.getRotatedX(v134, 0, this.bulletAngle)
        v208 = LogicMath.getRotatedY(v134, 0, this.bulletAngle)
      }

      let v135
      let v136

      if (v218 != null && !v218.indirect) {
        v136 = 0
        v135 = 0
      } else {
        v135 = 15
        v136 = 1
      }

      let v190 = -1
      let v191 = -1

      if (this.getIndex() !== -16 && this.skillType === 1) {
        const player = this.getPlayer()

        if (player != null) {
          v191 = player.getCardValueForPassive('curve_ball', 1)
          if (v191 >= 0) v190 = player.getCardValueForPassive('curve_ball', 0)
        }
      }

      if (v127 >= 1) {
        const list = []
        const v193 = 100 * v131
        const v192 = Math.trunc(360 / v127)
        const battle = this.gameObjectManager.getBattle()

        for (let v223 = 0; v127 > 0; v127--, v223++) {
          const v140 = LogicMath.normalizeAngle360(v135 + v192 * v223)
          const v142 = LogicMath.getRotatedX(v193, 0, v140) + this.getX()
          const v144 = LogicMath.getRotatedY(v193, 0, v140) + this.getY()
          let v145

          if (v136 > 0) {
            v145 = LogicMath.sqrt(200000)
          } else {
            let v146 = v142 + v213 - this.getX()
            let v147 = v144 + v208 - this.getY()
            const v148 = LogicMath.sqrt(v146 * v146 + v147 * v147)

            if (v148 > 0) {
              v146 = Math.trunc(200 * v146 / v148)
              v147 = Math.trunc(200 * v147 / v148)
            }

            const v154 = LogicMath.clamp(this.getX() + v146, 1, this.mapWidth - 2)
            const v157 = LogicMath.clamp(this.getY() + v147, 1, this.mapHeight - 2)
            v145 = 0
            const v162 = battle.getTileMap().getTile(Math.trunc(v154 / 300), Math.trunc(v157 / 300), true)
            if (v162 != null && !v162.isDestructed() && v162.data.blocksProjectiles) continue
          }

          if (v218 == null) continue

          let v163 = v144 + v208
          let v164 = v142 + v213

          if (v190 >= 0) {
            let v165 = v164 - this.getX()
            let v166 = v163 - this.getY()
            const v167 = LogicMath.sqrt(v165 * v165 + v166 * v166)

            if (v167 > 0) {
              v165 = Math.trunc(v165 * v190 / v167)
              v166 = Math.trunc(v166 * v190 / v167)
            }

            v163 += v166
            v164 += v165
          }

          const Projectile = getProjectileClass()
          const v174 = Projectile.shootProjectile(-1, -1, this.source, this, v218, v164, v163, this.getDamage(0), this.normalDMG, 0, false, v145, battle, 0, this.skillType)
          if (v174 == null) continue

          list.push(v174)
          v174.setPreyOnTheWeak(this.preyOnTheWeakPercent, this.preyOnTheWeakDamage)
          if (v191 >= 0) v174.curving = v191
        }

        if (data.name === 'CrossBomberClusterExplosion' || data.name === 'CrossBomberUltiClusterExplosion') {
          for (const projectile of list) {
            for (const projectile1 of list) {
              if (projectile === projectile1) continue
              projectile.linkedProjectileGIDs.push(projectile1.getGlobalID())
            }
          }
        }
      }
    }
  }

  static getRangeAgainst (a1, a2) {
    return a1.radius + a2.characterData.collisionRadius - 50
  }

  spawnTriggeredArea (name) {
    const areaData = DataTables.get(DataType.AreaEffect).getData(name)
    if (areaData == null) return
    const area = new AreaEffect(areaData)
    area.setPosition(this.getX(), this.getY(), 0)
    area.setIndex(-16)
    area.damage = areaData.damage
    this.getBattle().getGameObjectManager().addGameObject(area)
    area.trigger()
  }

  spawnKingOfHillComplete (team, state) {
    const completeData = DataTables.get(DataType.AreaEffect).getData('KingOfHillAreaComplete')
    if (completeData == null) return
    const battle = this.getBattle()
    const completeEffect = new AreaEffect(completeData)
    completeEffect.setPosition(this.getX(), this.getY(), 0)

    if (battle.getKOHZoneCount() === 1) {
      completeEffect.setIndex(team * 16)
    } else if (battle.getKOHZoneCount() === 2) {
      completeEffect.setIndex(team * 16)
      if (team === 0) state.canContinueUpTeam0 = false
      else state.canContinueUpTeam1 = false
    }

    this.gameObjectManager.addGameObject(completeEffect)
    completeEffect.trigger()
  }

  tick () {
    const data = this.areaEffectData
    const v3 = this.ticksGone
    const lifeTime = this.endingTick - this.deployedTick

    this.lifeTimeConsumedPercent = lifeTime > 0 ? Math.trunc(Math.fround(Math.fround(1000 / lifeTime) * (v3 - this.deployedTick))) : 1000

    if (v3 >= this.endingTick) {
      this.shouldBeDestructed = true

      if (data.chainAreaEffect) {
        const v21 = GameObjectFactory.createGameObjectByData(DataTables.getAreaEffectByName(data.chainAreaEffect))

        if (v21 != null) {
          v21.setPosition(this.getX(), this.getY(), this.getZ())
          v21.setIndex(this.getIndex())
          v21.setSource(this.source, this.skillType)

          if (this.damage > 0) {
            v21.damage = this.damage
            v21.normalDMG = this.normalDMG
          }

          this.gameObjectManager.addGameObject(v21)
          v21.trigger()
        }
      }

      return
    }

    if (data.type === 'Slippery') {
      this.damage = 38

      for (const c of this.getCharacters()) {
        if (teamOf(c.getIndex()) === teamOf(this.getIndex())) continue
        if (!c.characterData.isHero()) continue
        if (this.position.getDistance(c.getPosition()) > data.radius) continue
        c.addFrozen(0.7, this.source)
        if (this.slowStrength >= 1) c.giveSpeedSlowerBuff(-this.slowStrength, 12)
        c.slipperyTicks = Math.max(c.slipperyTicks, 12)
      }
    }

    const type = data.type

    if (type === 'Vision' || type === 'Dot' || type === 'Hot' || type === 'DelayedDamage' || type === 'DamageBoost' || type === 'Slow' || type === 'HotAndDot') {
      let v10
      if (type === 'Vision') v10 = 1
      else if (type === 'Slow') v10 = 10
      else v10 = 20

      this.effectTimer++

      const delayedTick = this.endingTick - Math.trunc(data.timeMs / 50) + Math.trunc(data.customValue / 50)

      if ((type !== 'DelayedDamage' && this.effectTimer >= v10) || (type === 'DelayedDamage' && this.ticksGone === delayedTick)) {
        const v148 = this.getDamage(0)
        this.isActive = true

        const v151 = this.source != null ? this.source.getCardValueForPassive('cactus_heal', 1) : -1
        const v57 = teamOf(this.getIndex())

        for (const v56 of this.getCharacters()) {
          if (v56.characterData.isCarryable()) continue

          const sameTeam = teamOf(v56.getIndex()) === v57
          let v58 = false
          let v60 = false

          if (!sameTeam) {
            v58 = type === 'Dot' || type === 'DelayedDamage' || type === 'Slow' || this.aoeDot > 0 || type === 'HotAndDot'
          }

          if ((sameTeam || v57 === -1) && (type === 'DamageBoost' || type === 'Hot' || type === 'HotAndDot')) {
            v60 = v56.characterData.isHero() && sameTeam
          }

          const v61 = v151 !== -1 && (type === 'Dot' || type === 'HotAndDot') && this.getIndex() === v56.getIndex()

          if (!v56.isAlive() || v56.isImmuneAndBulletsGoThrough(this.isInRealm) || v56.characterData.isTrain()) continue
          if (!v58 && !v60 && !v61) continue
          if (!this.isInsideRange(v56, data.radius)) continue

          if (type === 'Dot' || type === 'DelayedDamage' || (type === 'HotAndDot' && (!sameTeam || v61))) {
            const isSelf = v56.getIndex() === this.getIndex()

            if (isSelf) {
              v56.heal(v56.getIndex(), v151, true, data)
            } else if (v56.causeDamage(this.source, v148, this.normalDMG, this.skillType === 2, data, true)) {
              if (this.slowStrength >= 1) {
                let fs = -this.slowStrength
                if (this.source != null && this.source.getGearBoost(10) >= 1) {
                  fs += Math.trunc(fs * this.source.getGearBoost(10) / 100)
                }
                v56.giveSpeedSlowerBuff(fs, data.freezeTicks)
              }

              if (data.sameAreaEffectCanNotDamageMs >= 1) {
                v56.setImmunity(this.getIndex(), data.sameAreaEffectCanNotDamageMs, data)
              }
            }

            if (data.pushbackStrength >= 1 && !isSelf) {
              v56.triggerPushback(this.getX(), this.getY(), data.pushbackStrength, true, 1, false, false, false, false, false, false, false, 0)
            }
          } else if (type === 'Slow') {
            if (!v56.isImmuneAndBulletsGoThrough(this.isInRealm)) v56.giveSpeedSlowerBuff(-this.slowStrength, data.freezeTicks)
          } else if (type === 'Hot' || type === 'HotAndDot') {
            if (sameTeam || this.aoeDot < 1) {
              if (v56.heal(this.getIndex(), -this.getDamage(0), true, data) && data.sameAreaEffectCanNotDamageMs >= 1) {
                v56.setImmunity(this.getIndex(), data.sameAreaEffectCanNotDamageMs, data)
              }
            } else {
              v56.causeDamage(this.source, this.aoeDot, 0, this.skillType === 2, data, true)
            }
          } else if (type === 'Vision') {
            v56.setForcedVisible()
          } else {
            v56.giveDamageBuff2(this.getDamage(0), 21)
          }
        }

        if (type === 'Dot' || type === 'DelayedDamage') {
          this.gameObjectManager.getBattle().getTileMap().destroyEnvironment(this.getX(), this.getY(), data.radius, !data.destroysEnvironment)
        }

        this.effectTimer = 0
      }

      return
    }

    if (type === 'SmokeScreen') {
      this.effectTimer++

      for (const c of this.getCharacters()) {
        if (teamOf(c.getIndex()) !== teamOf(this.getIndex())) continue
        if (!c.characterData.isHero()) continue
        if (this.position.getDistance(c.getPosition()) > data.radius) continue
        c.setInvisible()
        if (this.damage < 0 && this.effectTimer >= 20) c.heal(this.getIndex(), -this.damage, true, data)
      }

      const crippleBoost = this.source != null ? this.source.getGearBoost(12) : 0

      if (this.damage > 0 || crippleBoost >= 1) {
        for (const c of this.getCharacters()) {
          if (teamOf(c.getIndex()) === teamOf(this.getIndex())) continue
          if (c.characterData.isCarryable()) continue
          if (c.isImmuneAndBulletsGoThrough(this.isInRealm)) continue
          if (this.position.getDistance(c.getPosition()) > data.radius) continue
          if (this.effectTimer >= 20 && this.damage > 0) c.causeDamage(this.source, this.damage, 0, false, data, true)
          if (crippleBoost >= 1) c.cripple(crippleBoost, 2)
        }
      }

      if (this.effectTimer >= 20) this.effectTimer = 0
    }

    if (data.name === 'ExplosionSpawn') {
      if (this.ticksElapsed + 48 === this.ticksGone) {
        this.spawnTriggeredArea('EventExplosion')
      }
    }

    if (type === 'InvasionIndicator') {
      if (this.ticksElapsed + 99 === this.ticksGone) {
        this.spawnTriggeredArea('InvasionSpawnExplosion')

        const allowedMinions = ['InvasionMeleeEnemy', 'InvasionFastMeleeEnemy', 'InvasionRangedEnemy']
        const minionName = this.ticksGone >= 1500 && this.ticksGone <= 1650 ? 'InvasionBossEnemy' : allowedMinions[Math.floor(Math.random() * allowedMinions.length)]
        const minionData = DataTables.getCharacterByName(minionName)

        if (minionData != null) {
          const Character = getCharacterClass()
          const melee = new Character(minionData)
          this.gameObjectManager.addGameObject(melee)
          melee.setIndex(-16)
          melee.setPosition(this.getX(), this.getY(), 0)
        }
      }
    }

    if (data.name === 'KingOfHillArea') {
      this.tickKingOfHill()
    }

    if (type === 'SpeedBuff') {
      for (const v112 of this.getCharacters()) {
        if (!v112.isAlive()) continue
        const v113 = data.isPersonal ? v112.getIndex() === this.getIndex() : teamOf(v112.getIndex()) === teamOf(this.getIndex())
        if (!v113 || !v112.characterData.isHero()) continue
        const dx = v112.getX() - this.getX()
        const dy = v112.getY() - this.getY()

        if (dx * dx + dy * dy <= data.radius * data.radius) {
          v112.giveSpeedFasterBuff(data.damage, data.customValue, false)
        }
      }
    }

    if (type === 'AllyChargeSuper' || type === 'EnemyChargeSuper') {
      if (this.source != null) this.setFadeCounter(this.source.getFadeCounter())
      this.effectTimer++

      if (this.effectTimer % 20 === 0) {
        for (const v112 of this.getCharacters()) {
          if (!v112.isAlive() || v112 === this.source) continue
          let v113 = teamOf(v112.getIndex()) === teamOf(this.getIndex())
          if (type === 'EnemyChargeSuper') v113 = !v113
          if (!v113 || !v112.characterData.isHero()) continue
          const dx = v112.getX() - this.getX()
          const dy = v112.getY() - this.getY()

          if (dx * dx + dy * dy <= data.radius * data.radius) {
            if (this.source != null) this.source.chargeUlti(data.customValue, false, true, this.getPlayer(), this.source)
          }
        }

        this.effectTimer = 0
      }
    }
  }

  tickKingOfHill () {
    const battle = this.getBattle()
    const count = battle.getKOHZoneCount()
    let upTicks = 15

    switch (count) {
      case 1:
        upTicks = 15
        break
      case 2:
        upTicks = 10
        break
      case 3:
        upTicks = 5
        break
    }

    if (battle.getTicksGone() <= 120) return

    const state = battle.getZoneByUID(this.kohUID)
    if (state == null) return

    const areaEffect = DataTables.get(DataType.AreaEffect).getData('KingOfHillArea')
    const captureData = DataTables.get(DataType.AreaEffect).getData('KingOfHillAreaCapture')
    const gaugeData = DataTables.get(DataType.AreaEffect).getData('KingOfHillAreaGauge')
    const gom = this.gameObjectManager

    if (!state.canContinueUpTeam0 && !state.hillCompleteEffectSpawnedTeam0) {
      gom.removeGameObject(state.currentCaptureEffectTeam0)
      gom.removeGameObject(state.gaugeTeam0Effect)
      this.spawnKingOfHillComplete(0, state)
      state.hillCompleteEffectSpawnedTeam0 = true
    }

    if (!state.canContinueUpTeam1 && !state.hillCompleteEffectSpawnedTeam1) {
      gom.removeGameObject(state.currentCaptureEffectTeam1)
      gom.removeGameObject(state.gaugeTeam1Effect)
      this.spawnKingOfHillComplete(1, state)
      state.hillCompleteEffectSpawnedTeam1 = true
    }

    const playersInZone = this.getCharacters()
      .filter(c => c.characterData.isHero())
      .filter(c => this.position.getDistance(c.getPosition()) <= areaEffect.radius)
    const team0Players = playersInZone.filter(p => teamOf(p.getIndex()) === 0)
    const team1Players = playersInZone.filter(p => teamOf(p.getIndex()) === 1)

    if (captureData != null) {
      if (team0Players.length > 0 && !state.captureEffectActiveTeam0 && !state.hillCompleteEffectSpawnedTeam0 && state.canContinueUpTeam0) {
        state.currentCaptureEffectTeam0 = new AreaEffect(captureData)
        state.currentCaptureEffectTeam0.setPosition(this.getX(), this.getY(), 0)
        state.currentCaptureEffectTeam0.setIndex(0)
        gom.addGameObject(state.currentCaptureEffectTeam0)
        state.currentCaptureEffectTeam0.trigger()
        state.captureEffectActiveTeam0 = true
      } else if (team0Players.length === 0 && state.captureEffectActiveTeam0 && state.canContinueUpTeam0) {
        gom.removeGameObject(state.currentCaptureEffectTeam0)
        state.currentCaptureEffectTeam0 = null
        state.captureEffectActiveTeam0 = false
      }

      if (team1Players.length > 0 && !state.captureEffectActiveTeam1 && !state.hillCompleteEffectSpawnedTeam1 && state.canContinueUpTeam1) {
        state.currentCaptureEffectTeam1 = new AreaEffect(captureData)
        state.currentCaptureEffectTeam1.setPosition(this.getX(), this.getY(), 0)
        state.currentCaptureEffectTeam1.setIndex(16)
        gom.addGameObject(state.currentCaptureEffectTeam1)
        state.currentCaptureEffectTeam1.trigger()
        state.captureEffectActiveTeam1 = true
      } else if (team1Players.length === 0 && state.captureEffectActiveTeam1 && state.canContinueUpTeam1) {
        gom.removeGameObject(state.currentCaptureEffectTeam1)
        state.currentCaptureEffectTeam1 = null
        state.captureEffectActiveTeam1 = false
      }
    }

    if (gaugeData != null) {
      if (!state.gaugeTeam0 && state.gaugeTeam0Effect == null) {
        state.gaugeTeam0Effect = new AreaEffect(gaugeData)
        state.gaugeTeam0Effect.setPosition(this.getX(), this.getY(), 0)
        state.gaugeTeam0Effect.setIndex(0)
        gom.addGameObject(state.gaugeTeam0Effect)
        state.gaugeTeam0 = true
      }

      if (!state.gaugeTeam1 && state.gaugeTeam1Effect == null) {
        state.gaugeTeam1Effect = new AreaEffect(gaugeData)
        state.gaugeTeam1Effect.setPosition(this.getX(), this.getY(), 0)
        state.gaugeTeam1Effect.setIndex(16)
        gom.addGameObject(state.gaugeTeam1Effect)
        state.gaugeTeam1 = true
      }
    }

    if (state.gaugeTeam0Effect != null && state.gaugeTeam0) {
      state.gaugeTeam0Effect.trigger()
      state.gaugeTeam0Effect.payback = count === 1 ? battle.getZone1Score() : state.zonePercentage
    }

    if (state.gaugeTeam1Effect != null && state.gaugeTeam1) {
      state.gaugeTeam1Effect.trigger()
      state.gaugeTeam1Effect.payback = count === 1 ? battle.getZone2Score() : state.zonePercentage
    }

    const currentTicks = battle.getTicksGone()

    if (team0Players.length > 0 && currentTicks >= state.lastUpTickTeam0 + upTicks && state.canContinueUpTeam0) {
      battle.addScoreTo1Zone()
      state.lastUpTickTeam0 = currentTicks
      if (count !== 1) state.zonePercentage += 2
    }

    if (team1Players.length > 0 && currentTicks >= state.lastUpTickTeam1 + upTicks && state.canContinueUpTeam1) {
      battle.addScoreTo2Zone()
      state.lastUpTickTeam1 = currentTicks
      if (count !== 1) state.zonePercentage += 2
    }

    const removeAll = () => {
      gom.removeGameObject(state.currentCaptureEffectTeam0)
      gom.removeGameObject(state.currentCaptureEffectTeam1)
      gom.removeGameObject(state.gaugeTeam0Effect)
      gom.removeGameObject(state.gaugeTeam1Effect)
    }

    if ((battle.getZone1Score() >= 100 || state.zonePercentage >= 100) && !state.hillCompleteEffectSpawnedTeam0) {
      removeAll()
      this.spawnKingOfHillComplete(0, state)
      state.hillCompleteEffectSpawnedTeam0 = true
    }

    if ((battle.getZone2Score() >= 100 || state.zonePercentage >= 100) && !state.hillCompleteEffectSpawnedTeam1) {
      removeAll()
      this.spawnKingOfHillComplete(1, state)
      state.hillCompleteEffectSpawnedTeam1 = true
    }
  }

  encode (bitStream, isOwnObject, visionTeam) {
    super.encode(bitStream, isOwnObject, visionTeam)

    bitStream.writePositiveIntMax127(0)

    if (this.areaEffectData.type === 'DelayedDamage') bitStream.writeBoolean(this.isActive)
    if (this.areaEffectData.playbackType === 4) bitStream.writePositiveIntMax127(this.payback)

    const hasDisplayScale = this.displayScale !== 0
    bitStream.writeBoolean(hasDisplayScale)
    if (hasDisplayScale) bitStream.writePositiveVIntMax65535OftenZero(this.displayScale)

    bitStream.writePositiveVIntMax65535OftenZero(0)
  }

  setSource (source, skillType) {
    this.source = source
    this.skillType = skillType
  }

  setDamage (damage) {
    this.damage = damage
  }

  getRadius () {
    return this.effectData.radius
  }

  shouldDestruct () {
    return this.shouldBeDestructed
  }

  getObjectType () {
    return 2
  }
}

module.exports = AreaEffect
