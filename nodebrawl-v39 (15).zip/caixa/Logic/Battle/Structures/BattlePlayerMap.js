const ByteStreamHelper = require('../../Helper/ByteStreamHelper')

class BattlePlayerMap {
  constructor (map) {
    this.mapId = map.mapId
    this.mapName = map.mapName
    this.mapEnvironmentData = map.mapEnvironmentData
    this.accountId = map.accountId
    this.avatarName = map.avatarName
    this.mapData = map.mapData
    this.gmv = map.gmv
  }

  encode (stream) {
    ByteStreamHelper.encodeLogicLong(stream, this.mapId)
    stream.writeString(this.mapName)
    stream.writeVInt(this.gmv)
    stream.writeVInt(54)
    stream.writeVInt(this.mapEnvironmentData)
    if (this.mapData != null) stream.writeBytes(this.mapData, this.mapData.length)
    else stream.writeBytes(null, 1)
    ByteStreamHelper.encodeLogicLong(stream, this.accountId)
    stream.writeString(this.avatarName)
    stream.writeVInt(1)
    stream.writeVInt(-1)
  }
}

module.exports = BattlePlayerMap
