class TickDamage {
  constructor (tick = 0, damage = 0) {
    this.tick = tick
    this.damage = damage
  }
}

module.exports = TickDamage
