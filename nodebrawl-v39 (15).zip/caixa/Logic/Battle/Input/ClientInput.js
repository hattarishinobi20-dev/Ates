class ClientInput {
  constructor () {
    this.index = 0
    this.type = 0
    this.x = 0
    this.y = 0
    this.autoAttack = false
    this.autoAttackTarget = 0
    this.emoteIndex = 0
    this.ownerSessionId = 0
  }

  decode (stream) {
    this.index = stream.readPositiveInt(15)
    this.type = stream.readPositiveInt(4)
    this.x = stream.readInt(15)
    this.y = stream.readInt(15)
    this.autoAttack = stream.readBoolean()
    if (this.type === 9) {
      this.emoteIndex = stream.readPositiveInt(3)
    }
    if (this.autoAttack) {
      if (stream.readBoolean()) {
        this.autoAttackTarget = stream.readPositiveInt(14)
      }
    }
  }
}

module.exports = ClientInput
