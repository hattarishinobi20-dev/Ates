const DataTables = require('../../Data/DataTables')
const DataType = require('../../Data/DataType')
const LogicMath = require('../../../Titan/Math/LogicMath')
const LogicVector2 = require('../../../Titan/Math/LogicVector2')
const GamePlayUtil = require('../../Util/GamePlayUtil')
const Debugger = require('../../../Titan/Debug/Debugger')

class Skill {
  constructor (globalId, isUltiSkill, character = null) {
    this.skillId = globalId
    this.isUltiSkill = isUltiSkill
    this.character = character

    const maxChargeCount = this.skillData.maxCharge
    this.maxCharge = LogicMath.max(1000, 1000 * maxChargeCount)
    this.charge = this.maxCharge

    this.x = 0
    this.y = 0
    this.activeTime = 0
    this.ticksActive = -1
    this.coolDown = 0
    this.onActivate = false
    this.infinity = false
    this.isFromAutoAttack = false
    this.seemToBeActive = false
    this.pendingExecution = false

    if (this.skillData.attackPattern === 6) {
      this.ATTACK_PATTERN_TABLE = new Array(4).fill(0)

      let p = 0
      const step = Math.trunc(this.skillData.spread / 6)
      const sp = -step * 2
      for (let i = 0; i < 4; i++) {
        if (i >= 2) {
          if (i === 2) {
            this.ATTACK_PATTERN_TABLE[i] = sp
          } else {
            this.ATTACK_PATTERN_TABLE[i] = -sp
          }
        } else {
          this.ATTACK_PATTERN_TABLE[i] = p
          p += step
        }
      }
    } else {
      this.ATTACK_PATTERN_TABLE = []
    }
  }

  get skillData () {
    return DataTables.get(DataType.Skill).getDataByGlobalId(this.skillId)
  }

  get isRapidSpreadPattern () {
    return this.skillData.attackPattern === 6
  }

  get isActive () {
    return this.ticksActive >= 0 && this.ticksActive < this.activeTime + 1
  }

  get shouldEndThisTick () {
    return this.ticksActive >= this.activeTime
  }

  get canMoveAtSameTime () {
    return this.skillData.canMoveAtSameTime
  }

  hasEnoughCharge () {
    return this.charge >= 1000
  }

  hasFullCharge () {
    return this.charge >= this.maxCharge
  }

  addCharge (character, amount) {
    this.charge = LogicMath.min(this.maxCharge, this.charge + amount)
  }

  interrupt () {
    this.ticksActive = -1
    this.pendingExecution = false
  }

  tick (character = null) {
    const skillData = this.skillData
    if (this.pendingExecution && character != null && character.castingTime <= 0) {
      this.pendingExecution = false
      if (this.isActive) this.execute(character)
    }
    this.onActivate = false

    if (this.coolDown > 0) this.coolDown--

    if (this.charge < this.maxCharge && !this.isActive && skillData.maxCharge !== 0) {
      const rechargeTicks = Math.trunc(skillData.rechargeTime / 50)
      if (rechargeTicks > 0) {
        this.charge += Math.trunc(1000 / rechargeTicks)
      } else {
        this.charge = this.maxCharge
      }
      this.charge = LogicMath.min(this.maxCharge, this.charge)
    }

    if (this.ticksActive === 0) {
      this.ticksActive = -1
    } else if (this.isActive) {
      this.ticksActive++
      if (this.ticksActive > this.activeTime) this.ticksActive = -1
    }
  }

  activate (character, x, y, tileMap) {
    const skillData = this.skillData
    if (this.charge < 1000 && skillData.maxCharge !== 0) return

    if (!this.infinity) this.charge -= 1000

    if (this.isUltiSkill) {
      character.interruptAllSkills()
    }

    this.x = x
    this.y = y

    this.ticksActive = 1
    if (skillData.behaviorType !== 'Charge') {
      this.activeTime = Math.trunc(skillData.activeTime / 50) - 1
    } else {
      this.activeTime = Math.trunc(skillData.castingRange / 2)
    }

    this.onActivate = true
    this.coolDown = this.activeTime + 1 + Math.trunc(skillData.cooldown / 50)
    this.pendingExecution = true
    if (skillData.castingTime > 0) character.castingTime = skillData.castingTime

    if (this.isUltiSkill) character.ultiUsed()

    character.blockHealthRegen()
  }

  activateLaserBall (character, type) {
    this.ticksActive = -1
    this.onActivate = true
    this.pendingExecution = false
    this.coolDown = LogicMath.max(1, Math.trunc(this.skillData.cooldown / 50))

    if (this.isUltiSkill) character.ultiUsed()

    character.blockHealthRegen()
  }

  getTargetInRange (character, maxRange) {
    const range = this.skillData.castingRange * 100
    const dx = this.x - character.getX()
    const dy = this.y - character.getY()
    const length = LogicMath.sqrt(dx * dx + dy * dy)
    if (length === 0) {
      const distance = maxRange ? range : 0
      return new LogicVector2(character.getX() + LogicMath.getRotatedX(distance, 0, character.attackAngle), character.getY() + LogicMath.getRotatedY(distance, 0, character.attackAngle))
    }
    if (maxRange || length > range) {
      return new LogicVector2(character.getX() + Math.trunc(dx * range / length), character.getY() + Math.trunc(dy * range / length))
    }
    return new LogicVector2(this.x, this.y)
  }

  execute (character) {
    const skillData = this.skillData
    const skillType = this.isUltiSkill ? 2 : 1
    const damage = character.getAbsoluteDamage(skillData.damage)
    const normalDMG = skillData.damage
    const areaEffectData = skillData.areaEffectObject ? DataTables.getAreaEffectByName(skillData.areaEffectObject) : null
    const areaEffectData2 = skillData.areaEffectObject2 ? DataTables.getAreaEffectByName(skillData.areaEffectObject2) : null

    switch (skillData.behaviorType) {
      case 'Attack': {
        character.ultiSkill = this.isUltiSkill
        const projectileData = skillData.projectile ? DataTables.getProjectileByName(skillData.projectile) : null
        const summoned = skillData.summonedCharacter ? DataTables.getCharacterByName(skillData.summonedCharacter) : null
        if (summoned != null) {
          const level = character.getHeroLevel()
          const extraDamage = character.getAbsoluteDamage(summoned.autoAttackDamage) - summoned.autoAttackDamage
          const extraHealth = Math.floor(summoned.hitpoints * (1.0 + level / 10.0)) - summoned.hitpoints
          character.setCharacterSummoningVariables(summoned, LogicMath.max(1, skillData.numSpawns), LogicMath.max(1, skillData.maxSpawns), extraDamage, extraHealth)
        } else {
          character.setCharacterSummoningVariables(null, 0, 0, 0, 0)
        }
        const item = skillData.spawnedItem ? DataTables.getItemByName(skillData.spawnedItem) : null
        if (item != null) {
          character.setItemSummoningVariables(item, LogicMath.max(1, skillData.numSpawns), LogicMath.max(1, skillData.maxSpawns), damage, normalDMG)
        } else {
          character.setItemSummoningVariables(null, 0, 0, 0, 0)
        }
        if (projectileData == null && areaEffectData != null) {
          character.triggerAreaEffect(areaEffectData, character.getX(), character.getY(), 0, skillType)
          if (areaEffectData2 != null) character.triggerAreaEffect(areaEffectData2, character.getX(), character.getY(), 0, skillType)
          if (skillData.numBulletsInOneAttack <= 0) break
        }
        const range = skillData.castingRange + this.getSkillRangeAddFromHold(character.getSkillHoldedTicks())
        character.triggerRapidFire(this.x, this.y, skillData.attackPattern, skillData.numBulletsInOneAttack, skillData.msBetweenAttacks, projectileData, damage, range, skillData.spread, skillData.activeTime, normalDMG, skillData.executeFirstAttackImmediately)
        break
      }
      case 'Charge': {
        character.ultiSkill = this.isUltiSkill
        character.chargeNormalDMG = normalDMG
        const target = this.getTargetInRange(character, skillData.alwaysCastAtMaxRange)
        character.triggerCharge(target.x, target.y, skillData.chargeSpeed, skillData.chargeType, damage, skillData.chargePushback, false, areaEffectData)
        break
      }
      case 'Blink': {
        character.ultiSkill = this.isUltiSkill
        const target = this.getTargetInRange(character, skillData.alwaysCastAtMaxRange)
        const tileMap = character.getBattle().getTileMap()
        const spot = new LogicVector2(target.x, target.y)
        GamePlayUtil.getClosestPassableSpot(0, target.x, target.y, 10, tileMap, spot, character.characterData.canWalkOverWater)
        character.triggerBlink(spot.x, spot.y, areaEffectData, areaEffectData2, damage, normalDMG)
        break
      }
      case 'Ww':
        character.triggerWhirlwind(damage, normalDMG, skillData.msBetweenAttacks)
        break
      case 'AreaBuff':
        if (areaEffectData != null) character.areaEffect = character.triggerAreaEffect(areaEffectData, character.getX(), character.getY(), 0, skillType)
        break
      case 'Shield':
      case 'Invisibility':
        break
      default:
        Debugger.warning('Unknown skill type: ' + skillData.behaviorType)
    }
  }

  shouldAttackThisTick () {
    const skillData = this.skillData
    if (this.ticksActive === 0) {
      return skillData.executeFirstAttackImmediately
    }
    const interval = Math.trunc(skillData.msBetweenAttacks / 50)
    if (interval <= 0) return true
    return (this.ticksActive % interval) === 0
  }

  encode (bitStream) {
    const skillData = this.skillData
    bitStream.writePositiveVIntMax255OftenZero(this.ticksActive >= 0 && this.isActive ? this.ticksActive + 1 : 0)
    bitStream.writeBoolean(false)
    bitStream.writePositiveVIntMax255OftenZero(0)
    if (skillData.maxCharge >= 1) {
      bitStream.writePositiveIntMax4095(LogicMath.clamp(this.charge, 0, 4095))
    }

    if (skillData.skillCanChange) {
      const instanceId = skillData.getInstanceId()
      bitStream.writePositiveIntMax255(instanceId)
    }
  }

  getSkillRangeAddFromHold (ticks) {
    if (this.skillData.attackPattern !== 13) return 0

    const Character = require('../Objects/Character')
    return LogicMath.min(Math.trunc(ticks / 2), Math.trunc(Character.MAX_SKILL_HOLD_TICKS / 2))
  }

  getMaxCharge () {
    return this.maxCharge
  }

  hasButton () {
    return true
  }

  isOkToReduceCooldown () {
    return true
  }

  maxCooldown () {
    return this.skillData.cooldown
  }
}

module.exports = Skill
