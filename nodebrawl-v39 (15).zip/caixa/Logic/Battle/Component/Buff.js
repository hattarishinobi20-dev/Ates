class Buff {
  constructor (type, duration, modifier, sizeIncrease) {
    this.type = type
    this.duration = duration
    this.modifier = modifier
    this.sizeIncrease = sizeIncrease
    this.sourceIndex = -1
    this.effectType = 0
    this.normalDMG = 0
    this.belleWeaponBounces = 0
  }

  canStack () {
    return false
  }

  tick (character) {
    this.duration--
    return this.duration <= 0
  }
}

module.exports = Buff
