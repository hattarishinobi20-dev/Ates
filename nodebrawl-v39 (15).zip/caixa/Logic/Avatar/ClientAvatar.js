const ChecksumEncoder = require('../../Titan/DataStream/ChecksumEncoder')
const ByteStreamHelper = require('../Helper/ByteStreamHelper')
const Hero = require('../Home/Structures/Hero')
const Friend = require('../Friends/Friend')
const AllianceRole = require('./AllianceRole')

const JSON_FIELDS = [
  'accountId', 'passToken', 'name', 'nameSetByUser', 'tutorialsCompletedCount', 'gold', 'diamonds', 'heroes',
  'trioWins', 'duoWins', 'soloWins', 'tokens', 'starTokens', 'starPoints', 'isDev', 'isPremium', 'premiumLevel',
  'allianceId', 'allianceRole', 'lastOnline', 'friends', 'banned', 'doNotDisturb', 'starpowers', 'selectedStarpowers',
  'isCommunityBanned', 'isCommunityWarned', 'highestTrophies', 'rollsSinceGoodDrop', 'forcedDrops', 'shouldRedirect',
  'redirectId', 'password', 'guaranteedBrawlerPending'
]

class ClientAvatar {
  constructor () {
    this.accountId = 0
    this.passToken = null
    this.name = 'Brawler'
    this.nameSetByUser = false
    this.tutorialsCompletedCount = 2
    this.allianceName = null
    this.battleStartTime = 0
    this.homeMode = null
    this.gold = 0
    this.diamonds = 0
    this.heroes = []
    this.trioWins = 0
    this.duoWins = 0
    this.soloWins = 0
    this.tokens = 0
    this.starTokens = 0
    this.starPoints = 0
    this.isDev = false
    this.isPremium = false
    this.premiumLevel = 0
    this.allianceId = -1
    this.allianceRole = AllianceRole.None
    this.lastOnline = Date.now()
    this.friends = []
    this.banned = false
    this.doNotDisturb = false
    this.playerStatus = 0
    this.teamId = 0
    this.battleId = 0
    this.udpSessionId = 0
    this.teamIndex = 0
    this.ownIndex = 0
    this.starpowers = []
    this.selectedStarpowers = []
    this.isCommunityBanned = false
    this.isCommunityWarned = false
    this.highestTrophies = 0
    this.rollsSinceGoodDrop = 0
    this.forcedDrops = 0
    this.shouldRedirect = false
    this.redirectId = 0
    this.password = null
    this.guaranteedBrawlerPending = false

    if (this.highestTrophies === 0 && this.trophies !== 0) {
      this.highestTrophies = this.trophies
    }
  }

  get trophies () {
    let result = 0
    for (const hero of this.heroes) {
      result += hero.trophies
    }
    return result
  }

  addTrophies (t) {
    this.highestTrophies = Math.max(this.highestTrophies, this.trophies + t)
  }

  getUnlockedBrawlersCountWithRarity (rarity) {
    return this.heroes.filter(x => x.cardData != null && x.cardData.rarity === rarity).length
  }

  resetTrophies () {
    for (const hero of this.heroes) {
      hero.trophies = 0
      hero.highestTrophies = 0
    }
  }

  getUnlockedHeroesCount () {
    return this.heroes.length
  }

  unlockHero (characterId, cardId) {
    this.heroes.push(new Hero(characterId, cardId))
  }

  hasHero (characterId) {
    return this.heroes.some(x => x.characterId === characterId)
  }

  getHero (characterId) {
    return this.heroes.find(x => x.characterId === characterId) || null
  }

  useDiamonds (count) {
    if (count > this.diamonds) return false
    this.diamonds -= count
    return true
  }

  useGold (count) {
    if (count > this.gold) return false
    this.gold -= count
    return true
  }

  useStarPoints (count) {
    if (count > this.starPoints) return false
    this.starPoints -= count
    return true
  }

  addDiamonds (count) {
    this.diamonds += count
  }

  addGold (count) {
    this.gold += count
  }

  useTokens (count) {
    if (count > this.tokens) return false
    this.tokens -= count
    return true
  }

  addTokens (count) {
    this.homeMode.home.brawlPassTokens += count
  }

  useStarTokens (count) {
    if (count > this.starTokens) return false
    this.starTokens -= count
    return true
  }

  addStarTokens (count) {
    this.starTokens += count
  }

  setPasword (pass) {
    this.password = pass
  }

  skipTutorial () {
    this.tutorialsCompletedCount = 2
  }

  isTutorialState () {
    return this.tutorialsCompletedCount < 2
  }

  getRequestFriendById (id) {
    return this.friends.find(friend => friend.accountId === id && friend.friendState !== 4) || null
  }

  getAcceptedFriendById (id) {
    return this.friends.find(friend => friend.accountId === id && friend.friendState === 4) || null
  }

  getFriendById (id) {
    return this.friends.find(friend => friend.accountId === id) || null
  }

  get checksum () {
    const encoder = new ChecksumEncoder()
    this.encode(encoder)
    return encoder.getCheckSum()
  }

  encode (stream) {
    stream.writeVLong(this.accountId)
    stream.writeVLong(this.accountId)
    stream.writeVLong(this.accountId)
    stream.writeString(this.name)
    stream.writeBoolean(this.nameSetByUser)
    stream.writeInt(-1)

    stream.writeVInt(15)

    stream.writeVInt(4 + this.heroes.length)
    ByteStreamHelper.writeDataReference(stream, 5000001)
    stream.writeVInt(this.tokens)
    ByteStreamHelper.writeDataReference(stream, 5000008)
    stream.writeVInt(this.gold)
    ByteStreamHelper.writeDataReference(stream, 5000009)
    stream.writeVInt(this.starTokens)
    ByteStreamHelper.writeDataReference(stream, 5000010)
    stream.writeVInt(this.starPoints)
    for (const hero of this.heroes) {
      ByteStreamHelper.writeDataReference(stream, hero.cardData)
      stream.writeVInt(1)
    }

    stream.writeVInt(this.heroes.length)
    for (const hero of this.heroes) {
      ByteStreamHelper.writeDataReference(stream, hero.characterData)
      stream.writeVInt(hero.trophies)
    }

    stream.writeVInt(this.heroes.length)
    for (const hero of this.heroes) {
      ByteStreamHelper.writeDataReference(stream, hero.characterData)
      stream.writeVInt(hero.highestTrophies)
    }

    stream.writeVInt(0)

    stream.writeVInt(this.heroes.length)
    for (const hero of this.heroes) {
      ByteStreamHelper.writeDataReference(stream, hero.characterData)
      stream.writeVInt(hero.powerPoints)
    }

    stream.writeVInt(this.heroes.length)
    for (const hero of this.heroes) {
      ByteStreamHelper.writeDataReference(stream, hero.characterData)
      stream.writeVInt(hero.powerLevel)
    }

    for (let i = 0; i < 9; i++) {
      stream.writeVInt(0)
    }

    stream.writeVInt(this.diamonds)

    for (let i = 0; i < 10; i++) {
      stream.writeVInt(0)
    }

    stream.writeVInt(this.tutorialsCompletedCount)
  }

  toJSON () {
    const data = {}
    for (const field of JSON_FIELDS) data[field] = this[field]
    return data
  }

  static fromJSON (data) {
    const avatar = new ClientAvatar()
    for (const field of JSON_FIELDS) {
      if (data[field] !== undefined && data[field] !== null) avatar[field] = data[field]
    }
    avatar.heroes = Array.isArray(data.heroes) ? data.heroes.map(hero => Hero.fromJSON(hero)) : []
    avatar.friends = Array.isArray(data.friends) ? data.friends.map(friend => Friend.fromJSON(friend)) : []
    avatar.starpowers = Array.isArray(data.starpowers) ? data.starpowers.slice() : []
    avatar.selectedStarpowers = Array.isArray(data.selectedStarpowers) ? data.selectedStarpowers.slice() : []
    return avatar
  }
}

module.exports = ClientAvatar
