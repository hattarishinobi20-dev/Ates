const AllianceRole = Object.freeze({
  None: 0,
  Member: 1,
  Leader: 2,
  Elder: 3,
  CoLeader: 4
})

module.exports = AllianceRole
