const LogicData = require('./Helper/LogicData')

class GameModeVariationData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

GameModeVariationData.columns = [
  ['name', 'Name', 'string'],
  ['variation', 'Variation', 'int'],
  ['disabled', 'Disabled', 'bool'],
  ['tid', 'TID', 'string'],
  ['chatSuggestionItemName', 'ChatSuggestionItemName', 'string'],
  ['gameModeRoomIconName', 'GameModeRoomIconName', 'string'],
  ['gameModeIconName', 'GameModeIconName', 'string'],
  ['scoreSfx', 'ScoreSfx', 'string'],
  ['opponentScoreSfx', 'OpponentScoreSfx', 'string'],
  ['scoreText', 'ScoreText', 'string'],
  ['scoreTextEnd', 'ScoreTextEnd', 'string'],
  ['friendlyMenuOrder', 'FriendlyMenuOrder', 'int'],
  ['introText', 'IntroText', 'string'],
  ['introDescText', 'IntroDescText', 'string'],
  ['introDescText2', 'IntroDescText2', 'string'],
  ['startNotification', 'StartNotification', 'string'],
  ['endNotification', 'EndNotification', 'string']
]

module.exports = GameModeVariationData
