const LogicData = require('./Helper/LogicData')

class SkillData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }

  isPositionalTargeted () {
    return false
  }
}

SkillData.columns = [
  ['name', 'Name', 'string'],
  ['behaviorType', 'BehaviorType', 'string'],
  ['canMoveAtSameTime', 'CanMoveAtSameTime', 'bool'],
  ['targeted', 'Targeted', 'bool'],
  ['canAutoShoot', 'CanAutoShoot', 'bool'],
  ['faceMovement', 'FaceMovement', 'bool'],
  ['cooldown', 'Cooldown', 'int'],
  ['activeTime', 'ActiveTime', 'int'],
  ['castingTime', 'CastingTime', 'int'],
  ['castingRange', 'CastingRange', 'int'],
  ['rangeVisual', 'RangeVisual', 'int'],
  ['rangeInputScale', 'RangeInputScale', 'int'],
  ['maxCastingRange', 'MaxCastingRange', 'int'],
  ['forceValidTile', 'ForceValidTile', 'int'],
  ['rechargeTime', 'RechargeTime', 'int'],
  ['maxCharge', 'MaxCharge', 'int'],
  ['damage', 'Damage', 'int'],
  ['msBetweenAttacks', 'MsBetweenAttacks', 'int'],
  ['spread', 'Spread', 'int'],
  ['attackPattern', 'AttackPattern', 'int'],
  ['numBulletsInOneAttack', 'NumBulletsInOneAttack', 'int'],
  ['twoGuns', 'TwoGuns', 'bool'],
  ['executeFirstAttackImmediately', 'ExecuteFirstAttackImmediately', 'bool'],
  ['chargePushback', 'ChargePushback', 'int'],
  ['chargeSpeed', 'ChargeSpeed', 'int'],
  ['chargeType', 'ChargeType', 'int'],
  ['numSpawns', 'NumSpawns', 'int'],
  ['maxSpawns', 'MaxSpawns', 'int'],
  ['breakInvisibilityOnAttack', 'BreakInvisibilityOnAttack', 'bool'],
  ['seeInvisibilityDistance', 'SeeInvisibilityDistance', 'int'],
  ['alwaysCastAtMaxRange', 'AlwaysCastAtMaxRange', 'bool'],
  ['projectile', 'Projectile', 'string'],
  ['summonedCharacter', 'SummonedCharacter', 'string'],
  ['areaEffectObject', 'AreaEffectObject', 'string'],
  ['areaEffectObject2', 'AreaEffectObject2', 'string'],
  ['spawnedItem', 'SpawnedItem', 'string'],
  ['iconSWF', 'IconSWF', 'string'],
  ['iconExportName', 'IconExportName', 'string'],
  ['largeIconSWF', 'LargeIconSWF', 'string'],
  ['largeIconExportName', 'LargeIconExportName', 'string'],
  ['buttonSWF', 'ButtonSWF', 'string'],
  ['buttonExportName', 'ButtonExportName', 'string'],
  ['attackEffect', 'AttackEffect', 'string'],
  ['useEffect', 'UseEffect', 'string'],
  ['endEffect', 'EndEffect', 'string'],
  ['loopEffect', 'LoopEffect', 'string'],
  ['loopEffect2', 'LoopEffect2', 'string'],
  ['chargeMoveSound', 'ChargeMoveSound', 'string'],
  ['multiShot', 'MultiShot', 'bool'],
  ['skillCanChange', 'SkillCanChange', 'bool'],
  ['showTimerBar', 'ShowTimerBar', 'bool'],
  ['secondaryProjectile', 'SecondaryProjectile', 'string'],
  ['chargedShotCount', 'ChargedShotCount', 'int'],
  ['damageModifier', 'DamageModifier', 'int']
]

module.exports = SkillData
