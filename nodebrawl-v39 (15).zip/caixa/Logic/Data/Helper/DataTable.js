const GlobalId = require('./GlobalId')

class DataTable {
  constructor (table, index) {
    this.datas = []
    this.index = index != null ? index : 0
    this.names = new Map()

    if (table != null) {
      const DataTables = require('../DataTables')

      for (let i = 0; i < table.getRowCount(); i++) {
        const row = table.getRowAt(i)
        const data = DataTables.create(this.index, row, this)
        this.datas.push(data)

        if (data != null) {
          const name = data.getName()

          if (!this.names.has(name)) {
            this.names.set(name, data)
          }
        }
      }
    }
  }

  getCount () {
    return this.datas.length
  }

  get count () {
    return this.datas.length
  }

  getDatas () {
    return this.datas
  }

  getDataWithId (id) {
    return this.getItemAt(GlobalId.getInstanceId(id))
  }

  getData (nameOrIndex) {
    if (typeof nameOrIndex === 'string') {
      const data = this.names.get(nameOrIndex)
      return data != null ? data : null
    }

    return this.getItemAt(nameOrIndex)
  }

  getDataByGlobalId (id) {
    return this.getItemAt(GlobalId.getInstanceId(id))
  }

  getItemAt (index) {
    if (!Number.isInteger(index) || index < 0 || index >= this.datas.length) {
      return null
    }

    return this.datas[index]
  }

  getInstanceId (name) {
    const data = this.getData(name)
    return data != null ? data.getInstanceId() : -1
  }

  getIndex () {
    return this.index
  }
}

module.exports = DataTable
