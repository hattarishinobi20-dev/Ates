const GlobalId = require('./GlobalId')
const Debugger = require('../../../Titan/Debug/Debugger')

const DEFAULTS = {
  int: () => 0,
  bool: () => false,
  string: () => null,
  'int[]': () => [],
  'bool[]': () => [],
  'string[]': () => []
}

class LogicData {
  constructor (row, dataTable) {
    this.row = row
    this.dataTable = dataTable
    this.dataType = 0
    this.globalId = 0

    for (const [field, , type] of this.constructor.columns || []) {
      this[field] = DEFAULTS[type]()
    }
  }

  loadData (data, row) {
    const DataTables = require('../DataTables')

    this.dataType = DataTables.getDataType(this.constructor)
    this.globalId = GlobalId.createGlobalId(this.dataType, this.dataTable.getCount())
    this.row = row

    try {
      this.row.loadData(data)
    } catch (e) {
      Debugger.warning(`Failed to load ${this.constructor.name} row ${row != null ? row.getName() : null}: ${e.message}`)
    }
  }

  getDataType () {
    return this.dataType
  }

  getGlobalId () {
    return this.globalId
  }

  getInstanceId () {
    return GlobalId.getInstanceId(this.globalId)
  }

  getClassId () {
    return GlobalId.getClassId(this.globalId)
  }

  getName () {
    return this.row.getName()
  }
}

module.exports = LogicData
