const DataType = Object.freeze({
  Projectile: 6,
  AllianceBadge: 8,
  Location: 15,
  Character: 16,
  AreaEffect: 17,
  Item: 18,
  Skill: 20,
  Card: 23,
  Tile: 27,
  PlayerThumbnail: 28,
  Skin: 29,
  Milestone: 39,
  NameColor: 43,
  SkinConf: 44,
  Accessory: 50,
  Emote: 52
})

module.exports = DataType
