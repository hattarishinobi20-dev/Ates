const LogicData = require('./Helper/LogicData')

class AreaEffectData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

AreaEffectData.columns = [
  ['name', 'Name', 'string'],
  ['parentAreaEffectForSkin', 'ParentAreaEffectForSkin', 'string'],
  ['fileName', 'FileName', 'string'],
  ['ownExportName', 'OwnExportName', 'string'],
  ['blueExportName', 'BlueExportName', 'string'],
  ['redExportName', 'RedExportName', 'string'],
  ['neutralExportName', 'NeutralExportName', 'string'],
  ['layer', 'Layer', 'string'],
  ['exportNameTop', 'ExportNameTop', 'string'],
  ['exportNameObject', 'ExportNameObject', 'string'],
  ['effect', 'Effect', 'string'],
  ['loopingEffect', 'LoopingEffect', 'string'],
  ['allowEffectInterrupt', 'AllowEffectInterrupt', 'bool'],
  ['serverControlsFrame', 'ServerControlsFrame', 'bool'],
  ['scale', 'Scale', 'int'],
  ['timeMs', 'TimeMs', 'int'],
  ['radius', 'Radius', 'int'],
  ['damage', 'Damage', 'int'],
  ['customValue', 'CustomValue', 'int'],
  ['type', 'Type', 'string'],
  ['isPersonal', 'IsPersonal', 'bool'],
  ['bulletExplosionBullet', 'BulletExplosionBullet', 'string'],
  ['bulletExplosionBulletDistance', 'BulletExplosionBulletDistance', 'int'],
  ['bulletExplosionItem', 'BulletExplosionItem', 'string'],
  ['destroysEnvironment', 'DestroysEnvironment', 'bool'],
  ['pushbackStrength', 'PushbackStrength', 'int'],
  ['pushbackStrengthSelf', 'PushbackStrengthSelf', 'int'],
  ['pushbackDeadzone', 'PushbackDeadzone', 'int'],
  ['canStopGrapple', 'CanStopGrapple', 'bool'],
  ['freezeStrength', 'FreezeStrength', 'int'],
  ['freezeTicks', 'FreezeTicks', 'int'],
  ['shouldShowEvenIfOutsideScreen', 'ShouldShowEvenIfOutsideScreen', 'bool'],
  ['sameAreaEffectCanNotDamageMs', 'SameAreaEffectCanNotDamageMs', 'int'],
  ['dontShowToEnemy', 'DontShowToEnemy', 'bool'],
  ['requireLineOfSight', 'RequireLineOfSight', 'bool']
]

module.exports = AreaEffectData
