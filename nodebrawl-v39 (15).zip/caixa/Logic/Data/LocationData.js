const LogicData = require('./Helper/LogicData')

class LocationData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

LocationData.columns = [
  ['name', 'Name', 'string'],
  ['disabled', 'Disabled', 'bool'],
  ['tid', 'TID', 'string'],
  ['bgPrefix', 'BgPrefix', 'string'],
  ['locationTheme', 'LocationTheme', 'string'],
  ['groundSCW', 'GroundSCW', 'string'],
  ['campaignGroundSCW', 'CampaignGroundSCW', 'string'],
  ['environmentSCW', 'EnvironmentSCW', 'string'],
  ['iconSWF', 'IconSWF', 'string'],
  ['iconExportName', 'IconExportName', 'string'],
  ['gameMode', 'GameMode', 'string'],
  ['allowedMaps', 'AllowedMaps', 'string'],
  ['music', 'Music', 'string'],
  ['communityCredit', 'CommunityCredit', 'string']
]

module.exports = LocationData
