class Column {
  constructor () {
    this.values = []
  }

  static getArraySize (offset, nOffset) {
    return nOffset - offset
  }

  add (value) {
    if (value == null) {
      this.values.push(this.values.length > 0 ? this.values[this.values.length - 1] : '')
    } else {
      this.values.push(value)
    }
  }

  get (row) {
    return this.values[row]
  }

  getSize () {
    return this.values.length
  }
}

module.exports = Column
