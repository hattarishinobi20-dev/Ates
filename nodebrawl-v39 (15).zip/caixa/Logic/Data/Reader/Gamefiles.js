const DataTable = require('../Helper/DataTable')

class Gamefiles {
  constructor (gamefiles) {
    this.dataTables = new Map()

    for (const index of gamefiles.keys()) {
      this.dataTables.set(index, new DataTable())
    }
  }

  dispose () {
    this.dataTables.clear()
  }

  get (index) {
    const table = this.dataTables.get(index)
    return table != null ? table : null
  }

  containsTable (index) {
    return this.dataTables.has(index)
  }

  initialize (table, index) {
    this.dataTables.set(index, new DataTable(table, index))
  }
}

module.exports = Gamefiles
