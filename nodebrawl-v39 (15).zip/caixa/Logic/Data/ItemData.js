const LogicData = require('./Helper/LogicData')

class ItemData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

ItemData.columns = [
  ['name', 'Name', 'string'],
  ['parentItemForSkin', 'ParentItemForSkin', 'string'],
  ['fileName', 'FileName', 'string'],
  ['exportName', 'ExportName', 'string'],
  ['exportNameEnemy', 'ExportNameEnemy', 'string'],
  ['shadowExportName', 'ShadowExportName', 'string'],
  ['groundGlowExportName', 'GroundGlowExportName', 'string'],
  ['loopingEffect', 'LoopingEffect', 'string'],
  ['value', 'Value', 'int'],
  ['value2', 'Value2', 'int'],
  ['triggerRangeSubTiles', 'TriggerRangeSubTiles', 'int'],
  ['triggerAreaEffect', 'TriggerAreaEffect', 'string'],
  ['canBePickedUp', 'CanBePickedUp', 'bool'],
  ['spawnEffect', 'SpawnEffect', 'string'],
  ['activateEffect', 'ActivateEffect', 'string'],
  ['scw', 'SCW', 'string'],
  ['scwEnemy', 'SCWEnemy', 'string'],
  ['layer', 'Layer', 'string']
]

module.exports = ItemData
