const LogicData = require('./Helper/LogicData')

class EmoteData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

EmoteData.columns = [
  ['name', 'Name', 'string'],
  ['disabled', 'Disabled', 'bool'],
  ['fileName', 'FileName', 'string'],
  ['exportName', 'ExportName', 'string'],
  ['character', 'Character', 'string'],
  ['skin', 'Skin', 'string'],
  ['isPicto', 'IsPicto', 'bool'],
  ['battleCategory', 'BattleCategory', 'string'],
  ['type', 'Type', 'int'],
  ['rarity', 'Rarity', 'int'],
  ['emoteType', 'EmoteType', 'string'],
  ['soundEffect', 'SoundEffect', 'string'],
  ['sfxIndex', 'SfxIndex', 'int'],
  ['lockedForChronos', 'LockedForChronos', 'bool'],
  ['emoteBundles', 'EmoteBundles', 'string'],
  ['isDefaultBattleEmote', 'IsDefaultBattleEmote', 'bool']
]

module.exports = EmoteData
