const LogicData = require('./Helper/LogicData')

class LocationThemeData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

LocationThemeData.columns = [
  ['name', 'Name', 'string'],
  ['tileSetPrefix', 'TileSetPrefix', 'string'],
  ['maskedEnvironmentSCW', 'MaskedEnvironmentSCW', 'string'],
  ['blocking1SCW', 'Blocking1SCW', 'string'],
  ['blocking1Mesh', 'Blocking1Mesh', 'string'],
  ['blocking1AngleStep', 'Blocking1AngleStep', 'int'],
  ['blocking2SCW', 'Blocking2SCW', 'string'],
  ['blocking2Mesh', 'Blocking2Mesh', 'string'],
  ['blocking2AngleStep', 'Blocking2AngleStep', 'int'],
  ['blocking3SCW', 'Blocking3SCW', 'string'],
  ['blocking3Mesh', 'Blocking3Mesh', 'string'],
  ['blocking3AngleStep', 'Blocking3AngleStep', 'int'],
  ['blocking4SCW', 'Blocking4SCW', 'string'],
  ['blocking4Mesh', 'Blocking4Mesh', 'string'],
  ['blocking4AngleStep', 'Blocking4AngleStep', 'int'],
  ['respawningWallSCW', 'RespawningWallSCW', 'string'],
  ['respawningWallMesh', 'RespawningWallMesh', 'string'],
  ['respawningWallAngleStep', 'RespawningWallAngleStep', 'int'],
  ['respawningForestSCW', 'RespawningForestSCW', 'string'],
  ['forestSCW', 'ForestSCW', 'string'],
  ['destructableSCW', 'DestructableSCW', 'string'],
  ['destructableMesh', 'DestructableMesh', 'string'],
  ['destructableAngleStep', 'DestructableAngleStep', 'int'],
  ['destructableSCW_CN', 'DestructableSCW_CN', 'string'],
  ['destructableMesh_CN', 'DestructableMesh_CN', 'string'],
  ['destructableAngleStep_CN', 'DestructableAngleStep_CN', 'int'],
  ['fragileSCW', 'FragileSCW', 'string'],
  ['fragileMesh', 'FragileMesh', 'string'],
  ['fragileAngleStep', 'FragileAngleStep', 'int'],
  ['fragileSCW_CN', 'FragileSCW_CN', 'string'],
  ['fragileMesh_CN', 'FragileMesh_CN', 'string'],
  ['fragileAngleStep_CN', 'FragileAngleStep_CN', 'int'],
  ['waterTileSCW', 'WaterTileSCW', 'string'],
  ['fenceSCW', 'FenceSCW', 'string'],
  ['indestructibleSCW', 'IndestructibleSCW', 'string'],
  ['indestructibleMesh', 'IndestructibleMesh', 'string'],
  ['benchSCW', 'BenchSCW', 'string'],
  ['laserBallSkinOverride', 'LaserBallSkinOverride', 'string'],
  ['mineGemSpawnSCWOverride', 'MineGemSpawnSCWOverride', 'string'],
  ['lootBoxSkinOverride', 'LootBoxSkinOverride', 'string'],
  ['showdownBoostSCWOverride', 'ShowdownBoostSCWOverride', 'string'],
  ['mapPreviewBGColorRed', 'MapPreviewBGColorRed', 'int'],
  ['mapPreviewBGColorGreen', 'MapPreviewBGColorGreen', 'int'],
  ['mapPreviewBGColorBlue', 'MapPreviewBGColorBlue', 'int'],
  ['mapPreviewGemGrabSpawnHoleExportName', 'MapPreviewGemGrabSpawnHoleExportName', 'string'],
  ['mapPreviewBallExportName', 'MapPreviewBallExportName', 'string'],
  ['mapPreviewGoal1ExportName', 'MapPreviewGoal1ExportName', 'string'],
  ['mapPreviewGoal2ExportName', 'MapPreviewGoal2ExportName', 'string'],
  ['mapPreviewCNOverrides', 'MapPreviewCNOverrides', 'string']
]

module.exports = LocationThemeData
