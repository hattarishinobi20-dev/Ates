const LogicData = require('./Helper/LogicData')

class MapBlockData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

MapBlockData.columns = [
  ['codeName', 'CodeName', 'string'],
  ['group', 'Group', 'string'],
  ['data', 'Data', 'string']
]

module.exports = MapBlockData
