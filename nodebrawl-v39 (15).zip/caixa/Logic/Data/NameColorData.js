const LogicData = require('./Helper/LogicData')

class NameColorData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

NameColorData.columns = [
  ['name', 'Name', 'string'],
  ['colorCode', 'ColorCode', 'string'],
  ['gradient', 'Gradient', 'string'],
  ['requiredExpLevel', 'RequiredExpLevel', 'int'],
  ['requiredTotalTrophies', 'RequiredTotalTrophies', 'int'],
  ['requiredSeasonPoints', 'RequiredSeasonPoints', 'int'],
  ['requiredHero', 'RequiredHero', 'string'],
  ['sortOrder', 'SortOrder', 'int']
]

module.exports = NameColorData
