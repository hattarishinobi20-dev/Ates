const path = require('path')
const Debugger = require('../../Titan/Debug/Debugger')
const DataType = require('./DataType')
const Gamefiles = require('./Reader/Gamefiles')
const Table = require('./Reader/Table')

const ASSETS = path.join(__dirname, '../../Assets/csv_logic')

class DataTables {
  static gamefiles = new Map()
  static dataTypes = new Map()
  static types = new Map()
  static tables = null

  static registerTypes () {
    if (DataTables.dataTypes.size > 0) {
      return
    }

    DataTables.dataTypes.set(DataType.Projectile, require('./ProjectileData'))
    DataTables.dataTypes.set(DataType.AllianceBadge, require('./AllianceBadgeData'))
    DataTables.dataTypes.set(DataType.Location, require('./LocationData'))
    DataTables.dataTypes.set(DataType.Character, require('./CharacterData'))
    DataTables.dataTypes.set(DataType.AreaEffect, require('./AreaEffectData'))
    DataTables.dataTypes.set(DataType.Item, require('./ItemData'))
    DataTables.dataTypes.set(DataType.Skill, require('./SkillData'))
    DataTables.dataTypes.set(DataType.Card, require('./CardData'))
    DataTables.dataTypes.set(DataType.Tile, require('./TileData'))
    DataTables.dataTypes.set(DataType.PlayerThumbnail, require('./PlayerThumbnailData'))
    DataTables.dataTypes.set(DataType.Skin, require('./SkinData'))
    DataTables.dataTypes.set(DataType.Milestone, require('./MilestoneData'))
    DataTables.dataTypes.set(DataType.NameColor, require('./NameColorData'))
    DataTables.dataTypes.set(DataType.SkinConf, require('./SkinConfData'))
    DataTables.dataTypes.set(DataType.Accessory, require('./AccessoryData'))
    DataTables.dataTypes.set(DataType.Emote, require('./EmoteData'))

    for (const [type, dataClass] of DataTables.dataTypes) {
      DataTables.types.set(dataClass, type)
    }
  }

  static addFilesToLoad () {
    DataTables.gamefiles.clear()
    DataTables.gamefiles.set(DataType.Projectile, 'projectiles.csv')
    DataTables.gamefiles.set(DataType.AllianceBadge, 'alliance_badges.csv')
    DataTables.gamefiles.set(DataType.Location, 'locations.csv')
    DataTables.gamefiles.set(DataType.Character, 'characters.csv')
    DataTables.gamefiles.set(DataType.AreaEffect, 'area_effects.csv')
    DataTables.gamefiles.set(DataType.Item, 'items.csv')
    DataTables.gamefiles.set(DataType.Skill, 'skills.csv')
    DataTables.gamefiles.set(DataType.Card, 'cards.csv')
    DataTables.gamefiles.set(DataType.Tile, 'tiles.csv')
    DataTables.gamefiles.set(DataType.PlayerThumbnail, 'player_thumbnails.csv')
    DataTables.gamefiles.set(DataType.Skin, 'skins.csv')
    DataTables.gamefiles.set(DataType.Milestone, 'milestones.csv')
    DataTables.gamefiles.set(DataType.NameColor, 'name_colors.csv')
    DataTables.gamefiles.set(DataType.SkinConf, 'skin_confs.csv')
    DataTables.gamefiles.set(DataType.Accessory, 'accessories.csv')
    DataTables.gamefiles.set(DataType.Emote, 'emotes.csv')
  }

  static load () {
    DataTables.registerTypes()
    DataTables.addFilesToLoad()

    DataTables.tables = new Gamefiles(DataTables.gamefiles)

    for (const [type, file] of DataTables.gamefiles) {
      DataTables.tables.initialize(new Table(path.join(ASSETS, file)), type)
    }

    Debugger.print(`${DataTables.gamefiles.size} Data Tables initialized!`)
  }

  static tableExists (type) {
    return DataTables.tables != null && DataTables.tables.containsTable(type)
  }

  static get (type) {
    return DataTables.tables != null ? DataTables.tables.get(type) : null
  }

  static getDataType (dataClass) {
    DataTables.registerTypes()

    const type = DataTables.types.get(dataClass)

    if (type == null) {
      throw new Error(`${dataClass.name} is not registered in DataTables`)
    }

    return type
  }

  static create (type, row, dataTable) {
    DataTables.registerTypes()

    const DataClass = DataTables.dataTypes.get(type)

    if (DataClass != null) {
      return new DataClass(row, dataTable)
    }

    return null
  }

  static getByName (type, name) {
    const table = DataTables.get(type)
    return table != null ? table.getData(name) : null
  }

  static getAreaEffectByName (name) {
    return DataTables.getByName(DataType.AreaEffect, name)
  }

  static getCharacterByName (name) {
    return DataTables.getByName(DataType.Character, name)
  }

  static getItemByName (name) {
    return DataTables.getByName(DataType.Item, name)
  }

  static getProjectileByName (name) {
    return DataTables.getByName(DataType.Projectile, name)
  }
}

module.exports = DataTables
