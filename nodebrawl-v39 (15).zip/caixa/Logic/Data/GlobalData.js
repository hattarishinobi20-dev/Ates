const LogicData = require('./Helper/LogicData')

class GlobalData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

GlobalData.columns = [
  ['name', 'Name', 'string'],
  ['numberValue', 'NumberValue', 'int'],
  ['booleanValue', 'BooleanValue', 'bool'],
  ['textValue', 'TextValue', 'string'],
  ['stringArray', 'StringArray', 'string'],
  ['numberArray', 'NumberArray', 'int']
]

module.exports = GlobalData
