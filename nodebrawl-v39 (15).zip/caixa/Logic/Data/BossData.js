const LogicData = require('./Helper/LogicData')

class BossData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

BossData.columns = [
  ['name', 'Name', 'string'],
  ['tid', 'TID', 'string'],
  ['playerCount', 'PlayerCount', 'int'],
  ['requiredCampaignProgressToUnlock', 'RequiredCampaignProgressToUnlock', 'int'],
  ['location', 'Location', 'string'],
  ['allowedHeroes', 'AllowedHeroes', 'string'],
  ['reward', 'Reward', 'string'],
  ['levelGenerationSeed', 'LevelGenerationSeed', 'int'],
  ['map', 'Map', 'string'],
  ['boss', 'Boss', 'string'],
  ['bossLevel', 'BossLevel', 'int']
]

module.exports = BossData
