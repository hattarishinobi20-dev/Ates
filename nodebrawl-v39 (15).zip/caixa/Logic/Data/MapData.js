const LogicData = require('./Helper/LogicData')

class MapData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

MapData.columns = [
  ['codeName', 'CodeName', 'string'],
  ['group', 'Group', 'string'],
  ['data', 'Data', 'string'],
  ['constructFromBlocks', 'ConstructFromBlocks', 'bool']
]

module.exports = MapData
