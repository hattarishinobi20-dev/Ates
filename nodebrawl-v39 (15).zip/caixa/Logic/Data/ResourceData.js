const LogicData = require('./Helper/LogicData')

class ResourceData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

ResourceData.columns = [
  ['name', 'Name', 'string'],
  ['tid', 'TID', 'string'],
  ['iconSWF', 'IconSWF', 'string'],
  ['collectEffect', 'CollectEffect', 'string'],
  ['iconExportName', 'IconExportName', 'string'],
  ['type', 'Type', 'string'],
  ['rarity', 'Rarity', 'string'],
  ['premiumCurrency', 'PremiumCurrency', 'bool'],
  ['textRed', 'TextRed', 'int'],
  ['textGreen', 'TextGreen', 'int'],
  ['textBlue', 'TextBlue', 'int'],
  ['cap', 'Cap', 'int']
]

module.exports = ResourceData
