const LogicData = require('./Helper/LogicData')

class TileData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

TileData.columns = [
  ['name', 'Name', 'string'],
  ['tileCode', 'TileCode', 'string'],
  ['dynamicCode', 'DynamicCode', 'int'],
  ['blocksMovement', 'BlocksMovement', 'bool'],
  ['blocksProjectiles', 'BlocksProjectiles', 'bool'],
  ['isDestructible', 'IsDestructible', 'bool'],
  ['isDestructibleNormalWeapon', 'IsDestructibleNormalWeapon', 'bool'],
  ['hidesHero', 'HidesHero', 'bool'],
  ['respawnSeconds', 'RespawnSeconds', 'int'],
  ['collisionMargin', 'CollisionMargin', 'int'],
  ['baseExportName', 'BaseExportName', 'string'],
  ['baseExplosionEffect', 'BaseExplosionEffect', 'string'],
  ['baseHitEffect', 'BaseHitEffect', 'string'],
  ['baseWindEffect', 'BaseWindEffect', 'string'],
  ['baseBulletHole1', 'BaseBulletHole1', 'string'],
  ['baseBulletHole2', 'BaseBulletHole2', 'string'],
  ['baseCrack1', 'BaseCrack1', 'string'],
  ['baseCrack2', 'BaseCrack2', 'string'],
  ['sortOffset', 'SortOffset', 'int'],
  ['hasHitAnim', 'HasHitAnim', 'bool'],
  ['hasWindAnim', 'HasWindAnim', 'bool'],
  ['shadowScaleX', 'ShadowScaleX', 'int'],
  ['shadowScaleY', 'ShadowScaleY', 'int'],
  ['shadowX', 'ShadowX', 'int'],
  ['shadowY', 'ShadowY', 'int'],
  ['shadowSkew', 'ShadowSkew', 'int'],
  ['lifetime', 'Lifetime', 'int'],
  ['customSCW', 'CustomSCW', 'string'],
  ['customMesh', 'CustomMesh', 'string'],
  ['customAngleStep', 'CustomAngleStep', 'int']
]

module.exports = TileData
