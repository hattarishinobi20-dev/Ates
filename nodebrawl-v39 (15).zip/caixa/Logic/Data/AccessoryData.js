const LogicData = require('./Helper/LogicData')

class AccessoryData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

AccessoryData.columns = [
  ['name', 'Name', 'string'],
  ['type', 'Type', 'string'],
  ['chargeCount', 'ChargeCount', 'int'],
  ['cooldown', 'Cooldown', 'int'],
  ['useEffect', 'UseEffect', 'string'],
  ['loopingEffect', 'LoopingEffect', 'string'],
  ['activationDelay', 'ActivationDelay', 'int'],
  ['activeTicks', 'ActiveTicks', 'int'],
  ['stopMovement', 'StopMovement', 'bool'],
  ['setAttackAngle', 'SetAttackAngle', 'bool'],
  ['aimGuideType', 'AimGuideType', 'int'],
  ['consumesAmmo', 'ConsumesAmmo', 'bool'],
  ['areaEffect', 'AreaEffect', 'string'],
  ['petAreaEffect', 'PetAreaEffect', 'string'],
  ['interruptsAction', 'InterruptsAction', 'bool'],
  ['allowStunActivation', 'AllowStunActivation', 'bool'],
  ['requirePet', 'RequirePet', 'bool'],
  ['destroyPet', 'DestroyPet', 'bool'],
  ['requireEnemyDistance', 'RequireEnemyDistance', 'int'],
  ['shieldPercent', 'ShieldPercent', 'int'],
  ['shieldTicks', 'ShieldTicks', 'int'],
  ['skipTypeCondition', 'SkipTypeCondition', 'bool'],
  ['customObject', 'CustomObject', 'string'],
  ['customValue1', 'CustomValue1', 'int'],
  ['customValue2', 'CustomValue2', 'int'],
  ['customValue3', 'CustomValue3', 'int'],
  ['customValue4', 'CustomValue4', 'int'],
  ['customValue5', 'CustomValue5', 'int'],
  ['customValue6', 'CustomValue6', 'int'],
  ['missingTargetText', 'MissingTargetText', 'string'],
  ['targetTooFarText', 'TargetTooFarText', 'string'],
  ['targetAlreadyActiveText', 'TargetAlreadyActiveText', 'string'],
  ['subType', 'SubType', 'int'],
  ['showCountdown', 'ShowCountdown', 'bool']
]

module.exports = AccessoryData
