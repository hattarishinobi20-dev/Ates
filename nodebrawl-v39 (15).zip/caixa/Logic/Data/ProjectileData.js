const LogicData = require('./Helper/LogicData')

class ProjectileData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
    this.travelTypeVariable = 0
    this.uniqueProperty = 0
    this.suppressHealing = 0
    this.pushbackType = 0
    this.appliedEffectVisualType = 0
    this.ignoreLevelBoarder = false
  }

  getDamagePercentStart () {
    return this.damagePercentStart > 0 ? this.damagePercentStart : 100
  }

  getDamagePercentEnd () {
    return this.damagePercentEnd > 0 ? this.damagePercentEnd : 100
  }

  executeChainOnNoHit () {
    return this.executeChainSpecialCase === 1
  }

  executeChainAlways () {
    return this.executeChainSpecialCase === 2
  }

  get damagesConstantly () {
    return this.damagesConstantlyTickDelay > 0
  }

  getScaleStart () {
    return this.scaleStart > 0 ? this.scaleStart : 100
  }

  getScaleEnd () {
    return this.scaleEnd > 0 ? this.scaleEnd : 100
  }

  getFreezeDuration () {
    return Math.trunc(this.freezeDurationMS / 50)
  }

  getStunLengthTicks () {
    return Math.trunc(this.stunLengthMS / 50)
  }

  executeChainOnObjectHit () {
    return this.executeChainSpecialCase === 0 || this.executeChainSpecialCase === 1
  }

  executeChainOnAnyHit () {
    return this.executeChainSpecialCase === 3
  }
}

ProjectileData.columns = [
  ['name', 'Name', 'string'],
  ['parentProjectileForSkin', 'ParentProjectileForSkin', 'string'],
  ['speed', 'Speed', 'int'],
  ['fileName', 'FileName', 'string'],
  ['blueSCW', 'BlueSCW', 'string'],
  ['redSCW', 'RedSCW', 'string'],
  ['blueExportName', 'BlueExportName', 'string'],
  ['redExportName', 'RedExportName', 'string'],
  ['shadowExportName', 'ShadowExportName', 'string'],
  ['blueGroundGlowExportName', 'BlueGroundGlowExportName', 'string'],
  ['redGroundGlowExportName', 'RedGroundGlowExportName', 'string'],
  ['preExplosionBlueExportName', 'PreExplosionBlueExportName', 'string'],
  ['preExplosionRedExportName', 'PreExplosionRedExportName', 'string'],
  ['preExplosionTimeMs', 'PreExplosionTimeMs', 'int'],
  ['hitEffectEnv', 'HitEffectEnv', 'string'],
  ['hitEffectChar', 'HitEffectChar', 'string'],
  ['maxRangeReachedEffect', 'MaxRangeReachedEffect', 'string'],
  ['cancelEffect', 'CancelEffect', 'string'],
  ['radius', 'Radius', 'int'],
  ['indirect', 'Indirect', 'bool'],
  ['constantFlyTime', 'ConstantFlyTime', 'bool'],
  ['triggerWithDelayMs', 'TriggerWithDelayMs', 'int'],
  ['bouncePercent', 'BouncePercent', 'int'],
  ['gravity', 'Gravity', 'int'],
  ['earlyTicks', 'EarlyTicks', 'int'],
  ['hideTime', 'HideTime', 'int'],
  ['scale', 'Scale', 'int'],
  ['randomStartFrame', 'RandomStartFrame', 'int'],
  ['spawnAreaEffectObject', 'SpawnAreaEffectObject', 'string'],
  ['spawnAreaEffectObject2', 'SpawnAreaEffectObject2', 'string'],
  ['spawnCharacter', 'SpawnCharacter', 'string'],
  ['spawnItem', 'SpawnItem', 'string'],
  ['trailEffect', 'TrailEffect', 'string'],
  ['shotByHero', 'ShotByHero', 'bool'],
  ['isBeam', 'IsBeam', 'bool'],
  ['isBouncing', 'IsBouncing', 'bool'],
  ['distanceAddFromBounce', 'DistanceAddFromBounce', 'int'],
  ['rendering', 'Rendering', 'string'],
  ['piercesCharacters', 'PiercesCharacters', 'bool'],
  ['piercesEnvironment', 'PiercesEnvironment', 'bool'],
  ['piercesEnvironmentLikeButter', 'PiercesEnvironmentLikeButter', 'bool'],
  ['pushbackStrength', 'PushbackStrength', 'int'],
  ['variablePushback', 'VariablePushback', 'bool'],
  ['directionAlignedPushback', 'DirectionAlignedPushback', 'bool'],
  ['chainsToEnemies', 'ChainsToEnemies', 'int'],
  ['chainBullets', 'ChainBullets', 'int'],
  ['chainSpread', 'ChainSpread', 'int'],
  ['chainTravelDistance', 'ChainTravelDistance', 'int'],
  ['chainBullet', 'ChainBullet', 'string'],
  ['executeChainSpecialCase', 'ExecuteChainSpecialCase', 'int'],
  ['damagePercentStart', 'DamagePercentStart', 'int'],
  ['damagePercentEnd', 'DamagePercentEnd', 'int'],
  ['damagesConstantlyTickDelay', 'DamagesConstantlyTickDelay', 'int'],
  ['freezeStrength', 'FreezeStrength', 'int'],
  ['freezeDurationMS', 'FreezeDurationMS', 'int'],
  ['stunLengthMS', 'StunLengthMS', 'int'],
  ['scaleStart', 'ScaleStart', 'int'],
  ['scaleEnd', 'ScaleEnd', 'int'],
  ['attractsPet', 'AttractsPet', 'bool'],
  ['lifeStealPercent', 'LifeStealPercent', 'int'],
  ['passesEnvironment', 'PassesEnvironment', 'bool'],
  ['poisonDamagePercent', 'PoisonDamagePercent', 'int'],
  ['damageOnlyWithOneProj', 'DamageOnlyWithOneProj', 'bool'],
  ['healOwnPercent', 'HealOwnPercent', 'int'],
  ['canGrowStronger', 'CanGrowStronger', 'bool'],
  ['hideFaster', 'HideFaster', 'bool'],
  ['grapplesEnemy', 'GrapplesEnemy', 'bool'],
  ['kickBack', 'KickBack', 'int'],
  ['useColorMod', 'UseColorMod', 'bool'],
  ['redAdd', 'RedAdd', 'int'],
  ['greenAdd', 'GreenAdd', 'int'],
  ['blueAdd', 'BlueAdd', 'int'],
  ['redMul', 'RedMul', 'int'],
  ['greenMul', 'GreenMul', 'int'],
  ['blueMul', 'BlueMul', 'int'],
  ['groundBasis', 'GroundBasis', 'bool'],
  ['minDistanceForSpread', 'MinDistanceForSpread', 'int'],
  ['isFriendlyHomingMissile', 'IsFriendlyHomingMissile', 'bool'],
  ['isBoomerang', 'IsBoomerang', 'bool'],
  ['canHitAgainAfterBounce', 'CanHitAgainAfterBounce', 'bool'],
  ['isHomingMissile', 'IsHomingMissile', 'bool'],
  ['blockUltiCharge', 'BlockUltiCharge', 'bool'],
  ['poisonType', 'PoisonType', 'int'],
  ['travelType', 'TravelType', 'int'],
  ['steerStrength', 'SteerStrength', 'int'],
  ['steerIgnoreTicks', 'SteerIgnoreTicks', 'int'],
  ['homeDistance', 'HomeDistance', 'int'],
  ['steerLifeTime', 'SteerLifeTime', 'int']
]

module.exports = ProjectileData
