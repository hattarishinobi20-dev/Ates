const LogicData = require('./Helper/LogicData')

class CardData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

CardData.columns = [
  ['name', 'Name', 'string'],
  ['iconSWF', 'IconSWF', 'string'],
  ['iconExportName', 'IconExportName', 'string'],
  ['target', 'Target', 'string'],
  ['lockedForChronos', 'LockedForChronos', 'bool'],
  ['dynamicRarityStartSeason', 'DynamicRarityStartSeason', 'int'],
  ['metaType', 'MetaType', 'int'],
  ['requiresCard', 'RequiresCard', 'string'],
  ['type', 'Type', 'string'],
  ['skill', 'Skill', 'string'],
  ['value', 'Value', 'int'],
  ['value2', 'Value2', 'int'],
  ['value3', 'Value3', 'int'],
  ['rarity', 'Rarity', 'string'],
  ['tid', 'TID', 'string'],
  ['powerNumberTID', 'PowerNumberTID', 'string'],
  ['powerNumber2TID', 'PowerNumber2TID', 'string'],
  ['powerNumber3TID', 'PowerNumber3TID', 'string'],
  ['powerIcon1ExportName', 'PowerIcon1ExportName', 'string'],
  ['powerIcon2ExportName', 'PowerIcon2ExportName', 'string'],
  ['sortOrder', 'SortOrder', 'int'],
  ['dontUpgradeStat', 'DontUpgradeStat', 'bool'],
  ['hideDamageStat', 'HideDamageStat', 'bool']
]

module.exports = CardData
