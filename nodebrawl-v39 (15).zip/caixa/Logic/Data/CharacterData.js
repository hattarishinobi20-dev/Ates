const LogicData = require('./Helper/LogicData')

class CharacterData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }

  isDecoy () {
    return this.type === 'Minion_Mirage'
  }

  isBoss () {
    return this.type === 'Npc_Boss' || this.type === 'Npc_Boss_TownCrush'
  }

  isTrain () {
    return this.type === 'Train'
  }

  isBase () {
    return this.type === 'Pvp_Base'
  }

  isLootBox () {
    return this.type === 'LootBox'
  }

  isTrainingDummy () {
    return this.type === 'Minion_Building_charges_ulti'
  }

  isTownCrushBoss () {
    return this.type === 'Npc_Boss_TownCrush'
  }

  isCarryable () {
    return this.type === 'Carryable'
  }

  isHero () {
    return this.type === 'Hero'
  }

  isPet () {
    return this.pet != null
  }

  isDuplicate () {
    return this.type === 'Minion_Duplicate'
  }

  isPayload () {
    return this.type === 'Payload'
  }

  hasAutoAttack () {
    return this.autoAttackDamage > 0
  }

  hasVeryMuchHitPoints () {
    return this.hitpoints > 5799
  }
}

CharacterData.columns = [
  ['name', 'Name', 'string'],
  ['lockedForChronos', 'LockedForChronos', 'bool'],
  ['disabled', 'Disabled', 'bool'],
  ['itemName', 'ItemName', 'string'],
  ['weaponSkill', 'WeaponSkill', 'string'],
  ['ultimateSkill', 'UltimateSkill', 'string'],
  ['pet', 'Pet', 'string'],
  ['speed', 'Speed', 'int'],
  ['hitpoints', 'Hitpoints', 'int'],
  ['meleeAutoAttackSplashDamage', 'MeleeAutoAttackSplashDamage', 'bool'],
  ['autoAttackSpeedMs', 'AutoAttackSpeedMs', 'int'],
  ['autoAttackDamage', 'AutoAttackDamage', 'int'],
  ['autoAttackBulletsPerShot', 'AutoAttackBulletsPerShot', 'int'],
  ['autoAttackMode', 'AutoAttackMode', 'string'],
  ['autoAttackProjectileSpread', 'AutoAttackProjectileSpread', 'int'],
  ['autoAttackProjectile', 'AutoAttackProjectile', 'string'],
  ['autoAttackRange', 'AutoAttackRange', 'int'],
  ['regeneratePerSecond', 'RegeneratePerSecond', 'int'],
  ['ultiChargeMul', 'UltiChargeMul', 'int'],
  ['ultiChargeUltiMul', 'UltiChargeUltiMul', 'int'],
  ['type', 'Type', 'string'],
  ['damagerPercentFromAliens', 'DamagerPercentFromAliens', 'int'],
  ['defaultSkin', 'DefaultSkin', 'string'],
  ['fileName', 'FileName', 'string'],
  ['blueExportName', 'BlueExportName', 'string'],
  ['redExportName', 'RedExportName', 'string'],
  ['shadowExportName', 'ShadowExportName', 'string'],
  ['areaEffect', 'AreaEffect', 'string'],
  ['deathAreaEffect', 'DeathAreaEffect', 'string'],
  ['takeDamageEffect', 'TakeDamageEffect', 'string'],
  ['deathEffect', 'DeathEffect', 'string'],
  ['moveEffect', 'MoveEffect', 'string'],
  ['reloadEffect', 'ReloadEffect', 'string'],
  ['outOfAmmoEffect', 'OutOfAmmoEffect', 'string'],
  ['dryFireEffect', 'DryFireEffect', 'string'],
  ['spawnEffect', 'SpawnEffect', 'string'],
  ['meleeHitEffect', 'MeleeHitEffect', 'string'],
  ['autoAttackStartEffect', 'AutoAttackStartEffect', 'string'],
  ['boneEffect1', 'BoneEffect1', 'string'],
  ['boneEffect2', 'BoneEffect2', 'string'],
  ['boneEffect3', 'BoneEffect3', 'string'],
  ['boneEffect4', 'BoneEffect4', 'string'],
  ['boneEffectUse', 'BoneEffectUse', 'string'],
  ['loopedEffect', 'LoopedEffect', 'string'],
  ['loopedEffect2', 'LoopedEffect2', 'string'],
  ['killCelebrationSoundVO', 'KillCelebrationSoundVO', 'string'],
  ['inLeadCelebrationSoundVO', 'InLeadCelebrationSoundVO', 'string'],
  ['startSoundVO', 'StartSoundVO', 'string'],
  ['useUltiSoundVO', 'UseUltiSoundVO', 'string'],
  ['takeDamageSoundVO', 'TakeDamageSoundVO', 'string'],
  ['deathSoundVO', 'DeathSoundVO', 'string'],
  ['attackSoundVO', 'AttackSoundVO', 'string'],
  ['attackStartEffectOffset', 'AttackStartEffectOffset', 'int'],
  ['twoWeaponAttackEffectOffset', 'TwoWeaponAttackEffectOffset', 'int'],
  ['shadowScaleX', 'ShadowScaleX', 'int'],
  ['shadowScaleY', 'ShadowScaleY', 'int'],
  ['shadowX', 'ShadowX', 'int'],
  ['shadowY', 'ShadowY', 'int'],
  ['shadowSkew', 'ShadowSkew', 'int'],
  ['scale', 'Scale', 'int'],
  ['heroScreenScale', 'HeroScreenScale', 'int'],
  ['fitToBoxScale', 'FitToBoxScale', 'int'],
  ['endScreenScale', 'EndScreenScale', 'int'],
  ['gatchaScreenScale', 'GatchaScreenScale', 'int'],
  ['homeScreenScale', 'HomeScreenScale', 'int'],
  ['heroScreenXOffset', 'HeroScreenXOffset', 'int'],
  ['heroScreenZOffset', 'HeroScreenZOffset', 'int'],
  ['collisionRadius', 'CollisionRadius', 'int'],
  ['healthBar', 'HealthBar', 'string'],
  ['healthBarOffsetY', 'HealthBarOffsetY', 'int'],
  ['flyingHeight', 'FlyingHeight', 'int'],
  ['projectileStartZ', 'ProjectileStartZ', 'int'],
  ['stopMovementAfterMS', 'StopMovementAfterMS', 'int'],
  ['waitMS', 'WaitMS', 'int'],
  ['tid', 'TID', 'string'],
  ['forceAttackAnimationToEnd', 'ForceAttackAnimationToEnd', 'bool'],
  ['iconSWF', 'IconSWF', 'string'],
  ['iconExportName', 'IconExportName', 'string'],
  ['recoilAmount', 'RecoilAmount', 'int'],
  ['homeworld', 'Homeworld', 'string'],
  ['footstepClip', 'FootstepClip', 'string'],
  ['differentFootstepOffset', 'DifferentFootstepOffset', 'int'],
  ['footstepIntervalMS', 'FootstepIntervalMS', 'int'],
  ['attackingWeaponScale', 'AttackingWeaponScale', 'int'],
  ['useThrowingLeftWeaponBoneScaling', 'UseThrowingLeftWeaponBoneScaling', 'bool'],
  ['useThrowingRightWeaponBoneScaling', 'UseThrowingRightWeaponBoneScaling', 'bool'],
  ['commonSetUpgradeBonus', 'CommonSetUpgradeBonus', 'int'],
  ['rareSetUpgradeBonus', 'RareSetUpgradeBonus', 'int'],
  ['superRareSetUpgradeBonus', 'SuperRareSetUpgradeBonus', 'int'],
  ['canWalkOverWater', 'CanWalkOverWater', 'bool'],
  ['manualRotations', 'ManualRotations', 'bool'],
  ['hasPowerLevels', 'HasPowerLevels', 'bool'],
  ['useColorMod', 'UseColorMod', 'bool'],
  ['redAdd', 'RedAdd', 'int'],
  ['greenAdd', 'GreenAdd', 'int'],
  ['blueAdd', 'BlueAdd', 'int'],
  ['redMul', 'RedMul', 'int'],
  ['greenMul', 'GreenMul', 'int'],
  ['blueMul', 'BlueMul', 'int'],
  ['chargeUltiAutomatically', 'ChargeUltiAutomatically', 'int'],
  ['videoLink', 'VideoLink', 'string'],
  ['shouldEncodePetStatus', 'ShouldEncodePetStatus', 'bool'],
  ['secondaryPet', 'SecondaryPet', 'bool'],
  ['extraMinions', 'ExtraMinions', 'int'],
  ['petAutoSpawnDelay', 'PetAutoSpawnDelay', 'int'],
  ['offenseRating', 'OffenseRating', 'int'],
  ['defenseRating', 'DefenseRating', 'int'],
  ['utilityRating', 'UtilityRating', 'int']
]

module.exports = CharacterData
