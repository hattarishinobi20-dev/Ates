const LogicData = require('./Helper/LogicData')

class MilestoneData extends LogicData {
  constructor (row, dataTable) {
    super(row, dataTable)

    this.loadData(this, row)
  }
}

MilestoneData.columns = [
  ['name', 'Name', 'string'],
  ['type', 'Type', 'int'],
  ['index', 'Index', 'int'],
  ['progressStart', 'ProgressStart', 'int'],
  ['progress', 'Progress', 'int'],
  ['league', 'League', 'int'],
  ['tier', 'Tier', 'int'],
  ['season', 'Season', 'int'],
  ['seasonEndRewardKeys', 'SeasonEndRewardKeys', 'int'],
  ['primaryLvlUpRewardType', 'PrimaryLvlUpRewardType', 'int'],
  ['primaryLvlUpRewardCount', 'PrimaryLvlUpRewardCount', 'int'],
  ['primaryLvlUpRewardExtraData', 'PrimaryLvlUpRewardExtraData', 'int'],
  ['primaryLvlUpRewardData', 'PrimaryLvlUpRewardData', 'string'],
  ['secondaryLvlUpRewardType', 'SecondaryLvlUpRewardType', 'int'],
  ['secondaryLvlUpRewardCount', 'SecondaryLvlUpRewardCount', 'int'],
  ['secondaryLvlUpRewardExtraData', 'SecondaryLvlUpRewardExtraData', 'int'],
  ['secondaryLvlUpRewardData', 'SecondaryLvlUpRewardData', 'string']
]

module.exports = MilestoneData
