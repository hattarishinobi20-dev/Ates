const net = require('net')
const MessageFactory = require('./Protocol/MessageFactory')
const Program = require('./Server/Program')
const Connection = require('./Server/Networking/Connection')
const Connections = require('./Server/Networking/Connections')
const server = new net.Server()
const Messages = new MessageFactory()

Program.start()

const PORT = 9339

server.on('connection', async (client) => {
  client.setNoDelay(true)
  client.log = function (text) {
    return console.log(`[${this.remoteAddress.split(':').slice(-1)}] >> ${text}`)
  }

  client.log('A wild connection appeard!')
  
  const packets = Messages.getPackets();

  client.connection = new Connection(client)
  Connections.addConnection(client.connection)

  client.on('data', async (data) => {
    const messages = client.connection.messaging.onReceive(data)
    if (messages == null) {
      client.log('Invalid message length, closing connection.')
      client.connection.onDisconnect()
      return
    }

    for (const message of messages) {
      if (packets.indexOf(String(message.id)) !== -1) {
        try {
          const packet = new (Messages.handle(message.id))(message.payload, client)

          client.log(`Gotcha ${message.id} (${packet.constructor.name}) packet! `)

          await packet.decode()
          await packet.process()
        } catch (e) {
          console.log(e)
        }
      } else {
        client.log(`Gotcha undefined ${message.id} packet!`)
      }
    }
  })

  client.on('end', async () => {
    return client.log('Client disconnected.')
  })

  client.on('close', async () => {
    client.connection.onDisconnect()
  })

  client.on('error', async error => {
    try {
      client.log('A wild error!')
      console.log(error)
      client.destroy()
    } catch (e) { }
  })
})

server.once('listening', () => console.log(`[SERVER] >> Server started on ${PORT} port!`))
server.listen(PORT)


process.on("uncaughtException", e => console.log(e));

process.on("unhandledRejection", e => console.log(e));
