const Debugger = require('../Debug/Debugger')
const LogicLong = require('../Math/LogicLong')

class ChecksumEncoder {
  constructor () {
    this.checksum = 0
    this.snapshotChecksum = 0
    this.enabled = true
  }

  enableCheckSum (enable) {
    if (!this.enabled || enable) {
      if (!this.enabled && enable) {
        this.checksum = this.snapshotChecksum
      }

      this.enabled = enable
    } else {
      this.snapshotChecksum = this.checksum
      this.enabled = false
    }
  }

  resetCheckSum () {
    this.checksum = 0
  }

  rotateRight (value, count) {
    return ((value >>> count) | (value << (32 - count))) >>> 0
  }

  writeBoolean (value) {
    this.checksum = ((value ? 13 : 7) + this.rotateRight(this.checksum, 31)) >>> 0
    return value
  }

  writeByte (value) {
    this.checksum = ((value & 0xFF) + this.rotateRight(this.checksum, 31) + 11) >>> 0
  }

  writeShort (value) {
    this.checksum = (((value << 16) >> 16) + this.rotateRight(this.checksum, 31) + 19) >>> 0
  }

  writeInt (value) {
    this.checksum = ((value | 0) + this.rotateRight(this.checksum, 31) + 9) >>> 0
  }

  writeVInt (value) {
    this.checksum = ((value | 0) + this.rotateRight(this.checksum, 31) + 33) >>> 0
  }

  writeLong (value) {
    LogicLong.from(value).encode(this)
  }

  writeVLong (value) {
    const logicLong = LogicLong.from(value)
    this.writeVInt(logicLong.getHigherInt())
    this.writeVInt(logicLong.getLowerInt())
  }

  writeBytes (value, length) {
    this.checksum = (((value != null ? length + 28 : 27) + (this.checksum >>> 31)) | (this.checksum << 1)) >>> 0
  }

  writeString (value) {
    this.checksum = ((value != null ? value.length + 28 : 27) + this.rotateRight(this.checksum, 31)) >>> 0
  }

  writeStringReference (value) {
    if (value == null) value = ''
    this.checksum = (value.length + this.rotateRight(this.checksum, 31) + 38) >>> 0
  }

  hashCode () {
    Debugger.error('ChecksumEncoder hashCode not designed')
    return 42
  }

  isCheckSumEnabled () {
    return this.enabled
  }

  isCheckSumOnlyMode () {
    return true
  }

  equals (encoder) {
    if (encoder != null) {
      let checksum = encoder.checksum
      let checksum2 = this.checksum

      if (!encoder.enabled) {
        checksum = encoder.snapshotChecksum
      }

      if (!this.enabled) {
        checksum2 = this.snapshotChecksum
      }

      return checksum === checksum2
    }

    return false
  }

  getCheckSum () {
    return this.checksum | 0
  }
}

module.exports = ChecksumEncoder
