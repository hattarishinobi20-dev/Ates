const ChecksumEncoder = require('./ChecksumEncoder')
const LogicLong = require('../Math/LogicLong')

class ByteStream extends ChecksumEncoder {
  constructor (data = 10, length) {
    super()

    this.bitOffset = 0
    this.offset = 0

    if (Buffer.isBuffer(data)) {
      this.buffer = data
      this.length = length != null ? length : data.length
    } else {
      this.buffer = Buffer.alloc(data)
      this.length = 0
    }
  }

  ensureReadable (count) {
    if (count < 0 || this.offset + count > this.buffer.length) {
      throw new RangeError(`ByteStream: trying to read ${count} bytes at offset ${this.offset}, buffer length is ${this.buffer.length}`)
    }
  }

  getLength () {
    if (this.offset < this.length) {
      return this.length
    }

    return this.offset
  }

  getOffset () {
    return this.offset
  }

  isAtEnd () {
    return this.offset >= this.length
  }

  clear (capacity) {
    this.buffer = Buffer.alloc(capacity)
    this.offset = 0
    this.bitOffset = 0
  }

  getByteArray () {
    return this.buffer
  }

  getBytes () {
    return this.buffer.subarray(0, this.offset)
  }

  readBoolean () {
    if (this.bitOffset === 0) {
      this.ensureReadable(1)
      ++this.offset
    }

    const value = (this.buffer[this.offset - 1] & (1 << this.bitOffset)) !== 0
    this.bitOffset = (this.bitOffset + 1) & 7
    return value
  }

  readByte () {
    this.bitOffset = 0
    this.ensureReadable(1)
    return this.buffer[this.offset++]
  }

  readShort () {
    this.bitOffset = 0
    this.ensureReadable(2)

    const value = (this.buffer[this.offset] << 8) | this.buffer[this.offset + 1]
    this.offset += 2
    return (value << 16) >> 16
  }

  readInt () {
    this.bitOffset = 0
    this.ensureReadable(4)

    const value = this.buffer.readInt32BE(this.offset)
    this.offset += 4
    return value
  }

  readVInt () {
    this.bitOffset = 0
    let value = 0
    let byteValue = this.readVIntByte()

    if ((byteValue & 0x40) !== 0) {
      value |= byteValue & 0x3F

      if ((byteValue & 0x80) !== 0) {
        value |= ((byteValue = this.readVIntByte()) & 0x7F) << 6

        if ((byteValue & 0x80) !== 0) {
          value |= ((byteValue = this.readVIntByte()) & 0x7F) << 13

          if ((byteValue & 0x80) !== 0) {
            value |= ((byteValue = this.readVIntByte()) & 0x7F) << 20

            if ((byteValue & 0x80) !== 0) {
              value |= ((byteValue = this.readVIntByte()) & 0x7F) << 27
              return (value | 0x80000000) | 0
            }

            return (value | 0xF8000000) | 0
          }

          return (value | 0xFFF00000) | 0
        }

        return (value | 0xFFFFE000) | 0
      }

      return (value | 0xFFFFFFC0) | 0
    }

    value |= byteValue & 0x3F

    if ((byteValue & 0x80) !== 0) {
      value |= ((byteValue = this.readVIntByte()) & 0x7F) << 6

      if ((byteValue & 0x80) !== 0) {
        value |= ((byteValue = this.readVIntByte()) & 0x7F) << 13

        if ((byteValue & 0x80) !== 0) {
          value |= ((byteValue = this.readVIntByte()) & 0x7F) << 20

          if ((byteValue & 0x80) !== 0) {
            value |= ((byteValue = this.readVIntByte()) & 0x7F) << 27
          }
        }
      }
    }

    return value | 0
  }

  readVIntByte () {
    this.ensureReadable(1)
    return this.buffer[this.offset++]
  }

  readLong () {
    const high = this.readInt()
    const low = this.readInt()
    return new LogicLong(high, low)
  }

  readVLong () {
    const high = this.readVInt()
    const low = this.readVInt()
    return new LogicLong(high, low)
  }

  readBytesLength () {
    return this.readInt()
  }

  readBytes (length, maxCapacity) {
    this.bitOffset = 0

    if (length <= -1) {
      return null
    }

    if (length <= maxCapacity) {
      this.ensureReadable(length)
      const array = Buffer.from(this.buffer.subarray(this.offset, this.offset + length))
      this.offset += length
      return array
    }

    return null
  }

  readString (maxCapacity = 9000000) {
    const length = this.readBytesLength()

    if (length <= -1) {
      return null
    }

    if (length <= maxCapacity) {
      this.ensureReadable(length)
      const value = this.buffer.toString('utf8', this.offset, this.offset + length)
      this.offset += length
      return value
    }

    return null
  }

  readStringReference (maxCapacity = 9000000) {
    const length = this.readBytesLength()

    if (length <= -1) {
      return ''
    }

    if (length <= maxCapacity) {
      this.ensureReadable(length)
      const value = this.buffer.toString('utf8', this.offset, this.offset + length)
      this.offset += length
      return value
    }

    return ''
  }

  writeBoolean (value) {
    if (this.bitOffset === 0) {
      this.ensureCapacity(1)
      this.buffer[this.offset++] = 0
    }

    if (value) {
      this.buffer[this.offset - 1] |= (1 << this.bitOffset)
    }

    this.bitOffset = (this.bitOffset + 1) & 7
    return value
  }

  writeByte (value) {
    this.ensureCapacity(1)
    this.bitOffset = 0
    this.buffer[this.offset++] = value & 0xFF
  }

  writeShort (value) {
    this.ensureCapacity(2)
    this.bitOffset = 0
    this.buffer[this.offset++] = (value >> 8) & 0xFF
    this.buffer[this.offset++] = value & 0xFF
  }

  writeLongLong128 (value) {
    const big = BigInt(value)
    this.writeIntToByteArray(Number(BigInt.asUintN(32, big)))
    this.writeIntToByteArray(Number(BigInt.asUintN(32, big >> 32n)))
    this.writeIntToByteArray(Number(BigInt.asUintN(32, big >> 64n)))
    this.writeIntToByteArray(Number(BigInt.asUintN(32, big >> 96n)))
  }

  writeInt (value) {
    this.ensureCapacity(4)
    this.bitOffset = 0
    this.buffer[this.offset++] = (value >> 24) & 0xFF
    this.buffer[this.offset++] = (value >> 16) & 0xFF
    this.buffer[this.offset++] = (value >> 8) & 0xFF
    this.buffer[this.offset++] = value & 0xFF
  }

  writeVInt (value) {
    value |= 0
    this.ensureCapacity(5)
    this.bitOffset = 0

    const b = this.buffer

    if (value >= 0) {
      if (value >= 64) {
        if (value >= 0x2000) {
          if (value >= 0x100000) {
            if (value >= 0x8000000) {
              b[this.offset++] = (value & 0x3F) | 0x80
              b[this.offset++] = ((value >> 6) & 0x7F) | 0x80
              b[this.offset++] = ((value >> 13) & 0x7F) | 0x80
              b[this.offset++] = ((value >> 20) & 0x7F) | 0x80
              b[this.offset++] = (value >> 27) & 0xF
            } else {
              b[this.offset++] = (value & 0x3F) | 0x80
              b[this.offset++] = ((value >> 6) & 0x7F) | 0x80
              b[this.offset++] = ((value >> 13) & 0x7F) | 0x80
              b[this.offset++] = (value >> 20) & 0x7F
            }
          } else {
            b[this.offset++] = (value & 0x3F) | 0x80
            b[this.offset++] = ((value >> 6) & 0x7F) | 0x80
            b[this.offset++] = (value >> 13) & 0x7F
          }
        } else {
          b[this.offset++] = (value & 0x3F) | 0x80
          b[this.offset++] = (value >> 6) & 0x7F
        }
      } else {
        b[this.offset++] = value & 0x3F
      }
    } else {
      if (value <= -0x40) {
        if (value <= -0x2000) {
          if (value <= -0x100000) {
            if (value <= -0x8000000) {
              b[this.offset++] = (value & 0x3F) | 0xC0
              b[this.offset++] = ((value >> 6) & 0x7F) | 0x80
              b[this.offset++] = ((value >> 13) & 0x7F) | 0x80
              b[this.offset++] = ((value >> 20) & 0x7F) | 0x80
              b[this.offset++] = (value >> 27) & 0xF
            } else {
              b[this.offset++] = (value & 0x3F) | 0xC0
              b[this.offset++] = ((value >> 6) & 0x7F) | 0x80
              b[this.offset++] = ((value >> 13) & 0x7F) | 0x80
              b[this.offset++] = (value >> 20) & 0x7F
            }
          } else {
            b[this.offset++] = (value & 0x3F) | 0xC0
            b[this.offset++] = ((value >> 6) & 0x7F) | 0x80
            b[this.offset++] = (value >> 13) & 0x7F
          }
        } else {
          b[this.offset++] = (value & 0x3F) | 0xC0
          b[this.offset++] = (value >> 6) & 0x7F
        }
      } else {
        b[this.offset++] = (value & 0x3F) | 0x40
      }
    }
  }

  writeIntToByteArray (value) {
    this.ensureCapacity(4)
    this.bitOffset = 0
    this.buffer[this.offset++] = (value >> 24) & 0xFF
    this.buffer[this.offset++] = (value >> 16) & 0xFF
    this.buffer[this.offset++] = (value >> 8) & 0xFF
    this.buffer[this.offset++] = value & 0xFF
  }

  writeLong (value) {
    const logicLong = LogicLong.from(value)
    this.writeIntToByteArray(logicLong.getHigherInt())
    this.writeIntToByteArray(logicLong.getLowerInt())
  }

  writeLongLE (value) {
    const logicLong = LogicLong.from(value)
    this.writeIntToByteArray(logicLong.getLowerInt())
    this.writeIntToByteArray(logicLong.getHigherInt())
  }

  writeBytes (value, length) {
    if (value == null) {
      this.writeIntToByteArray(-1)
    } else {
      if (length == null) length = value.length
      this.ensureCapacity(length + 4)
      this.writeIntToByteArray(length)
      Buffer.from(value).copy(this.buffer, this.offset, 0, length)
      this.offset += length
    }
  }

  writeBytesWithoutLength (value, length) {
    if (value != null) {
      if (length == null) length = value.length
      this.ensureCapacity(length)
      Buffer.from(value).copy(this.buffer, this.offset, 0, length)
      this.offset += length
    }
  }

  writeString (value) {
    if (value == null) {
      this.writeIntToByteArray(-1)
    } else {
      const bytes = Buffer.from(String(value), 'utf8')
      const length = bytes.length

      if (length <= 900000) {
        this.ensureCapacity(length + 4)
        this.writeIntToByteArray(length)
        bytes.copy(this.buffer, this.offset)
        this.offset += length
      } else {
        this.writeIntToByteArray(-1)
      }
    }
  }

  writeStringReference (value) {
    const bytes = Buffer.from(value == null ? '' : String(value), 'utf8')
    const length = bytes.length

    if (length <= 900000) {
      this.ensureCapacity(length + 4)
      this.writeIntToByteArray(length)
      bytes.copy(this.buffer, this.offset)
      this.offset += length
    } else {
      this.writeIntToByteArray(-1)
    }
  }

  setByteArray (buffer, length) {
    this.offset = 0
    this.bitOffset = 0
    this.buffer = buffer
    this.length = length != null ? length : buffer.length
  }

  resetOffset () {
    this.offset = 0
    this.bitOffset = 0
  }

  setOffset (offset) {
    this.offset = offset
    this.bitOffset = 0
  }

  removeByteArray () {
    const byteArray = this.buffer
    this.buffer = null
    return byteArray
  }

  ensureCapacity (capacity) {
    const bufferLength = this.buffer.length

    if (this.offset + capacity > bufferLength) {
      const tmpBuffer = Buffer.alloc(bufferLength + capacity + 100)
      this.buffer.copy(tmpBuffer, 0, 0, bufferLength)
      this.buffer = tmpBuffer
    }
  }

  isCheckSumOnlyMode () {
    return false
  }

  destruct () {
    this.buffer = null
    this.bitOffset = 0
    this.length = 0
    this.offset = 0
  }
}

module.exports = ByteStream
