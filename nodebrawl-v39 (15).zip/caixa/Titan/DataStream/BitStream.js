class BitStream {
  constructor (data = 10, length) {
    this.offset = 0
    this.bitOffset = 0

    if (Buffer.isBuffer(data)) {
      this.buffer = data
      this.length = length != null ? length : data.length
    } else {
      this.buffer = Buffer.alloc(data)
      this.length = data
    }
  }

  getLength () {
    if (this.length > this.offset) {
      return this.length
    }

    return this.offset
  }

  readBit () {
    if (this.offset >= this.buffer.length) {
      return 0
    }

    const value = (this.buffer[this.offset] >> this.bitOffset) & 1
    this.bitOffset++

    if (this.bitOffset === 8) {
      this.bitOffset = 0
      this.offset += 1
    }

    return value
  }

  readBytes (length) {
    const data = []

    for (let i = 0; i < length;) {
      let value = 0

      for (let p = 0; p < 8 && i < length; p++, i++) {
        value |= (this.readBit() << p)
      }

      data.push(value & 0xFF)
    }

    return data
  }

  readPositiveInt (bitsCount) {
    const bytes = this.readBytes(bitsCount)

    if (bytes.length === 1) {
      return bytes[0]
    }

    if (bytes.length === 2) {
      return bytes[0] | (bytes[1] << 8)
    }

    if (bytes.length === 3) {
      return bytes[0] | (bytes[1] << 8) | (bytes[2] << 16)
    }

    if (bytes.length === 4) {
      return bytes[0] | (bytes[1] << 8) | (bytes[2] << 16) | (bytes[3] << 24)
    }

    return -1
  }

  readInt (bits) {
    const v2 = 2 * this.readPositiveInt(1) - 1
    return v2 * this.readPositiveInt(bits)
  }

  readIntMax32767 () {
    return this.readInt(15)
  }

  readPositiveVIntMax255 () {
    const v2 = this.readPositiveInt(3)
    return this.readPositiveInt(v2)
  }

  readPositiveIntMax15 () {
    return this.readPositiveInt(4)
  }

  readPositiveIntMax32767 () {
    return this.readPositiveInt(15)
  }

  readBoolean () {
    return this.readPositiveInt(1) === 1
  }

  writeBit (data) {
    if (this.bitOffset === 0) {
      this.offset += 1
      this.writeByte(0xFF)
    }

    let value = this.buffer[this.offset - 1]
    value &= ~(1 << this.bitOffset)
    value |= ((data & 1) << this.bitOffset)
    this.buffer[this.offset - 1] = value & 0xFF
    this.bitOffset = (this.bitOffset + 1) % 8
  }

  writeBits (bits, count) {
    let position = 0

    for (let i = 0; i < count;) {
      for (let p = 0; p < 8 && i < count; i++, p++) {
        this.writeBit((bits[position] >> p) & 1)
      }

      position++
    }
  }

  writePositiveInt (value, bits) {
    const bytes = Buffer.alloc(4)
    bytes.writeInt32LE(value | 0)
    this.writeBits(bytes, Math.min(bits, 32))
  }

  writePositiveIntMax1 (value) {
    this.writePositiveInt(value, 1)
  }

  writePositiveIntMax3 (value) {
    this.writePositiveInt(value, 2)
  }

  writePositiveIntMax7 (value) {
    this.writePositiveInt(value, 3)
  }

  writePositiveIntMax15 (value) {
    this.writePositiveInt(value, 4)
  }

  writePositiveIntMax31 (value) {
    this.writePositiveInt(value, 5)
  }

  writePositiveIntMax63 (value) {
    this.writePositiveInt(value, 6)
  }

  writePositiveIntMax127 (value) {
    this.writePositiveInt(value, 7)
  }

  writePositiveIntMax255 (value) {
    this.writePositiveInt(value, 8)
  }

  writePositiveIntMax511 (value) {
    this.writePositiveInt(value, 9)
  }

  writePositiveIntMax1023 (value) {
    this.writePositiveInt(value, 10)
  }

  writePositiveIntMax2047 (value) {
    this.writePositiveInt(value, 11)
  }

  writePositiveIntMax4095 (value) {
    this.writePositiveInt(value, 12)
  }

  writePositiveIntMax8191 (value) {
    this.writePositiveInt(value, 13)
  }

  writePositiveIntMax16383 (value) {
    this.writePositiveInt(value, 14)
  }

  writePositiveIntMax32767 (value) {
    this.writePositiveInt(value, 15)
  }

  writePositiveIntMax65535 (value) {
    this.writePositiveInt(value, 16)
  }

  writePositiveIntMax131071 (value) {
    this.writePositiveInt(value, 17)
  }

  writePositiveIntMax262143 (value) {
    this.writePositiveInt(value, 18)
  }

  writePositiveIntMax524287 (value) {
    this.writePositiveInt(value, 19)
  }

  writePositiveIntMax1048575 (value) {
    this.writePositiveInt(value, 20)
  }

  writePositiveIntMax2097151 (value) {
    this.writePositiveInt(value, 21)
  }

  writePositiveIntMax4194303 (value) {
    this.writePositiveInt(value, 22)
  }

  writeBoolean (value) {
    if (value) {
      this.writePositiveInt(1, 1)
    } else {
      this.writePositiveInt(0, 1)
    }

    return value
  }

  writeInt (value, bits) {
    let val = value

    if (val <= -1) {
      this.writePositiveInt(0, 1)
      val = -value
    } else {
      this.writePositiveInt(1, 1)
      val = value
    }

    this.writePositiveInt(val, bits)
  }

  writeIntMax1 (value) {
    this.writeInt(value, 1)
  }

  writeIntMax3 (value) {
    this.writeInt(value, 2)
  }

  writeIntMax7 (value) {
    this.writeInt(value, 3)
  }

  writeIntMax15 (value) {
    this.writeInt(value, 4)
  }

  writeIntMax31 (value) {
    this.writeInt(value, 5)
  }

  writeIntMax63 (value) {
    this.writeInt(value, 6)
  }

  writeIntMax127 (value) {
    this.writeInt(value, 7)
  }

  writeIntMax2047 (value) {
    this.writeInt(value, 11)
  }

  writeIntMax16383 (value) {
    this.writeInt(value, 14)
  }

  writeIntMax1023 (value) {
    this.writeInt(value, 10)
  }

  writeIntMax65535 (value) {
    this.writeInt(value, 16)
  }

  writePositiveVInt (value, bits) {
    let v3 = 1
    const v7 = value < 0 ? 0 : value

    if (v7 !== 0) {
      let v8 = v7
      v3 = 0

      do {
        v3 += 1
        v8 >>>= 1
      } while (v8 !== 0)
    }

    this.writePositiveInt(v3 - 1, bits)
    this.writePositiveInt(v7, v3)
  }

  writePositiveVIntMax255OftenZero (value) {
    if (value === 0) {
      this.writePositiveInt(1, 1)
      return
    }

    this.writePositiveInt(0, 1)
    this.writePositiveVInt(value, 3)
  }

  writePositiveVIntMax65535OftenZero (value) {
    if (value === 0) {
      this.writePositiveInt(1, 1)
      return
    }

    this.writePositiveInt(0, 1)
    this.writePositiveVInt(value, 4)
  }

  writePositiveVIntMax65535 (value) {
    this.writePositiveVInt(value, 4)
  }

  writePositiveVIntMax255 (value) {
    this.writePositiveVInt(value, 3)
  }

  writeByte (value) {
    this.ensureCapacity(1)
    this.bitOffset = 0
    this.buffer[this.offset - 1] = value & 0xFF
  }

  ensureCapacity (capacity) {
    const bufferLength = this.buffer.length

    if (this.offset + capacity > bufferLength) {
      const tmpBuffer = Buffer.alloc(bufferLength + capacity)
      this.buffer.copy(tmpBuffer, 0, 0, bufferLength)
      this.buffer = tmpBuffer
    }
  }

  getByteArray () {
    return this.buffer
  }

  getBytes () {
    return this.buffer.subarray(0, this.offset)
  }

  writePositiveVIntOftenZero (v1, v2) {
    if (v1 === 0) {
      this.writePositiveInt(1, 1)
      return
    }

    this.writePositiveInt(0, 1)
    this.writePositiveVInt(v1, v2)
  }
}

module.exports = BitStream
