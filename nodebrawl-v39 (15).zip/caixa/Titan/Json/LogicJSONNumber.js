const { LogicJSONNode, LogicJSONNodeType } = require('./LogicJSONNode')

class LogicJSONNumber extends LogicJSONNode {
  constructor (value = 0) {
    super()
    this.value = value | 0
  }

  getIntValue () {
    return this.value
  }

  setIntValue (value) {
    this.value = value | 0
  }

  getJSONNodeType () {
    return LogicJSONNodeType.NUMBER
  }

  writeToString (builder) {
    builder.push(String(this.value))
  }
}

module.exports = LogicJSONNumber
