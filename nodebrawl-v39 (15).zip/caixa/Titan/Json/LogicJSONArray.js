const { LogicJSONNode, LogicJSONNodeType } = require('./LogicJSONNode')

class LogicJSONArray extends LogicJSONNode {
  constructor () {
    super()
    this.items = []
  }

  get (idx) {
    return this.items[idx]
  }

  add (item) {
    this.items.push(item)
  }

  getJSONArray (index) {
    const node = this.items[index]

    if (node == null || node.getJSONNodeType() !== LogicJSONNodeType.ARRAY) {
      return null
    }

    return node
  }

  getJSONBoolean (index) {
    const node = this.items[index]

    if (node == null || node.getJSONNodeType() !== LogicJSONNodeType.BOOLEAN) {
      return null
    }

    return node
  }

  getJSONNumber (index) {
    const node = this.items[index]

    if (node == null || node.getJSONNodeType() !== LogicJSONNodeType.NUMBER) {
      return null
    }

    return node
  }

  getJSONObject (index) {
    const node = this.items[index]

    if (node == null || node.getJSONNodeType() !== LogicJSONNodeType.OBJECT) {
      return null
    }

    return node
  }

  getJSONString (index) {
    const node = this.items[index]

    if (node == null || node.getJSONNodeType() !== LogicJSONNodeType.STRING) {
      return null
    }

    return node
  }

  size () {
    return this.items.length
  }

  getJSONNodeType () {
    return LogicJSONNodeType.ARRAY
  }

  writeToString (builder) {
    builder.push('[')

    for (let i = 0; i < this.items.length; i++) {
      if (i > 0) {
        builder.push(',')
      }

      this.items[i].writeToString(builder)
    }

    builder.push(']')
  }
}

module.exports = LogicJSONArray
