const LogicJSONNodeType = {
  ARRAY: 1,
  OBJECT: 2,
  NUMBER: 3,
  STRING: 4,
  BOOLEAN: 5,
  NULL: 6,
}

class LogicJSONNode {
  getJSONNodeType () {
    return 0
  }

  writeToString (builder) {

  }
}

module.exports = { LogicJSONNode, LogicJSONNodeType }
