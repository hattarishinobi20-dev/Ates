const Debugger = require('../Debug/Debugger')
const LogicJSONArray = require('./LogicJSONArray')
const LogicJSONBoolean = require('./LogicJSONBoolean')
const LogicJSONNull = require('./LogicJSONNull')
const LogicJSONNumber = require('./LogicJSONNumber')
const LogicJSONObject = require('./LogicJSONObject')
const LogicJSONString = require('./LogicJSONString')

class CharStream {
  constructor (str) {
    this.string = str
    this.offset = 0
  }

  read (length) {
    if (length === undefined) {
      if (this.offset >= this.string.length) {
        return '\0'
      }

      return this.string[this.offset++]
    }

    if (this.offset + length > this.string.length) {
      return null
    }

    const str = this.string.substr(this.offset, length)
    this.offset += length
    return str
  }

  nextChar () {
    if (this.offset >= this.string.length) {
      return '\0'
    }

    return this.string[this.offset]
  }

  skipWhitespace () {
    while (this.offset < this.string.length && this.string[this.offset] <= ' ') {
      this.offset++
    }
  }
}

class LogicJSONParser {
  static createJSONString (root) {
    const builder = []
    root.writeToString(builder)
    return builder.join('')
  }

  static writeString (value, builder) {
    builder.push('"')

    if (value != null && value.length > 0) {
      for (let i = 0; i < value.length; i++) {
        const charValue = value[i]

        if (charValue <= '\r' && charValue >= '\b') {
          switch (charValue) {
            case '\b':
              builder.push('\\b')
              break
            case '\t':
              builder.push('\\t')
              break
            case '\n':
              builder.push('\\n')
              break
            case '\f':
              builder.push('\\f')
              break
            case '\r':
              builder.push('\\r')
              break
            default:
              builder.push(charValue)
              break
          }
        } else {
          switch (charValue) {
            case '"':
              builder.push('\\"')
              break
            case '/':
              builder.push('\\/')
              break
            case '\\':
              builder.push('\\\\')
              break
            default:
              builder.push(charValue)
              break
          }
        }
      }
    }

    builder.push('"')
  }

  static parseError (error) {
    Debugger.warning('JSON Parse error: ' + error)
  }

  static parse (json) {
    return LogicJSONParser.parseValue(new CharStream(json))
  }

  static parseValue (stream) {
    stream.skipWhitespace()

    const charValue = stream.nextChar()
    let node = null

    switch (charValue) {
      case '{':
        node = LogicJSONParser.parseObjectStream(stream)
        break
      case '[':
        node = LogicJSONParser.parseArrayStream(stream)
        break
      case 'n':
        node = LogicJSONParser.parseNull(stream)
        break
      case 'f':
      case 't':
        node = LogicJSONParser.parseBoolean(stream)
        break
      case '"':
        node = LogicJSONParser.parseString(stream)
        break
      case '-':
        node = LogicJSONParser.parseNumber(stream)
        break
      default:
        if (charValue >= '0' && charValue <= '9') {
          node = LogicJSONParser.parseNumber(stream)
        } else {
          LogicJSONParser.parseError('Not of any recognized value: ' + charValue)
        }

        break
    }

    return node
  }

  static parseArray (json) {
    return LogicJSONParser.parseArrayStream(new CharStream(json))
  }

  static parseArrayStream (stream) {
    stream.skipWhitespace()

    if (stream.read() !== '[') {
      LogicJSONParser.parseError('Not an array')
      return null
    }

    const jsonArray = new LogicJSONArray()

    stream.skipWhitespace()

    let nextChar = stream.nextChar()

    if (nextChar !== '\0') {
      if (nextChar === ']') {
        stream.read()
        return jsonArray
      }

      while (true) {
        const node = LogicJSONParser.parseValue(stream)

        if (node == null) {
          break
        }

        jsonArray.add(node)
        stream.skipWhitespace()

        nextChar = stream.read()

        if (nextChar !== ',') {
          if (nextChar === ']') {
            return jsonArray
          }

          break
        }
      }
    }

    LogicJSONParser.parseError('Not an array')
    return null
  }

  static parseObject (json) {
    return LogicJSONParser.parseObjectStream(new CharStream(json))
  }

  static parseObjectStream (stream) {
    stream.skipWhitespace()

    if (stream.read() !== '{') {
      LogicJSONParser.parseError('Not an object')
      return null
    }

    const jsonObject = new LogicJSONObject()

    stream.skipWhitespace()

    let nextChar = stream.nextChar()

    if (nextChar !== '\0') {
      if (nextChar === '}') {
        stream.read()
        return jsonObject
      }

      while (true) {
        const key = LogicJSONParser.parseString(stream)

        if (key == null) {
          break
        }

        stream.skipWhitespace()

        nextChar = stream.read()

        if (nextChar !== ':') {
          break
        }

        const node = LogicJSONParser.parseValue(stream)

        if (node == null) {
          break
        }

        jsonObject.put(key.getStringValue(), node)
        stream.skipWhitespace()

        nextChar = stream.read()

        if (nextChar !== ',') {
          if (nextChar === '}') {
            return jsonObject
          }

          break
        }

        stream.skipWhitespace()

        if (stream.nextChar() === '}') {
          stream.read()
          return jsonObject
        }
      }
    }

    LogicJSONParser.parseError('Not an object')
    return null
  }

  static parseString (stream) {
    stream.skipWhitespace()

    if (stream.read() !== '"') {
      LogicJSONParser.parseError('Not a string')
      return null
    }

    const builder = []

    while (true) {
      let nextChar = stream.read()

      if (nextChar === '\0') {
        LogicJSONParser.parseError('Not a string')
        return null
      }

      if (nextChar === '"') {
        break
      }

      if (nextChar === '\\') {
        nextChar = stream.read()

        switch (nextChar) {
          case 'n':
            nextChar = '\n'
            break
          case 'r':
            nextChar = '\r'
            break
          case 't':
            nextChar = '\t'
            break
          case 'u': {
            const hex = stream.read(4)

            if (hex == null || !/^[0-9a-fA-F]{4}$/.test(hex)) {
              LogicJSONParser.parseError('Not a string')
              return null
            }

            nextChar = String.fromCharCode(parseInt(hex, 16))
            break
          }
          case 'b':
            nextChar = '\b'
            break
          case 'f':
            nextChar = '\f'
            break
          case '\0':
            LogicJSONParser.parseError('Not a string')
            return null
        }
      }

      builder.push(nextChar)
    }

    return new LogicJSONString(builder.join(''))
  }

  static parseBoolean (stream) {
    stream.skipWhitespace()

    const nextChar = stream.read()

    if (nextChar === 'f') {
      if (stream.read() === 'a' && stream.read() === 'l' && stream.read() === 's' && stream.read() === 'e') {
        return new LogicJSONBoolean(false)
      }
    } else if (nextChar === 't') {
      if (stream.read() === 'r' && stream.read() === 'u' && stream.read() === 'e') {
        return new LogicJSONBoolean(true)
      }
    }

    LogicJSONParser.parseError('Not a boolean')
    return null
  }

  static parseNull (stream) {
    stream.skipWhitespace()

    const nextChar = stream.read()

    if (nextChar === 'n') {
      if (stream.read() === 'u' && stream.read() === 'l' && stream.read() === 'l') {
        return new LogicJSONNull()
      }
    }

    LogicJSONParser.parseError('Not a null')
    return null
  }

  static parseNumber (stream) {
    stream.skipWhitespace()

    let nextChar = stream.nextChar()
    let multiplier = 1

    if (nextChar === '-') {
      multiplier = -1
      stream.read()
      nextChar = stream.nextChar()
    }

    if (nextChar < '0' || nextChar > '9') {
      LogicJSONParser.parseError('Not a number')
      return null
    }

    let value = 0

    while ((nextChar = stream.nextChar()) <= '9' && nextChar >= '0') {
      stream.read()
      value = (nextChar.charCodeAt(0) - 48 + Math.imul(10, value)) | 0
    }

    if (nextChar === 'e' || nextChar === 'E' || nextChar === '.') {
      LogicJSONParser.parseError('JSON floats not supported')
      return null
    }

    return new LogicJSONNumber(Math.imul(value, multiplier))
  }
}

module.exports = LogicJSONParser
