const { LogicJSONNode, LogicJSONNodeType } = require('./LogicJSONNode')

class LogicJSONString extends LogicJSONNode {
  constructor (value) {
    super()
    this.value = value
  }

  getStringValue () {
    return this.value
  }

  setStringValue (value) {
    this.value = value
  }

  getJSONNodeType () {
    return LogicJSONNodeType.STRING
  }

  writeToString (builder) {
    require('./LogicJSONParser').writeString(this.value, builder)
  }
}

module.exports = LogicJSONString
