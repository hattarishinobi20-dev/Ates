const { LogicJSONNode, LogicJSONNodeType } = require('./LogicJSONNode')

class LogicJSONObject extends LogicJSONNode {
  constructor () {
    super()
    this.keys = []
    this.items = []
  }

  destruct () {
    this.keys = null
    this.items = null
  }

  get (key) {
    const itemIndex = this.keys.indexOf(key)

    if (itemIndex === -1) {
      return null
    }

    return this.items[itemIndex]
  }

  getJSONArray (key) {
    const node = this.get(key)

    if (node != null && node.getJSONNodeType() === LogicJSONNodeType.ARRAY) {
      return node
    }

    return null
  }

  getJSONBoolean (key) {
    const node = this.get(key)

    if (node != null && node.getJSONNodeType() === LogicJSONNodeType.BOOLEAN) {
      return node
    }

    return null
  }

  getJSONNumber (key) {
    const node = this.get(key)

    if (node != null && node.getJSONNodeType() === LogicJSONNodeType.NUMBER) {
      return node
    }

    return null
  }

  getJSONObject (key) {
    const node = this.get(key)

    if (node != null && node.getJSONNodeType() === LogicJSONNodeType.OBJECT) {
      return node
    }

    return null
  }

  getJSONString (key) {
    const node = this.get(key)

    if (node != null && node.getJSONNodeType() === LogicJSONNodeType.STRING) {
      return node
    }

    return null
  }

  put (key, item) {
    if (this.keys.indexOf(key) !== -1) {
      return
    }

    if (this.items.indexOf(item) !== -1) {
      return
    }

    this.items.push(item)
    this.keys.push(key)
  }

  remove (key) {
    const keyIndex = this.keys.indexOf(key)

    if (keyIndex !== -1) {
      this.keys.splice(keyIndex, 1)
      this.items.splice(keyIndex, 1)
    }
  }

  getObjectCount () {
    return this.items.length
  }

  getJSONNodeType () {
    return LogicJSONNodeType.OBJECT
  }

  writeToString (builder) {
    const LogicJSONParser = require('./LogicJSONParser')

    builder.push('{')

    for (let i = 0; i < this.items.length; i++) {
      if (i > 0) {
        builder.push(',')
      }

      LogicJSONParser.writeString(this.keys[i], builder)
      builder.push(':')
      this.items[i].writeToString(builder)
    }

    builder.push('}')
  }
}

module.exports = LogicJSONObject
