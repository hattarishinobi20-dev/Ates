class Debugger {
  static listener = null

  static setListener (listener) {
    this.listener = listener
  }

  static print (log) {
    if (this.listener) this.listener.print(log)
  }

  static warning (log) {
    if (this.listener) this.listener.warning(log)
  }

  static error (log) {
    if (this.listener) this.listener.error(log)
  }

  static doAssert (assertion, assertionError) {
    if (!assertion) {
      this.error(assertionError)
    }

    return assertion
  }
}

module.exports = Debugger
