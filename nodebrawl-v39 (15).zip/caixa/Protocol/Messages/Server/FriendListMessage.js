const GameMessage = require('../../../Logic/Message/GameMessage')

class FriendListMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20105
    this.version = 0
    this.friends = []
  }

  encode () {
    this.writeInt(0)
    this.writeBoolean(true)
    this.writeInt(this.friends.length)
    for (const friend of this.friends) {
      friend.encode(this)
    }
  }

  getServiceNodeType () {
    return 3
  }
}

module.exports = FriendListMessage
