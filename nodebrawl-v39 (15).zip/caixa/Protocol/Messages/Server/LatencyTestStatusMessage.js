const GameMessage = require('../../../Logic/Message/GameMessage')

class LatencyTestStatusMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 29003
    this.version = 0
    this.ping = 0
  }

  encode () {
    this.writeVInt(1)
    for (let i = 0; i < 1; i++) {
      this.writeVInt(0)
      this.writeVInt(this.ping)
      this.writeVInt(0)
      this.writeVInt(0)
      this.writeInt(2)
      this.writeInt(1)
      this.writeInt(0)
      this.writeString('localhost')
      this.writeInt(1)
      this.writeVInt(1)
    }
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = LatencyTestStatusMessage
