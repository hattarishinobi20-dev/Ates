const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class TeamGameStartingMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24130
    this.version = 0
    this.slot = 0
    this.locationId = 0
  }

  encode () {
    this.writeVInt(0)
    this.writeVInt(0)
    ByteStreamHelper.writeDataReference(this, this.locationId)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamGameStartingMessage
