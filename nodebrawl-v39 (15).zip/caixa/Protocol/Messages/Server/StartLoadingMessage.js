const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class StartLoadingMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20559
    this.version = 0
    this.players = []
    this.ownIndex = 0
    this.teamIndex = 0
    this.locationId = 0
    this.gameMode = 0
    this.spectateMode = 0
  }

  encode () {
    this.writeInt(this.players.length)
    this.writeInt(this.ownIndex)
    this.writeInt(this.teamIndex)
    this.writeInt(this.players.length)
    for (const player of this.players) {
      player.encode(this)
    }
    this.writeInt(0)
    this.writeInt(0)
    this.writeInt(0)
    this.writeVInt(this.gameMode)
    this.writeVInt(1)
    this.writeVInt(1)
    this.writeBoolean(true)
    this.writeVInt(this.spectateMode)
    this.writeVInt(0)
    ByteStreamHelper.writeDataReference(this, this.locationId)
    this.writeBoolean(false)
  }

  getServiceNodeType () {
    return 4
  }
}

module.exports = StartLoadingMessage
