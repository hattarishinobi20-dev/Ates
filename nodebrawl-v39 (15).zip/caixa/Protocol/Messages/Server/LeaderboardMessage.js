const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class LeaderboardMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24403
    this.version = 0
    this.leaderboardType = 1
    this.charachterId = 0
    this.avatars = []
    this.brawlers = []
    this.allianceList = []
    this.ownAvatarId = 0
    this.region = null
  }

  encode () {
    let playerIndex = 0

    this.writeVInt(this.leaderboardType)
    this.writeVInt(2)
    ByteStreamHelper.writeDataReference(this, this.charachterId)
    this.writeString(this.region)

    if (this.leaderboardType === 1 || this.leaderboardType === 0 || this.leaderboardType === 3) {
      const list = this.leaderboardType === 0 ? this.brawlers : this.avatars
      this.writeVInt(list.length)
      list.forEach(([home, avatar], index) => {
        if (avatar.accountId === this.ownAvatarId) {
          playerIndex = index + 1
        }

        this.writeVLong(avatar.accountId)

        this.writeVInt(1)
        if (this.leaderboardType === 1) {
          this.writeVInt(avatar.trophies)
          this.writeVInt(1)
        } else if (this.leaderboardType === 0) {
          const hero = avatar.getHero(this.charachterId)
          this.writeVInt(hero != null ? hero.trophies : 0)
          this.writeVInt(1)
        } else {
          this.writeVInt(22)
          this.writeVInt(3)
        }

        this.writeString(avatar.allianceName)

        this.writeString(avatar.name != null ? avatar.name : 'Brawler')
        this.writeVInt(100)
        this.writeVInt(home.thumbnailId)
        this.writeVInt(home.nameColorId)
        this.writeVInt(home.hasPremiumPass || home.nameColorId === 43000012 ? home.nameColorId : 0)
        this.writeVInt(0)
      })
    } else if (this.leaderboardType === 2) {
      this.writeVInt(this.allianceList.length)
      for (const alliance of this.allianceList) {
        this.writeVLong(alliance.id)

        this.writeVInt(1)
        this.writeVInt(alliance.trophies)

        this.writeVInt(2)

        this.writeString(alliance.name)
        this.writeVInt(alliance.members.length)
        ByteStreamHelper.writeDataReference(this, alliance.allianceBadgeId)
      }
    } else {
      this.writeVInt(0)
    }

    this.writeVInt(0)
    this.writeVInt(playerIndex)
    this.writeVInt(0)
    this.writeVInt(0)
    this.writeString('US')
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = LeaderboardMessage
