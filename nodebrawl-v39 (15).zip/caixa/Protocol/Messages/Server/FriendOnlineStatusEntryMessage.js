const GameMessage = require('../../../Logic/Message/GameMessage')

class FriendOnlineStatusEntryMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24555
    this.version = 0
    this.avatarId = 0
    this.playerStatus = 0
  }

  encode () {
    this.writeLong(this.avatarId)
    if (this.writeBoolean(this.playerStatus >= 0)) {
      this.writeLong(this.avatarId)
      this.writeVInt(this.playerStatus)
      this.writeVInt(0)
      this.writeBoolean(false)
      this.writeBoolean(false)
    }
  }

  getServiceNodeType () {
    return 3
  }
}

module.exports = FriendOnlineStatusEntryMessage
