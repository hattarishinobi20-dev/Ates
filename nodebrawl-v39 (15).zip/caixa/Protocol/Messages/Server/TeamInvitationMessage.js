const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamInvitationMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24589
    this.version = 0
    this.unknown = 0
    this.teamId = 0
    this.friendEntry = null
  }

  encode () {
    this.writeVInt(this.unknown)
    this.writeLong(this.teamId)
    this.friendEntry.encode(this)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamInvitationMessage
