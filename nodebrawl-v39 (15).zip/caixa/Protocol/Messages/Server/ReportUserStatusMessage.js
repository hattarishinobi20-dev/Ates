const GameMessage = require('../../../Logic/Message/GameMessage')

class ReportUserStatusMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20117
    this.version = 0
    this.status = 0
  }

  encode () {
    this.writeInt(this.status)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = ReportUserStatusMessage
