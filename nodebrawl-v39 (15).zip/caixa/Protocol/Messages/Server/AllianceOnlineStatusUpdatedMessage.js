const GameMessage = require('../../../Logic/Message/GameMessage')

class AllianceOnlineStatusUpdatedMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20207
    this.version = 0
    this.avatarId = 0
    this.playerStatus = 0
    this.members = 0
  }

  encode () {
    this.writeVInt(this.members)
    this.writeVInt(1)
    this.writeLong(this.avatarId)
    this.writeVInt(this.playerStatus)
  }

  getServiceNodeType () {
    return 3
  }
}

module.exports = AllianceOnlineStatusUpdatedMessage
