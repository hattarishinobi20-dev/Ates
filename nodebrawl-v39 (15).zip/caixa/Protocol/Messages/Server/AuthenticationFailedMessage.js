const GameMessage = require('../../../Logic/Message/GameMessage')

class AuthenticationFailedMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20103
    this.version = 0
    this.errorCode = 0
    this.fingerprintSha = null
    this.message = null
    this.updateUrl = null
    this.contentUrl = null
  }

  encode () {
    this.writeInt(this.errorCode)
    this.writeString(this.fingerprintSha)
    this.writeString(null)
    this.writeString(this.contentUrl)
    this.writeString(this.updateUrl)
    this.writeString(this.message)
    this.writeInt(-1)
    this.writeBoolean(false)
    for (let i = 0; i < 9; i++) {
      this.writeInt(0)
    }
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = AuthenticationFailedMessage
