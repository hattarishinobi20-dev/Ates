const GameMessage = require('../../../Logic/Message/GameMessage')

class SyncSSIDResponce extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 21000
    this.version = 0
    this.requests = new Map()
    this.recAccs = new Map()
  }

  encode () {
    this.writeInt(this.requests.size)
    for (const [key, value] of this.requests) {
      this.writeString(key)
      this.writeString(value)
    }
    this.writeInt(this.recAccs.size)
    for (const [key, value] of this.recAccs) {
      this.writeString(key)
      this.writeString(value[0])
      this.writeString(value[1])
    }
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = SyncSSIDResponce
