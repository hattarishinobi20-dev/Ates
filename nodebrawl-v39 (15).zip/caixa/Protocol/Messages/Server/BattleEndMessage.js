const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class BattleEndMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 23456
    this.version = 0
    this.result = 0
    this.tokensReward = 0
    this.trophiesReward = 0
    this.doubledTokensReward = 0
    this.tokenDoublersLeft = 0
    this.experienceReward = 0
    this.experience = 0
    this.milestoneReward = 0
    this.starExperienceReward = 0
    this.pp = []
    this.progressiveQuests = []
    this.ownPlayer = null
    this.starToken = false
    this.underdogTrophies = 0
    this.powerPlayScoreGained = 0
    this.powerPlayEpicScoreGained = 0
    this.milestoneRewards = []
    this.gameMode = 0
    this.hasNoTokens = false
    this.isPvP = false
    this.isPowerPlay = false
  }

  encode () {
    this.writeInt(0)
    this.writeInt(0)
    this.writeInt(0)
    this.writeInt(0)

    this.writeVInt(this.gameMode)
    this.writeVInt(this.result)
    this.writeVInt(this.tokensReward)
    this.writeVInt(this.trophiesReward)
    this.writeVInt(this.powerPlayScoreGained)
    this.writeVInt(this.doubledTokensReward)
    this.writeVInt(0)
    this.writeVInt(this.tokenDoublersLeft)
    this.writeVInt(0)
    this.writeVInt(this.powerPlayEpicScoreGained)
    this.writeVInt(0)

    this.writeBoolean(false)
    this.writeVInt(0)
    this.writeVInt(0)
    this.writeBoolean(false)
    this.writeVInt(0)
    this.writeVInt(0)
    this.writeVInt(0)
    this.writeVInt(0)
    this.writeVInt(0)

    this.writeBoolean(false)
    this.writeBoolean(false)
    this.writeBoolean(false)
    this.writeBoolean(false)
    this.writeBoolean(false)
    this.writeBoolean(false)
    this.writeBoolean(false)
    this.writeBoolean(this.isPvP)
    this.writeVInt(-1)
    this.writeBoolean(false)

    this.writeVInt(this.pp.length)
    for (const player of this.pp) {
      const isOwn = player.accountId === this.ownPlayer.accountId
      this.writeBoolean(isOwn)
      this.writeBoolean(player.teamIndex !== this.ownPlayer.teamIndex)
      this.writeBoolean(player.isStarplayer)

      ByteStreamHelper.writeDataReference(this, player.characterId)
      ByteStreamHelper.writeDataReference(this, player.skinId)

      this.writeVInt(player.trophies)
      this.writeVInt(player.powerPlayScore)
      this.writeVInt(player.heroPowerLevel + 1)
      this.writeVInt(0)
      this.writeBoolean(isOwn)
      if (isOwn) {
        this.writeLong(player.accountId)
      }

      player.displayData.encode(this)

      this.writeBoolean(false)
    }

    this.writeVInt(2)
    this.writeVInt(0)
    this.writeVInt(this.experienceReward)
    this.writeVInt(8)
    this.writeVInt(this.starExperienceReward)

    this.writeVInt(this.milestoneRewards.length)
    for (const award of this.milestoneRewards) {
      ByteStreamHelper.writeDataReference(this, award)
    }

    this.writeVInt(2)
    this.writeVInt(1)
    this.writeVInt(this.ownPlayer.trophies)
    this.writeVInt(this.ownPlayer.highestTrophies)
    this.writeVInt(5)
    this.writeVInt(this.experience)
    this.writeVInt(this.experience)

    ByteStreamHelper.writeDataReference(this, 28000000)

    this.writeBoolean(false)

    this.writeBoolean(this.progressiveQuests.length > 0)
    if (this.progressiveQuests.length > 0) {
      this.writeVInt(this.progressiveQuests.length)
      for (const quest of this.progressiveQuests) {
        quest.encode(this)
      }
    }

    this.writeBoolean(false)

    this.writeVInt(0)
    this.writeVInt(0)

    this.writeBoolean(false)
    this.writeVInt(0)
    this.writeBoolean(false)
  }

  getServiceNodeType () {
    return 27
  }
}

module.exports = BattleEndMessage
