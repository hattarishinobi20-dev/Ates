const GameMessage = require('../../../Logic/Message/GameMessage')

class DisconnectedMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 25892
    this.version = 0
    this.reason = 0
  }

  encode () {
    this.writeInt(this.reason)
  }

  decode () {
    this.reason = this.readInt()
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = DisconnectedMessage
