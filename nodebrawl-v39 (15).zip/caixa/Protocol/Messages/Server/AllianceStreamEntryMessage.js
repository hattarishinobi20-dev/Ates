const GameMessage = require('../../../Logic/Message/GameMessage')

class AllianceStreamEntryMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24312
    this.version = 0
    this.entry = null
  }

  encode () {
    this.entry.encode(this)
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = AllianceStreamEntryMessage
