const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24124
    this.version = 0
    this.team = null
  }

  encode () {
    this.team.encode(this)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamMessage
