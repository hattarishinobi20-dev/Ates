const GameMessage = require('../../../Logic/Message/GameMessage')

class MatchMakingCancelledMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20406
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = MatchMakingCancelledMessage
