const GameMessage = require('../../../Logic/Message/GameMessage')

class ShutdownStartedMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20161
    this.version = 0
  }

  encode () {
    this.writeInt(0)
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = ShutdownStartedMessage
