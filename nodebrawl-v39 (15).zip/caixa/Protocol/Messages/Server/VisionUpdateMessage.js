const GameMessage = require('../../../Logic/Message/GameMessage')

class VisionUpdateMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24109
    this.version = 0
    this.tick = 0
    this.handledInputs = 0
    this.viewers = 0
    this.visionBitStream = null
  }

  encode () {
    this.writeVInt(this.tick)
    this.writeVInt(this.handledInputs)
    this.writeVInt(0)
    this.writeVInt(this.viewers)
    this.writeBoolean(false)
    this.writeBytes(this.visionBitStream.getByteArray(), this.visionBitStream.getLength())
  }

  getServiceNodeType () {
    return 4
  }
}

module.exports = VisionUpdateMessage
