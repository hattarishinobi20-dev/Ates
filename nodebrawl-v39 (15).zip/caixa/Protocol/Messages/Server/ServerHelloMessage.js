const crypto = require('crypto')
const GameMessage = require('../../../Logic/Message/GameMessage')

class ServerHelloMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20100
    this.version = 0
    this.serverHelloToken = null
    this.serversc = 0
  }

  encode () {
    if (this.serverHelloToken == null) {
      const messaging = this.client.connection.messaging
      messaging.serversc = crypto.randomInt(1, 256)
      this.serversc = messaging.serversc
      this.setServerHelloToken(messaging.sessionToken)
    }

    this.writeByte(this.serverHelloToken[23])
    this.writeByte(this.serversc)
    this.writeBytes(this.serverHelloToken, 22)
    this.writeBytes(Buffer.from('Hi :)', 'ascii'), 5)
  }

  setServerHelloToken (token) {
    this.serverHelloToken = token
  }

  removeServerHelloToken () {
    const token = this.serverHelloToken
    this.serverHelloToken = null
    return token
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = ServerHelloMessage
