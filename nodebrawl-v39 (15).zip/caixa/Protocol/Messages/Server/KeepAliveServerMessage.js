const GameMessage = require('../../../Logic/Message/GameMessage')

class KeepAliveServerMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 20108
    this.version = 0
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = KeepAliveServerMessage
