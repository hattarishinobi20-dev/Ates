const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamErrorMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 24129
    this.version = 0
    this.reason = 0
  }

  encode () {
    this.writeInt(this.reason)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamErrorMessage
