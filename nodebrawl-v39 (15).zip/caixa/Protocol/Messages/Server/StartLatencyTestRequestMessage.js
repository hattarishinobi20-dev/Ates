const GameMessage = require('../../../Logic/Message/GameMessage')

class StartLatencyTestRequestMessage extends GameMessage {
  constructor (client) {
    super(null, client)
    this.id = 29001
    this.version = 0
  }

  encode () {
    for (let i = 0; i < 13; i++) {
      this.writeInt(0)
    }
    this.writeVInt(1)
    for (let i = 0; i < 9; i++) {
      this.writeInt(0)
    }
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = StartLatencyTestRequestMessage
