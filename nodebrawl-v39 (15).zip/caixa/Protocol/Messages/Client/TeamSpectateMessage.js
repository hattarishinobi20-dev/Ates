const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamSpectateMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14358
    this.version = 0
    this.teamId = 0
  }

  decode () {
    this.teamId = this.readVLong().toNumber()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamSpectateMessage
