const GameMessage = require('../../../Logic/Message/GameMessage')

class AskForJoinableAllianceListMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14303
    this.version = 0
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = AskForJoinableAllianceListMessage
