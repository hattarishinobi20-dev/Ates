const GameMessage = require('../../../Logic/Message/GameMessage')

class ChangeAllianceMemberRoleMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14306
    this.version = 0
    this.accountId = 0
    this.role = 0
  }

  decode () {
    this.accountId = this.readLong().toNumber()
    this.role = this.readVInt()
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = ChangeAllianceMemberRoleMessage
