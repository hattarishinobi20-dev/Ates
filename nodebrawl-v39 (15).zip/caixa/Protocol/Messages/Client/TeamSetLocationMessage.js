const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class TeamSetLocationMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14363
    this.version = 0
    this.locid = 0
    this.customModifiers = []
  }

  decode () {
    try {
      this.locid = ByteStreamHelper.readDataReference(this)
      this.customModifiers = ByteStreamHelper.readIntList(this, 30)
    } catch (e) {
      this.customModifiers = []
    }
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamSetLocationMessage
