const GameMessage = require('../../../Logic/Message/GameMessage')

class PlayerStatusMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14366
    this.version = 0
  }

  decode () {
    this.status = this.readVInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = PlayerStatusMessage
