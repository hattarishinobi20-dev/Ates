const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class TeamPremadeChatMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14369
    this.version = 0
    this.messageDataId = 0
    this.targetId = -1
    this.unknown1 = 0
    this.unknown2 = 0
  }

  decode () {
    this.messageDataId = ByteStreamHelper.readDataReference(this)
    if (this.readBoolean()) {
      this.targetId = this.readLong().toNumber()
    }
    this.unknown1 = this.readVInt()
    this.unknown2 = this.readVInt()
    if (!this.isAtEnd()) {
      this.readVInt()
    }
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamPremadeChatMessage
