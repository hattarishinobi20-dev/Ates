const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamInvitationResponseMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14479
    this.version = 0
    this.response = 0
    this.teamId = 0
    this.mutePlayer = false
  }

  decode () {
    this.response = this.readVInt()
    this.teamId = this.readLong().toNumber()
    this.mutePlayer = this.readBoolean()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamInvitationResponseMessage
