const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamInviteMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14365
    this.version = 0
    this.avatarId = 0
    this.team = 0
  }

  decode () {
    this.avatarId = this.readVLong().toNumber()
    this.team = this.readVInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamInviteMessage
