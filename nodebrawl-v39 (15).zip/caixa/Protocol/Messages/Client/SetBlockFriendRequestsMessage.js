const GameMessage = require('../../../Logic/Message/GameMessage')

class SetBlockFriendRequestsMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10576
    this.version = 0
    this.state = false
  }

  decode () {
    this.state = this.readBoolean()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = SetBlockFriendRequestsMessage
