const GameMessage = require('../../../Logic/Message/GameMessage')

class RequestDBChanges extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 19998
    this.version = 0
    this.authPass = null
    this.message = null
  }

  decode () {
    this.authPass = this.readString()
    this.message = this.readString()
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = RequestDBChanges
