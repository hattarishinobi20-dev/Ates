const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')
const GlobalId = require('../../../Logic/Data/Helper/GlobalId')

class CreatePlayerMapMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 12100
    this.version = 0
    this.name = null
    this.gmv = 0
    this.pmed = 0
  }

  decode () {
    this.name = this.readString()
    this.gmv = this.readVInt()
    this.pmed = GlobalId.getInstanceId(ByteStreamHelper.readDataReference(this))
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = CreatePlayerMapMessage
