const GameMessage = require('../../../Logic/Message/GameMessage')

class GetPlayerMapsMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 12102
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = GetPlayerMapsMessage
