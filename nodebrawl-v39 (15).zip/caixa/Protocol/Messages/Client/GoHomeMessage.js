const GameMessage = require('../../../Logic/Message/GameMessage')

class GoHomeMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14101
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = GoHomeMessage
