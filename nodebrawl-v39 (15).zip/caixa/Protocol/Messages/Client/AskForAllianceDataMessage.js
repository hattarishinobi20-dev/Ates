const GameMessage = require('../../../Logic/Message/GameMessage')

class AskForAllianceDataMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14302
    this.version = 0
    this.allianceId = 0
  }

  decode () {
    this.allianceId = this.readLong().toNumber()
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = AskForAllianceDataMessage
