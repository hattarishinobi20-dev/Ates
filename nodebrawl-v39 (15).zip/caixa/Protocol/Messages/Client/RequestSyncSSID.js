const GameMessage = require('../../../Logic/Message/GameMessage')

class RequestSyncSSID extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 11000
    this.version = 0
    this.authPass = null
    this.requests = new Map()
    this.disposeRequests = []
  }

  decode () {
    this.requests = new Map()
    this.disposeRequests = []
    this.authPass = this.readString()
    const count = this.readInt()
    for (let x = 0; x < count && this.offset < this.buffer.length; x++) {
      const key = this.readString()
      this.requests.set(key, this.readString())
    }
    const dCount = this.readInt()
    for (let y = 0; y < dCount && this.offset < this.buffer.length; y++) {
      this.disposeRequests.push(this.readString())
    }
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = RequestSyncSSID
