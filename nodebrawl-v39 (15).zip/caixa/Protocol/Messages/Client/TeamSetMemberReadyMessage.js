const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamSetMemberReadyMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14355
    this.version = 0
    this.isReady = false
  }

  decode () {
    this.isReady = this.readBoolean()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamSetMemberReadyMessage
