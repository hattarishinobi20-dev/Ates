const GameMessage = require('../../../Logic/Message/GameMessage')

class TeamMemberStatusMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14361
    this.version = 0
    this.status = 0
  }

  decode () {
    this.status = this.readVInt()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamMemberStatusMessage
