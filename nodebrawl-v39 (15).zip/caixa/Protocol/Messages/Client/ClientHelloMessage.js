const GameMessage = require('../../../Logic/Message/GameMessage')

class ClientHelloMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10100
    this.version = 0
    this.keyVersion = 0
    this.clientSeed = 0
    this.major = 0
  }

  decode () {
    this.readInt()
    this.keyVersion = this.readInt()
    this.major = this.readInt()
    this.clientSeed = this.readInt()
    this.readInt()
    this.readString()
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = ClientHelloMessage
