const GameMessage = require('../../../Logic/Message/GameMessage')

class AvatarNameCheckRequestMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14600
    this.version = 0
    this.name = null
  }

  decode () {
    this.name = this.readString()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = AvatarNameCheckRequestMessage
