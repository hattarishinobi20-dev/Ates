const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class CreateAllianceMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14301
    this.version = 0
    this.name = null
    this.description = null
    this.badgeId = 0
    this.type = 0
    this.requiredTrophies = 0
  }

  decode () {
    this.name = this.readString()
    this.description = this.readString()
    this.badgeId = ByteStreamHelper.readDataReference(this)
    ByteStreamHelper.readDataReference(this)
    this.type = this.readVInt()
    this.requiredTrophies = this.readVInt()
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = CreateAllianceMessage
