const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class TeamSetPlayerMapMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 12110
    this.version = 0
    this.mapid = 0
  }

  decode () {
    this.mapid = ByteStreamHelper.decodeLogicLong(this).toNumber()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = TeamSetPlayerMapMessage
