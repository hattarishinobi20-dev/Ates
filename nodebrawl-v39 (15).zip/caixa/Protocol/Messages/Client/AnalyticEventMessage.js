const GameMessage = require('../../../Logic/Message/GameMessage')

class AnalyticEventMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10110
    this.version = 0
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = AnalyticEventMessage
