const GameMessage = require('../../../Logic/Message/GameMessage')

class GetPlayerProfileMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14113
    this.version = 0
    this.accountId = 0
  }

  decode () {
    this.accountId = this.readLong().toNumber()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = GetPlayerProfileMessage
