const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')

class UpdatePlayerMapMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 12103
    this.version = 0
    this.mapId = 0
    this.mapData = null
  }

  decode () {
    this.mapId = ByteStreamHelper.decodeLogicLong(this).getLowerInt()
    this.mapData = this.readBytes(this.readBytesLength(), 900000)
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = UpdatePlayerMapMessage
