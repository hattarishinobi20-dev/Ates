const GameMessage = require('../../../Logic/Message/GameMessage')

class AskForFriendListMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 10504
    this.version = 0
  }

  getServiceNodeType () {
    return 3
  }
}

module.exports = AskForFriendListMessage
