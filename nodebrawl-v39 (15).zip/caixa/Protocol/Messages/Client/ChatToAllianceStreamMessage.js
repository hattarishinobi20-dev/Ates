const GameMessage = require('../../../Logic/Message/GameMessage')

class ChatToAllianceStreamMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14315
    this.version = 0
    this.message = null
  }

  decode () {
    this.message = this.readString()
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = ChatToAllianceStreamMessage
