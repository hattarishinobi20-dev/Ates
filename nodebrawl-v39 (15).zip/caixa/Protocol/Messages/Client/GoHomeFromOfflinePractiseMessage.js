const GameMessage = require('../../../Logic/Message/GameMessage')

class GoHomeFromOfflinePractiseMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14109
    this.version = 0
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = GoHomeFromOfflinePractiseMessage
