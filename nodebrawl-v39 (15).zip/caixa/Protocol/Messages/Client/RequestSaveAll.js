const GameMessage = require('../../../Logic/Message/GameMessage')

class RequestSaveAll extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 19997
    this.version = 0
    this.authPass = null
  }

  decode () {
    this.authPass = this.readString()
  }

  getServiceNodeType () {
    return 1
  }
}

module.exports = RequestSaveAll
