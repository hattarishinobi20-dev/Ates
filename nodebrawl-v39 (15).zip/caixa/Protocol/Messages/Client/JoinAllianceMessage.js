const GameMessage = require('../../../Logic/Message/GameMessage')

class JoinAllianceMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14305
    this.version = 0
    this.allianceId = 0
  }

  decode () {
    this.allianceId = this.readLong().toNumber()
  }

  getServiceNodeType () {
    return 11
  }
}

module.exports = JoinAllianceMessage
