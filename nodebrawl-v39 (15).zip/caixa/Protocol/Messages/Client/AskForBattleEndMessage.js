const GameMessage = require('../../../Logic/Message/GameMessage')
const ByteStreamHelper = require('../../../Logic/Helper/ByteStreamHelper')
const BattlePlayer = require('../../../Logic/Battle/Structures/BattlePlayer')

class AskForBattleEndMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14110
    this.version = 0
    this.battleResult = 0
    this.rank = 0
    this.locationId = 0
    this.battlePlayersCount = 0
    this.battlePlayers = []
  }

  decode () {
    this.battleResult = this.readVInt()
    this.readVInt()
    this.rank = this.readVInt()
    this.locationId = ByteStreamHelper.readDataReference(this)
    this.battlePlayersCount = this.readVInt()
    if (this.battlePlayersCount < 0 || this.battlePlayersCount > 10) {
      this.battlePlayersCount = 0
    }
    this.battlePlayers = []
    for (let x = 0; x < this.battlePlayersCount; x++) {
      const player = new BattlePlayer()
      player.decode(this)
      this.battlePlayers.push(player)
    }
  }

  getServiceNodeType () {
    return 27
  }
}

module.exports = AskForBattleEndMessage
