const GameMessage = require('../../../Logic/Message/GameMessage')

class SetInvitesBlockedMessage extends GameMessage {
  constructor (bytes, client) {
    super(bytes, client)
    this.id = 14777
    this.version = 0
    this.state = false
  }

  decode () {
    this.state = this.readBoolean()
  }

  getServiceNodeType () {
    return 9
  }
}

module.exports = SetInvitesBlockedMessage
